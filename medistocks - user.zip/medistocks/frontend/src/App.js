import React, { useEffect } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useNavigate,
  Navigate,
} from 'react-router-dom';
import { useSelector } from 'react-redux';
import { createGlobalStyle } from 'styled-components';

// --- Component Imports ---
import SplashScreen from './components/SplashScreen';
import Dashboard from './components/RetailerDashBoard';
import Login from './components/Login';
import Registration from './components/Registration';
import PlanSelection from './components/SelectYourPlan';
import PlanPurchaseScreen from './components/PlanPurchase';
import DocumentUpload from './components/DocumentUpload';
import LiveVerification from './components/LiveVerification';
import VerificationStatus from './components/VerificationStatus';
import ChooseBusiness from './components/ChooseBusiness';
import DisributorDashBoard from './components/DisributorDashBoard';

/**
 * Global Styles
 */
const GlobalStyle = createGlobalStyle`
  body {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif;
    background-color: #f8fafc; /* Light background for consistency */
    color: #111827;
  }
`;

/**
 * Wrapper for the SplashScreen that navigates to the login page after a delay.
 */
function SplashWrapper() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/login');
    }, 3000);
    return () => clearTimeout(timer);
  }, [navigate]);

  return <SplashScreen />;
}

/**
 * Protects routes that require authentication.
 * Redirects to login if the user is not authenticated.
 */
function ProtectedRoute({ children }) {
  const { accessToken } = useSelector((state) => state.auth);

  if (!accessToken) {
    return <Navigate to="/login" replace />;
  }

  return children;
}

/**
 * Redirects authenticated users away from auth pages (like login/register)
 * to their main dashboard based on their role.
 */
function AuthRedirect({ children }) {
  const navigate = useNavigate();
  const { accessToken, role } = useSelector((state) => state.auth);

  useEffect(() => {
    if (accessToken) {
      const target = role === 'distributor' ? '/distributor-dashboard' : '/retailer-dashboard';
      navigate(target, { replace: true });
    }
  }, [accessToken, role, navigate]);

  return children;
}

/**
 * Main application component with routing.
 */
function App() {
  // Effect to load Bootstrap CSS dynamically
  useEffect(() => {
    const link = document.createElement('link');
    link.href = "https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css";
    link.rel = "stylesheet";
    document.head.appendChild(link);
    return () => document.head.removeChild(link);
  }, []);

  return (
    <Router>
      <GlobalStyle />
      <Routes>
        {/* Initial public route */}
        <Route path="/" element={<SplashWrapper />} />

        {/* --- Authentication & Registration Flow --- */}
        <Route path="/login" element={<AuthRedirect><Login /></AuthRedirect>} />
        <Route path="/registration" element={<AuthRedirect><Registration /></AuthRedirect>} />
        <Route path="/select-plan" element={<AuthRedirect><PlanSelection /></AuthRedirect>} />
        <Route path="/plan-purchase" element={<AuthRedirect><PlanPurchaseScreen /></AuthRedirect>} />
        <Route path="/document-upload" element={<AuthRedirect><DocumentUpload /></AuthRedirect>} />
        <Route path="/live-verification" element={<AuthRedirect><LiveVerification /></AuthRedirect>} />
        <Route path="/verification-status" element={<AuthRedirect><VerificationStatus /></AuthRedirect>} />
        <Route path="/choose-business" element={<AuthRedirect><ChooseBusiness /></AuthRedirect>} />

        {/* --- Protected Application Routes --- */}
        <Route
          path="/retailer-dashboard/:section?"
          element={<ProtectedRoute><Dashboard /></ProtectedRoute>}
        />
        <Route
          path="/distributor-dashboard/:section?"
          element={<ProtectedRoute><DisributorDashBoard /></ProtectedRoute>}
        />
        
        {/* Fallback route to redirect any unknown paths to the login page */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
