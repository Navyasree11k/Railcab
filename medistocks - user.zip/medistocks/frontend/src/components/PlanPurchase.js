import React, { useState } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import { FaLock, FaCreditCard } from 'react-icons/fa';
import { SiApplepay } from 'react-icons/si';
import { IoCheckmarkDone } from 'react-icons/io5';
import { RiQrCodeLine } from "react-icons/ri";
import { useNavigate, useLocation } from 'react-router-dom';
import BaseUrl from './BaseUrl';

// --- Global Styles for a consistent theme ---
const GlobalStyle = createGlobalStyle`
  body {
    background-color: #f8fafc; // A light, clean background
  }
`;

// --- Styled Components (Completely Redesigned) ---

const PageWrapper = styled.div`
  display: flex;
  justify-content: center;
  min-height: 100vh;
  padding: 2rem;
  background-color: #f8fafc;
`;

// New: Two-column layout for desktop, stacks on mobile
const PageLayout = styled.div`
  width: 100%;
  max-width: 1100px;
  display: grid;
  grid-template-columns: 1.2fr 1fr;
  gap: 3rem;

  @media (max-width: 992px) {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
`;

const PaymentSection = styled.div`
  display: flex;
  flex-direction: column;
`;

const SummarySection = styled.div`
  // This could be made sticky for a better UX on desktop
  position: sticky;
  top: 2rem;
  height: fit-content;
`;

const Header = styled.div`
  margin-bottom: 2rem;
  text-align: left;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 800;
  color: #111827;
  letter-spacing: -1px;
`;

const ErrorMessage = styled.div`
  background-color: #fef2f2;
  color: #ef4444;
  text-align: center;
  padding: 1rem;
  border-radius: 0.5rem;
  margin-bottom: 1.5rem;
  font-weight: 500;
  border: 1px solid #fca5a5;
`;

const SectionTitle = styled.h2`
  font-size: 1.25rem;
  font-weight: 700;
  color: #1e293b;
  margin-bottom: 1rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid #e2e8f0;
`;

// New: Visually appealing payment method selection
const PaymentMethodGrid = styled.div`
  display: grid;
  gap: 1rem;
`;

const PaymentMethodCard = styled.div`
  display: flex;
  align-items: center;
  padding: 1.25rem;
  border: 2px solid ${({ active }) => active ? '#4f46e5' : '#e2e8f0'};
  border-radius: 0.75rem;
  background-color: #ffffff;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  box-shadow: 0 1px 3px rgba(0,0,0,0.03);

  &:hover {
    border-color: #4f46e5;
  }
`;

const PaymentIcon = styled.div`
  font-size: 1.75rem;
  color: #4f46e5;
  margin-right: 1rem;
`;

const PaymentLabel = styled.span`
  font-size: 1rem;
  font-weight: 600;
  color: #1e293b;
`;

const RadioCircle = styled.div`
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 2px solid ${({ active }) => active ? '#4f46e5' : '#cbd5e1'};
  margin-left: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease-in-out;
`;

const SelectedDot = styled.div`
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: #4f46e5;
`;

// New: A self-contained, clean order summary card
const OrderSummaryCard = styled.div`
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 1rem;
  padding: 1.5rem;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
`;

const PriceDetails = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin: 1.5rem 0;
`;

const PriceRow = styled.div`
  display: flex;
  justify-content: space-between;
  font-size: 1rem;
  color: #475569;
`;

const DiscountRow = styled(PriceRow)`
  color: #16a34a; // Green for discount
`;

const TotalRow = styled(PriceRow)`
  font-weight: 700;
  font-size: 1.25rem;
  color: #1e293b;
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px dashed #cbd5e1;
`;

const CouponInputGroup = styled.div`
  display: flex;
  margin-top: 1.5rem;
`;

const CouponInput = styled.input`
  flex-grow: 1;
  border: 1px solid #cbd5e1;
  padding: 0.75rem;
  border-radius: 0.5rem 0 0 0.5rem;
  outline: none;
  &:focus {
    border-color: #4f46e5;
    box-shadow: 0 0 0 1px #4f46e5;
  }
`;

const ApplyButton = styled.button`
  background-color: #f1f5f9;
  border: 1px solid #cbd5e1;
  border-left: none;
  color: #475569;
  font-weight: 600;
  padding: 0.75rem 1rem;
  border-radius: 0 0.5rem 0.5rem 0;
  cursor: pointer;
  &:hover {
    background-color: #e2e8f0;
  }
`;

const PurchaseButton = styled.button`
  background-color: #4f46e5;
  padding: 1rem;
  border-radius: 0.75rem;
  border: none;
  color: white;
  font-size: 1.1rem;
  font-weight: 600;
  width: 100%;
  cursor: pointer;
  transition: background-color 0.2s;
  &:hover {
    background-color: #4338ca;
  }
  &:disabled {
    background-color: #a5b4fc;
    cursor: not-allowed;
  }
`;

const SecureBox = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 1rem 0;
  color: #64748b;
`;

const spin = keyframes`0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); }`;
const SpinnerOverlay = styled.div`
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background-color: rgba(255, 255, 255, 0.9);
  z-index: 9999; display: flex; flex-direction: column;
  align-items: center; justify-content: center;
`;
const Spinner = styled.div`
  border: 6px solid #e5e7eb; border-top: 6px solid #4f46e5;
  border-radius: 50%; width: 60px; height: 60px;
  animation: ${spin} 1s linear infinite;
`;
const SpinnerText = styled.p`
  margin-top: 1.5rem; font-size: 1rem; color: #111827;
  font-weight: 600;
`;


const PlanPurchaseScreen = () => {
    const [selectedOption, setSelectedOption] = useState('upi');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [statusMessage, setStatusMessage] = useState('');
    const [showSuccessSpinner, setShowSuccessSpinner] = useState(false);

    const navigate = useNavigate();
    const location = useLocation();
    const role = location.state?.role || '';
    const selectedPlan = location.state?.plan || 'gold';

    const plans = {
        silver: { name: 'Silver', price: 999, benefits: ['25 Chat messages/month', 'Static Product Search', '5 Purchase Requests/Day'] },
        gold: { name: 'Gold', price: 1999, benefits: ['50 Chat messages/month', 'Advanced Product Search', '20 Purchase Requests/Day', 'Invoice Generation'] },
        platinum: { name: 'Platinum', price: 3999, benefits: ['Unlimited Chat Messages', 'AI-Powered Search', '24/7 Priority Support', 'Dedicated Account Manager'] },
    };

    const plan = plans[selectedPlan] || plans.gold;
    const userId = localStorage.getItem('user_id');

    // Calculations in paise to avoid floating-point errors
    const discountInRupees = selectedPlan === 'gold' ? 200 : 0;
    const priceInPaise = plan.price * 100;
    const gstInPaise = Math.round(priceInPaise * 0.18);
    const discountInPaise = discountInRupees * 100;
    const totalAmountInPaise = priceInPaise + gstInPaise - discountInPaise;
    
    // Convert to rupees for display only
    const gstInRupees = gstInPaise / 100;
    const totalAmountInRupees = totalAmountInPaise / 100;

    const handlePurchase = async () => {
        setLoading(true); setError(''); setStatusMessage('Initializing payment...');
        if (!window.Razorpay) {
            const script = document.createElement('script');
            script.src = 'https://checkout.razorpay.com/v1/checkout.js';
            script.async = true;
            document.body.appendChild(script);
            await new Promise(resolve => { script.onload = resolve; });
        }
        const options = {
            key: 'rzp_test_RJ8BApOSPnF5hq', // Replace with your actual key
            amount: totalAmountInPaise,
            currency: 'INR',
            name: 'Pharmacy Deals',
            description: `${plan.name} Plan Purchase`,
            handler: async function (response) {
                setStatusMessage('Verifying payment...');
                try {
                    const purchasePayload = {
                        user_id: userId, selected_role: role, selected_plan: plan.name,
                        plan_benefits: plan.benefits, payment_mode: selectedOption, payment_type: 'online',
                        payment_status: 'success', payment_id: response.razorpay_payment_id,
                        payment_summary: {
                            planAmount: plan.price, gst: gstInRupees,
                            discount: discountInRupees, totalAmount: totalAmountInRupees,
                        },
                    };
                    const purchaseResponse = await fetch(`${BaseUrl}/auth/purchase_plan`, {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(purchasePayload),
                    });
                    if (!purchaseResponse.ok) {
                        const errorData = await purchaseResponse.json().catch(() => ({}));
                        throw new Error(errorData.error || 'Failed to confirm payment.');
                    }
                    setShowSuccessSpinner(true);
                    setStatusMessage('Payment successful! Redirecting...');
                    setTimeout(() => navigate('/document-upload'), 2000);
                } catch (err) {
                    setError(err.message);
                    setStatusMessage('');
                } finally {
                    setLoading(false);
                }
            },
            prefill: { contact: '', email: '' },
            theme: { color: '#4f46e5' },
        };
        const rzp = new window.Razorpay(options);
        rzp.open();
        setLoading(false); setStatusMessage('');
    };

    return (
        <>
            <GlobalStyle />
            {showSuccessSpinner && (
                <SpinnerOverlay>
                    <Spinner />
                    <SpinnerText>{statusMessage}</SpinnerText>
                </SpinnerOverlay>
            )}
            <PageWrapper>
                <PageLayout>
                    <PaymentSection>
                        <Header><Title>Complete Your Purchase</Title></Header>
                        {error && <ErrorMessage>{error}</ErrorMessage>}
                        <SectionTitle>Select Payment Method</SectionTitle>
                        <PaymentMethodGrid>
                            <PaymentMethodCard active={selectedOption === 'upi'} onClick={() => setSelectedOption('upi')}>
                                <PaymentIcon><RiQrCodeLine /></PaymentIcon>
                                <PaymentLabel>UPI / QR Code</PaymentLabel>
                                <RadioCircle active={selectedOption === 'upi'}><SelectedDot /></RadioCircle>
                            </PaymentMethodCard>
                            <PaymentMethodCard active={selectedOption === 'card'} onClick={() => setSelectedOption('card')}>
                                <PaymentIcon><FaCreditCard /></PaymentIcon>
                                <PaymentLabel>Credit / Debit Card</PaymentLabel>
                                <RadioCircle active={selectedOption === 'card'}><SelectedDot /></RadioCircle>
                            </PaymentMethodCard>
                            <PaymentMethodCard active={selectedOption === 'netbanking'} onClick={() => setSelectedOption('netbanking')}>
                                <PaymentIcon><SiApplepay /></PaymentIcon>
                                <PaymentLabel>Net Banking</PaymentLabel>
                                <RadioCircle active={selectedOption === 'netbanking'}><SelectedDot /></RadioCircle>
                            </PaymentMethodCard>
                        </PaymentMethodGrid>
                    </PaymentSection>

                    <SummarySection>
                        <OrderSummaryCard>
                            <SectionTitle>Order Summary</SectionTitle>
                            <div className="d-flex justify-content-between align-items-center">
                                <span className="fw-bold fs-5 text-dark">{plan.name} Plan</span>
                                <span className="fw-bold fs-5 text-dark">₹{plan.price}</span>
                            </div>
                            <ul className="list-unstyled text-secondary mt-3 small">
                                {plan.benefits.slice(0, 4).map((benefit) => ( // Show first 4 benefits
                                    <li key={benefit} className="d-flex align-items-center mb-1">
                                        <IoCheckmarkDone color="#16a34a" className="me-2" /> {benefit}
                                    </li>
                                ))}
                            </ul>

                            <PriceDetails>
                                <PriceRow><span>Base Amount</span><span>₹{plan.price.toFixed(2)}</span></PriceRow>
                                <PriceRow><span>GST (18%)</span><span>+ ₹{gstInRupees.toFixed(2)}</span></PriceRow>
                                {discountInRupees > 0 && <DiscountRow><span>Discount</span><span>- ₹{discountInRupees.toFixed(2)}</span></DiscountRow>}
                                <TotalRow><span>Total Amount</span><span>₹{totalAmountInRupees.toFixed(2)}</span></TotalRow>
                            </PriceDetails>

                            <PurchaseButton onClick={handlePurchase} disabled={loading}>
                                {loading ? statusMessage : `Pay ₹${totalAmountInRupees.toFixed(2)}`}
                            </PurchaseButton>
                            
                            <SecureBox>
                                <FaLock size={14} />
                                <span>Secure payments by Razorpay</span>
                            </SecureBox>

                            <CouponInputGroup>
                                <CouponInput placeholder="Enter coupon code" />
                                <ApplyButton>Apply</ApplyButton>
                            </CouponInputGroup>
                        </OrderSummaryCard>
                    </SummarySection>
                </PageLayout>
            </PageWrapper>
        </>
    );
};

export default PlanPurchaseScreen;