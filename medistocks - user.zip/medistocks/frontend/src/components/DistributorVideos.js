import React, { useState } from 'react';
import styled, { keyframes } from 'styled-components';
import { FiPlay, FiX } from 'react-icons/fi';

// --- Keyframes ---
const fadeIn = keyframes`
  from { opacity: 0; }
  to { opacity: 1; }
`;

const slideInUp = keyframes`
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
`;

// --- Mock Data ---
const mockVideos = [
  {
    id: 1,
    title: 'Understanding Drug Expiry Dates',
    thumbnail: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?q=80&w=800&auto=format&fit=crop',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    description: 'A comprehensive guide to understanding and managing drug expiry dates in your pharmacy to ensure patient safety and compliance.'
  },
  {
    id: 2,
    title: 'Best Practices for Inventory Management',
    thumbnail: 'https://images.unsplash.com/photo-1587854692152-cbe660feac88?q=80&w=800&auto=format&fit=crop',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    description: 'Learn the best practices for managing your pharmacy inventory, reducing waste, and optimizing stock levels for maximum profitability.'
  },
  {
    id: 3,
    title: 'How to Use the AI Demand Forecast Feature',
    thumbnail: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?q=80&w=800&auto=format&fit=crop',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    description: 'A step-by-step tutorial on how to leverage the AI Demand Forecast feature to make smarter purchasing decisions.'
  },
  {
    id: 4,
    title: 'Navigating the New Chat Interface',
    thumbnail: 'https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?q=80&w=800&auto=format&fit=crop',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    description: 'A quick tour of our new chat interface, designed to make communication with distributors faster and more efficient.'
  },
];

// --- Styled Components ---
const VideoContainer = styled.div`
  padding: 1rem;
`;

const PlayOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(99, 102, 241, 0.25);
  display: flex;
  justify-content: center;
  align-items: center;
  opacity: 0;
  transition: all 0.3s ease;
  z-index: 2;
  svg {
    color: white;
    filter: drop-shadow(0 4px 12px rgba(0,0,0,0.3));
  }
`;

const Thumbnail = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.5s ease;
`;

const VideoCard = styled.div`
  background: #ffffff;
  border: 1px solid #edf2f7;
  border-radius: 1.25rem;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  height: 100%;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);

  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    border-color: #6366f1;
    
    ${PlayOverlay} { opacity: 1; }
    ${Thumbnail} { transform: scale(1.05); }
  }
`;

const ThumbnailWrapper = styled.div`
  position: relative;
  width: 100%;
  height: 200px;
  overflow: hidden;
  background: #f1f5f9;
`;

const VideoTitle = styled.h3`
  font-size: 1.05rem;
  font-weight: 700;
  color: #1e293b;
  margin: 0;
  line-height: 1.4;
`;

const ModalBackdrop = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(15, 23, 42, 0.85);
  backdrop-filter: blur(10px);
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 1.5rem;
  z-index: 3000;
  animation: ${fadeIn} 0.3s ease-out;
`;

const ModalContent = styled.div`
  background-color: #ffffff;
  border-radius: 1.5rem;
  width: 100%;
  max-width: 950px;
  overflow: hidden;
  position: relative;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
  animation: ${slideInUp} 0.4s cubic-bezier(0.16, 1, 0.3, 1);
`;

const VideoPlayer = styled.video`
  width: 100%;
  aspect-ratio: 16 / 9;
  background-color: #000;
  display: block;
`;

const VideoDescription = styled.div`
  padding: 2.5rem;
  h2 {
    font-size: 1.75rem;
    font-weight: 800;
    color: #0f172a;
    margin-bottom: 1rem;
  }
  p {
    color: #475569;
    font-size: 1.05rem;
    line-height: 1.8;
    margin-bottom: 0;
  }

  @media (max-width: 768px) {
    padding: 1.5rem;
    h2 { font-size: 1.35rem; }
    p { font-size: 0.95rem; }
  }
`;

const CloseIconButton = styled.button`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: #ffffff;
  border: none;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  z-index: 3100;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  transition: all 0.2s ease;
  color: #64748b;

  &:hover {
    transform: rotate(90deg);
    color: #ef4444;
  }
`;

// --- Videos Component ---
const Videos = () => {
  const [selectedVideo, setSelectedVideo] = useState(null);

  const openPlayer = (video) => {
    setSelectedVideo(video);
    document.body.style.overflow = 'hidden';
  };

  const closePlayer = () => {
    setSelectedVideo(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <VideoContainer>
      <div className="row g-4 justify-content-center">
        {mockVideos.map(video => (
          <div className="col-12 col-sm-6 col-lg-4 col-xl-3" key={video.id}>
            <VideoCard onClick={() => openPlayer(video)}>
              <ThumbnailWrapper>
                <Thumbnail src={video.thumbnail} alt={video.title} loading="lazy" />
                <PlayOverlay>
                  <FiPlay size={48} />
                </PlayOverlay>
              </ThumbnailWrapper>
              <div className="p-4">
                <VideoTitle>{video.title}</VideoTitle>
                <div className="mt-3 text-primary small fw-bold d-flex align-items-center">
                  WATCH VIDEO <FiPlay className="ms-1" size={12} />
                </div>
              </div>
            </VideoCard>
          </div>
        ))}
      </div>

      {selectedVideo && (
        <ModalBackdrop onClick={closePlayer}>
          <ModalContent onClick={(e) => e.stopPropagation()}>
            <CloseIconButton onClick={closePlayer} aria-label="Close video player">
              <FiX size={24} />
            </CloseIconButton>
            <VideoPlayer src={selectedVideo.videoUrl} controls autoPlay />
            <VideoDescription>
              <h2>{selectedVideo.title}</h2>
              <p>{selectedVideo.description}</p>
            </VideoDescription>
          </ModalContent>
        </ModalBackdrop>
      )}
    </VideoContainer>
  );
};

export default Videos;