import React, { useState, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';
import axios from 'axios';
import BaseUrl from './BaseUrl';

const fadeUp = keyframes`from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}`;
const spin   = keyframes`to{transform:rotate(360deg)}`;
const ACCENT = '#10b981';

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 18px;`;

const FilterRow = styled.div`display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px;`;
const FilterBtn = styled.button`
  padding:7px 14px;border-radius:8px;border:1.5px solid ${p=>p.$active?ACCENT:'#e5e7eb'};
  background:${p=>p.$active?'rgba(16,185,129,.08)':'#fff'};
  color:${p=>p.$active?ACCENT:'#6b7280'};font-family:'Plus Jakarta Sans',sans-serif;
  font-size:.8rem;font-weight:${p=>p.$active?700:500};cursor:pointer;transition:all .15s;
  &:hover{border-color:${ACCENT};}
`;

const ReqCard = styled.div`
  background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;padding:18px 20px;
  margin-bottom:12px;box-shadow:0 1px 4px rgba(0,0,0,.04);
  animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*60}ms;
`;
const ReqTop  = styled.div`display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:12px;flex-wrap:wrap;`;
const ReqName = styled.div`font-weight:700;font-size:.95rem;color:#111827;`;
const ReqId   = styled.div`font-size:.74rem;color:#9ca3af;margin-top:2px;`;
const MetaGrid= styled.div`display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px;@media(max-width:600px){grid-template-columns:repeat(2,1fr);}`;
const MetaItem= styled.div``;
const MetaLabel=styled.div`font-size:.7rem;color:#9ca3af;text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px;`;
const MetaVal = styled.div`font-size:.86rem;font-weight:600;color:#374151;`;
const Divider = styled.div`height:1px;background:#f5f5f5;margin:12px 0;`;
const Actions = styled.div`display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;`;

const StatusBadge = styled.span`
  display:inline-flex;font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.4px;
  padding:3px 9px;border-radius:5px;white-space:nowrap;
  background:${p=>p.$s==='accepted'?'#f0fdf9':p.$s==='pending'?'#eff6ff':p.$s==='rejected'?'#fef2f2':'#f9fafb'};
  color:${p=>p.$s==='accepted'?'#059669':p.$s==='pending'?'#2563eb':p.$s==='rejected'?'#ef4444':'#6b7280'};
  border:1px solid ${p=>p.$s==='accepted'?'#a7f3d0':p.$s==='pending'?'#bfdbfe':p.$s==='rejected'?'#fecaca':'#e5e7eb'};
`;

const AcceptBtn = styled.button`
  padding:8px 18px;background:linear-gradient(135deg,${ACCENT},#0ea5e9);border:none;border-radius:8px;
  color:#fff;font-family:'Plus Jakarta Sans',sans-serif;font-size:.82rem;font-weight:700;cursor:pointer;
  transition:all .2s;&:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(16,185,129,.25);}
  &:disabled{opacity:.45;cursor:not-allowed;transform:none;}
`;
const RejectBtn = styled.button`
  padding:8px 18px;background:#fff;border:1.5px solid #fecaca;border-radius:8px;
  color:#ef4444;font-family:'Plus Jakarta Sans',sans-serif;font-size:.82rem;font-weight:700;cursor:pointer;
  transition:all .15s;&:hover{background:#fef2f2;}
  &:disabled{opacity:.45;cursor:not-allowed;}
`;
const ChatBtn = styled.button`
  padding:8px 16px;background:#fff;border:1.5px solid #e5e7eb;border-radius:8px;
  color:#374151;font-family:'Plus Jakarta Sans',sans-serif;font-size:.82rem;font-weight:600;cursor:pointer;
  transition:all .15s;&:hover{background:#f9fafb;}
`;

const SpinWrap = styled.div`display:flex;justify-content:center;padding:60px;`;
const Spin     = styled.div`width:32px;height:32px;border-radius:50%;border:3px solid #e5e7eb;border-top-color:${ACCENT};animation:${spin} .8s linear infinite;`;
const ErrBox   = styled.div`background:#fef2f2;border:1px solid #fecaca;color:#ef4444;border-radius:10px;padding:12px 16px;font-size:.86rem;margin-bottom:16px;`;

const IncomingRequests = ({ navigateTo }) => {
  const [requests, setRequests] = useState([]);
  const [filter, setFilter]     = useState('All');
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState('');
  const [acting, setActing]     = useState(null);

  useEffect(() => {
    (async () => {
      const uid = localStorage.getItem('user_id');
      if (!uid) { setError('Not logged in.'); setLoading(false); return; }
      try {
        const res = await axios.get(`${BaseUrl}/purchase-requests/receiver/${uid}`);
        setRequests(res.data.map(r => ({
          id: r.id,
          productName: r.tablet_name,
          senderName: r.sender?.username || `Buyer #${r.sender_id}`,
          unitPrice: `₹${r.unit_price.toFixed(2)}`,
          quantity: `${r.quantity} units`,
          totalAmount: `₹${(r.quantity*r.unit_price).toFixed(2)}`,
          status: r.status.toLowerCase(),
          description: r.description,
        })));
      } catch(e) {
        if(e.response?.status===404) setRequests([]);
        else setError(e.response?.data?.error||e.message);
      } finally { setLoading(false); }
    })();
  }, []);

  const updateStatus = async (id, status) => {
    setActing(id);
    try {
      await axios.put(`${BaseUrl}/purchase-requests/${id}/action`, { action: status });
      setRequests(requests.map(r => r.id===id ? {...r, status} : r));
    } catch(e) { alert(e.response?.data?.error||e.message); }
    finally { setActing(null); }
  };

  const filtered = filter==='All' ? requests : requests.filter(r => r.status===filter.toLowerCase());
  const cnt = s => requests.filter(r=>r.status===s.toLowerCase()).length;

  if(loading) return <SpinWrap><Spin/></SpinWrap>;

  return (
    <Page>
      <PageTitle>Incoming <em>Requests</em></PageTitle>
      <PageSub>Review and respond to purchase requests from buyers.</PageSub>

      {error && <ErrBox>⚠ {error}</ErrBox>}

      <FilterRow>
        {['All','Pending','Accepted','Rejected'].map(f=>(
          <FilterBtn key={f} $active={filter===f} onClick={()=>setFilter(f)}>
            {f} ({f==='All'?requests.length:cnt(f)})
          </FilterBtn>
        ))}
      </FilterRow>

      {filtered.length===0 && !loading && (
        <div style={{background:'#fff',border:'1.5px dashed #e5e7eb',borderRadius:14,padding:'48px 24px',textAlign:'center'}}>
          <div style={{fontSize:'2rem',opacity:.4,marginBottom:10}}>📋</div>
          <p style={{color:'#9ca3af',fontSize:'.86rem'}}>No {filter!=='All'?filter.toLowerCase()+' ':' '}requests found.</p>
        </div>
      )}

      {filtered.map((req, i) => (
        <ReqCard key={req.id} $i={i}>
          <ReqTop>
            <div>
              <ReqName>💊 {req.productName}</ReqName>
              <ReqId>Request #{req.id} · from {req.senderName}</ReqId>
            </div>
            <StatusBadge $s={req.status}>{req.status}</StatusBadge>
          </ReqTop>

          <MetaGrid>
            <MetaItem><MetaLabel>Buyer</MetaLabel><MetaVal>{req.senderName}</MetaVal></MetaItem>
            <MetaItem><MetaLabel>Unit Price</MetaLabel><MetaVal>{req.unitPrice}</MetaVal></MetaItem>
            <MetaItem><MetaLabel>Quantity</MetaLabel><MetaVal>{req.quantity}</MetaVal></MetaItem>
            <MetaItem><MetaLabel>Total</MetaLabel><MetaVal style={{color:ACCENT}}>{req.totalAmount}</MetaVal></MetaItem>
          </MetaGrid>

          {req.description && (
            <div style={{background:'#f9fafb',border:'1px solid #f0f0f0',borderRadius:9,padding:'10px 13px',fontSize:'.82rem',color:'#6b7280',marginBottom:12}}>
              📝 {req.description}
            </div>
          )}

          <Divider/>
          <Actions>
            <ChatBtn onClick={()=>navigateTo('Chat')}>💬 Chat</ChatBtn>
            {req.status==='pending' && (
              <>
                <RejectBtn onClick={()=>updateStatus(req.id,'rejected')} disabled={acting===req.id}>Reject</RejectBtn>
                <AcceptBtn onClick={()=>updateStatus(req.id,'accepted')} disabled={acting===req.id}>
                  {acting===req.id?'Updating…':'✓ Accept'}
                </AcceptBtn>
              </>
            )}
          </Actions>
        </ReqCard>
      ))}
    </Page>
  );
};

export default IncomingRequests;