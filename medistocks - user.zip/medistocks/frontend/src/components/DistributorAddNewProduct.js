import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { FaBoxOpen, FaCalendarAlt, FaTag, FaUpload, FaCheckCircle, FaSpinner, FaExclamationCircle } from 'react-icons/fa';

// --- Base URL for API ---
import BaseUrl from './BaseUrl';

// --- PHARMACY THEME TOKENS ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

// --- Styled Components (improved, responsive) ---
const PageContainer = styled.div`
  padding: 1rem;
  max-width: 1000px;
  margin: 0 auto;
  min-height: 100vh;
  background: ${LIGHT_GREEN};
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;

  @media (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const FormWrapper = styled.div`
  background: white;
  border-radius: 1.5rem;
  padding: 1.5rem;
  box-shadow: ${CARD_SHADOW};
  transition: all 0.3s ease;
  border: 1px solid ${BORDER_GREY};

  @media (min-width: 768px) {
    padding: 2rem;
  }
`;

const Header = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 1.5rem;
`;

const Title = styled.h2`
  font-weight: 700;
  color: ${DARK_NAVY};
  margin: 0;
  font-size: 1.5rem;
  letter-spacing: -0.3px;

  @media (min-width: 768px) {
    font-size: 1.75rem;
  }
`;

const Stepper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 2rem;
  position: relative;
  flex-wrap: wrap;
  gap: 0.5rem;
`;

const ProgressBar = styled.div`
  position: absolute;
  top: 20px;
  left: 0;
  height: 2px;
  background: ${PHARMACY_GREEN};
  width: ${props => props.progress}%;
  transform: translateY(-50%);
  transition: width 0.4s ease-in-out;
  z-index: 1;
  display: none;

  @media (min-width: 640px) {
    display: block;
  }
`;

const ProgressBackground = styled.div`
  position: absolute;
  top: 20px;
  left: 0;
  right: 0;
  height: 2px;
  background: ${BORDER_GREY};
  transform: translateY(-50%);
  z-index: 0;
  display: none;

  @media (min-width: 640px) {
    display: block;
  }
`;

const Step = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  z-index: 2;
  background: white;
  padding: 0 0.5rem;
  flex: 1;
  min-width: 80px;

  .icon {
    width: 40px;
    height: 40px;
    border-radius: 40px;
    display: grid;
    place-items: center;
    background: ${props => (props.active ? PHARMACY_GREEN : '#f3f4f6')};
    color: ${props => (props.active ? 'white' : '#8b96a5')};
    border: 2px solid ${props => (props.active ? PHARMACY_GREEN : BORDER_GREY)};
    transition: all 0.3s ease;
    font-size: 1rem;
  }
  .label {
    margin-top: 0.5rem;
    font-size: 0.7rem;
    font-weight: 600;
    text-align: center;
    color: ${props => (props.active ? DARK_NAVY : '#8b96a5')};
    @media (min-width: 768px) {
      font-size: 0.8rem;
    }
  }
`;

const FormSection = styled.div`
  animation: fadeIn 0.5s ease-in-out;
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;

const FormGroup = styled.div`
  margin-bottom: 1.25rem;
  .form-label {
    font-weight: 700;
    color: ${DARK_NAVY};
    margin-bottom: 0.5rem;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: block;
  }
`;

const FormInput = styled.input`
  background: white !important;
  color: ${DARK_NAVY} !important;
  border: 1.5px solid ${BORDER_GREY} !important;
  border-radius: 0.75rem !important;
  padding: 0.75rem 1rem !important;
  font-size: 0.9rem !important;
  transition: all 0.2s !important;
  &:focus {
    box-shadow: 0 0 0 3px ${PHARMACY_GREEN}20 !important;
    border-color: ${PHARMACY_GREEN} !important;
    outline: none;
  }
`;

const FormSelect = styled(FormInput).attrs({ as: 'select' })``;
const FormTextArea = styled(FormInput).attrs({ as: 'textarea' })`
  min-height: 100px;
`;

const ImageUploadBox = styled.label`
  border: 2px dashed ${BORDER_GREY};
  border-radius: 1rem;
  padding: 1.5rem;
  text-align: center;
  cursor: pointer;
  display: block;
  transition: all 0.2s;
  background: white;
  &:hover {
    border-color: ${PHARMACY_GREEN};
    background: ${LIGHT_GREEN};
  }
`;

const ImagePreview = styled.img`
  width: 120px;
  height: 120px;
  object-fit: cover;
  border-radius: 1rem;
  margin: 0 auto 1rem;
  display: block;
  border: 1px solid ${BORDER_GREY};
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  margin-top: 2rem;
  border-top: 1px solid ${BORDER_GREY};
  padding-top: 1.5rem;
  flex-direction: column;

  @media (min-width: 480px) {
    flex-direction: row;
  }
`;

const FormButton = styled.button`
  padding: 0.75rem 1.5rem;
  border-radius: 40px;
  font-weight: 700;
  font-size: 0.9rem;
  white-space: nowrap;
  transition: all 0.2s;
  border: none;
  cursor: pointer;
  width: 100%;

  @media (min-width: 480px) {
    width: auto;
  }
  
  &.primary {
    background: ${PHARMACY_GREEN};
    color: white;
    box-shadow: 0 2px 8px rgba(13,124,61,0.2);
    &:hover:not(:disabled) {
      background: #0a5e2e;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(13,124,61,0.3);
    }
  }
  
  &.secondary {
    background: white;
    border: 1.5px solid ${BORDER_GREY};
    color: ${DARK_NAVY};
    &:hover:not(:disabled) {
      background: ${LIGHT_GREEN};
      border-color: ${PHARMACY_GREEN};
    }
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const Alert = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 1rem;
  border-radius: 1rem;
  margin-top: 1.5rem;
  font-size: 0.85rem;
  &.alert-danger {
    background: #fee2e2;
    color: #c0392b;
    border-left: 4px solid #c0392b;
  }
  &.alert-success {
    background: ${LIGHT_GREEN};
    color: ${PHARMACY_GREEN};
    border-left: 4px solid ${PHARMACY_GREEN};
  }
`;

// --- Stepper Content Components (unchanged logic, improved layout) ---
const Step1 = ({ data, handleChange, handleImageChange, imagePreview }) => (
  <FormSection>
    <h4 className="fw-bold mb-4" style={{ color: DARK_NAVY }}>1. Product Details</h4>
    <div className="row g-4">
      <div className="col-md-6">
        <FormGroup>
          <label className="form-label">Tablet Name *</label>
          <FormInput type="text" className="form-control" name="tablet_name" value={data.tablet_name} onChange={handleChange('basic_information')} placeholder="e.g., Paracetamol 500mg" required />
        </FormGroup>
        <FormGroup>
          <label className="form-label">Brand/Manufacturer</label>
          <FormInput type="text" className="form-control" name="brand" value={data.brand} onChange={handleChange('basic_information')} placeholder="e.g., Cipla, Sun Pharma" />
        </FormGroup>
      </div>
      <div className="col-md-6">
        <FormGroup>
          <label className="form-label">Product Image *</label>
          <ImageUploadBox htmlFor="image-upload">
            {imagePreview ? <ImagePreview src={imagePreview} alt="Product preview" /> : <div className="fs-1 mb-2" style={{ color: PHARMACY_GREEN }}><FaUpload /></div>}
            <p className="fw-bold mb-1" style={{ color: DARK_NAVY }}>Click to upload image</p>
            <small className="text-secondary">PNG, JPG up to 5MB</small>
          </ImageUploadBox>
          <input id="image-upload" type="file" accept="image/png, image/jpeg" className="d-none" onChange={handleImageChange} />
        </FormGroup>
      </div>
    </div>
  </FormSection>
);

const Step2 = ({ data, handleChange }) => (
  <FormSection>
    <h4 className="fw-bold mb-4" style={{ color: DARK_NAVY }}>2. Inventory & Dates</h4>
    <div className="row g-4">
      <div className="col-md-6">
        <FormGroup>
          <label className="form-label">Quantity</label>
          <FormInput type="number" className="form-control" name="quantity" value={data.quantity} onChange={handleChange('basic_information')} placeholder="100" />
        </FormGroup>
        <FormGroup>
          <label className="form-label">Unit Type</label>
          <FormSelect className="form-select" name="unit_type" value={data.unit_type} onChange={handleChange('basic_information')}>
            <option>Tablets</option>
            <option>Capsules</option>
            <option>Strips</option>
            <option>Bottles</option>
          </FormSelect>
        </FormGroup>
        <FormGroup>
          <label className="form-label">Batch Number</label>
          <FormInput type="text" className="form-control" name="batch_number" value={data.batch_number} onChange={handleChange('additional_details')} placeholder="e.g., BT001234" />
        </FormGroup>
      </div>
      <div className="col-md-6">
        <FormGroup>
          <label className="form-label">Manufacturing Date</label>
          <FormInput type="date" className="form-control" name="manufacturing_date" value={data.manufacturing_date} onChange={handleChange('important_dates')} />
        </FormGroup>
        <FormGroup>
          <label className="form-label">Best Before Date</label>
          <FormInput type="date" className="form-control" name="best_before_date" value={data.best_before_date} onChange={handleChange('important_dates')} />
        </FormGroup>
        <FormGroup>
          <label className="form-label">Expiry Date *</label>
          <FormInput type="date" className="form-control" name="expiry_date" value={data.expiry_date} onChange={handleChange('important_dates')} required />
        </FormGroup>
      </div>
    </div>
  </FormSection>
);

const Step3 = ({ data, handleChange }) => (
  <FormSection>
    <h4 className="fw-bold mb-4" style={{ color: DARK_NAVY }}>3. Pricing & Usage</h4>
    <div className="row g-4">
      <div className="col-md-6">
        <FormGroup>
          <label className="form-label">Original Price (₹)</label>
          <FormInput type="number" className="form-control" name="original_price" value={data.original_price} onChange={handleChange('pricing_discounts')} placeholder="100.00" />
        </FormGroup>
        <FormGroup>
          <label className="form-label">Discount Slabs</label>
          {[50, 75, 90].map(d => (
            <div className="form-check" key={d}>
              <input 
                className="form-check-input" 
                type="checkbox" 
                name={d} 
                id={`discount${d}`} 
                checked={data.discount.includes(d)} 
                onChange={handleChange('pricing_discounts', 'discount')}
                style={{ accentColor: PHARMACY_GREEN }}
              />
              <label className="form-check-label" style={{ color: DARK_NAVY }} htmlFor={`discount${d}`}>{d}% Discount</label>
            </div>
          ))}
        </FormGroup>
      </div>
      <div className="col-md-6">
        <FormGroup>
          <label className="form-label">Usage Instructions</label>
          <FormTextArea className="form-control" rows="3" name="usage_instructions" value={data.usage_instructions} onChange={handleChange('usage_information')} placeholder="e.g., Twice 1-2 tablets with water..."></FormTextArea>
        </FormGroup>
        <FormGroup>
          <label className="form-label">Storage Instructions</label>
          <FormInput type="text" className="form-control" name="storage_instructions" value={data.storage_instructions} onChange={handleChange('usage_information')} placeholder="e.g., Store in cool, dry place" />
        </FormGroup>
      </div>
    </div>
  </FormSection>
);

// --- Main Add New Product Component (logic untouched) ---
const AddNewProduct = ({ navigateTo }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState({ error: '', success: '' });
  
  const [productData, setProductData] = useState({
    location: '',
    basic_information: { tablet_name: '', brand: '', quantity: '', unit_type: 'Tablets' },
    important_dates: { manufacturing_date: '', best_before_date: '', expiry_date: '' },
    usage_information: { usage_instructions: '', storage_instructions: '' },
    pricing_discounts: { original_price: '', discount: [] },
    additional_details: { batch_number: '' }
  });
  
  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setProductData(prev => ({...prev, location: `${latitude},${longitude}`}));
      },
      () => console.warn("Could not get user location.")
    );
  }, []);

  const handleChange = (section, field) => (e) => {
    const { name, value, type, checked } = e.target;
    
    if (type === 'checkbox' && field === 'discount') {
      const numericName = parseInt(name, 10);
      setProductData(prev => {
        const currentDiscounts = prev.pricing_discounts.discount;
        const newDiscounts = checked ? [...currentDiscounts, numericName] : currentDiscounts.filter(d => d !== numericName);
        return { ...prev, pricing_discounts: { ...prev.pricing_discounts, discount: newDiscounts } };
      });
    } else {
      setProductData(prev => ({
        ...prev,
        [section]: { ...prev[section], [name]: value }
      }));
    }
  };
  
  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const nextStep = () => setCurrentStep(prev => prev < 3 ? prev + 1 : 3);
  const prevStep = () => setCurrentStep(prev => prev > 1 ? prev - 1 : 1);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (currentStep !== 3) return; 
    setIsLoading(true);
    setStatus({ error: '', success: '' });
    if (!productData.basic_information.tablet_name || !productData.important_dates.expiry_date || !imageFile) {
      setStatus({ error: 'Please fill all required fields (*) and upload an image.', success: '' });
      setIsLoading(false);
      return;
    }
    const formData = new FormData();
    formData.append('file', imageFile);
    formData.append('user_id', localStorage.getItem('user_id'));
    formData.append('location', productData.location);
    Object.entries(productData).forEach(([section, fields]) => {
      if (typeof fields === 'object' && fields !== null) {
        Object.entries(fields).forEach(([key, value]) => {
          const finalValue = Array.isArray(value) ? value.join(', ') : value;
          formData.append(`${section}[${key}]`, finalValue);
        });
      }
    });
    try {
      const response = await fetch(`${BaseUrl}/products/product`, {
        method: 'POST',
        body: formData
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Failed to add product.');
      setStatus({ success: 'Product published successfully! Redirecting...', error: '' });
      setTimeout(() => navigateTo('My Products'), 2000);
    } catch (err) {
      setStatus({ error: err.message, success: '' });
    } finally {
      setIsLoading(false);
    }
  };

  const steps = [
    { icon: <FaBoxOpen />, label: 'Product Details' },
    { icon: <FaCalendarAlt />, label: 'Inventory & Dates' },
    { icon: <FaTag />, label: 'Pricing & Usage' },
  ];
  
  const progressPercentage = ((currentStep - 1) / (steps.length - 1)) * 100;

  return (
    <PageContainer>
      <Header><Title>Add New Product</Title></Header>
      <FormWrapper>
        <Stepper>
          <ProgressBackground />
          <ProgressBar progress={progressPercentage} />
          {steps.map((step, index) => (
            <Step key={index} active={currentStep >= index + 1}>
              <div className="icon">{step.icon}</div>
              <div className="label">{step.label}</div>
            </Step>
          ))}
        </Stepper>
        
        <form onSubmit={handleSubmit}>
          {currentStep === 1 && <Step1 data={productData.basic_information} handleChange={handleChange} handleImageChange={handleImageChange} imagePreview={imagePreview} />}
          {currentStep === 2 && <Step2 data={{ ...productData.basic_information, ...productData.additional_details, ...productData.important_dates }} handleChange={handleChange} />}
          {currentStep === 3 && <Step3 data={{ ...productData.pricing_discounts, ...productData.usage_information }} handleChange={handleChange} />}
          
          <ButtonGroup>
            <FormButton type="button" className="secondary" onClick={prevStep} disabled={currentStep === 1}>Back</FormButton>
            {currentStep < 3 ? (
              <FormButton type="button" className="primary" onClick={nextStep}>Next</FormButton>
            ) : (
              <FormButton type="submit" className="primary" disabled={isLoading}>
                {isLoading ? <><FaSpinner className="fa-spin me-2" /> Publishing...</> : 'Publish Product'}
              </FormButton>
            )}
          </ButtonGroup>

          {status.error && <Alert className="alert-danger"><FaExclamationCircle /> {status.error}</Alert>}
          {status.success && <Alert className="alert-success"><FaCheckCircle /> {status.success}</Alert>}
        </form>
      </FormWrapper>
    </PageContainer>
  );
};

export default AddNewProduct;