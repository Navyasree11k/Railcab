import React, { useState, useMemo, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';
import axios from 'axios';
import BaseUrl from './BaseUrl';

const fadeUp = keyframes`from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}`;
const spin   = keyframes`to{transform:rotate(360deg)}`;
const ACCENT = '#10b981';

const fmt = (d) => d ? new Date(d).toLocaleString('en-IN',{day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit',hour12:true}) : null;

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 18px;`;

const FilterRow = styled.div`display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px;`;
const FilterBtn = styled.button`
  padding:7px 14px;border-radius:8px;border:1.5px solid ${p=>p.$active?ACCENT:'#e5e7eb'};
  background:${p=>p.$active?'rgba(16,185,129,.08)':'#fff'};
  color:${p=>p.$active?ACCENT:'#6b7280'};font-family:'Plus Jakarta Sans',sans-serif;
  font-size:.8rem;font-weight:${p=>p.$active?700:500};cursor:pointer;transition:all .15s;
  &:hover{border-color:${ACCENT};}
`;

const ReqCard = styled.div`
  background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;padding:18px 20px;
  margin-bottom:12px;box-shadow:0 1px 4px rgba(0,0,0,.04);
  animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*60}ms;
`;
const ReqTop = styled.div`display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:12px;flex-wrap:wrap;`;
const ReqName= styled.div`font-weight:700;font-size:.95rem;color:#111827;`;
const ReqId  = styled.div`font-size:.74rem;color:#9ca3af;margin-top:2px;`;
const MetaGrid= styled.div`display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px;@media(max-width:600px){grid-template-columns:repeat(2,1fr);}`;
const MetaItem= styled.div``;
const MetaLabel= styled.div`font-size:.7rem;color:#9ca3af;text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px;`;
const MetaVal = styled.div`font-size:.86rem;font-weight:600;color:#374151;`;
const Divider = styled.div`height:1px;background:#f5f5f5;margin:12px 0;`;
const ReqBot  = styled.div`display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;`;
const Actions = styled.div`display:flex;flex-wrap:wrap;gap:8px;`;

const StatusBadge = styled.span`
  display:inline-flex;font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.4px;
  padding:3px 9px;border-radius:5px;white-space:nowrap;
  background:${p=>p.$s==='accepted'||p.$s==='invoice_ready'?'#f0fdf9':p.$s==='pending'?'#eff6ff':p.$s==='rejected'?'#fef2f2':'#f9fafb'};
  color:${p=>p.$s==='accepted'||p.$s==='invoice_ready'?'#059669':p.$s==='pending'?'#2563eb':p.$s==='rejected'?'#ef4444':'#6b7280'};
  border:1px solid ${p=>p.$s==='accepted'||p.$s==='invoice_ready'?'#a7f3d0':p.$s==='pending'?'#bfdbfe':p.$s==='rejected'?'#fecaca':'#e5e7eb'};
`;

const SmallBtn = styled.button`
  padding:7px 14px;border-radius:8px;font-family:'Plus Jakarta Sans',sans-serif;font-size:.8rem;font-weight:600;cursor:pointer;transition:all .15s;
  background:${p=>p.$primary?`linear-gradient(135deg,${ACCENT},#0ea5e9)`:'#fff'};
  color:${p=>p.$primary?'#fff':'#374151'};
  border:1.5px solid ${p=>p.$primary?'transparent':'#e5e7eb'};
  &:hover{${p=>p.$primary?`transform:translateY(-1px);box-shadow:0 4px 12px rgba(16,185,129,.25);`:`background:#f9fafb;`}}
`;

const ActionBanner = styled.div`
  background:#fffbeb;border:1px solid #fde68a;border-radius:10px;padding:14px 16px;margin-top:12px;
`;
const CodeForm = styled.div`display:flex;gap:8px;margin-top:8px;@media(max-width:480px){flex-direction:column;}`;
const CodeInput= styled.input`
  flex:1;background:#fff;border:1.5px solid #e5e7eb;border-radius:8px;padding:9px 12px;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.875rem;color:#374151;outline:none;
  &:focus{border-color:${ACCENT};box-shadow:0 0 0 3px rgba(16,185,129,.1);}
`;

const ModalBg = styled.div`position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(4px);display:flex;justify-content:center;align-items:center;z-index:1050;`;
const ModalBox= styled.div`background:#fff;border-radius:16px;padding:24px;width:90%;max-width:400px;box-shadow:0 20px 40px rgba(0,0,0,.1);`;
const SpinWrap= styled.div`display:flex;justify-content:center;padding:60px;`;
const Spin    = styled.div`width:32px;height:32px;border-radius:50%;border:3px solid #e5e7eb;border-top-color:${ACCENT};animation:${spin} .8s linear infinite;`;
const ErrBox  = styled.div`background:#fef2f2;border:1px solid #fecaca;color:#ef4444;border-radius:10px;padding:12px 16px;font-size:.86rem;margin-bottom:16px;`;

const SentRequests = ({ navigateTo }) => {
  const [requests, setRequests] = useState([]);
  const [filter, setFilter]     = useState('All');
  const [modal, setModal]       = useState({ type:null, req:null });
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const uid = localStorage.getItem('user_id');
        if (!uid) throw new Error('User not logged in.');
        const res = await axios.get(`${BaseUrl}/purchase-requests/user/${uid}/sent-requests`);
        setRequests(res.data.map(r => ({
          id: r.id,
          productName: r.tablet_name,
          receiverName: r.receiver?.username || `Receiver #${r.receiver_id}`,
          unitPrice: `₹${r.unit_price.toFixed(2)}`,
          quantity: `${r.quantity} units`,
          totalAmount: `₹${(r.quantity * r.unit_price).toFixed(2)}`,
          requestedDate: fmt(r.created_at),
          respondedDate: fmt(r.updated_at) !== fmt(r.created_at) ? fmt(r.updated_at) : null,
          status: r.status.toLowerCase(),
          rejectionReason: r.rejection_reason || null,
        })));
      } catch (e) {
        if (e.response?.status === 404) setRequests([]);
        else setError(e.response?.data?.error || e.message);
      } finally { setLoading(false); }
    })();
  }, []);

  const filtered = useMemo(() => filter === 'All' ? requests : requests.filter(r => r.status === filter.toLowerCase()), [filter, requests]);

  const counts = s => requests.filter(r => r.status === s.toLowerCase()).length;

  const cancelReq = () => { setRequests(requests.filter(r => r.id !== modal.req.id)); setModal({type:null,req:null}); };
  const reqAgain  = id  => setRequests(requests.map(r => r.id===id ? {...r,status:'pending',respondedDate:null,rejectionReason:null} : r));
  const submitCode= e => { e.preventDefault(); setSubmitting(true); setTimeout(()=>{ setSubmitting(false); navigateTo('Orders'); }, 2000); };

  if (loading) return <SpinWrap><Spin /></SpinWrap>;

  return (
    <Page>
      <PageTitle>Sent <em>Requests</em></PageTitle>
      <PageSub>Track the status of your purchase requests.</PageSub>

      {error && <ErrBox>⚠ {error}</ErrBox>}

      <FilterRow>
        {['All','Pending','Accepted','Rejected'].map(f => (
          <FilterBtn key={f} $active={filter===f} onClick={()=>setFilter(f)}>
            {f} ({f==='All'?requests.length:counts(f)})
          </FilterBtn>
        ))}
      </FilterRow>

      {filtered.length === 0 && !loading && (
        <div style={{background:'#fff',border:'1.5px dashed #e5e7eb',borderRadius:14,padding:'48px 24px',textAlign:'center'}}>
          <div style={{fontSize:'2rem',opacity:.4,marginBottom:10}}>📋</div>
          <p style={{color:'#9ca3af',fontSize:'.86rem'}}>No {filter!=='All'?filter.toLowerCase()+' ':' '}requests found.</p>
        </div>
      )}

      {filtered.map((req, i) => (
        <ReqCard key={req.id} $i={i}>
          <ReqTop>
            <div>
              <ReqName>💊 {req.productName}</ReqName>
              <ReqId>Request #{req.id}</ReqId>
            </div>
            <StatusBadge $s={req.status}>{req.status}</StatusBadge>
          </ReqTop>

          <MetaGrid>
            <MetaItem><MetaLabel>Sent To</MetaLabel><MetaVal>{req.receiverName}</MetaVal></MetaItem>
            <MetaItem><MetaLabel>Unit Price</MetaLabel><MetaVal>{req.unitPrice}</MetaVal></MetaItem>
            <MetaItem><MetaLabel>Quantity</MetaLabel><MetaVal>{req.quantity}</MetaVal></MetaItem>
            <MetaItem><MetaLabel>Total</MetaLabel><MetaVal style={{color:ACCENT}}>{req.totalAmount}</MetaVal></MetaItem>
          </MetaGrid>

          {req.rejectionReason && (
            <div style={{background:'#fef2f2',border:'1px solid #fecaca',borderRadius:8,padding:'8px 12px',fontSize:'.8rem',color:'#ef4444',marginBottom:10}}>
              ⚠ {req.rejectionReason}
            </div>
          )}

          <Divider />
          <ReqBot>
            <div style={{fontSize:'.76rem',color:'#9ca3af'}}>Sent: {req.requestedDate}{req.respondedDate&&` · Responded: ${req.respondedDate}`}</div>
            <Actions>
              {req.status==='accepted' && (
                <><SmallBtn onClick={()=>navigateTo('Chat')}>💬 Chat</SmallBtn><SmallBtn $primary>📄 Invoice</SmallBtn></>
              )}
              {req.status==='pending' && (
                <><span style={{fontSize:'.78rem',color:'#6b7280',alignSelf:'center'}}>Awaiting response…</span><SmallBtn onClick={()=>setModal({type:'cancel',req})}>Cancel</SmallBtn></>
              )}
              {req.status==='rejected' && (
                <><SmallBtn onClick={()=>navigateTo('Products')}>Find Alternative</SmallBtn><SmallBtn $primary onClick={()=>reqAgain(req.id)}>Request Again</SmallBtn></>
              )}
              {req.status==='invoice_ready' && (
                <SmallBtn onClick={()=>navigateTo('Chat')}>💬 Chat</SmallBtn>
              )}
            </Actions>
          </ReqBot>

          {req.status==='invoice_ready' && (
            <ActionBanner>
              <div style={{fontSize:'.8rem',color:'#92400e',marginBottom:6}}>⚠ Action Required: Enter the unique code from the receiver to finalize this transaction.</div>
              <form onSubmit={submitCode}>
                <CodeForm>
                  <CodeInput type="text" placeholder="Enter code…" required/>
                  <SmallBtn $primary type="submit" disabled={submitting}>{submitting?'Submitting…':'Submit'}</SmallBtn>
                </CodeForm>
              </form>
            </ActionBanner>
          )}
        </ReqCard>
      ))}

      {modal.type==='cancel' && (
        <ModalBg onClick={()=>setModal({type:null,req:null})}>
          <ModalBox onClick={e=>e.stopPropagation()}>
            <div style={{fontWeight:700,fontSize:'1rem',color:'#111827',marginBottom:8}}>Cancel Request?</div>
            <p style={{color:'#6b7280',fontSize:'.86rem',marginBottom:20}}>Are you sure you want to cancel this request? This cannot be undone.</p>
            <div style={{display:'flex',gap:10}}>
              <SmallBtn style={{flex:1}} onClick={()=>setModal({type:null,req:null})}>Keep It</SmallBtn>
              <SmallBtn $primary style={{flex:1}} onClick={cancelReq}>Yes, Cancel</SmallBtn>
            </div>
          </ModalBox>
        </ModalBg>
      )}
    </Page>
  );
};

export default SentRequests;