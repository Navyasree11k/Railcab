import React, { useState, useEffect, useMemo } from 'react';
import styled from 'styled-components';
import axios from 'axios';
// This import is now correct because BaseUrl.js has the named export
import BaseUrl, { GOOGLE_MAPS_API_KEY } from './BaseUrl';
import { GoogleMap, useJsApiLoader, HeatmapLayer } from '@react-google-maps/api';

// --- Styled Components for the New Theme ---
const PageWrapper = styled.div`
  background-color: #f4f7fa;
  min-height: 100vh;
`;
const Header = styled.header`
  background-color: #ffffff;
  padding: 1.5rem 2rem;
  border-bottom: 1px solid #e2e8f0;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
`;
const FilterBar = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  padding: 1rem 2rem;
  background-color: #ffffff;
  border-bottom: 1px solid #e2e8f0;
`;
const FilterGroup = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  align-items: center;
`;
const FilterButton = styled.button`
  background-color: ${({ active }) => (active ? '#0ea5e9' : '#f1f5f9')};
  color: ${({ active }) => (active ? '#ffffff' : '#475569')};
  border: 1px solid ${({ active }) => (active ? '#0ea5e9' : '#e2e8f0')};
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  font-weight: 500;
  font-size: 0.875rem;
  transition: all 0.2s ease-in-out;
  white-space: nowrap;
  &:hover {
    background-color: ${({ active }) => (active ? '#0284c7' : '#e2e8f0')};
    border-color: ${({ active }) => (active ? '#0284c7' : '#cbd5e1')};
  }
`;
const ContentArea = styled.main`
  padding: 2rem;
`;
const ProductCard = styled.div`
  background-color: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 0.75rem;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  height: 100%;
  box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
  transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
  }
`;
const ProductImage = styled.img`
  width: 100%;
  height: 150px;
  object-fit: cover;
  border-bottom: 1px solid #e2e8f0;
`;
const CardBody = styled.div`
  padding: 1rem;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
`;
const PriceContainer = styled.div`
  display: flex;
  align-items: baseline;
  gap: 0.5rem;
  margin-top: 0.5rem;
`;
const DiscountedPrice = styled.span`
  font-size: 1.25rem;
  font-weight: 700;
  color: #1e293b;
`;
const OriginalPrice = styled.span`
  font-size: 0.875rem;
  text-decoration: line-through;
  color: #94a3b8;
`;
const DiscountBadge = styled.span`
  background-color: #10b981;
  color: white;
  padding: 0.15rem 0.5rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 600;
`;

// --- Heatmap Component ---
const HeatmapComponent = ({ products }) => {
    const { isLoaded } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: GOOGLE_MAPS_API_KEY,
        libraries: ['visualization'],
    });

    const mapCenter = useMemo(() => ({ lat: 17.3850, lng: 78.4867 }), []); // Center on Hyderabad

    const heatmapData = useMemo(() => {
        if (!isLoaded || !products || !window.google) return [];
        return products
            .filter(p => p.distributor_location)
            .map(p => {
                const [lat, lng] = p.distributor_location.split(',').map(Number);
                return new window.google.maps.LatLng(lat, lng);
            });
    }, [isLoaded, products]);

    // This check is now safer and handles if the key is missing from the import
    if (!GOOGLE_MAPS_API_KEY || !GOOGLE_MAPS_API_KEY.startsWith('AIza')) {
        return <div className="alert alert-warning">Please make sure your Google Maps API key is correctly set in BaseUrl.js.</div>;
    }
    
    if (!isLoaded) return <div className="text-center p-5">Loading Map...</div>;

    return (
        <GoogleMap
            mapContainerStyle={{ width: '100%', height: '600px', borderRadius: '0.75rem' }}
            center={mapCenter}
            zoom={10}
        >
            <HeatmapLayer data={heatmapData} />
        </GoogleMap>
    );
};

// --- Main NearbyInventory Component ---
const NearbyInventory = () => {
    const [products, setProducts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [radius, setRadius] = useState(10);
    const [viewMode, setViewMode] = useState('list');
    const userId = parseInt(localStorage.getItem('user_id'), 10);


    useEffect(() => {
        const fetchInventory = async () => {
            if (!userId) {
                setError("User ID not found. Please log in.");
                setIsLoading(false);
                return;
            }
            setIsLoading(true);
            setError('');
            try {
                const response = await axios.get(`${BaseUrl}/products/nearby-inventory/${userId}`, {
                    params: { radius: radius }
                });
                setProducts(response.data.nearby_products || []);
            } catch (err) {
                setError("Could not fetch nearby inventory. Please try again.");
                console.error("API Error:", err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchInventory();
    }, [userId, radius]);

    const calculateDiscountedPrice = (price, discount) => {
        return (price * (1 - discount / 100)).toFixed(2);
    };

    return (
        <PageWrapper>
            <Header>
                <h1 className="h4 fw-bold text-dark mb-0">Nearby Inventory Discovery</h1>
                <p className="text-secondary mb-0">Find stock from distributors near you.</p>
            </Header>
            <FilterBar>
                <FilterGroup>
                    <span className="fw-medium text-secondary me-2">Radius:</span>
                    {[5, 10, 15, 50].map(r => (
                        <FilterButton key={r} active={radius === r} onClick={() => setRadius(r)}>
                            {r} km
                        </FilterButton>
                    ))}
                </FilterGroup>
                <FilterGroup>
                    <FilterButton active={viewMode === 'list'} onClick={() => setViewMode('list')}>
                        <span className="me-2">☰</span> List
                    </FilterButton>
                    <FilterButton active={viewMode === 'map'} onClick={() => setViewMode('map')}>
                        <span className="me-2">📍</span> Heatmap
                    </FilterButton>
                </FilterGroup>
            </FilterBar>
            <ContentArea>
                {isLoading ? (
                    <div className="text-center p-5"><div className="spinner-border text-primary" role="status"></div></div>
                ) : error ? (
                    <div className="alert alert-danger">{error}</div>
                ) : (
                    <>
                        {viewMode === 'list' ? (
                            products.length > 0 ? (
                                <div className="row g-4">
                                    {products.map((item) => (
                                        <div className="col-12 col-md-6 col-lg-4 col-xl-3" key={item.id}>
                                            <ProductCard>
                                                <ProductImage src={item.image_url} alt={item.tablet_name} onError={(e) => { e.target.onerror = null; e.target.src='https://placehold.co/400x300/e2e8f0/334155?text=No+Image'; }} />
                                                <CardBody>
                                                    <h5 className="fw-bold text-dark fs-6 mb-1">{item.tablet_name}</h5>
                                                    <p className="text-secondary small mb-2">{item.brand}</p>
                                                    <PriceContainer>
                                                        <DiscountedPrice>₹{calculateDiscountedPrice(item.original_price, item.discount)}</DiscountedPrice>
                                                        <OriginalPrice>₹{item.original_price}</OriginalPrice>
                                                        <DiscountBadge>{item.discount}% OFF</DiscountBadge>
                                                    </PriceContainer>
                                                    <hr className="my-3" />
                                                    <div className="small text-secondary mt-auto">
                                                        <p className="mb-1 fw-medium text-dark">{item.distributor_email.split('@')[0]}</p>
                                                        <p className="mb-0">📍 {item.distance_km} km away</p>
                                                    </div>
                                                </CardBody>
                                            </ProductCard>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center p-5 bg-white rounded-3">
                                    <h5 className="text-dark">No Products Found</h5>
                                    <p className="text-secondary">Try increasing the search radius to find more products.</p>
                                </div>
                            )
                        ) : (
                            <HeatmapComponent products={products} />
                        )}
                    </>
                )}
            </ContentArea>
        </PageWrapper>
    );
};

export default NearbyInventory;