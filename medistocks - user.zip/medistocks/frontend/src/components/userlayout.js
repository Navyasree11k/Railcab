import React, { useState, useRef, useEffect } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { logout } from './redux/authSlice';

/* ─── Google Fonts ─────────────────────────────────────────────────────────── */
const GlobalStyle = createGlobalStyle`
  *, *::before, *::after { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: 'Plus Jakarta Sans', sans-serif;
    background: #f5f7fa;
    color: #111827;
  }
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: #e5e7eb; border-radius: 4px; }
`;

/* ─── Animations ────────────────────────────────────────────────────────────── */
const slideIn  = keyframes`from{opacity:0;transform:translateX(-8px)}to{opacity:1;transform:translateX(0)}`;
const dropDown = keyframes`from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}`;
const fadeIn   = keyframes`from{opacity:0}to{opacity:1}`;

/* ─── Design Tokens ─────────────────────────────────────────────────────────── */
// accent: emerald-teal gradient
const ACCENT  = 'linear-gradient(135deg, #10b981 0%, #0ea5e9 100%)';
const ACCENT1 = '#10b981';
const ACCENT2 = '#0ea5e9';

/* ══════════════════════════════════════════════════════════════════════════════
   SIDEBAR
══════════════════════════════════════════════════════════════════════════════ */
const SIDEBAR_W = '240px';

const SidebarRoot = styled.aside`
  position: fixed;
  top: 0; left: 0;
  width: ${SIDEBAR_W};
  height: 100vh;
  background: #ffffff;
  border-right: 1px solid #f0f0f0;
  display: flex;
  flex-direction: column;
  z-index: 200;
  transition: transform 0.28s cubic-bezier(.4,0,.2,1);
  box-shadow: 2px 0 12px rgba(0,0,0,0.04);

  @media (max-width: 1024px) {
    transform: translateX(${p => p.$open ? '0' : '-100%'});
  }
`;

const LogoArea = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 20px 18px 16px;
  border-bottom: 1px solid #f5f5f5;
`;

const LogoMark = styled.div`
  width: 34px; height: 34px;
  border-radius: 9px;
  background: ${ACCENT};
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 4px 10px rgba(16,185,129,0.28);
  flex-shrink: 0;
`;

const LogoText = styled.span`
  font-size: 1.05rem;
  font-weight: 800;
  color: #111827;
  letter-spacing: -0.3px;
  em { color: ${ACCENT1}; font-style: normal; }
`;

const NavScroll = styled.nav`
  flex: 1;
  overflow-y: auto;
  padding: 10px 10px;
  display: flex;
  flex-direction: column;
  gap: 1px;
`;

const NavSection = styled.div`
  margin-top: 14px;
  &:first-child { margin-top: 4px; }
`;

const NavSectionLabel = styled.p`
  font-size: 0.65rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.9px;
  color: #c4c9d4;
  padding: 0 10px;
  margin: 0 0 4px;
`;

const NavItem = styled.button`
  width: 100%;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 10px;
  border-radius: 9px;
  border: none;
  background: ${p => p.$active
    ? 'linear-gradient(135deg,rgba(16,185,129,0.1),rgba(14,165,233,0.07))'
    : 'transparent'};
  color: ${p => p.$active ? ACCENT1 : '#6b7280'};
  font-family: 'Plus Jakarta Sans', sans-serif;
  font-size: 0.845rem;
  font-weight: ${p => p.$active ? 600 : 500};
  cursor: pointer;
  text-align: left;
  transition: all 0.15s;
  border: 1px solid ${p => p.$active ? 'rgba(16,185,129,0.18)' : 'transparent'};
  position: relative;
  animation: ${slideIn} 0.25s ease both;

  .nav-icon { font-size: 1rem; flex-shrink: 0; }

  ${p => p.$active && `
    &::before {
      content: '';
      position: absolute;
      left: 0; top: 20%; height: 60%; width: 3px;
      background: ${ACCENT};
      border-radius: 0 3px 3px 0;
    }
  `}

  &:hover:not([disabled]) {
    background: #f9fafb;
    color: #374151;
  }
`;

const Overlay = styled.div`
  display: none;
  @media (max-width: 1024px) {
    display: ${p => p.$show ? 'block' : 'none'};
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.35);
    z-index: 199;
    animation: ${fadeIn} 0.2s ease;
  }
`;

/* Profile at the bottom of sidebar */
const SidebarFooter = styled.div`
  border-top: 1px solid #f5f5f5;
  padding: 12px 10px;
  position: relative;
`;

const SidebarProfileBtn = styled.button`
  width: 100%;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 10px;
  border-radius: 9px;
  border: none;
  background: transparent;
  cursor: pointer;
  transition: background 0.15s;
  &:hover { background: #f9fafb; }
`;

const SidebarAvatar = styled.div`
  width: 32px; height: 32px;
  border-radius: 8px;
  background: ${ACCENT};
  display: flex; align-items: center; justify-content: center;
  font-weight: 700;
  font-size: 0.82rem;
  color: #fff;
  flex-shrink: 0;
`;

const MiniDropdown = styled.div`
  position: absolute;
  bottom: calc(100% + 6px);
  left: 10px; right: 10px;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 5px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.09);
  z-index: 300;
  animation: ${dropDown} 0.15s ease;
`;

const MiniDropItem = styled.button`
  width: 100%;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 8px 10px;
  border-radius: 7px;
  border: none;
  background: none;
  color: #374151;
  font-size: 0.84rem;
  font-family: 'Plus Jakarta Sans', sans-serif;
  cursor: pointer;
  text-align: left;
  &:hover { background: #f9fafb; }
  &.danger:hover { background: #fef2f2; color: #ef4444; }
`;

/* ══════════════════════════════════════════════════════════════════════════════
   TOP BAR
══════════════════════════════════════════════════════════════════════════════ */
const TopBarRoot = styled.header`
  position: fixed;
  top: 0;
  left: ${SIDEBAR_W};
  right: 0;
  height: 60px;
  background: rgba(255,255,255,0.95);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  z-index: 100;
  box-shadow: 0 1px 6px rgba(0,0,0,0.04);
  transition: left 0.28s cubic-bezier(.4,0,.2,1);

  @media (max-width: 1024px) {
    left: 0;
    padding: 0 16px;
  }
`;

const TopLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
`;

const HamburgerBtn = styled.button`
  display: none;
  background: none;
  border: none;
  cursor: pointer;
  padding: 6px;
  border-radius: 7px;
  color: #6b7280;
  font-size: 1.2rem;
  transition: background 0.15s;
  &:hover { background: #f3f4f6; }
  @media (max-width: 1024px) { display: flex; align-items: center; }
`;

const Breadcrumb = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
`;

const BreadcrumbItem = styled.span`
  font-size: 0.82rem;
  color: ${p => p.$current ? '#111827' : '#9ca3af'};
  font-weight: ${p => p.$current ? 700 : 400};
  cursor: ${p => p.$clickable ? 'pointer' : 'default'};
  &:hover { color: ${p => p.$clickable ? ACCENT1 : 'inherit'}; }
`;

const BreadcrumbSep = styled.span`
  color: #d1d5db;
  font-size: 0.78rem;
`;

const ActivePageTitle = styled.h1`
  font-size: 1.05rem;
  font-weight: 700;
  color: #111827;
  margin: 0;
  letter-spacing: -0.2px;
`;

const TopRight = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
`;

const IconBtn = styled.button`
  width: 36px; height: 36px;
  border-radius: 9px;
  border: none;
  background: transparent;
  color: #6b7280;
  font-size: 1.1rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s;
  position: relative;
  &:hover { background: #f3f4f6; color: #111827; }
`;

const NotifDot = styled.span`
  position: absolute;
  top: 6px; right: 6px;
  width: 7px; height: 7px;
  border-radius: 50%;
  background: #ef4444;
  border: 1.5px solid #fff;
`;

const Divider = styled.div`
  width: 1px; height: 22px;
  background: #e5e7eb;
  margin: 0 4px;
`;

/* Top-bar profile */
const TopProfileBtn = styled.button`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 5px 10px 5px 5px;
  border-radius: 10px;
  border: 1px solid #e5e7eb;
  background: #fff;
  cursor: pointer;
  transition: all 0.15s;
  &:hover { border-color: #d1d5db; background: #f9fafb; }
`;

const TopAvatar = styled.div`
  width: 28px; height: 28px;
  border-radius: 7px;
  background: ${ACCENT};
  display: flex; align-items: center; justify-content: center;
  font-weight: 700;
  font-size: 0.75rem;
  color: #fff;
`;

const TopProfileName = styled.span`
  font-size: 0.82rem;
  font-weight: 600;
  color: #374151;
  @media (max-width: 480px) { display: none; }
`;

const TopDropdown = styled.div`
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  width: 200px;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 6px;
  box-shadow: 0 12px 32px rgba(0,0,0,0.1);
  z-index: 400;
  animation: ${dropDown} 0.15s ease;
`;

const TopDropItem = styled.button`
  width: 100%;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 9px 12px;
  border-radius: 8px;
  border: none;
  background: none;
  color: #374151;
  font-size: 0.84rem;
  font-family: 'Plus Jakarta Sans', sans-serif;
  cursor: pointer;
  text-align: left;
  &:hover { background: #f9fafb; color: #111827; }
  &.danger:hover { background: #fef2f2; color: #ef4444; }
`;

const NotifDropdown = styled(TopDropdown)`width: 300px;`;
const NotifItem = styled.div`
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
  &:hover { background: #f9fafb; }
`;
const NotifTitle = styled.div`font-size: 0.82rem; font-weight: 600; color: #111827; margin-bottom: 2px;`;
const NotifSub   = styled.div`font-size: 0.75rem; color: #9ca3af;`;
const NotifDivider = styled.div`height: 1px; background: #f3f4f6; margin: 4px 0;`;

/* ══════════════════════════════════════════════════════════════════════════════
   MAIN CONTENT WRAPPER
══════════════════════════════════════════════════════════════════════════════ */
const MainWrap = styled.main`
  margin-left: ${SIDEBAR_W};
  margin-top: 60px;
  min-height: calc(100vh - 60px);
  background: #f5f7fa;
  transition: margin-left 0.28s cubic-bezier(.4,0,.2,1);

  @media (max-width: 1024px) {
    margin-left: 0;
  }
`;

const ContentPad = styled.div`
  padding: 24px;
  @media (max-width: 640px) { padding: 16px; }
`;

/* ══════════════════════════════════════════════════════════════════════════════
   NAV CONFIG
══════════════════════════════════════════════════════════════════════════════ */
export const NAV_SECTIONS = [
  {
    label: 'Store',
    items: [
      { name: 'Products',          icon: '🛍️' },
      { name: 'My Products',       icon: '📦' },
      { name: 'Nearby Inventory',  icon: '📍' },
      { name: 'Cart',              icon: '🛒' },
    ],
  },
  {
    label: 'Operations',
    items: [
      { name: 'Purchase Requests', icon: '📄' },
      { name: 'Requests',          icon: '📋' },
      { name: 'Inventory',         icon: '📈' },
      { name: 'Orders',            icon: '🚚' },
    ],
  },
  {
    label: 'Communicate',
    items: [
      { name: 'Chat',              icon: '💬' },
      { name: 'Videos',            icon: '▶️' },
      { name: 'Ad Management',     icon: '📢' },
    ],
  },
  {
    label: 'Account',
    items: [
      { name: 'Profile',           icon: '👤' },
      { name: 'Settings',          icon: '⚙️' },
      { name: 'FAQs',              icon: '❓' },
      { name: 'Support',           icon: '🎧' },
    ],
  },
];

const MOCK_NOTIFS = [
  { title: 'New purchase request', sub: '2 min ago — Ravi Kumar sent a request' },
  { title: 'Order shipped', sub: '1 hr ago — ORD001234 is on the way' },
  { title: 'Ad campaign live', sub: '3 hrs ago — Your ad is now running' },
];

/* ══════════════════════════════════════════════════════════════════════════════
   MAIN LAYOUT COMPONENT
══════════════════════════════════════════════════════════════════════════════ */
const UserLayout = ({ activeTab, navHistory = [], navigateTo, onBack, children }) => {
  const [sidebarOpen,  setSidebarOpen]  = useState(false);
  const [profileOpen,  setProfileOpen]  = useState(false);
  const [notifOpen,    setNotifOpen]    = useState(false);
  const [sideProfileOpen, setSideProfileOpen] = useState(false);

  const profileRef  = useRef(null);
  const notifRef    = useRef(null);
  const sideProRef  = useRef(null);
  const dispatch    = useDispatch();
  const navigate    = useNavigate();

  /* close dropdowns on outside click */
  useEffect(() => {
    const handler = (e) => {
      if (profileRef.current  && !profileRef.current.contains(e.target))  setProfileOpen(false);
      if (notifRef.current    && !notifRef.current.contains(e.target))    setNotifOpen(false);
      if (sideProRef.current  && !sideProRef.current.contains(e.target))  setSideProfileOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login', { replace: true });
  };

  const go = (tab) => {
    navigateTo(tab);
    setSidebarOpen(false);
    setProfileOpen(false);
    setSideProfileOpen(false);
  };

  const userName = localStorage.getItem('user_name') || 'User';
  const initials = userName.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2) || 'U';

  return (
    <>
      <GlobalStyle />

      {/* ── SIDEBAR ─────────────────────────────────────────── */}
      <SidebarRoot $open={sidebarOpen}>
        <LogoArea>
          <LogoMark>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M9 12H15M12 9V15" stroke="#fff" strokeWidth="2.2" strokeLinecap="round"/>
            </svg>
          </LogoMark>
          <LogoText>Medi<em>Stox</em></LogoText>
        </LogoArea>

        <NavScroll>
          {NAV_SECTIONS.map(({ label, items }) => (
            <NavSection key={label}>
              <NavSectionLabel>{label}</NavSectionLabel>
              {items.map(({ name, icon }) => (
                <NavItem key={name} $active={activeTab === name} onClick={() => go(name)}>
                  <span className="nav-icon">{icon}</span>
                  {name}
                </NavItem>
              ))}
            </NavSection>
          ))}
        </NavScroll>

        {/* Sidebar bottom profile */}
        <SidebarFooter ref={sideProRef}>
          {sideProfileOpen && (
            <MiniDropdown>
              <MiniDropItem onClick={() => go('Profile')}>👤 Profile</MiniDropItem>
              <MiniDropItem onClick={() => go('Settings')}>⚙️ Settings</MiniDropItem>
              <div style={{ height: 1, background: '#f3f4f6', margin: '3px 0' }} />
              <MiniDropItem className="danger" onClick={handleLogout}>🚪 Log Out</MiniDropItem>
            </MiniDropdown>
          )}
          <SidebarProfileBtn onClick={() => setSideProfileOpen(p => !p)}>
            <SidebarAvatar>{initials}</SidebarAvatar>
            <div style={{ textAlign: 'left', minWidth: 0 }}>
              <div style={{ fontSize: '0.82rem', fontWeight: 600, color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {userName}
              </div>
              <div style={{ fontSize: '0.7rem', color: '#9ca3af' }}>Retailer</div>
            </div>
            <span style={{ marginLeft: 'auto', color: '#c4c9d4', fontSize: '0.65rem' }}>
              {sideProfileOpen ? '▲' : '▼'}
            </span>
          </SidebarProfileBtn>
        </SidebarFooter>
      </SidebarRoot>

      {/* Mobile overlay */}
      <Overlay $show={sidebarOpen} onClick={() => setSidebarOpen(false)} />

      {/* ── TOP BAR ─────────────────────────────────────────── */}
      <TopBarRoot>
        <TopLeft>
          {/* Hamburger */}
          <HamburgerBtn onClick={() => setSidebarOpen(o => !o)}>
            {sidebarOpen ? '✕' : '☰'}
          </HamburgerBtn>

          {/* Breadcrumb + active page title */}
          <div>
            {navHistory.length > 1 && (
              <Breadcrumb>
                {navHistory.map((tab, i) => (
                  <React.Fragment key={tab + i}>
                    <BreadcrumbItem
                      $current={i === navHistory.length - 1}
                      $clickable={i < navHistory.length - 1}
                      onClick={() => i < navHistory.length - 1 && onBack && onBack()}
                    >
                      {tab}
                    </BreadcrumbItem>
                    {i < navHistory.length - 1 && <BreadcrumbSep>›</BreadcrumbSep>}
                  </React.Fragment>
                ))}
              </Breadcrumb>
            )}
            <ActivePageTitle>{activeTab}</ActivePageTitle>
          </div>
        </TopLeft>

        <TopRight>
          {/* Cart shortcut */}
          <IconBtn title="Cart" onClick={() => go('Cart')}>🛒</IconBtn>

          {/* Notifications */}
          <div style={{ position: 'relative' }} ref={notifRef}>
            <IconBtn title="Notifications" onClick={() => { setNotifOpen(o => !o); setProfileOpen(false); }}>
              🔔
              <NotifDot />
            </IconBtn>
            {notifOpen && (
              <NotifDropdown>
                <div style={{ padding: '8px 12px 6px', borderBottom: '1px solid #f3f4f6', marginBottom: 4 }}>
                  <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#111827' }}>Notifications</span>
                  <span style={{ float: 'right', fontSize: '0.72rem', color: ACCENT1, cursor: 'pointer' }}>Mark all read</span>
                </div>
                {MOCK_NOTIFS.map((n, i) => (
                  <React.Fragment key={i}>
                    <NotifItem>
                      <NotifTitle>{n.title}</NotifTitle>
                      <NotifSub>{n.sub}</NotifSub>
                    </NotifItem>
                    {i < MOCK_NOTIFS.length - 1 && <NotifDivider />}
                  </React.Fragment>
                ))}
              </NotifDropdown>
            )}
          </div>

          <Divider />

          {/* Profile */}
          <div style={{ position: 'relative' }} ref={profileRef}>
            <TopProfileBtn onClick={() => { setProfileOpen(o => !o); setNotifOpen(false); }}>
              <TopAvatar>{initials}</TopAvatar>
              <TopProfileName>{userName}</TopProfileName>
              <span style={{ fontSize: '0.6rem', color: '#9ca3af', marginLeft: 2 }}>▼</span>
            </TopProfileBtn>
            {profileOpen && (
              <TopDropdown>
                <div style={{ padding: '8px 12px 10px', borderBottom: '1px solid #f3f4f6', marginBottom: 4 }}>
                  <div style={{ fontSize: '0.84rem', fontWeight: 700, color: '#111827' }}>{userName}</div>
                  <div style={{ fontSize: '0.73rem', color: '#9ca3af' }}>Retailer Account</div>
                </div>
                <TopDropItem onClick={() => go('Profile')}>👤 My Profile</TopDropItem>
                <TopDropItem onClick={() => go('Settings')}>⚙️ Settings</TopDropItem>
                <TopDropItem onClick={() => go('FAQs')}>❓ FAQs</TopDropItem>
                <TopDropItem onClick={() => go('Support')}>🎧 Support</TopDropItem>
                <div style={{ height: 1, background: '#f3f4f6', margin: '4px 0' }} />
                <TopDropItem className="danger" onClick={handleLogout}>🚪 Log Out</TopDropItem>
              </TopDropdown>
            )}
          </div>
        </TopRight>
      </TopBarRoot>

      {/* ── MAIN CONTENT ────────────────────────────────────── */}
      <MainWrap>
        <ContentPad>
          {children}
        </ContentPad>
      </MainWrap>
    </>
  );
};

export default UserLayout;