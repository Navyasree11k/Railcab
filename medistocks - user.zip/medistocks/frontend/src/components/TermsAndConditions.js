import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import axios from 'axios';
import BaseUrl from './BaseUrl';

// --- Styled Components ---
const GlassmorphismContainer = styled.div`
  background-color: #fff;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(55, 65, 81, 0.8);
  border-radius: 1rem;
  padding: 1.5rem;
`;

const TermsContent = styled.div`
  padding-right: 1rem; /* space for potential scrollbar */
`;

const CheckboxLabel = styled.label`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  cursor: pointer;
`;

// --- Main Terms & Conditions Component ---
const TermsAndConditions = ({ onContinue, navigateTo }) => {
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [agreedPromotions, setAgreedPromotions] = useState(false);
  const [terms, setTerms] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTerms = async () => {
      try {
        const response = await axios.get(`${BaseUrl}/terms/`);
        if (response.data) {
          setTerms(response.data);
        }
      } catch (err) {
        console.error('Error fetching terms:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchTerms();
  }, []);

  return (
    <div
      className="container-fluid d-flex justify-content-center align-items-center"
      style={{ minHeight: '100vh' }}
    >
      <div style={{ width: '100%', maxWidth: '100%' }}>
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2 className="text-dark fw-bold mb-1">Terms & Conditions</h2>
            <p className="text-secondary">Please read carefully</p>
          </div>
          <button className="btn btn-outline-secondary">?</button>
        </div>

        <GlassmorphismContainer>
          <div className="mb-3">
            <p className="text-secondary small mb-1">
              Almost done! Accept terms to continue (9/10)
            </p>
            <div
              className="progress"
              style={{ height: '8px', backgroundColor: '#374151' }}
            >
              <div
                className="progress-bar"
                role="progressbar"
                style={{ width: '90%', backgroundColor: '#0ea5e9' }}
                aria-valuenow="90"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>

          <hr className="border-secondary" />

          <TermsContent>
            {loading ? (
              <p className="text-secondary text-center p-5">Loading terms...</p>
            ) : terms ? (
              <>
                <h5 className="text-dark">{terms.title || 'Pharmacy Deals Agreement'}</h5>
                <p className="text-secondary small">Last updated: {new Date(terms.updated_at || terms.created_at).toLocaleDateString()}</p>
                <div 
                  className="text-secondary mt-3" 
                  dangerouslySetInnerHTML={{ __html: (terms.content || '').replace(/\n/g, '<br/>') }} 
                />
              </>
            ) : (
              <>
                <h5 className="text-dark">Pharmacy Deals Agreement</h5>
                <p className="text-secondary small">Last updated: December 2024</p>

                <h6>1. Acceptance of Terms</h6>
                <p className="text-secondary">
                  By accessing and using Pharmacy Deals mobile application, you
                  accept and agree to be bound by the terms and provision of this
                  agreement. If you do not agree to abide by the above, please do
                  not use this service.
                </p>

                <h6>2. Service Description</h6>
                <p className="text-secondary">
                  Pharmacy Deals is a platform that connects pharmaceutical
                  distributors and retail shops for trading pharmacy products at
                  discounted rates before expiration. All transactions are subject
                  to verification and approval processes.
                </p>

                <h6>3. User Responsibilities</h6>
                <ul className="text-secondary">
                  <li>
                    Users must provide accurate information during registration and
                    maintain the confidentiality of their account credentials.
                  </li>
                  <li>Provide valid business documents.</li>
                  <li>Maintain professional conduct.</li>
                  <li>Comply with local pharmacy regulations.</li>
                </ul>
              </>
            )}
          </TermsContent>

          <hr className="border-secondary" />

          <div className="d-flex flex-column gap-3">
            <CheckboxLabel>
              <input
                type="checkbox"
                className="form-check-input"
                checked={agreedTerms}
                onChange={() => setAgreedTerms(!agreedTerms)}
              />
              <span className="text-dark">
                I have read and agree to the Terms & Conditions and Privacy
                Policy
              </span>
            </CheckboxLabel>
            <CheckboxLabel>
              <input
                type="checkbox"
                className="form-check-input"
                checked={agreedPromotions}
                onChange={() => setAgreedPromotions(!agreedPromotions)}
              />
              <span className="text-dark">
                I agree to receive promotional emails and notifications about
                deals and offers
              </span>
            </CheckboxLabel>
          </div>

          <div className="d-grid mt-4">
            <button
              className="btn btn-primary fw-bold p-3"
              style={{ backgroundColor: '#0ea5e9', borderColor: '#0ea5e9' }}
              disabled={!agreedTerms}
              onClick={onContinue}
            >
              Continue to Dashboard
            </button>
          </div>
        </GlassmorphismContainer>
      </div>
    </div>
  );
};

export default TermsAndConditions;
