import React, { useState, useEffect, useMemo, useCallback } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import { FaPlus, FaEdit, FaTrash, FaTimes, FaSearch, FaShoppingCart } from 'react-icons/fa';
import axios from 'axios';
import BaseUrl from './BaseUrl';

// --- PHARMACY THEME TOKENS ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

// --- Global Styles (improved) ---
const GlobalStyle = createGlobalStyle`
  body {
    background-color: ${LIGHT_GREEN};
    color: ${DARK_NAVY};
  }
`;

// --- Animations (unchanged) ---
const fadeIn = keyframes`from { opacity: 0; } to { opacity: 1; }`;
const slideUp = keyframes`from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; }`;

// --- Styled Components (improved, responsive) ---
const PageContainer = styled.div`
  padding: 1rem;
  margin: auto;
  animation: ${fadeIn} 0.5s ease-in-out;
  background: ${LIGHT_GREEN};
  min-height: 100vh;

  @media (min-width: 768px) {
    padding: 2rem;
    max-width: 1600px;
  }
`;

const Header = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 1rem;
  margin-bottom: 1.5rem;

  @media (min-width: 768px) {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }
`;

const Title = styled.h1`
  font-size: 1.75rem;
  font-weight: 700;
  margin: 0;
  color: ${DARK_NAVY};
  letter-spacing: -0.3px;

  @media (min-width: 768px) {
    font-size: 2.25rem;
  }
`;

const AddButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: ${PHARMACY_GREEN};
  color: white;
  border: none;
  border-radius: 40px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  width: 100%;
  box-shadow: 0 4px 10px rgba(13,124,61,0.2);

  &:hover {
    background: #0a5e2e;
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(13,124,61,0.3);
  }

  @media (min-width: 768px) {
    width: auto;
  }
`;

const FilterControls = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 1.5rem;
  padding: 1rem;
  background: white;
  border-radius: 1rem;
  box-shadow: ${CARD_SHADOW};
  border: 1px solid ${BORDER_GREY};

  @media (min-width: 768px) {
    flex-direction: row;
    align-items: center;
  }
`;

const SearchInputContainer = styled.div`
  position: relative;
  flex-grow: 1;
`;

const SearchInput = styled.input`
  width: 100%;
  padding: 0.75rem 1rem 0.75rem 2.5rem;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 40px;
  font-size: 0.9rem;
  transition: all 0.2s;
  &:focus {
    outline: none;
    border-color: ${PHARMACY_GREEN};
    box-shadow: 0 0 0 3px ${PHARMACY_GREEN}20;
  }
`;

const SearchIcon = styled(FaSearch)`
  position: absolute;
  left: 1rem;
  top: 50%;
  transform: translateY(-50%);
  color: #8b96a5;
`;

const ToggleContainer = styled.label`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-weight: 500;
  cursor: pointer;
  color: ${DARK_NAVY};
  font-size: 0.9rem;
  input {
    width: 18px;
    height: 18px;
    accent-color: ${PHARMACY_GREEN};
  }
`;

const TableContainer = styled.div`
  background: white;
  border-radius: 1.25rem;
  box-shadow: ${CARD_SHADOW};
  overflow-x: auto;
  width: 100%;
  border: 1px solid ${BORDER_GREY};
`;

const StyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  min-width: 900px;

  th, td {
    padding: 1rem 1.25rem;
    text-align: left;
    vertical-align: middle;
  }

  th {
    background-color: ${LIGHT_GREEN};
    font-weight: 700;
    color: ${DARK_NAVY};
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  tbody tr {
    border-top: 1px solid ${BORDER_GREY};
    transition: background-color 0.2s;
  }

  tbody tr:nth-child(even) {
    background-color: #fafafa;
  }

  tbody tr:hover {
    background-color: ${LIGHT_GREEN};
  }

  tr[style*="#fff3cd"] {
    background-color: #fff9e6 !important;
    color: #856404;
  }
  tr[style*="#f8d7da"] {
    background-color: #fee2e2 !important;
    color: #c0392b;
  }

  @media (max-width: 992px) {
    .hide-on-mobile {
      display: none;
    }
    th, td {
      padding: 0.75rem 0.75rem;
      font-size: 0.8rem;
    }
    min-width: 0;
    width: 100%;
  }
`;

const StatusBadge = styled.span`
  padding: 0.3rem 0.8rem;
  border-radius: 40px;
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: capitalize;
  color: white;
  background-color: ${({ status }) => {
    if (status === 'near_expiry') return '#f39c12';
    if (status === 'expired') return '#c0392b';
    return PHARMACY_GREEN;
  }};
`;

const ProductImage = styled.img`
  width: 50px;
  height: 50px;
  object-fit: cover;
  border-radius: 12px;
  border: 1px solid ${BORDER_GREY};
  @media (min-width: 992px) {
    width: 60px;
    height: 60px;
  }
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 0.25rem;
  @media (min-width: 992px) {
    gap: 0.5rem;
  }
`;

const ActionButton = styled.button`
  background: none;
  border: none;
  cursor: pointer;
  color: #6c757d;
  font-size: 1rem;
  padding: 0.5rem;
  border-radius: 40px;
  transition: all 0.2s;
  
  @media (min-width: 992px) {
    font-size: 1.1rem;
  }

  &:hover {
    &.sell { color: ${PHARMACY_GREEN}; background: ${PHARMACY_GREEN}10; }
    &.edit { color: ${PHARMACY_GREEN}; background: ${PHARMACY_GREEN}10; }
    &.delete { color: #c0392b; background: #fee2e2; }
  }
`;

// --- MODALS (improved styling) ---
const ModalBackdrop = styled.div`
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(5px);
  display: flex; justify-content: center; align-items: center;
  z-index: 1000;
  animation: ${fadeIn} 0.3s;
  padding: 1rem;
`;

const ModalContent = styled.div`
  background: white;
  border-radius: 1.5rem;
  width: 100%;
  max-width: 700px;
  box-shadow: ${HOVER_SHADOW};
  animation: ${slideUp} 0.4s;
  display: flex;
  flex-direction: column;
  max-height: 90vh;
  border: 1px solid ${BORDER_GREY};
`;

const ModalHeader = styled.div`
  padding: 1rem 1.5rem;
  border-bottom: 1px solid ${BORDER_GREY};
  position: relative;
  h2 {
    margin: 0;
    font-size: 1.25rem;
    color: ${DARK_NAVY};
    font-weight: 700;
  }
  @media (min-width: 768px) {
    padding: 1.5rem 2rem;
    h2 { font-size: 1.5rem; }
  }
`;

const ModalBody = styled.div`
  padding: 1.5rem;
  overflow-y: auto;
  @media (min-width: 768px) {
    padding: 2rem;
  }
`;

const ModalFooter = styled.div`
  padding: 1rem 1.5rem;
  border-top: 1px solid ${BORDER_GREY};
  background: ${LIGHT_GREEN};
  border-radius: 0 0 1.5rem 1.5rem;
  @media (min-width: 768px) {
    padding: 1rem 2rem;
  }
`;

const CloseButton = styled.button`
  position: absolute;
  top: 50%;
  right: 1rem;
  transform: translateY(-50%);
  background: none;
  border: none;
  font-size: 1.25rem;
  color: #8b96a5;
  cursor: pointer;
  transition: color 0.2s;
  &:hover { color: ${DARK_NAVY}; }
  @media (min-width: 768px) {
    right: 1.5rem;
  }
`;

const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;

const FormLabel = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 700;
  color: ${DARK_NAVY};
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`;

const FormInput = styled.input`
  width: 100%;
  padding: 0.75rem;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 12px;
  font-size: 0.9rem;
  transition: all 0.2s;
  &:focus {
    outline: none;
    border-color: ${PHARMACY_GREEN};
    box-shadow: 0 0 0 3px ${PHARMACY_GREEN}20;
  }
`;

const FormRow = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 1rem;
  @media (min-width: 576px) {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  }
`;

const SubmitButton = styled(AddButton)`
  width: 100%;
  justify-content: center;
  font-size: 0.9rem;
`;

// --- API URL ---
const API_URL = BaseUrl;

const InventoryTable = () => {
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isSellModalOpen, setIsSellModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentItem, setCurrentItem] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showExpiringSoon, setShowExpiringSoon] = useState(false);
  const [formData, setFormData] = useState({});
  const [file, setFile] = useState(null);

  const fetchInventory = useCallback(async () => {
    try {
      const userId = localStorage.getItem('user_id') || '1'; 
      setLoading(true);
      const response = await axios.get(`${API_URL}/billing/get-user-billing-records/${userId}`);
      setInventory(response.data.records || []);
      setError(null);
    } catch (err) {
      setError('Failed to fetch inventory. Please try again later.');
      setInventory([]);
    } finally {
      setLoading(false);
    }
  }, []);
  
  useEffect(() => {
    fetchInventory();
  }, [fetchInventory]);

  const filteredInventory = useMemo(() => {
    if (!Array.isArray(inventory)) return [];
    return inventory
      .filter(item => 
        item.tablet_name && item.tablet_name.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .filter(item => showExpiringSoon ? item.status === 'near_expiry' : true);
  }, [inventory, searchTerm, showExpiringSoon]);
  
  const handleOpenEditModal = (item = null) => {
    if (item) {
      setIsEditMode(true);
      setCurrentItem(item);
      setFormData({
        tablet_name: item.tablet_name || '',
        brand: item.brand || '',
        quantity: item.quantity || 0,
        unit_cost: item.unit_cost || 0.0,
        discount_percentage: item.discount_percentage || 0.0,
        expiry_date: item.expiry_date ? item.expiry_date.split('T')[0] : '',
        batch_number: item.batch_number || '',
      });
    } else {
      setIsEditMode(false);
      setCurrentItem(null);
      setFormData({
        user_id: localStorage.getItem('user_id') || '1',
        tablet_name: '', brand: '', quantity: '', unit_cost: '',
        discount_percentage: '', expiry_date: '', batch_number: '',
      });
    }
    setFile(null);
    setIsEditModalOpen(true);
  };

  const handleOpenSellModal = (item) => {
    setCurrentItem(item);
    setFormData({
        user_id: localStorage.getItem('user_id') || '1',
        'basic_information[tablet_name]': item.tablet_name,
        'basic_information[brand]': item.brand || '',
        'basic_information[quantity]': item.quantity,
        'pricing_discounts[original_price]': item.unit_cost,
        'important_dates[expiry_date]': item.expiry_date ? item.expiry_date.split('T')[0] : '',
        'additional_details[batch_number]': item.batch_number,
        'pricing_discounts[discount]': '10',
    });
    setFile(null);
    setIsSellModalOpen(true);
  };
  
  const handleCloseModals = () => {
    setIsEditModalOpen(false);
    setIsSellModalOpen(false);
  };
  
  const handleInputChange = (e) => setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  const handleFileChange = (e) => setFile(e.target.files[0]);

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    Object.keys(formData).forEach(key => data.append(key, formData[key]));
    if (file) data.append('file', file);

    try {
      if (isEditMode) {
        await axios.put(`${API_URL}/billing/myinventory/${currentItem.id}`, data);
      } else {
        if (!file) {
          alert("Product image is required for a new item.");
          return;
        }
        await axios.post(`${API_URL}/billing/myinventory`, data);
      }
      fetchInventory();
      handleCloseModals();
    } catch (err) {
      alert(`Error: ${err.response?.data?.error || 'Could not save item.'}`);
    }
  };

  const handleSellSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
        alert("A product image is required to create a listing.");
        return;
    }
    const data = new FormData();
    Object.keys(formData).forEach(key => data.append(key, formData[key]));
    data.append('file', file);

    try {
        await axios.post(`${API_URL}/products/product`, data);
        alert(`Successfully listed "${formData['basic_information[tablet_name]']}" for sale!`);
        handleCloseModals();
    } catch (err) {
        alert(`Error: ${err.response?.data?.error || 'Could not list product for sale.'}`);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      try {
        await axios.delete(`${API_URL}/billing/myinventory/${id}`);
        fetchInventory();
      } catch (err) {
        alert('Could not delete item.');
      }
    }
  };

  return (
    <>
      <GlobalStyle />
      <PageContainer>
        <Header>
          <Title>Inventory Management</Title>
          <AddButton onClick={() => handleOpenEditModal()}>
            <FaPlus /> Add New Item
          </AddButton>
        </Header>

        <FilterControls>
          <SearchInputContainer>
            <SearchIcon />
            <SearchInput
              type="text"
              placeholder="Search by tablet name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </SearchInputContainer>
          <ToggleContainer>
            <input
              type="checkbox"
              checked={showExpiringSoon}
              onChange={(e) => setShowExpiringSoon(e.target.checked)}
            />
            Show Expiring Soon
          </ToggleContainer>
        </FilterControls>
        
        <TableContainer>
          <StyledTable>
            <thead>
              <tr>
                <th>Image</th>
                <th>Tablet Name</th>
                <th className="hide-on-mobile">Brand</th>
                <th>Status</th>
                <th>Quantity</th>
                <th className="hide-on-mobile">Unit Cost</th>
                <th className="hide-on-mobile">Discount</th>
                <th className="hide-on-mobile">Total Value</th>
                <th className="hide-on-mobile">Batch No.</th>
                <th>Expiry Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="11" style={{ textAlign: 'center', padding: '1.25rem' }}>Loading...</td></tr>
              ) : error ? (
                <tr><td colSpan="11" style={{ textAlign: 'center', padding: '1.25rem', color: '#c0392b' }}>{error}</td></tr>
              ) : (
                filteredInventory.length > 0 ? filteredInventory.map(item => (
                  <tr key={item.id} style={{
                    backgroundColor: item.status === 'near_expiry' ? '#fff9e6' : item.status === 'expired' ? '#fee2e2' : undefined
                  }}>
                    <td><ProductImage src={item.image_url || 'https://via.placeholder.com/60'} alt={item.tablet_name} /></td>
                    <td>{item.tablet_name}</td>
                    <td className="hide-on-mobile">{item.brand || 'N/A'}</td>
                    <td><StatusBadge status={item.status}>{item.status.replace('_', ' ')}</StatusBadge></td>
                    <td>{item.quantity}</td>
                    <td className="hide-on-mobile">₹{item.unit_cost.toFixed(2)}</td>
                    <td className="hide-on-mobile">{item.discount_percentage}%</td>
                    <td className="hide-on-mobile">₹{item.total_amount.toFixed(2)}</td>
                    <td className="hide-on-mobile">{item.batch_number || 'N/A'}</td>
                    <td>{item.expiry_date ? new Date(item.expiry_date).toLocaleDateString() : 'N/A'}</td>
                    <td>
                      <ActionButtons>
                        <ActionButton className="sell" title="Sell Item" onClick={() => handleOpenSellModal(item)}><FaShoppingCart /></ActionButton>
                        <ActionButton className="edit" title="Edit Item" onClick={() => handleOpenEditModal(item)}><FaEdit /></ActionButton>
                        <ActionButton className="delete" title="Delete Item" onClick={() => handleDelete(item.id)}><FaTrash /></ActionButton>
                      </ActionButtons>
                    </td>
                  </tr>
                )) : (
                  <tr><td colSpan="11" style={{ textAlign: 'center', padding: '1.25rem' }}>No inventory found. Add your first item to get started.</td></tr>
                )
              )}
            </tbody>
          </StyledTable>
        </TableContainer>
      </PageContainer>
      
      {/* Edit/Add Modal */}
      {isEditModalOpen && (
        <ModalBackdrop onClick={handleCloseModals}>
          <ModalContent onClick={e => e.stopPropagation()}>
            <ModalHeader>
              <h2>{isEditMode ? 'Edit Item' : 'Add New Item'}</h2>
              <CloseButton onClick={handleCloseModals}><FaTimes /></CloseButton>
            </ModalHeader>
            <ModalBody>
              <form id="edit-form" onSubmit={handleEditSubmit}>
                <FormRow>
                  <FormGroup><FormLabel>Tablet Name</FormLabel><FormInput name="tablet_name" value={formData.tablet_name} onChange={handleInputChange} required /></FormGroup>
                  <FormGroup><FormLabel>Brand</FormLabel><FormInput name="brand" value={formData.brand} onChange={handleInputChange} /></FormGroup>
                </FormRow>
                <FormRow>
                  <FormGroup><FormLabel>Batch Number</FormLabel><FormInput name="batch_number" value={formData.batch_number} onChange={handleInputChange} /></FormGroup>
                  <FormGroup><FormLabel>Quantity</FormLabel><FormInput name="quantity" type="number" value={formData.quantity} onChange={handleInputChange} required /></FormGroup>
                </FormRow>
                <FormRow>
                  <FormGroup><FormLabel>Unit Cost (₹)</FormLabel><FormInput name="unit_cost" type="number" step="0.01" value={formData.unit_cost} onChange={handleInputChange} required /></FormGroup>
                  <FormGroup><FormLabel>Discount (%)</FormLabel><FormInput name="discount_percentage" type="number" step="0.01" value={formData.discount_percentage} onChange={handleInputChange} /></FormGroup>
                  <FormGroup><FormLabel>Expiry Date</FormLabel><FormInput name="expiry_date" type="date" value={formData.expiry_date} onChange={handleInputChange} /></FormGroup>
                </FormRow>
                <FormGroup>
                  <FormLabel>Product Image {isEditMode && "(Leave blank to keep existing)"}</FormLabel>
                  <FormInput type="file" onChange={handleFileChange} />
                </FormGroup>
              </form>
            </ModalBody>
            <ModalFooter>
              <SubmitButton type="submit" form="edit-form">{isEditMode ? 'Save Changes' : 'Add to Inventory'}</SubmitButton>
            </ModalFooter>
          </ModalContent>
        </ModalBackdrop>
      )}

      {/* Sell Modal */}
      {isSellModalOpen && (
        <ModalBackdrop onClick={handleCloseModals}>
          <ModalContent onClick={e => e.stopPropagation()}>
            <ModalHeader>
              <h2>List Product for Sale</h2>
              <CloseButton onClick={handleCloseModals}><FaTimes /></CloseButton>
            </ModalHeader>
            <ModalBody>
              <form id="sell-form" onSubmit={handleSellSubmit}>
                <p style={{ marginBottom: '1rem', color: DARK_NAVY }}>You are listing <strong>{currentItem?.tablet_name}</strong> for sale. Please confirm the details for the listing.</p>
                <FormRow>
                  <FormGroup><FormLabel>Brand Name</FormLabel><FormInput name="basic_information[brand]" value={formData['basic_information[brand]']} onChange={handleInputChange} required /></FormGroup>
                  <FormGroup><FormLabel>Quantity to Sell</FormLabel><FormInput name="basic_information[quantity]" type="number" max={currentItem?.quantity} value={formData['basic_information[quantity]']} onChange={handleInputChange} required /></FormGroup>
                </FormRow>
                <FormRow>
                  <FormGroup><FormLabel>Sale Price (₹)</FormLabel><FormInput name="pricing_discounts[original_price]" type="number" step="0.01" value={formData['pricing_discounts[original_price]']} onChange={handleInputChange} required /></FormGroup>
                  <FormGroup><FormLabel>Discount (%)</FormLabel><FormInput name="pricing_discounts[discount]" type="text" placeholder="e.g. 10,20" value={formData['pricing_discounts[discount]']} onChange={handleInputChange} /></FormGroup>
                </FormRow>
                <FormGroup>
                  <FormLabel>Product Image for Listing</FormLabel>
                  <FormInput type="file" onChange={handleFileChange} required />
                </FormGroup>
              </form>
            </ModalBody>
            <ModalFooter>
              <SubmitButton type="submit" form="sell-form">List for Sale</SubmitButton>
            </ModalFooter>
          </ModalContent>
        </ModalBackdrop>
      )}
    </>
  );
};

export default InventoryTable;