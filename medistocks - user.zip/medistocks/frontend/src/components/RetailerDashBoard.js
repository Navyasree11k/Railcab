import React, { useState, useMemo, useEffect, useRef } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { logout } from './redux/authSlice';
import BaseUrl from './BaseUrl';
import GenerateInvoice from './GenerateInvoice';
import Chat from './RetailerChat';
import Videos from './RetailerVideos';
import Requests from './RetailerRequests';
import AiDemandForecast from './RetailerAIDemandForeCast';
import NearbyInventory from './RetailerNearByInventory';
import Orders from './RetailerOrders';
import Cart from './RetailerCart';
import Profile from './RetailerProfile';
import ProductDetails from './RetailerProductDetails';
import Billing from './DistibutorMyInventory';
import Support from './RetailerCustomerSupport';
import FAQ from './Faq';
import TermsAndConditions from './TermsAndConditions';
import Settings from './RetailerSettingsPage';
import RetailerMyProducts from './RetailerMyProducts';
import RetailerAddNewProduct from './RetailerAddNewProduct';
import AdManagement from './AdManagment';
import IncomingRequests from './DistributorRequests';
import ChatSupportPage from './Chat_support';

/* ─────────────────────────────────────────────────────
   PHARMACY THEME TOKENS
───────────────────────────────────────────────────── */
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';
const ACCENT_GRADIENT = `linear-gradient(135deg, ${PHARMACY_GREEN} 0%, #0F9D4E 100%)`;

/* ─────────────────────────────────────────────────────
   GLOBAL
───────────────────────────────────────────────────── */
const GlobalStyle = createGlobalStyle`
  *, *::before, *::after { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: ${LIGHT_GREEN};
    color: ${DARK_NAVY};
  }
  ::-webkit-scrollbar { width: 5px; height: 5px; }
  ::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 10px; }
  ::-webkit-scrollbar-thumb { background: ${PHARMACY_GREEN}; border-radius: 10px; }
`;

/* ─────────────────────────────────────────────────────
   ANIMATIONS
───────────────────────────────────────────────────── */
const slideInLeft = keyframes`from{opacity:0;transform:translateX(-8px)}to{opacity:1;transform:translateX(0)}`;
const dropDown    = keyframes`from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}`;
const fadeIn      = keyframes`from{opacity:0}to{opacity:1}`;
const slideUp     = keyframes`from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}`;
const bounceIn    = keyframes`0%{transform:scale(.85);opacity:0}60%{transform:scale(1.02)}100%{transform:scale(1);opacity:1}`;

/* ─────────────────────────────────────────────────────
   SIDEBAR (improved)
───────────────────────────────────────────────────── */
const Sidebar = styled.aside`
  position: fixed;
  top: 0; left: 0;
  width: 260px;
  height: 100vh;
  background: white;
  border-right: 1px solid ${BORDER_GREY};
  display: flex;
  flex-direction: column;
  z-index: 200;
  transition: transform 0.28s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 2px 0 12px rgba(0,0,0,0.03);

  @media (max-width: 1024px) {
    transform: translateX(${p => p.$open ? '0' : '-100%'});
  }
`;

const LogoArea = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 20px 18px 16px;
  border-bottom: 1px solid ${BORDER_GREY};
`;

const LogoMark = styled.div`
  width: 36px; height: 36px;
  border-radius: 12px;
  background: ${ACCENT_GRADIENT};
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 4px 10px rgba(13,124,61,0.25);
  flex-shrink: 0;
`;

const LogoText = styled.span`
  font-size: 1.1rem; font-weight: 800; color: ${DARK_NAVY}; letter-spacing: -0.3px;
  em { color: ${PHARMACY_GREEN}; font-style: normal; }
`;

const NavScroll = styled.nav`
  flex: 1; overflow-y: auto; padding: 12px 8px;
  display: flex; flex-direction: column; gap: 2px;
  &::-webkit-scrollbar { width: 3px; }
`;

const NavGroup = styled.div`margin-top: 16px; &:first-child { margin-top: 4px; }`;

const NavGroupLabel = styled.p`
  font-size: 0.65rem; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.8px; color: #8b96a5; padding: 0 10px; margin: 0 0 6px;
`;

const NavBtn = styled.button`
  width: 100%;
  display: flex; align-items: center; gap: 12px;
  padding: 10px 12px; border-radius: 12px; border: none;
  background: ${p => p.$active ? `${PHARMACY_GREEN}10` : 'transparent'};
  color: ${p => p.$active ? PHARMACY_GREEN : '#5a6b7a'};
  font-family: 'Inter', sans-serif;
  font-size: 0.85rem; font-weight: ${p => p.$active ? 700 : 500};
  cursor: pointer; text-align: left; transition: all 0.2s;
  border: 1px solid ${p => p.$active ? `${PHARMACY_GREEN}30` : 'transparent'};
  position: relative;
  animation: ${slideInLeft} 0.2s ease both;

  .nav-icon { font-size: 1rem; flex-shrink: 0; }

  ${p => p.$active && `
    &::before {
      content: '';
      position: absolute; left: -4px; top: 18%; height: 64%; width: 3px;
      background: ${PHARMACY_GREEN}; border-radius: 0 4px 4px 0;
    }
  `}
  &:hover { background: ${LIGHT_GREEN}; color: ${DARK_NAVY}; }
`;

const SidebarFooter = styled.div`
  border-top: 1px solid ${BORDER_GREY}; padding: 12px 8px; position: relative;
`;

const SidebarProfileBtn = styled.button`
  width: 100%; display: flex; align-items: center; gap: 12px;
  padding: 8px 12px; border-radius: 12px; border: none;
  background: transparent; cursor: pointer; transition: background 0.15s;
  &:hover { background: ${LIGHT_GREEN}; }
`;

const AvatarBox = styled.div`
  width: ${p => p.$size || '36px'}; height: ${p => p.$size || '36px'};
  border-radius: ${p => p.$round ? '50%' : '12px'};
  background: ${ACCENT_GRADIENT};
  display: flex; align-items: center; justify-content: center;
  font-weight: 800; font-size: ${p => p.$fs || '0.85rem'};
  color: white; flex-shrink: 0;
`;

const MiniDrop = styled.div`
  position: absolute; bottom: calc(100% + 8px); left: 8px; right: 8px;
  background: white; border: 1px solid ${BORDER_GREY}; border-radius: 16px;
  padding: 6px; box-shadow: ${HOVER_SHADOW};
  z-index: 300; animation: ${dropDown} 0.15s ease;
`;

const DropItem = styled.button`
  width: 100%; display: flex; align-items: center; gap: 10px;
  padding: 10px 12px; border-radius: 10px; border: none;
  background: none; color: ${DARK_NAVY}; font-size: 0.85rem;
  font-family: 'Inter', sans-serif;
  cursor: pointer; text-align: left;
  &:hover { background: ${LIGHT_GREEN}; }
  &.danger:hover { background: #fee2e2; color: #c0392b; }
`;

const MobileOverlay = styled.div`
  display: none;
  @media (max-width: 1024px) {
    display: ${p => p.$show ? 'block' : 'none'};
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.4); z-index: 199;
    animation: ${fadeIn} 0.2s ease;
  }
`;

/* ─────────────────────────────────────────────────────
   TOP BAR (improved)
───────────────────────────────────────────────────── */
const TopBar = styled.header`
  position: fixed; top: 0;
  left: 260px; right: 0; height: 64px;
  background: rgba(255,255,255,0.98);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid ${BORDER_GREY};
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 28px; z-index: 100;
  box-shadow: 0 2px 8px rgba(0,0,0,0.02);
  transition: left 0.28s cubic-bezier(0.4,0,0.2,1);

  @media (max-width: 1024px) { left: 0; padding: 0 20px; }
`;

const TopLeft = styled.div`display: flex; align-items: center; gap: 12px;`;

const HamBtn = styled.button`
  display: none; background: none; border: none; cursor: pointer;
  padding: 8px; border-radius: 12px; color: ${DARK_NAVY}; font-size: 1.2rem;
  transition: background 0.15s; &:hover { background: ${LIGHT_GREEN}; }
  @media (max-width: 1024px) { display: flex; align-items: center; }
`;

const Breadcrumb = styled.div`display: flex; align-items: center; gap: 6px; margin-bottom: 2px;`;
const BCItem = styled.span`
  font-size: 0.75rem;
  color: ${p => p.$cur ? DARK_NAVY : '#8b96a5'};
  font-weight: ${p => p.$cur ? 700 : 400};
  cursor: ${p => p.$link ? 'pointer' : 'default'};
  &:hover { color: ${p => p.$link ? PHARMACY_GREEN : 'inherit'}; }
`;
const BCSep = styled.span`color: ${BORDER_GREY}; font-size: 0.7rem;`;

const PageTitleText = styled.h1`
  font-size: 1.1rem; font-weight: 800; color: ${DARK_NAVY}; margin: 0; letter-spacing: -0.2px;
`;

const TopRight = styled.div`display: flex; align-items: center; gap: 8px;`;

const IconBtn = styled.button`
  width: 40px; height: 40px; border-radius: 40px;
  border: none; background: transparent; color: #5a6b7a; font-size: 1.1rem;
  cursor: pointer; display: flex; align-items: center; justify-content: center;
  transition: all 0.2s; position: relative;
  &:hover { background: ${LIGHT_GREEN}; color: ${PHARMACY_GREEN}; }
`;

const NotifDot = styled.span`
  position: absolute; top: 8px; right: 8px;
  width: 8px; height: 8px; border-radius: 50%;
  background: #c0392b; border: 2px solid white;
`;

const VDivider = styled.div`width: 1px; height: 28px; background: ${BORDER_GREY}; margin: 0 4px;`;

const ProfileTopBtn = styled.button`
  display: flex; align-items: center; gap: 10px;
  padding: 6px 12px 6px 6px; border-radius: 40px;
  border: 1px solid ${BORDER_GREY}; background: white;
  cursor: pointer; transition: all 0.2s;
  &:hover { border-color: ${PHARMACY_GREEN}; background: ${LIGHT_GREEN}; }
`;

const ProfileName = styled.span`
  font-size: 0.85rem; font-weight: 600; color: ${DARK_NAVY};
  @media (max-width: 480px) { display: none; }
`;

const DropMenu = styled.div`
  position: absolute; top: calc(100% + 10px); right: 0;
  width: ${p => p.$w || '220px'};
  background: white; border: 1px solid ${BORDER_GREY};
  border-radius: 16px; padding: 8px;
  box-shadow: ${HOVER_SHADOW};
  z-index: 400; animation: ${dropDown} 0.15s ease;
`;

const TopDropItem = styled.button`
  width: 100%; display: flex; align-items: center; gap: 10px;
  padding: 10px 12px; border-radius: 12px; border: none;
  background: none; color: ${DARK_NAVY}; font-size: 0.85rem;
  font-family: 'Inter', sans-serif;
  cursor: pointer; text-align: left;
  &:hover { background: ${LIGHT_GREEN}; }
  &.danger:hover { background: #fee2e2; color: #c0392b; }
`;

const NotifDrop = styled(DropMenu)`width: 320px;`;
const NotifItem = styled.div`
  padding: 12px; border-radius: 12px; cursor: pointer;
  &:hover { background: ${LIGHT_GREEN}; }
`;

/* ─────────────────────────────────────────────────────
   BOTTOM NAV (mobile)
───────────────────────────────────────────────────── */
const BottomNav = styled.nav`
  display: none;
  @media (max-width: 1024px) {
    display: flex;
    position: fixed; bottom: 0; left: 0; right: 0;
    height: 68px;
    background: white;
    border-top: 1px solid ${BORDER_GREY};
    box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
    z-index: 150;
    align-items: stretch;
  }
`;

const BottomNavItem = styled.button`
  flex: 1;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 4px; border: none; background: transparent; cursor: pointer;
  padding: 8px 4px;
  position: relative;
  transition: all 0.2s;

  .bn-icon { font-size: 1.2rem; transition: transform 0.2s; }
  .bn-label {
    font-size: 0.6rem; font-weight: 700; letter-spacing: 0.3px;
    color: ${p => p.$active ? PHARMACY_GREEN : '#8b96a5'};
  }

  ${p => p.$active && `
    .bn-icon { transform: translateY(-2px); }
    &::after {
      content: '';
      position: absolute; top: 0; left: 20%; right: 20%; height: 3px;
      background: ${PHARMACY_GREEN}; border-radius: 0 0 4px 4px;
    }
  `}
  &:hover .bn-label { color: ${PHARMACY_GREEN}; }
`;

const MoreDrawer = styled.div`
  position: fixed; bottom: 68px; left: 0; right: 0;
  background: white; border-top: 1px solid ${BORDER_GREY};
  border-radius: 24px 24px 0 0;
  z-index: 151;
  padding: 20px 20px 16px;
  box-shadow: 0 -8px 24px rgba(0,0,0,0.08);
  animation: ${slideUp} 0.22s ease;
`;

const DrawerHandle = styled.div`
  width: 40px; height: 4px; border-radius: 2px;
  background: ${BORDER_GREY}; margin: 0 auto 20px;
`;

const DrawerTitle = styled.div`
  font-size: 0.7rem; font-weight: 800; text-transform: uppercase;
  letter-spacing: 0.8px; color: #8b96a5; margin-bottom: 12px; padding: 0 4px;
`;

const DrawerGrid = styled.div`
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px;
`;

const DrawerItem = styled.button`
  display: flex; flex-direction: column; align-items: center; gap: 6px;
  background: ${p => p.$active ? `${PHARMACY_GREEN}10` : LIGHT_GREEN};
  border: 1.5px solid ${p => p.$active ? `${PHARMACY_GREEN}40` : BORDER_GREY};
  border-radius: 16px; padding: 12px 6px; cursor: pointer; transition: all 0.2s;
  &:hover { border-color: ${PHARMACY_GREEN}; background: ${PHARMACY_GREEN}08; }
  .di-icon { font-size: 1.3rem; }
  .di-label { font-size: 0.65rem; font-weight: 700; color: ${p => p.$active ? PHARMACY_GREEN : DARK_NAVY}; text-align: center; }
`;

const DrawerOverlay = styled.div`
  position: fixed; inset: 0; background: rgba(0,0,0,0.3); z-index: 150;
  animation: ${fadeIn} 0.18s ease;
`;

/* ─────────────────────────────────────────────────────
   MAIN CONTENT AREA
───────────────────────────────────────────────────── */
const Main = styled.main`
  margin-left: 260px; margin-top: 64px;
  min-height: calc(100vh - 64px);
  background: ${LIGHT_GREEN};
  transition: margin-left 0.28s cubic-bezier(0.4,0,0.2,1);

  @media (max-width: 1024px) {
    margin-left: 0;
    padding-bottom: 76px;
  }
`;

const ContentPad = styled.div`
  padding: 28px;
  @media (max-width: 640px) { padding: 20px; }
`;

/* ─────────────────────────────────────────────────────
   NAV CONFIG (unchanged)
───────────────────────────────────────────────────── */
const NAV_SECTIONS = [
  { label: 'Store', items: [
    { name: 'Dashboard',         icon: '🏠' },
    { name: 'Products',         icon: '🛍️' },
    { name: 'My Products',      icon: '📦' },
    { name: 'Nearby Inventory', icon: '📍' },
    { name: 'Cart',             icon: '🛒' },
  ]},
  { label: 'Operations', items: [
    { name: 'Purchase Requests', icon: '📄' },
    { name: 'Requests',          icon: '📋' },
    { name: 'Inventory',         icon: '📈' },
    { name: 'Orders',            icon: '🚚' },
    { name: 'AI Demand Forecast',icon: '🤖' },
  ]},
  { label: 'Communicate', items: [
    { name: 'Chat',         icon: '💬' },
    { name: 'Videos',       icon: '▶️' },
    { name: 'Ad Management',icon: '📢' },
  ]},
  { label: 'Account', items: [
    { name: 'Profile',  icon: '👤' },
    { name: 'Settings', icon: '⚙️' },
    { name: 'FAQs',     icon: '❓' },
    { name: 'Support',  icon: '🎧' },
  ]},
];

const BOTTOM_NAV = [
  { name: 'Dashboard', icon: '🏠', label: 'Home'   },
  { name: 'Products',  icon: '🛍️', label: 'Shop'   },
  { name: 'Cart',      icon: '🛒', label: 'Cart'   },
  { name: 'Orders',    icon: '🚚', label: 'Orders' },
  { name: 'Profile',   icon: '👤', label: 'Profile'},
];

const DRAWER_SECTIONS = [
  { label: 'Store', items: [
    { name: 'My Products',      icon: '📦' },
    { name: 'Nearby Inventory', icon: '📍' },
  ]},
  { label: 'Operations', items: [
    { name: 'Purchase Requests', icon: '📄' },
    { name: 'Requests',          icon: '📋' },
    { name: 'Inventory',         icon: '📈' },
  ]},
  { label: 'Communicate', items: [
    { name: 'Videos',        icon: '▶️' },
    { name: 'Ad Management', icon: '📢' },
  ]},
  { label: 'Account', items: [
    { name: 'Settings', icon: '⚙️' },
    { name: 'FAQs',     icon: '❓' },
    { name: 'Support',  icon: '🎧' },
  ]},
];

const MOCK_NOTIFS = []; // Will be populated from API

/* ─────────────────────────────────────────────────────
   LAYOUT COMPONENT (improved)
───────────────────────────────────────────────────── */
const UserLayout = ({ activeTab, navHistory, navigateTo, onBack, children }) => {
  const [sidebarOpen,    setSidebarOpen]    = useState(false);
  const [profileOpen,    setProfileOpen]    = useState(false);
  const [notifOpen,      setNotifOpen]      = useState(false);
  const [sideProfOpen,   setSideProfOpen]   = useState(false);
  const [drawerOpen,     setDrawerOpen]     = useState(false);
  const [notifications,  setNotifications]  = useState([]);

  const profileRef = useRef(null);
  const notifRef   = useRef(null);
  const sideProRef = useRef(null);
  const dispatch   = useDispatch();
  const navigate   = useNavigate();

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const uid = localStorage.getItem('user_id');
        const response = await axios.get(`${BaseUrl}/notifications/list?role=Retailer`);
        const data = Array.isArray(response.data) ? response.data : (response.data.notifications || []);
        // Only show notifications targeted at this user
        setNotifications(uid ? data.filter(n => String(n.user_id) === String(uid) || n.audience_type === 'all') : data);
      } catch (err) {
        console.error('Error fetching notifications:', err);
      }
    };
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const h = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false);
      if (notifRef.current   && !notifRef.current.contains(e.target))   setNotifOpen(false);
      if (sideProRef.current && !sideProRef.current.contains(e.target)) setSideProfOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const handleLogout = () => { dispatch(logout()); navigate('/login', { replace: true }); };

  const go = (tab) => {
    navigateTo(tab);
    setSidebarOpen(false);
    setProfileOpen(false);
    setSideProfOpen(false);
    setDrawerOpen(false);
  };

  const userName = localStorage.getItem('user_name') || 'User';
  const initials = userName.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) || 'U';

  const dismissNotification = async (id) => {
    try {
      await axios.delete(`${BaseUrl}/notifications/delete/${id}`, {
        headers: { 'X-Admin-Token': 'secret123' }
      });
      setNotifications(prev => prev.filter(n => n.id !== id));
    } catch (err) {
      console.error('Failed to dismiss notification:', err);
      // Still remove from UI for better UX
      setNotifications(prev => prev.filter(n => n.id !== id));
    }
  };

  return (
    <>
      <GlobalStyle />

      <Sidebar $open={sidebarOpen}>
        <LogoArea>
          <LogoMark>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M9 12H15M12 9V15" stroke="#fff" strokeWidth="2.2" strokeLinecap="round"/>
            </svg>
          </LogoMark>
          <LogoText>Medi<em>Stox</em></LogoText>
        </LogoArea>

        <NavScroll>
          {NAV_SECTIONS.map(({ label, items }) => (
            <NavGroup key={label}>
              <NavGroupLabel>{label}</NavGroupLabel>
              {items.map(({ name, icon }) => (
                <NavBtn key={name} $active={activeTab === name} onClick={() => go(name)}>
                  <span className="nav-icon">{icon}</span>
                  {name}
                </NavBtn>
              ))}
            </NavGroup>
          ))}
        </NavScroll>

        <SidebarFooter ref={sideProRef}>
          {sideProfOpen && (
            <MiniDrop>
              <DropItem onClick={() => go('Profile')}>👤 Profile</DropItem>
              <DropItem onClick={() => go('Settings')}>⚙️ Settings</DropItem>
              <div style={{ height: 1, background: BORDER_GREY, margin: '6px 0' }} />
              <DropItem className="danger" onClick={handleLogout}>🚪 Log Out</DropItem>
            </MiniDrop>
          )}
          <SidebarProfileBtn onClick={() => setSideProfOpen(p => !p)}>
            <AvatarBox $size="36px">{initials}</AvatarBox>
            <div style={{ textAlign: 'left', minWidth: 0 }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, color: DARK_NAVY, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{userName}</div>
              <div style={{ fontSize: '0.7rem', color: '#8b96a5' }}>Retailer</div>
            </div>
            <span style={{ marginLeft: 'auto', color: '#8b96a5', fontSize: '0.6rem' }}>{sideProfOpen ? '▲' : '▼'}</span>
          </SidebarProfileBtn>
        </SidebarFooter>
      </Sidebar>

      <MobileOverlay $show={sidebarOpen} onClick={() => setSidebarOpen(false)} />

      <TopBar>
        <TopLeft>
          <HamBtn onClick={() => setSidebarOpen(o => !o)}>{sidebarOpen ? '✕' : '☰'}</HamBtn>
          <div>
            {navHistory.length > 1 && (
              <Breadcrumb>
                {navHistory.map((tab, i) => (
                  <React.Fragment key={tab + i}>
                    <BCItem $cur={i === navHistory.length - 1} $link={i < navHistory.length - 1}
                      onClick={() => i < navHistory.length - 1 && onBack && onBack()}>
                      {tab}
                    </BCItem>
                    {i < navHistory.length - 1 && <BCSep>›</BCSep>}
                  </React.Fragment>
                ))}
              </Breadcrumb>
            )}
            <PageTitleText>{activeTab}</PageTitleText>
          </div>
        </TopLeft>

        <TopRight>
          <IconBtn title="Cart" onClick={() => go('Cart')}>🛒</IconBtn>

          <div style={{ position: 'relative' }} ref={notifRef}>
            <IconBtn onClick={() => { setNotifOpen(o => !o); setProfileOpen(false); }}>
              🔔{notifications.length > 0 && <NotifDot />}
            </IconBtn>
            {notifOpen && (
              <NotifDrop>
                <div style={{ padding: '10px 14px 8px', borderBottom: `1px solid ${BORDER_GREY}`, marginBottom: 6, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: DARK_NAVY }}>Notifications</span>
                  {notifications.length > 0 && <span style={{ fontSize: '0.7rem', color: PHARMACY_GREEN, cursor: 'pointer' }} onClick={() => {
                    notifications.forEach(n => dismissNotification(n.id));
                  }}>Mark all read</span>}
                </div>
                {notifications.length === 0 ? (
                  <div style={{ padding: '20px', textAlign: 'center', color: '#8b96a5', fontSize: '0.8rem' }}>
                    No new notifications
                  </div>
                ) : (
                  notifications.map((n, i) => (
                    <React.Fragment key={n.id || i}>
                      <NotifItem style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <div>
                          <div style={{ fontSize: '0.85rem', fontWeight: 700, color: DARK_NAVY, marginBottom: 3 }}>{n.title}</div>
                          <div style={{ fontSize: '0.75rem', color: '#8b96a5' }}>{n.message}</div>
                          <div style={{ fontSize: '0.65rem', color: '#b0b8c1', marginTop: 4 }}>{new Date(n.created_at).toLocaleString()}</div>
                        </div>
                        <button onClick={(e) => { e.stopPropagation(); dismissNotification(n.id); }} style={{ border: 'none', background: 'transparent', cursor: 'pointer', color: '#8b96a5', fontSize: '1rem', padding: '0 0 0 8px' }}>&times;</button>
                      </NotifItem>
                      {i < notifications.length - 1 && <div style={{ height: 1, background: BORDER_GREY, margin: '4px 0' }} />}
                    </React.Fragment>
                  ))
                )}
              </NotifDrop>
            )}
          </div>

          <VDivider />

          <div style={{ position: 'relative' }} ref={profileRef}>
            <ProfileTopBtn onClick={() => { setProfileOpen(o => !o); setNotifOpen(false); }}>
              <AvatarBox $size="32px" $fs="0.8rem">{initials}</AvatarBox>
              <ProfileName>{userName}</ProfileName>
              <span style={{ fontSize: '0.55rem', color: '#8b96a5', marginLeft: 2 }}>▼</span>
            </ProfileTopBtn>
            {profileOpen && (
              <DropMenu>
                <div style={{ padding: '10px 14px 12px', borderBottom: `1px solid ${BORDER_GREY}`, marginBottom: 6 }}>
                  <div style={{ fontSize: '0.9rem', fontWeight: 800, color: DARK_NAVY }}>{userName}</div>
                  <div style={{ fontSize: '0.7rem', color: '#8b96a5' }}>Retailer Account</div>
                </div>
                <TopDropItem onClick={() => go('Profile')}>👤 My Profile</TopDropItem>
                <TopDropItem onClick={() => go('Settings')}>⚙️ Settings</TopDropItem>
                <TopDropItem onClick={() => go('FAQs')}>❓ FAQs</TopDropItem>
                <TopDropItem onClick={() => go('Support')}>🎧 Support</TopDropItem>
                <div style={{ height: 1, background: BORDER_GREY, margin: '6px 0' }} />
                <TopDropItem className="danger" onClick={handleLogout}>🚪 Log Out</TopDropItem>
              </DropMenu>
            )}
          </div>
        </TopRight>
      </TopBar>

      <BottomNav>
        {BOTTOM_NAV.map(({ name, icon, label }) => (
          <BottomNavItem key={name} $active={activeTab === name} onClick={() => go(name)}>
            <span className="bn-icon">{icon}</span>
            <span className="bn-label">{label}</span>
          </BottomNavItem>
        ))}
        <BottomNavItem $active={drawerOpen} onClick={() => setDrawerOpen(o => !o)}>
          <span className="bn-icon">⋯</span>
          <span className="bn-label" style={{ color: drawerOpen ? PHARMACY_GREEN : '#8b96a5' }}>More</span>
        </BottomNavItem>
      </BottomNav>

      {drawerOpen && (
        <>
          <DrawerOverlay onClick={() => setDrawerOpen(false)} />
          <MoreDrawer>
            <DrawerHandle />
            {DRAWER_SECTIONS.map(({ label, items }) => (
              <div key={label}>
                <DrawerTitle>{label}</DrawerTitle>
                <DrawerGrid>
                  {items.map(({ name, icon }) => (
                    <DrawerItem key={name} $active={activeTab === name} onClick={() => go(name)}>
                      <span className="di-icon">{icon}</span>
                      <span className="di-label">{name}</span>
                    </DrawerItem>
                  ))}
                </DrawerGrid>
              </div>
            ))}
            <div style={{ height: 1, background: BORDER_GREY, margin: '8px 0 16px' }} />
            <DrawerGrid>
              <DrawerItem onClick={handleLogout} style={{ borderColor: '#fee2e2' }}>
                <span className="di-icon">🚪</span>
                <span className="di-label" style={{ color: '#c0392b' }}>Log Out</span>
              </DrawerItem>
            </DrawerGrid>
          </MoreDrawer>
        </>
      )}

      <Main>
        <ContentPad>{children}</ContentPad>
      </Main>
    </>
  );
};

/* ─────────────────────────────────────────────────────
   EXPIRY BAR (improved)
───────────────────────────────────────────────────── */
const EBarTrack = styled.div`height: 4px; background: #f1f5f9; border-radius: 4px; overflow: hidden;`;
const EBarFill  = styled.div`
  height: 100%; border-radius: 4px;
  background: ${p => p.$p > 70 ? '#c0392b' : p.$p > 50 ? '#f39c12' : PHARMACY_GREEN};
  transition: width 0.5s ease;
`;
const ExpiryBar = ({ pct }) => <EBarTrack><EBarFill $p={pct} style={{ width: `${pct}%` }} /></EBarTrack>;

/* ─────────────────────────────────────────────────────
   PRODUCT CARD (improved)
───────────────────────────────────────────────────── */
const PCard = styled.div`
  background: white; border: 1px solid ${BORDER_GREY}; border-radius: 1.25rem;
  overflow: hidden; cursor: pointer;
  opacity: 0; animation: ${slideUp} 0.4s ease both; animation-delay: ${p => p.$i * 50}ms;
  transition: transform 0.25s, box-shadow 0.25s, border-color 0.25s;
  box-shadow: ${CARD_SHADOW};
  &:hover { transform: translateY(-5px); box-shadow: ${HOVER_SHADOW}; border-color: ${PHARMACY_GREEN}60; }
`;

const ProductCard = ({ product, index, onClick }) => {
  const price = ((product.original_price || 0) * (1 - (product.discount || 0) / 100)).toFixed(2);
  return (
    <PCard $i={index} onClick={onClick}>
      <div style={{ position: 'relative' }}>
        <img src={product.image_url || 'https://placehold.co/300x180/f5f7fa/9ca3af?text=No+Image'} alt={product.tablet_name}
          style={{ width: '100%', height: '160px', objectFit: 'cover', display: 'block' }}
          onError={e => { e.target.src = 'https://placehold.co/300x180/f5f7fa/9ca3af?text=No+Image'; }} />
        {product.discount > 0 && (
          <span style={{ position: 'absolute', top: '10px', right: '10px', background: '#c0392b', color: 'white', fontSize: '0.7rem', fontWeight: 800, padding: '4px 10px', borderRadius: '40px', boxShadow: '0 2px 6px rgba(0,0,0,0.1)' }}>
            {product.discount}% OFF
          </span>
        )}
      </div>
      <div style={{ padding: '14px' }}>
        <div style={{ fontWeight: 800, fontSize: '0.95rem', color: DARK_NAVY, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', marginBottom: 4 }}>{product.tablet_name}</div>
        <div style={{ fontSize: '0.75rem', color: '#8b96a5', marginBottom: 8 }}>{product.brand || 'Generic'}</div>
        <div style={{ marginBottom: 10 }}>
          <span style={{ fontWeight: 800, color: PHARMACY_GREEN, fontSize: '1rem' }}>₹{price}</span>
          {product.discount > 0 && <span style={{ color: '#adb5bd', textDecoration: 'line-through', fontSize: '0.75rem', marginLeft: 8 }}>₹{product.original_price?.toFixed(2)}</span>}
        </div>
        <div style={{ fontSize: '0.7rem', color: '#8b96a5', marginBottom: 5 }}>Expiry</div>
        <ExpiryBar pct={product.expiryPercentage} />
      </div>
      <div style={{ padding: '10px 14px', borderTop: `1px solid ${BORDER_GREY}`, display: 'flex', alignItems: 'center', gap: 10, background: '#fefefe' }}>
        <img src={product.user?.profile_pic_url || 'https://placehold.co/28x28/f1f5f9/9ca3af?text=S'} alt=""
          style={{ width: 28, height: 28, borderRadius: '50%', objectFit: 'cover' }}
          onError={e => { e.target.src = 'https://placehold.co/28x28/f1f5f9/9ca3af?text=S'; }} />
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: DARK_NAVY, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{product.user?.shop_name || 'Unknown'}</div>
          <div style={{ fontSize: '0.65rem', color: '#8b96a5' }}>{product.user?.state || ''}</div>
        </div>
      </div>
    </PCard>
  );
};

/* ─────────────────────────────────────────────────────
   BANNER AD (improved)
───────────────────────────────────────────────────── */
const BannerAd = () => (
  <div style={{
    background: `linear-gradient(135deg, ${PHARMACY_GREEN}10, #ecfdf5)`,
    borderRadius: '1.25rem',
    padding: '1.25rem 1.5rem',
    marginBottom: '1.75rem',
    border: `1px solid ${PHARMACY_GREEN}30`,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: '1rem'
  }}>
    <div>
      <div style={{ fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '1px', color: PHARMACY_GREEN, fontWeight: 800, marginBottom: 6 }}>🔥 Limited Offer</div>
      <div style={{ fontWeight: 800, fontSize: '1.1rem', color: DARK_NAVY, marginBottom: 4 }}>Exclusive Deals on Top Brands</div>
      <div style={{ color: '#5a6b7a', fontSize: '0.85rem' }}>Get up to 40% off on your next bulk order</div>
    </div>
    <button style={{
      background: PHARMACY_GREEN,
      border: 'none',
      borderRadius: '40px',
      padding: '10px 24px',
      color: 'white',
      fontFamily: 'Inter, sans-serif',
      fontWeight: 700,
      fontSize: '0.85rem',
      cursor: 'pointer',
      boxShadow: '0 4px 10px rgba(13,124,61,0.25)',
      transition: 'all 0.2s'
    }}>
      Learn More →
    </button>
  </div>
);

/* ─────────────────────────────────────────────────────
   RETAILER HUB HOME (New)
───────────────────────────────────────────────────── */
const StatCard = ({ title, value, icon, color }) => (
  <PCard style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem', cursor: 'default' }}>
    <div style={{
      width: '48px', height: '48px', borderRadius: '12px',
      background: `${color}10`, color: color,
      display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem'
    }}>
      {icon}
    </div>
    <div>
      <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#8b96a5', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '2px' }}>{title}</div>
      <div style={{ fontSize: '1.25rem', fontWeight: 800, color: DARK_NAVY }}>{value}</div>
    </div>
  </PCard>
);

const HubActionBtn = styled.button`
  background: white; border: 1px solid ${BORDER_GREY}; border-radius: 1rem;
  padding: 1.25rem; display: flex; flex-direction: column; align-items: center; gap: 0.75rem;
  cursor: pointer; transition: all 0.2s; box-shadow: ${CARD_SHADOW};
  &:hover { transform: translateY(-4px); box-shadow: ${HOVER_SHADOW}; border-color: ${PHARMACY_GREEN}40; }
  .icon { font-size: 2rem; }
  .label { font-size: 0.85rem; fontWeight: 700; color: ${DARK_NAVY}; }
`;

const RetailerHubHome = ({ navigateTo }) => {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const uid = localStorage.getItem('user_id');
        const res = await axios.get(`${BaseUrl}/dashboard/dashboard-summary/${uid}`);
        setSummary(res.data);
      } catch (e) { 
        console.error('Dashboard Summary Error:', e); 
      } finally { 
        setLoading(false); 
      }
    })();
  }, []);

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', padding: '4rem' }}><SpinRing /></div>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
      <BannerAd />
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem' }}>
        <StatCard title="Inventory" value={summary?.total_products || 0} icon="📦" color={PHARMACY_GREEN} />
        <StatCard title="Requests" value={summary?.total_purchase_requests || 0} icon="🛒" color="#3498db" />
        <StatCard title="Revenue" value={`₹${summary?.total_revenue?.toLocaleString() || 0}`} icon="₹" color="#f1c40f" />
        <StatCard title="Active Ads" value={summary ? summary.total_ads - summary.pending_ads : 0} icon="📢" color="#e67e22" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '1rem' }}>
        <HubActionBtn onClick={() => navigateTo('Products')}><span className="icon">🛍️</span><span className="label">Shop Items</span></HubActionBtn>
        <HubActionBtn onClick={() => navigateTo('Requests')}><span className="icon">📄</span><span className="label">My Requests</span></HubActionBtn>
        <HubActionBtn onClick={() => navigateTo('AI Demand Forecast')}><span className="icon">🤖</span><span className="label">AI Forecast</span></HubActionBtn>
        <HubActionBtn onClick={() => navigateTo('Nearby Inventory')}><span className="icon">📍</span><span className="label">Nearby</span></HubActionBtn>
      </div>

      <PCard style={{ padding: '1.5rem', cursor: 'default' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
          <h3 style={{ fontSize: '1.1rem', fontWeight: 800, color: DARK_NAVY, margin: 0 }}>Recent Activity</h3>
          <button onClick={() => navigateTo('Requests')} style={{ background: 'none', border: 'none', color: PHARMACY_GREEN, fontWeight: 700, fontSize: '0.8rem', cursor: 'pointer' }}>View All →</button>
        </div>
        {summary?.today_purchase_requests?.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {summary.today_purchase_requests.map((req, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px', borderRadius: '12px', background: LIGHT_GREEN }}>
                <div>
                  <div style={{ fontSize: '0.85rem', fontWeight: 700, color: DARK_NAVY }}>{req.tablet_name}</div>
                  <div style={{ fontSize: '0.75rem', color: '#8b96a5' }}>Quantity: {req.quantity}</div>
                </div>
                <span style={{ 
                  fontSize: '0.7rem', fontWeight: 800, padding: '4px 10px', borderRadius: '20px',
                  background: req.status === 'pending' ? '#f39c1220' : '#2ecc7120',
                  color: req.status === 'pending' ? '#d35400' : '#27ae60'
                }}>
                  {req.status.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '2rem', color: '#8b96a5', fontSize: '0.85rem' }}>No recent activity to show.</div>
        )}
      </PCard>
    </div>
  );
};

/* ─────────────────────────────────────────────────────
   HELPERS
───────────────────────────────────────────────────── */
const calcExpiry = (mfg, exp) => {
  const m = new Date(mfg), e = new Date(exp), t = new Date();
  if (!mfg || !exp || t >= e) return 100;
  if (t <= m) return 0;
  return Math.min(100, Math.max(0, ((t - m) / (e - m)) * 100));
};

const spinAnim = keyframes`to{transform:rotate(360deg)}`;
const SpinRing = styled.div`width: 36px; height: 36px; border-radius: 50%; border: 3px solid ${BORDER_GREY}; border-top-color: ${PHARMACY_GREEN}; animation: ${spinAnim} 0.8s linear infinite;`;

/* ─────────────────────────────────────────────────────
   PRODUCTS PAGE (improved filter bar)
───────────────────────────────────────────────────── */
const ProductsPage = ({ products, loading, onProductClick }) => {
  const [search,   setSearch]   = useState('');
  const [expiry,   setExpiry]   = useState(100);
  const [discount, setDiscount] = useState('none');

  const filtered = useMemo(() =>
    products
      .filter(p => p.tablet_name.toLowerCase().includes(search.toLowerCase()))
      .filter(p => p.expiryPercentage <= expiry)
      .sort((a, b) => discount === 'desc' ? b.discount - a.discount : discount === 'asc' ? a.discount - b.discount : 0),
    [products, search, expiry, discount]
  );

  return (
    <div>
      <BannerAd />
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        flexWrap: 'wrap',
        marginBottom: '1.5rem',
        padding: '12px 16px',
        background: 'white',
        borderRadius: '1rem',
        border: `1px solid ${BORDER_GREY}`,
        boxShadow: CARD_SHADOW
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          background: LIGHT_GREEN,
          border: `1px solid ${BORDER_GREY}`,
          borderRadius: '40px',
          padding: '8px 16px',
          flex: 1,
          maxWidth: '300px'
        }}>
          <span style={{ color: '#8b96a5' }}>🔍</span>
          <input
            type="text"
            placeholder="Search products…"
            onChange={e => setSearch(e.target.value)}
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              color: DARK_NAVY,
              fontFamily: 'Inter, sans-serif',
              fontSize: '0.85rem',
              width: '100%'
            }}
          />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.8rem', color: DARK_NAVY }}>
          <span style={{ fontWeight: 600 }}>Expiry:</span>
          <input
            type="range"
            min="0"
            max="100"
            value={expiry}
            onChange={e => setExpiry(Number(e.target.value))}
            style={{ accentColor: PHARMACY_GREEN, width: '100px' }}
          />
          <span style={{ background: `${PHARMACY_GREEN}10`, color: PHARMACY_GREEN, border: `1px solid ${PHARMACY_GREEN}30`, borderRadius: '20px', padding: '2px 10px', fontSize: '0.7rem', fontWeight: 700 }}>{expiry}%</span>
        </div>
        <select
          value={discount}
          onChange={e => setDiscount(e.target.value)}
          style={{
            background: LIGHT_GREEN,
            border: `1px solid ${BORDER_GREY}`,
            borderRadius: '40px',
            padding: '8px 16px',
            color: DARK_NAVY,
            fontFamily: 'Inter, sans-serif',
            fontSize: '0.8rem',
            outline: 'none'
          }}
        >
          <option value="none">Sort by Discount</option>
          <option value="desc">Highest First</option>
          <option value="asc">Lowest First</option>
        </select>
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>
          <SpinRing />
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '1.25rem' }}>
          {filtered.length > 0
            ? filtered.map((p, i) => <ProductCard key={p.product_id} product={p} index={i} onClick={() => onProductClick(p)} />)
            : <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: '3rem', color: '#8b96a5' }}>No products match.</div>
          }
        </div>
      )}
    </div>
  );
};

/* ─────────────────────────────────────────────────────
   DASHBOARD ROOT (unchanged logic)
───────────────────────────────────────────────────── */
const Dashboard = () => {
  const { section } = useParams();
  const navigate = useNavigate();

  // Map URL slugs to Tab Names
  const slugToTab = useMemo(() => ({
    'dashboard': 'Dashboard',
    'products': 'Products',
    'my-products': 'My Products',
    'nearby-inventory': 'Nearby Inventory',
    'cart': 'Cart',
    'purchase-requests': 'Purchase Requests',
    'requests': 'Requests',
    'inventory': 'Inventory',
    'orders': 'Orders',
    'chat': 'Chat',
    'videos': 'Videos',
    'ad-management': 'Ad Management',
    'ai-demand-forecast': 'AI Demand Forecast',
    'profile': 'Profile',
    'settings': 'Settings',
    'faqs': 'FAQs',
    'support': 'Support',
    'add-product': 'Add New Product',
    'product-details': 'Product Details'
  }), []);

  const tabToSlug = useMemo(() => 
    Object.fromEntries(Object.entries(slugToTab).map(([s, t]) => [t, s])),
    [slugToTab]
  );

  const activeTab = useMemo(() => {
    if (!section) return 'Dashboard';
    return slugToTab[section] || 'Dashboard';
  }, [section, slugToTab]);

  const [navHistory, setNavHistory] = useState([activeTab]);
  const [products,        setProducts]        = useState([]);
  const [loading,         setLoading]         = useState(true);
  const [selectedProduct, setSelectedProduct] = useState(null);

  // Sync history when URL changes
  useEffect(() => {
    setNavHistory(prev => {
      if (prev[prev.length - 1] === activeTab) return prev;
      // If it's a top-level reset
      const TOP_LEVEL_TABS = Object.values(slugToTab);
      if (TOP_LEVEL_TABS.includes(activeTab)) return [activeTab];
      return [...prev, activeTab];
    });
  }, [activeTab, slugToTab]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const uid = localStorage.getItem('user_id');
        const res = await fetch(`${BaseUrl}/products/${uid}`);
        if (!res.ok) throw new Error('Failed');
        const d = await res.json();
        if (d.status !== 'success' || !Array.isArray(d.data)) throw new Error('Invalid');
        setProducts(d.data.map(p => ({ ...p, expiryPercentage: calcExpiry(p.manufacturing_date, p.expiry_date) })));
      } catch (e) { console.error(e); } finally { setLoading(false); }
    })();
  }, []);

  const navigateTo = (tab) => {
    const slug = tabToSlug[tab] || tab.toLowerCase().replace(/ /g, '-');
    navigate(`/retailer-dashboard/${slug}`);
  };

  const handleBack = () => {
    if (navHistory.length > 1) {
      const prevTab = navHistory[navHistory.length - 2];
      navigateTo(prevTab);
    }
  };

  const onProductClick = (p) => {
    setSelectedProduct(p);
    navigateTo('Product Details');
  };

  const renderContent = () => {
    if (activeTab === 'Product Details' && selectedProduct)
      return <ProductDetails product={selectedProduct} onBack={handleBack} navigateTo={navigateTo} />;
    switch (activeTab) {
      case 'Dashboard':            return <RetailerHubHome navigateTo={navigateTo} />;
      case 'Products':             return <ProductsPage products={products} loading={loading} onProductClick={onProductClick} />;
      case 'Chat':                 return <Chat navigateTo={navigateTo} />;
      case 'Videos':               return <Videos navigateTo={navigateTo} onBack={handleBack} />;
      case 'Purchase Requests':    return <Requests navigateTo={navigateTo} onBack={handleBack} />;
      case 'AI Demand Forecast':   return <AiDemandForecast navigateTo={navigateTo} onBack={handleBack} />;
      case 'Nearby Inventory':     return <NearbyInventory navigateTo={navigateTo} onBack={handleBack} />;
      case 'Cart':                 return <Cart navigateTo={navigateTo} onBack={handleBack} />;
      case 'Orders':               return <Orders navigateTo={navigateTo} onBack={handleBack} />;
      case 'Profile':              return <Profile navigateTo={navigateTo} onBack={handleBack} />;
      case 'Inventory':            return <Billing navigateTo={navigateTo} onBack={handleBack} />;
      case 'Generate Invoice':     return <GenerateInvoice navigateTo={navigateTo} onBack={handleBack} />;
      case 'Support':              return <Support navigateTo={navigateTo} onBack={handleBack} />;
      case 'FAQs':                 return <FAQ navigateTo={navigateTo} onBack={handleBack} />;
      case 'Ad Management':        return <AdManagement navigateTo={navigateTo} onBack={handleBack} />;
      case 'Requests':             return <IncomingRequests navigateTo={navigateTo} onBack={handleBack} />;
      case 'My Products':          return <RetailerMyProducts onAddProduct={() => navigateTo('Add New Product')} />;
      case 'Add New Product':      return <RetailerAddNewProduct onBack={handleBack} navigateTo={navigateTo} />;
      case 'Terms and Conditions': return <TermsAndConditions navigateTo={navigateTo} onBack={handleBack} />;
      case 'Settings':             return <Settings navigateTo={navigateTo} onBack={handleBack} />;
      case 'Chat_support':         return <ChatSupportPage navigateTo={navigateTo} onBack={handleBack} />;
      default:                     return <div style={{ padding: '3rem', textAlign: 'center', color: '#8b96a5' }}>{activeTab}</div>;
    }
  };

  return (
    <UserLayout activeTab={activeTab} navHistory={navHistory} navigateTo={navigateTo} onBack={handleBack}>
      {renderContent()}
    </UserLayout>
  );
};

export default Dashboard;