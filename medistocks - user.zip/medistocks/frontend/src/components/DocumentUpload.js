import React, { useState, useEffect } from 'react';
import styled, { createGlobalStyle } from 'styled-components';
import { useNavigate } from 'react-router-dom';
import BaseUrl from './BaseUrl';
import { FaFileUpload, FaFilePdf, FaFileImage } from 'react-icons/fa';
import { IoCloseCircle, IoCheckmarkCircle } from "react-icons/io5";

// --- Global Styles for a consistent theme ---
const GlobalStyle = createGlobalStyle`
  body {
    background-color: #f8fafc; // A light, clean background
  }
`;

// --- Styled Components (Redesigned for better UX) ---

const PageWrapper = styled.div`
  min-height: 100vh;
  padding: 2rem;
`;

const LayoutGrid = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1.5fr 1fr;
  gap: 3rem;

  @media (max-width: 992px) {
    grid-template-columns: 1fr;
  }
`;

const UploadSection = styled.div`
  display: flex;
  flex-direction: column;
`;

const SummarySection = styled.div`
  position: sticky;
  top: 2rem;
  height: fit-content;
`;

const Header = styled.div`
  margin-bottom: 2rem;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 800;
  color: #111827;
`;

const Subtitle = styled.p`
  font-size: 1.1rem;
  color: #475569;
`;

const Card = styled.div`
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 1rem;
  padding: 1.5rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
`;

const CardTitle = styled.h2`
  font-size: 1.25rem;
  font-weight: 700;
  margin-bottom: 1.5rem;
  color: #1e293b;
`;

const DocumentGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;

  @media (max-width: 576px) {
    grid-template-columns: 1fr;
  }
`;

const Alert = styled.div`
  padding: 1rem;
  margin-bottom: 2rem;
  border-radius: 0.75rem;
  font-weight: 500;
  color: ${({ type }) => (type === 'success' ? '#155724' : '#721c24')};
  background-color: ${({ type }) => (type === 'success' ? '#d4edda' : '#f8d7da')};
  border: 1px solid ${({ type }) => (type === 'success' ? '#c3e6cb' : '#f5c6cb')};
`;

const SubmitButton = styled.button`
  width: 100%;
  background-color: #4f46e5;
  border: none;
  color: white;
  padding: 1rem;
  font-size: 1.1rem;
  font-weight: 600;
  border-radius: 0.75rem;
  cursor: pointer;
  transition: background-color 0.2s;

  &:hover { background-color: #4338ca; }
  &:disabled { background-color: #a5b4fc; cursor: not-allowed; }
`;

// --- NEW: Interactive FileUploader Component ---
const DocumentInputContainer = styled.div`
  h3 {
    font-size: 1rem;
    font-weight: 600;
    color: #334155;
    margin-bottom: 0.5rem;
  }
`;

const DropZone = styled.label`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border: 2px dashed #cbd5e1;
  border-radius: 0.75rem;
  padding: 1.5rem;
  text-align: center;
  cursor: pointer;
  background-color: #f8fafc;
  transition: all 0.2s ease-in-out;
  
  &:hover {
    border-color: #4f46e5;
    background-color: #f0f0ff;
  }

  p { margin: 0.5rem 0 0.25rem; font-weight: 500; color: #475569; }
  small { color: #94a3b8; }
`;

const FilePreview = styled.div`
  display: flex;
  align-items: center;
  border: 1px solid #e2e8f0;
  border-radius: 0.75rem;
  padding: 0.75rem;
  background-color: #f8fafc;
`;

const FileIcon = styled.div`
  flex-shrink: 0;
  font-size: 2.5rem;
  margin-right: 1rem;
  color: #64748b;
`;

const PreviewImage = styled.img`
  width: 48px;
  height: 48px;
  border-radius: 0.5rem;
  object-fit: cover;
  margin-right: 1rem;
`;

const FileInfo = styled.div`
  flex-grow: 1;
  overflow: hidden;
  p {
    margin: 0;
    font-weight: 600;
    color: #1e293b;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  small { color: #64748b; }
`;

const RemoveButton = styled.button`
  background: none;
  border: none;
  color: #ef4444;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0;
  margin-left: 1rem;
`;

const ChecklistItem = styled.li`
  display: flex;
  align-items: center;
  padding: 0.75rem 0;
  border-bottom: 1px solid #f1f5f9;
  color: ${({ completed }) => (completed ? '#1e293b' : '#64748b')};
  font-weight: ${({ completed }) => (completed ? '600' : '500')};
  transition: all 0.2s;
`;

const DocumentInput = ({ title, onFileChange }) => {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    // Create a preview for image files
    if (file.type.startsWith('image/')) {
      const objectUrl = URL.createObjectURL(file);
      setPreview(objectUrl);
      return () => URL.revokeObjectURL(objectUrl);
    }
  }, [file]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      onFileChange(selectedFile);
    }
  };

  const handleRemoveFile = () => {
    setFile(null);
    setPreview(null);
    onFileChange(null);
  };

  return (
    <DocumentInputContainer>
      <h3>{title}</h3>
      {!file ? (
        <DropZone>
          <input type="file" hidden accept=".jpg,.jpeg,.png,.pdf" onChange={handleFileChange} />
          <FaFileUpload size={24} color="#94a3b8" />
          <p>Click to upload</p>
          <small>PNG, JPG, PDF up to 5MB</small>
        </DropZone>
      ) : (
        <FilePreview>
          {preview ? (
            <PreviewImage src={preview} alt="preview" />
          ) : (
            <FileIcon>{file.type === "application/pdf" ? <FaFilePdf color="#ef4444"/> : <FaFileImage />}</FileIcon>
          )}
          <FileInfo>
            <p>{file.name}</p>
            <small>{(file.size / 1024 / 1024).toFixed(2)} MB</small>
          </FileInfo>
          <RemoveButton onClick={handleRemoveFile}>
            <IoCloseCircle />
          </RemoveButton>
        </FilePreview>
      )}
    </DocumentInputContainer>
  );
};


// --- Main Component ---
const DocumentUpload = () => {
  const navigate = useNavigate();
  const [docs, setDocs] = useState({
    aadhar_card_front: null,
    aadhar_card_back: null,
    pancard_front: null,
    pancard_back: null,
    pharmacy_license: null,
  });
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const userId = localStorage.getItem('user_id');

  const handleFileSelect = (docType, file) => {
    setDocs(prevDocs => ({ ...prevDocs, [docType]: file }));
  };
  
  const allDocsUploaded = Object.values(docs).every(doc => doc !== null);
  
  const handleUpload = async () => {
    setError(""); setSuccess(false);
    if (!allDocsUploaded) {
      setError("Please upload all required documents.");
      return;
    }
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("user_id", userId);
      for (const [key, value] of Object.entries(docs)) {
        formData.append(key, value);
      }
      
      const response = await fetch(`${BaseUrl}/auth/upload_documents`, {
        method: "POST", body: formData,
      });

      if (response.ok) {
        setSuccess(true);
        setTimeout(() => navigate("/live-verification"), 2000);
      } else {
        const errData = await response.json().catch(() => ({}));
        setError(errData.message || "Failed to upload documents. Please try again.");
      }
    } catch (err) {
      setError("A network error occurred. Please check your connection and try again.");
    } finally {
      setUploading(false);
    }
  };

  const documentList = [
      { title: "Aadhar Card (Front)", type: "aadhar_card_front" },
      { title: "Aadhar Card (Back)", type: "aadhar_card_back" },
      { title: "PAN Card (Front)", type: "pancard_front" },
      { title: "PAN Card (Back)", type: "pancard_back" },
      { title: "Pharmacy License", type: "pharmacy_license" },
  ];

  return (
    <>
      <GlobalStyle />
      <PageWrapper>
        <LayoutGrid>
          <UploadSection>
            <Header>
              <p className="fw-bold" style={{color: '#4f46e5'}}>STEP 4 OF 5</p>
              <Title>Upload Your Documents</Title>
              <Subtitle>Please provide clear images of the following documents for verification.</Subtitle>
            </Header>

            {error && <Alert type="error">{error}</Alert>}
            {success && <Alert type="success">Documents uploaded! Redirecting...</Alert>}

            <Card>
              <CardTitle>Identity Proof</CardTitle>
              <DocumentGrid>
                <DocumentInput title="Aadhar Card (Front)" onFileChange={(file) => handleFileSelect('aadhar_card_front', file)} />
                <DocumentInput title="Aadhar Card (Back)" onFileChange={(file) => handleFileSelect('aadhar_card_back', file)} />
              </DocumentGrid>
            </Card>

            <Card>
              <CardTitle>Business Proof</CardTitle>
              <DocumentGrid>
                <DocumentInput title="PAN Card (Front)" onFileChange={(file) => handleFileSelect('pancard_front', file)} />
                <DocumentInput title="PAN Card (Back)" onFileChange={(file) => handleFileSelect('pancard_back', file)} />
                <DocumentInput title="Pharmacy License" onFileChange={(file) => handleFileSelect('pharmacy_license', file)} />
              </DocumentGrid>
            </Card>
          </UploadSection>

          <SummarySection>
            <Card>
              <CardTitle>Required Documents</CardTitle>
              <ul className="list-unstyled">
                {documentList.map(doc => (
                  <ChecklistItem key={doc.type} completed={!!docs[doc.type]}>
                    {docs[doc.type] 
                      ? <IoCheckmarkCircle color="#16a34a" size={22} className="me-3"/> 
                      : <IoCloseCircle color="#cbd5e1" size={22} className="me-3"/>
                    }
                    {doc.title}
                  </ChecklistItem>
                ))}
              </ul>
              <SubmitButton onClick={handleUpload} disabled={uploading || !allDocsUploaded}>
                {uploading ? 'Uploading...' : 'Submit Documents'}
              </SubmitButton>
            </Card>
          </SummarySection>
        </LayoutGrid>
      </PageWrapper>
    </>
  );
};

export default DocumentUpload;