import React, { useState, useEffect, useCallback, useMemo } from 'react';
import styled, { keyframes } from 'styled-components';
import axios from 'axios';
import { useSelector } from 'react-redux';
import { FaTrash, FaSpinner, FaShoppingCart, FaBookmark } from 'react-icons/fa';
import BaseUrl from './BaseUrl';

const fadeUp = keyframes`from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}`;
const spin   = keyframes`to{transform:rotate(360deg)}`;

const ACCENT = '#10b981';

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;background:#f5f7fa;min-height:100%;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 22px;`;

const Layout = styled.div`
  display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start;
  @media(max-width:900px){grid-template-columns:1fr;}
`;
const ItemsCol   = styled.div`display:flex;flex-direction:column;gap:14px;`;
const SummaryCol = styled.div`@media(min-width:900px){position:sticky;top:80px;}`;

const Card = styled.div`
  background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;
  overflow:hidden;animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*60}ms;
  box-shadow:0 1px 4px rgba(0,0,0,.04);
`;

const ItemWrap = styled.div`
  display:flex;align-items:center;gap:16px;padding:16px;cursor:pointer;position:relative;
  @media(max-width:480px){flex-direction:column;align-items:flex-start;}
`;
const ItemImg  = styled.img`width:80px;height:80px;border-radius:10px;object-fit:cover;flex-shrink:0;border:1px solid #f0f0f0;`;
const ItemInfo = styled.div`flex:1;min-width:0;`;
const ItemName = styled.h5`font-weight:700;font-size:.95rem;color:#111827;margin:0 0 4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;`;
const ItemPrice= styled.div`font-size:1.1rem;font-weight:800;color:${ACCENT};`;
const ItemQty  = styled.div`font-size:.78rem;color:#9ca3af;margin-top:4px;`;

const DelBtn = styled.button`
  position:absolute;top:12px;right:12px;
  width:32px;height:32px;border-radius:50%;border:none;
  background:#fef2f2;color:#ef4444;
  display:flex;align-items:center;justify-content:center;
  cursor:pointer;transition:all .15s;
  &:hover{background:#ef4444;color:#fff;}
`;

const SummaryCard = styled(Card)`padding:20px;`;
const SumTitle = styled.h4`font-weight:700;font-size:1rem;color:#111827;margin:0 0 14px;`;
const SumList  = styled.div`max-height:180px;overflow-y:auto;margin-bottom:14px;
  &::-webkit-scrollbar{width:3px;}
  &::-webkit-scrollbar-thumb{background:#e5e7eb;border-radius:3px;}
`;
const SumItem  = styled.div`display:flex;justify-content:space-between;font-size:.8rem;color:#6b7280;padding:5px 0;border-bottom:1px solid #f5f5f5;&:last-child{border:none;}
  span:first-child{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:65%;}
  span:last-child{font-weight:600;color:#374151;}
`;
const Divider  = styled.div`height:1px;background:#f5f5f5;margin:12px 0;`;
const TotalRow = styled.div`display:flex;justify-content:space-between;font-size:${p=>p.$big?'1.1rem':'.84rem'};color:${p=>p.$big?'#111827':'#6b7280'};font-weight:${p=>p.$big?800:400};padding:4px 0;`;

const PrimaryBtn = styled.button`
  width:100%;padding:12px;margin-top:8px;
  background:linear-gradient(135deg,${ACCENT},#0ea5e9);
  border:none;border-radius:10px;color:#fff;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.9rem;font-weight:700;
  cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;
  transition:all .2s;box-shadow:0 4px 12px rgba(16,185,129,.24);
  &:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 18px rgba(16,185,129,.32);}
  &:disabled{opacity:.45;cursor:not-allowed;transform:none;box-shadow:none;}
  .sp{animation:${spin} 1s linear infinite;}
`;
const SecBtn = styled(PrimaryBtn)`background:#f9fafb;color:#374151;box-shadow:none;border:1.5px solid #e5e7eb;
  &:hover:not(:disabled){background:#f3f4f6;box-shadow:none;transform:none;}
`;

const EmptyBox = styled.div`background:#fff;border:1.5px dashed #e5e7eb;border-radius:14px;padding:60px 24px;text-align:center;`;
const SpinWrap = styled.div`display:flex;justify-content:center;padding:80px;`;
const Spin     = styled.div`width:32px;height:32px;border-radius:50%;border:3px solid #e5e7eb;border-top-color:${ACCENT};animation:${spin} .8s linear infinite;`;
const ErrBox   = styled.div`background:#fef2f2;border:1px solid #fecaca;color:#ef4444;border-radius:10px;padding:12px 16px;font-size:.86rem;margin-bottom:16px;`;
const SpinIcon = styled(FaSpinner)`animation:${spin} 1s linear infinite;`;

const Cart = ({ navigateTo }) => {
  const [cartItems, setCartItems]   = useState([]);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState(null);
  const [sending, setSending]       = useState(false);
  const [progress, setProgress]     = useState('');
  const loggedInUserId = useSelector(s => s.auth.userId);

  const fetchCart = useCallback(async (uid) => {
    if (!uid) { setError('Please log in to see your cart.'); setLoading(false); return; }
    setLoading(true); setError(null);
    try {
      const res = await axios.get(`${BaseUrl}/cart/my-cart/${uid}`);
      if (res.data.status === 'success') setCartItems(res.data.data);
      else throw new Error('Failed to load cart.');
    } catch (e) { setError(e.response?.data?.error || e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchCart(loggedInUserId); }, [fetchCart, loggedInUserId]);

  const deleteItem = async (id, silent = false) => {
    const orig = [...cartItems];
    setCartItems(p => p.filter(i => i.id !== id));
    try { await axios.delete(`${BaseUrl}/cart/delete/${id}`); }
    catch { setCartItems(orig); if (!silent) alert('Could not remove item.'); }
  };

  const sendAll = async () => {
    if (!loggedInUserId) { alert('Please log in.'); return; }
    setSending(true);
    const items = [...cartItems];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      setProgress(`Sending ${i+1} of ${items.length}…`);
      try {
        if (!item.seller_id) throw new Error(`Missing seller_id for ${item.tablet_name}`);
        await axios.post(`${BaseUrl}/purchase-requests/send-purchase-request`, {
          sender_id: loggedInUserId, receiver_id: item.seller_id,
          tablet_name: item.tablet_name, product_id: item.product_id,
          quantity: item.quantity, unit_price: item.amount,
          description: `Purchase request for ${item.quantity} units of ${item.tablet_name}.`
        });
        await deleteItem(item.id, true);
      } catch (e) { alert(`Failed: ${e.message}`); setSending(false); setProgress(''); fetchCart(loggedInUserId); return; }
    }
    setSending(false); setProgress('');
    alert('All purchase requests sent!');
  };

  const { subtotal, tax, total } = useMemo(() => {
    const sub = cartItems.reduce((a, i) => a + i.amount * i.quantity, 0);
    const t   = sub * 0.05;
    return { subtotal: sub, tax: t, total: sub + t };
  }, [cartItems]);

  if (loading) return <SpinWrap><Spin /></SpinWrap>;

  return (
    <Page>
      <PageTitle>My <em>Cart</em></PageTitle>
      <PageSub>Review items and send purchase requests to sellers.</PageSub>

      {error && <ErrBox>⚠ {error}</ErrBox>}

      {!loading && cartItems.length === 0 && !error && (
        <EmptyBox>
          <div style={{fontSize:'2.5rem',opacity:.4,marginBottom:14}}>🛒</div>
          <h3 style={{fontWeight:700,fontSize:'1.1rem',color:'#374151',margin:'0 0 8px'}}>Your cart is empty</h3>
          <p style={{color:'#9ca3af',fontSize:'.86rem',margin:'0 0 20px'}}>Add products from the marketplace to get started.</p>
          <PrimaryBtn style={{width:'auto',margin:'0 auto',padding:'10px 24px'}} onClick={() => navigateTo('Products')}>Browse Products</PrimaryBtn>
        </EmptyBox>
      )}

      {cartItems.length > 0 && (
        <Layout>
          <ItemsCol>
            {cartItems.map((item, i) => (
              <Card key={item.id} $i={i}>
                <ItemWrap onClick={() => navigateTo('Product Details', { productId: item.product_id })}>
                  <ItemImg src={item.image_url || 'https://placehold.co/80x80/f5f7fa/9ca3af?text=Img'} alt={item.tablet_name}
                    onError={e => { e.target.src = 'https://placehold.co/80x80/f5f7fa/9ca3af?text=Img'; }} />
                  <ItemInfo>
                    <ItemName>{item.tablet_name}</ItemName>
                    <ItemPrice>₹{(item.amount * item.quantity).toFixed(2)}</ItemPrice>
                    <ItemQty>Qty: {item.quantity} · ₹{item.amount}/unit</ItemQty>
                  </ItemInfo>
                  <DelBtn onClick={e => { e.stopPropagation(); deleteItem(item.id); }} title="Remove">
                    <FaTrash size={12} />
                  </DelBtn>
                </ItemWrap>
              </Card>
            ))}
          </ItemsCol>

          <SummaryCol>
            <SummaryCard $i={0}>
              <SumTitle>Order Summary</SumTitle>
              <SumList>
                {cartItems.map(i => (
                  <SumItem key={i.id}>
                    <span>{i.tablet_name} ×{i.quantity}</span>
                    <span>₹{(i.amount * i.quantity).toFixed(2)}</span>
                  </SumItem>
                ))}
              </SumList>
              <Divider />
              <TotalRow><span>Subtotal</span><span>₹{subtotal.toFixed(2)}</span></TotalRow>
              <TotalRow><span>Tax (5%)</span><span>₹{tax.toFixed(2)}</span></TotalRow>
              <Divider />
              <TotalRow $big><span>Total</span><span>₹{total.toFixed(2)}</span></TotalRow>
              <PrimaryBtn onClick={sendAll} disabled={sending || cartItems.length === 0}>
                {sending ? <><SpinIcon size={14} className="sp"/> {progress}</> : <><FaShoppingCart size={14}/> Send All Requests</>}
              </PrimaryBtn>
              <SecBtn disabled={sending} onClick={() => alert('Save for Later — coming soon!')}>
                <FaBookmark size={13}/> Save for Later
              </SecBtn>
            </SummaryCard>
          </SummaryCol>
        </Layout>
      )}
    </Page>
  );
};

export default Cart;