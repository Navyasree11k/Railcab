import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { FaBoxOpen, FaCalendarAlt, FaTag, FaUpload, FaCheckCircle, FaSpinner, FaExclamationCircle } from 'react-icons/fa';

// --- Base URL for API ---
import BaseUrl from './BaseUrl';
// --- Styled Components (with UI Enhancements) ---
const PageContainer = styled.div`
  padding: 1.5rem;
  max-width: 900px;
  margin: 0 auto;
  min-height: 100vh;
  background-color: #f2f3f6ff;
  font-family: 'Inter', sans-serif;
`;

const FormWrapper = styled.div`
  background-color: #fff;
  border-radius: 1rem;
  padding: 2.5rem;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease-in-out;
`;

const Header = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 2rem;
`;

const Title = styled.h2`
  font-weight: 700;
  color: #111827;
  margin: 0;
`;

const Stepper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 2rem;
  position: relative;
`;

const ProgressBar = styled.div`
  position: absolute;
  top: 50%;
  left: 0;
  height: 2px;
  background-color: #0ea5e9;
  width: ${props => props.progress}%;
  transform: translateY(-50%);
  transition: width 0.4s ease-in-out;
  z-index: 1;
`;

const ProgressBackground = styled.div`
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: 2px;
  background-color: #e5e7eb;
  transform: translateY(-50%);
  z-index: 0;
`;


const Step = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  z-index: 2;
  background-color: #fff;
  padding: 0 0.5rem;

  .icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    background-color: ${props => (props.active ? '#0ea5e9' : '#f3f4f6')};
    color: ${props => (props.active ? '#fff' : '#6b7280')};
    border: 2px solid ${props => (props.active ? '#0ea5e9' : '#e5e7eb')};
    transition: all 0.3s ease;
  }
  .label {
    margin-top: 0.5rem;
    font-size: 0.8rem;
    font-weight: 600;
    color: ${props => (props.active ? '#111827' : '#6b7280')};
  }
`;

const FormSection = styled.div`
  animation: fadeIn 0.5s ease-in-out;
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;

const FormGroup = styled.div`
  margin-bottom: 1.25rem;
  .form-label {
    font-weight: 600;
    color: #374151;
    margin-bottom: 0.5rem;
    font-size: 0.9rem;
  }
`;

const FormInput = styled.input`
  background-color: #f9fafb !important;
  color: #111827 !important;
  border: 1px solid #d1d5db !important;
  border-radius: 0.5rem !important;
  padding: 0.75rem 1rem !important;
  &:focus {
    box-shadow: 0 0 0 3px rgba(14, 165, 233, 0.2) !important;
    border-color: #0ea5e9 !important;
  }
`;

const FormSelect = styled(FormInput).attrs({ as: 'select' })``;
const FormTextArea = styled(FormInput).attrs({ as: 'textarea' })` min-height: 100px; `;

const ImageUploadBox = styled.label`
  border: 2px dashed #d1d5db;
  border-radius: 0.75rem;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
  display: block;
  transition: all 0.2s ease-in-out;
  &:hover {
    border-color: #0ea5e9;
    background-color: #f0f9ff;
  }
`;

const ImagePreview = styled.img`
  width: 150px;
  height: 150px;
  object-fit: cover;
  border-radius: 0.75rem;
  margin: 0 auto 1rem;
  display: block;
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 2rem;
  border-top: 1px solid #e5e7eb;
  padding-top: 1.5rem;
`;

const FormButton = styled.button`
  padding: 0.75rem 2rem;
  border-radius: 0.5rem;
  font-weight: 600;
  white-space: nowrap;
  transition: all 0.2s ease-in-out;
  
  &.primary {
    background-color: #0ea5e9;
    border-color: #0ea5e9;
    &:hover { background-color: #0284c7; }
  }
  
  &.secondary {
    background-color: #e5e7eb;
    border-color: #e5e7eb;
    color: #374151;
    &:hover { background-color: #d1d5db; }
  }

  &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
  }
`;

const Alert = styled.div`
    display: flex;
    align-items: center;
    gap: 0.75rem;
`;

// --- Stepper Content Components ---

const Step1 = ({ data, handleChange, handleImageChange, imagePreview }) => (
    <FormSection>
        <h4 className="fw-bold text-dark mb-4">1. Product Details</h4>
        <div className="row g-4">
            <div className="col-md-6">
                <FormGroup>
                    <label className="form-label">Tablet Name *</label>
                    <FormInput type="text" className="form-control" name="tablet_name" value={data.tablet_name} onChange={handleChange('basic_information')} placeholder="e.g., Paracetamol 500mg" required />
                </FormGroup>
                <FormGroup>
                    <label className="form-label">Brand/Manufacturer</label>
                    <FormInput type="text" className="form-control" name="brand" value={data.brand} onChange={handleChange('basic_information')} placeholder="e.g., Cipla, Sun Pharma" />
                </FormGroup>
            </div>
            <div className="col-md-6">
                <FormGroup>
                    <label className="form-label">Product Image *</label>
                    <ImageUploadBox htmlFor="image-upload">
                        {imagePreview ? <ImagePreview src={imagePreview} alt="Product preview" /> : <div className="fs-1 text-info mb-2"><FaUpload /></div>}
                        <p className="text-dark fw-bold mb-1">Click to upload image</p>
                        <small className="text-secondary">PNG, JPG up to 5MB</small>
                    </ImageUploadBox>
                    <input id="image-upload" type="file" accept="image/png, image/jpeg" className="d-none" onChange={handleImageChange} />
                </FormGroup>
            </div>
        </div>
    </FormSection>
);

const Step2 = ({ data, handleChange }) => (
    <FormSection>
        <h4 className="fw-bold text-dark mb-4">2. Inventory & Dates</h4>
        <div className="row g-4">
            <div className="col-md-6">
                <FormGroup>
                    <label className="form-label">Quantity</label>
                    <FormInput type="number" className="form-control" name="quantity" value={data.quantity} onChange={handleChange('basic_information')} placeholder="100" />
                </FormGroup>
                 <FormGroup>
                    <label className="form-label">Unit Type</label>
                    <FormSelect className="form-select" name="unit_type" value={data.unit_type} onChange={handleChange('basic_information')}>
                        <option>Tablets</option>
                        <option>Capsules</option>
                        <option>Strips</option>
                        <option>Bottles</option>
                    </FormSelect>
                </FormGroup>
                <FormGroup>
                    <label className="form-label">Batch Number</label>
                    <FormInput type="text" className="form-control" name="batch_number" value={data.batch_number} onChange={handleChange('additional_details')} placeholder="e.g., BT001234" />
                </FormGroup>
            </div>
            <div className="col-md-6">
                <FormGroup>
                    <label className="form-label">Manufacturing Date</label>
                    <FormInput type="date" className="form-control" name="manufacturing_date" value={data.manufacturing_date} onChange={handleChange('important_dates')} />
                </FormGroup>
                <FormGroup>
                    <label className="form-label">Best Before Date</label>
                    <FormInput type="date" className="form-control" name="best_before_date" value={data.best_before_date} onChange={handleChange('important_dates')} />
                </FormGroup>
                <FormGroup>
                    <label className="form-label">Expiry Date *</label>
                    <FormInput type="date" className="form-control" name="expiry_date" value={data.expiry_date} onChange={handleChange('important_dates')} required />
                </FormGroup>
            </div>
        </div>
    </FormSection>
);

const Step3 = ({ data, handleChange }) => (
    <FormSection>
        <h4 className="fw-bold text-dark mb-4">3. Pricing & Usage</h4>
        <div className="row g-4">
            <div className="col-md-6">
                <FormGroup>
                    <label className="form-label">Original Price (₹)</label>
                    <FormInput type="number" className="form-control" name="original_price" value={data.original_price} onChange={handleChange('pricing_discounts')} placeholder="100.00" />
                </FormGroup>
                <FormGroup>
                    <label className="form-label">Discount Slabs</label>
                    {[50, 75, 90].map(d => (
                        <div className="form-check" key={d}>
                            <input 
                                className="form-check-input" 
                                type="checkbox" 
                                name={d} 
                                id={`discount${d}`} 
                                checked={data.discount.includes(d)} 
                                onChange={handleChange('pricing_discounts', 'discount')} 
                            />
                            <label className="form-check-label text-dark" htmlFor={`discount${d}`}>{d}% Discount</label>
                        </div>
                    ))}
                </FormGroup>
            </div>
            <div className="col-md-6">
                <FormGroup>
                    <label className="form-label">Usage Instructions</label>
                    <FormTextArea className="form-control" rows="3" name="usage_instructions" value={data.usage_instructions} onChange={handleChange('usage_information')} placeholder="e.g., Twice 1-2 tablets with water..."></FormTextArea>
                </FormGroup>
                <FormGroup>
                    <label className="form-label">Storage Instructions</label>
                    <FormInput type="text" className="form-control" name="storage_instructions" value={data.storage_instructions} onChange={handleChange('usage_information')} placeholder="e.g., Store in cool, dry place" />
                </FormGroup>
            </div>
        </div>
    </FormSection>
);


// --- Main Add New Product Component ---
const AddNewProduct = ({ navigateTo }) => {
    const [currentStep, setCurrentStep] = useState(1);
    const [imageFile, setImageFile] = useState(null);
    const [imagePreview, setImagePreview] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [status, setStatus] = useState({ error: '', success: '' });
    
    const [productData, setProductData] = useState({
        location: '',
        basic_information: { tablet_name: '', brand: '', quantity: '', unit_type: 'Tablets' },
        important_dates: { manufacturing_date: '', best_before_date: '', expiry_date: '' },
        usage_information: { usage_instructions: '', storage_instructions: '' },
        pricing_discounts: { original_price: '', discount: [] },
        additional_details: { batch_number: '' }
    });
    
    useEffect(() => {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                setProductData(prev => ({...prev, location: `${latitude},${longitude}`}));
            },
            () => console.warn("Could not get user location.")
        );
    }, []);

    const handleChange = (section, field) => (e) => {
        const { name, value, type, checked } = e.target;
        
        if (type === 'checkbox' && field === 'discount') {
            const numericName = parseInt(name, 10);
            setProductData(prev => {
                const currentDiscounts = prev.pricing_discounts.discount;
                const newDiscounts = checked ? [...currentDiscounts, numericName] : currentDiscounts.filter(d => d !== numericName);
                return { ...prev, pricing_discounts: { ...prev.pricing_discounts, discount: newDiscounts } };
            });
        } else {
             setProductData(prev => ({
                ...prev,
                [section]: { ...prev[section], [name]: value }
            }));
        }
    };
    
    const handleImageChange = (e) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setImageFile(file);
            setImagePreview(URL.createObjectURL(file));
        }
    };

    const nextStep = () => setCurrentStep(prev => prev < 3 ? prev + 1 : 3);
    const prevStep = () => setCurrentStep(prev => prev > 1 ? prev - 1 : 1);

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (currentStep !== 3) {
            return; 
        }

        setIsLoading(true);
        setStatus({ error: '', success: '' });
        
        // Validation bypassed for testing
        if (false && (!productData.basic_information.tablet_name || !productData.important_dates.expiry_date || !imageFile)) {

            setStatus({ error: 'Please fill all required fields (*) and upload an image.', success: '' });
            setIsLoading(false);
            return;
        }
        
        const formData = new FormData();
        formData.append('file', imageFile);
        formData.append('user_id', localStorage.getItem('user_id'));
        formData.append('location', productData.location);
        
        Object.entries(productData).forEach(([section, fields]) => {
            if (typeof fields === 'object' && fields !== null) {
                Object.entries(fields).forEach(([key, value]) => {
                    const finalValue = Array.isArray(value) ? value.join(', ') : value;
                    formData.append(`${section}[${key}]`, finalValue);
                });
            }
        });

        // Debug: Log FormData entries
        for (let [key, value] of formData.entries()) {
            console.log(`FormData: ${key} =`, value);
        }
        
        try {
            const response = await fetch(`${BaseUrl}/products/product`, {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            if (!response.ok) throw new Error(result.error || 'Failed to add product.');
            
            setStatus({ success: 'Product published successfully! Redirecting...', error: '' });
            setTimeout(() => navigateTo('My Products'), 2000);

        } catch (err) {
            setStatus({ error: err.message, success: '' });
        } finally {
            setIsLoading(false);
        }
    };

    const steps = [
        { icon: <FaBoxOpen />, label: 'Product Details' },
        { icon: <FaCalendarAlt />, label: 'Inventory & Dates' },
        { icon: <FaTag />, label: 'Pricing & Usage' },
    ];
    
    const progressPercentage = ((currentStep - 1) / (steps.length - 1)) * 100;

    return (
        <PageContainer>
            <Header><Title>Add New Product</Title></Header>
            <FormWrapper>
                <Stepper>
                    <ProgressBackground />
                    <ProgressBar progress={progressPercentage} />
                    {steps.map((step, index) => (
                        <Step key={index} active={currentStep >= index + 1}>
                            <div className="icon">{step.icon}</div>
                            <div className="label">{step.label}</div>
                        </Step>
                    ))}
                </Stepper>
                
                <form onSubmit={handleSubmit}>
                    {currentStep === 1 && <Step1 data={productData.basic_information} handleChange={handleChange} handleImageChange={handleImageChange} imagePreview={imagePreview} />}
                    {currentStep === 2 && <Step2 data={{ ...productData.basic_information, ...productData.additional_details, ...productData.important_dates }} handleChange={handleChange} />}
                    {currentStep === 3 && <Step3 data={{ ...productData.pricing_discounts, ...productData.usage_information }} handleChange={handleChange} />}
                    
                    <ButtonGroup>
                        <FormButton type="button" className="btn secondary" onClick={prevStep} disabled={currentStep === 1}>Back</FormButton>
                        {currentStep < 3 ? (
                            <FormButton type="button" className="btn primary" onClick={nextStep}>Next</FormButton>
                        ) : (
                            <FormButton type="submit" className="btn primary" disabled={isLoading}>
                                {isLoading ? <><FaSpinner className="fa-spin me-2" /> Publishing...</> : 'Publish Product'}
                            </FormButton>
                        )}
                    </ButtonGroup>

                    {status.error && <Alert className="alert alert-danger mt-4"><FaExclamationCircle /> {status.error}</Alert>}
                    {status.success && <Alert className="alert alert-success mt-4"><FaCheckCircle /> {status.success}</Alert>}
                </form>
            </FormWrapper>
        </PageContainer>
    );
};

export default AddNewProduct;