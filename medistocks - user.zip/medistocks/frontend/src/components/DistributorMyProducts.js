import React, { useState, useEffect, useMemo } from 'react';
import styled, { keyframes } from 'styled-components';
import { FaPlus, FaSearch, FaFileExport, FaEdit, FaTrash, FaTimes, FaMapMarkerAlt, FaSpinner } from 'react-icons/fa';

// --- Base URL for API ---
import BaseUrl from './BaseUrl';

// --- PHARMACY THEME TOKENS ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

// --- Styled Components (improved, responsive) ---
const PageWrapper = styled.div`
  background: ${LIGHT_GREEN};
  min-height: 100vh;
  padding: 1rem;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  @media (min-width: 768px) {
    padding: 2rem;
  }
`;

const Header = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 1.5rem;
  @media (min-width: 640px) {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }
`;

const Title = styled.h2`
  font-weight: 700;
  color: ${DARK_NAVY};
  margin: 0;
  font-size: 1.5rem;
  letter-spacing: -0.3px;
  @media (min-width: 768px) {
    font-size: 1.75rem;
  }
`;

const HeaderActions = styled.div`
  display: flex;
  gap: 0.75rem;
  flex-wrap: wrap;
`;

const IconButton = styled.button`
  background: white;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 40px;
  padding: 0.6rem;
  color: ${DARK_NAVY};
  transition: all 0.2s;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  &:hover {
    background: ${LIGHT_GREEN};
    border-color: ${PHARMACY_GREEN};
    color: ${PHARMACY_GREEN};
    transform: translateY(-2px);
  }
`;

const AddProductButton = styled.button`
  background: ${PHARMACY_GREEN};
  color: white;
  border: none;
  border-radius: 40px;
  padding: 0.6rem 1.2rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.2s;
  box-shadow: 0 2px 8px rgba(13,124,61,0.2);
  cursor: pointer;
  &:hover {
    background: #0a5e2e;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(13,124,61,0.3);
  }
`;

const FilterContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-bottom: 2rem;
`;

const FilterChip = styled.button`
  background: ${({ active }) => (active ? PHARMACY_GREEN : 'white')};
  color: ${({ active }) => (active ? 'white' : DARK_NAVY)};
  border: 1.5px solid ${({ active }) => (active ? PHARMACY_GREEN : BORDER_GREY)};
  padding: 0.5rem 1rem;
  border-radius: 40px;
  font-weight: 600;
  font-size: 0.8rem;
  transition: all 0.2s;
  cursor: pointer;
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.05);
  }
  @media (min-width: 768px) {
    font-size: 0.9rem;
  }
`;

const ProductGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 1.25rem;
  @media (min-width: 576px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (min-width: 992px) {
    grid-template-columns: repeat(3, 1fr);
  }
  @media (min-width: 1200px) {
    grid-template-columns: repeat(4, 1fr);
  }
`;

const fadeIn = keyframes`
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
`;

const ProductCard = styled.div`
  background: white;
  border-radius: 1.25rem;
  border: 1px solid ${BORDER_GREY};
  padding: 1.25rem;
  box-shadow: ${CARD_SHADOW};
  cursor: pointer;
  transition: all 0.25s;
  animation: ${fadeIn} 0.4s ease-out;
  &:hover {
    transform: translateY(-4px);
    box-shadow: ${HOVER_SHADOW};
    border-color: ${PHARMACY_GREEN}40;
  }
`;

const CardHeader = styled.div`
  display: flex;
  gap: 1rem;
  align-items: flex-start;
`;

const ProductImage = styled.img`
  width: 70px;
  height: 70px;
  border-radius: 0.75rem;
  object-fit: cover;
  border: 1px solid ${BORDER_GREY};
  @media (min-width: 768px) {
    width: 80px;
    height: 80px;
  }
`;

const ProductInfo = styled.div`
  flex: 1;
`;

const ProductName = styled.h3`
  font-size: 1rem;
  font-weight: 700;
  color: ${DARK_NAVY};
  margin: 0 0 0.25rem;
  @media (min-width: 768px) {
    font-size: 1.1rem;
  }
`;

const BrandName = styled.p`
  font-size: 0.8rem;
  color: #6c757d;
  margin: 0 0 0.5rem;
`;

const StatusBadge = styled.span`
  padding: 0.2rem 0.6rem;
  border-radius: 40px;
  font-weight: 700;
  font-size: 0.7rem;
  color: white;
  background: ${({ status }) => {
    if (status === 'Active') return PHARMACY_GREEN;
    if (status === 'Expiring Soon') return '#f39c12';
    if (status === 'Expired') return '#c0392b';
    return '#6c757d';
  }};
  display: inline-block;
`;

const CardFooter = styled.div`
  margin-top: 1rem;
  padding-top: 0.75rem;
  border-top: 1px solid ${BORDER_GREY};
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.5rem;
`;

const PriceInfo = styled.div`
  display: flex;
  align-items: baseline;
  gap: 0.5rem;
  flex-wrap: wrap;
`;

const CurrentPrice = styled.span`
  font-size: 1.1rem;
  font-weight: 800;
  color: ${PHARMACY_GREEN};
  @media (min-width: 768px) {
    font-size: 1.25rem;
  }
`;

const OriginalPrice = styled.s`
  color: #8b96a5;
  font-size: 0.8rem;
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 0.25rem;
`;

// --- Modal Styles (improved) ---
const ModalBackdrop = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  padding: 1rem;
`;

const ModalContent = styled.div`
  background: white;
  border-radius: 1.5rem;
  padding: 1.5rem;
  width: 90%;
  max-width: ${props => props.small ? '500px' : '700px'};
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: ${HOVER_SHADOW};
  animation: ${fadeIn} 0.3s ease-out;
  @media (min-width: 768px) {
    padding: 2rem;
  }
`;

const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid ${BORDER_GREY};
  padding-bottom: 1rem;
  margin-bottom: 1rem;
`;

const DetailRow = styled.p`
  font-size: 0.85rem;
  color: #4a5568;
  margin-bottom: 0.75rem;
  strong { color: ${DARK_NAVY}; }
  @media (min-width: 768px) {
    font-size: 0.9rem;
  }
`;

const FormInput = styled.input`
  width: 100%;
  padding: 0.7rem;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 0.75rem;
  margin-top: 0.25rem;
  font-size: 0.85rem;
  transition: all 0.2s;
  &:focus {
    outline: none;
    border-color: ${PHARMACY_GREEN};
    box-shadow: 0 0 0 3px ${PHARMACY_GREEN}20;
  }
`;

const FormLabel = styled.label`
  font-weight: 700;
  font-size: 0.75rem;
  color: ${DARK_NAVY};
  text-transform: uppercase;
  letter-spacing: 0.5px;
`;

// --- Helper Functions (unchanged) ---
const formatDate = (dateString) => new Date(dateString).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
const formatDateForInput = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
};

const getProductStatus = (expiryDate) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysUntilExpiry = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    if (daysUntilExpiry < 0) return 'Expired';
    if (daysUntilExpiry <= 30) return 'Expiring Soon';
    return 'Active';
};

// --- Child Components for Modals (UI improved, logic unchanged) ---
const UpdateProductModal = ({ product, onClose, onUpdateSuccess }) => {
    const [formData, setFormData] = useState({
        tablet_name: product.tablet_name,
        brand: product.brand,
        quantity: product.quantity,
        original_price: product.original_price,
        discount: product.discount,
        expiry_date: formatDateForInput(product.expiry_date)
    });
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleUpdate = async () => {
        setIsLoading(true);
        try {
            const payload = {
                ...formData,
                user_id: localStorage.getItem('user_id'),
                quantity: parseInt(formData.quantity, 10),
                original_price: parseFloat(formData.original_price),
                discount: parseFloat(formData.discount),
            };
            const response = await fetch(`${BaseUrl}/products/item/${product.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || "Update failed");
            onUpdateSuccess(result.product);
            onClose();
        } catch (error) {
            alert(`Error: ${error.message}`);
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <ModalBackdrop>
            <ModalContent>
                <ModalHeader>
                    <Title style={{ fontSize: '1.3rem', margin: 0 }}>Update Product</Title>
                    <IconButton onClick={onClose}><FaTimes /></IconButton>
                </ModalHeader>
                <div className="row g-3">
                    <div className="col-12"><FormLabel>Tablet Name</FormLabel><FormInput name="tablet_name" value={formData.tablet_name} onChange={handleChange} /></div>
                    <div className="col-md-6"><FormLabel>Brand</FormLabel><FormInput name="brand" value={formData.brand} onChange={handleChange} /></div>
                    <div className="col-md-6"><FormLabel>Quantity</FormLabel><FormInput type="number" name="quantity" value={formData.quantity} onChange={handleChange} /></div>
                    <div className="col-md-6"><FormLabel>Price (₹)</FormLabel><FormInput type="number" name="original_price" value={formData.original_price} onChange={handleChange} /></div>
                    <div className="col-md-6"><FormLabel>Discount (%)</FormLabel><FormInput type="number" name="discount" value={formData.discount} onChange={handleChange} /></div>
                    <div className="col-12"><FormLabel>Expiry Date</FormLabel><FormInput type="date" name="expiry_date" value={formData.expiry_date} onChange={handleChange} /></div>
                </div>
                <div className="d-flex justify-content-end gap-3 mt-4">
                    <button className="btn btn-secondary" onClick={onClose} style={{ background: '#f1f5f9', border: '1.5px solid #dee2e6', borderRadius: '40px', padding: '0.5rem 1rem', fontWeight: 600 }}>Cancel</button>
                    <AddProductButton onClick={handleUpdate} disabled={isLoading}>
                        {isLoading ? <FaSpinner className="fa-spin me-2" /> : null} Save Changes
                    </AddProductButton>
                </div>
            </ModalContent>
        </ModalBackdrop>
    );
};

const DeleteConfirmModal = ({ onConfirm, onCancel, productName }) => (
    <ModalBackdrop>
        <ModalContent small>
            <Title style={{ fontSize: '1.3rem', marginBottom: '1rem' }}>Confirm Deletion</Title>
            <p className="my-3" style={{ color: DARK_NAVY }}>Are you sure you want to delete the product "<strong>{productName}</strong>"? This action cannot be undone.</p>
            <div className="d-flex justify-content-end gap-3 mt-4">
                <button className="btn btn-secondary" onClick={onCancel} style={{ background: '#f1f5f9', border: '1.5px solid #dee2e6', borderRadius: '40px', padding: '0.5rem 1rem', fontWeight: 600 }}>Cancel</button>
                <button className="btn btn-danger" onClick={onConfirm} style={{ background: '#c0392b', border: 'none', borderRadius: '40px', padding: '0.5rem 1rem', fontWeight: 600, color: 'white' }}>Delete</button>
            </div>
        </ModalContent>
    </ModalBackdrop>
);

// --- Main MyProducts Component (logic untouched, UI improved) ---
const MyProducts = ({ onAddProduct }) => {
    const [products, setProducts] = useState([]);
    const [filter, setFilter] = useState('All');
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [productToUpdate, setProductToUpdate] = useState(null);
    const [productToDelete, setProductToDelete] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchProducts = async () => {
            setLoading(true);
            const distributionId = localStorage.getItem('user_id');
            if (!distributionId) {
                console.error("Distribution ID not found.");
                setLoading(false);
                return;
            }
            try {
                const response = await fetch(`${BaseUrl}/products/user/${distributionId}`);
                if (!response.ok) throw new Error("Failed to fetch products.");
                const data = await response.json();
                const processedData = data.map(p => ({ ...p, status: getProductStatus(p.expiry_date) }));
                setProducts(processedData);
            } catch (error) {
                console.error("API Error:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchProducts();
    }, []);

    const handleUpdateSuccess = (updatedProduct) => {
        const processedProduct = { ...updatedProduct, status: getProductStatus(updatedProduct.expiry_date) };
        setProducts(products.map(p => p.id === processedProduct.id ? processedProduct : p));
    };

    const handleDelete = async () => {
        if (!productToDelete) return;
        try {
            const response = await fetch(`${BaseUrl}/products/item/${productToDelete.id}`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_id: localStorage.getItem('user_id') })
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || "Delete failed");
            setProducts(products.filter(p => p.id !== productToDelete.id));
            setProductToDelete(null);
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    };

    const filteredProducts = useMemo(() => {
        if (filter === 'All') return products;
        return products.filter(p => p.status === filter);
    }, [filter, products]);

    const getCount = (status) => {
        if (status === 'All') return products.length;
        return products.filter(p => p.status === status).length;
    };
    
    return (
        <PageWrapper>
            <Header>
                <Title>My Products</Title>
                <HeaderActions>
                    <IconButton><FaSearch size={14} /></IconButton>
                    <IconButton><FaFileExport size={14} /></IconButton>
                    <AddProductButton onClick={onAddProduct}><FaPlus size={14} /> Add Product</AddProductButton>
                </HeaderActions>
            </Header>

            <FilterContainer>
                {['All', 'Active', 'Expiring Soon', 'Expired'].map(f => (
                    <FilterChip key={f} active={filter === f} onClick={() => setFilter(f)}>
                        {f} ({getCount(f)})
                    </FilterChip>
                ))}
            </FilterContainer>

            {loading ? (
                <div style={{ textAlign: 'center', padding: '3rem', color: '#6c757d' }}>Loading products...</div>
            ) : (
                <ProductGrid>
                    {filteredProducts.map(product => (
                        <ProductCard key={product.id} onClick={() => setSelectedProduct(product)}>
                            <CardHeader>
                                <ProductImage src={product.image_url} alt={product.tablet_name} onError={(e) => { e.target.src = 'https://placehold.co/80x80/1a2e4a/white?text=No+Image'; }} />
                                <ProductInfo>
                                    <ProductName>{product.tablet_name}</ProductName>
                                    <BrandName>{product.brand || 'No brand'}</BrandName>
                                    <StatusBadge status={product.status}>{product.status}</StatusBadge>
                                </ProductInfo>
                            </CardHeader>
                            <CardFooter>
                                <PriceInfo>
                                    <CurrentPrice>₹{Math.round(product.original_price * (1 - product.discount / 100))}</CurrentPrice>
                                    <OriginalPrice>₹{product.original_price}</OriginalPrice>
                                </PriceInfo>
                                <ActionButtons>
                                    <IconButton onClick={(e) => { e.stopPropagation(); setProductToUpdate(product); }} style={{ padding: '0.4rem' }}><FaEdit size={12} /></IconButton>
                                    <IconButton onClick={(e) => { e.stopPropagation(); setProductToDelete(product); }} style={{ padding: '0.4rem' }}><FaTrash size={12} /></IconButton>
                                </ActionButtons>
                            </CardFooter>
                        </ProductCard>
                    ))}
                </ProductGrid>
            )}

            {selectedProduct && (
                <ModalBackdrop onClick={() => setSelectedProduct(null)}>
                    <ModalContent onClick={e => e.stopPropagation()}>
                        <ModalHeader>
                            <ProductName style={{ margin: 0 }}>{selectedProduct.tablet_name}</ProductName>
                            <IconButton onClick={() => setSelectedProduct(null)}><FaTimes /></IconButton>
                        </ModalHeader>
                        <div className="row">
                            <div className="col-md-6">
                                <DetailRow><strong>Brand:</strong> {selectedProduct.brand || 'N/A'}</DetailRow>
                                <DetailRow><strong>Quantity:</strong> {selectedProduct.quantity} {selectedProduct.unit_type}</DetailRow>
                                <DetailRow><strong>Batch No:</strong> {selectedProduct.batch_number || 'N/A'}</DetailRow>
                                <DetailRow><strong>Discount:</strong> {selectedProduct.discount}%</DetailRow>
                                <DetailRow><strong>Location:</strong> <a href={`https://www.google.com/maps?q=${selectedProduct.location}`} target="_blank" rel="noopener noreferrer" style={{ color: PHARMACY_GREEN }}><FaMapMarkerAlt className="ms-2 me-1" />View on Map</a></DetailRow>
                            </div>
                            <div className="col-md-6">
                                <DetailRow><strong>Mfg. Date:</strong> {formatDate(selectedProduct.manufacturing_date)}</DetailRow>
                                <DetailRow><strong>Best Before:</strong> {formatDate(selectedProduct.best_before_date)}</DetailRow>
                                <DetailRow><strong>Expiry Date:</strong> {formatDate(selectedProduct.expiry_date)}</DetailRow>
                            </div>
                        </div>
                        <div className="mt-3 pt-3 border-top" style={{ borderTopColor: BORDER_GREY }}>
                            <DetailRow><strong>Usage:</strong> {selectedProduct.usage_instructions || 'N/A'}</DetailRow>
                            <DetailRow><strong>Storage:</strong> {selectedProduct.storage_instructions || 'N/A'}</DetailRow>
                        </div>
                    </ModalContent>
                </ModalBackdrop>
            )}

            {productToUpdate && <UpdateProductModal product={productToUpdate} onClose={() => setProductToUpdate(null)} onUpdateSuccess={handleUpdateSuccess} />}
            {productToDelete && <DeleteConfirmModal productName={productToDelete.tablet_name} onCancel={() => setProductToDelete(null)} onConfirm={handleDelete} />}
        </PageWrapper>
    );
};

export default MyProducts;