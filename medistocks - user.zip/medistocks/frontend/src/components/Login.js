import React, { useState } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setAuthData } from './redux/authSlice';
import {
  FiMail,
  FiKey,
  FiLoader,
  FiShoppingCart,
  FiPlusSquare,
  FiUsers,
  FiAward,
  FiShield,
  FiLock,
} from 'react-icons/fi';
import MedicalAnimationCanvas from './MedicalAnimationCanvas';

import BaseUrl from './BaseUrl';

const TEMP_PASSWORD = '123456';

const GlobalStyle = createGlobalStyle`
  *, *::before, *::after { box-sizing: border-box; }
  body { margin: 0; padding: 0; overflow: hidden; font-family: 'Plus Jakarta Sans', sans-serif; background: #f5f7fa; }
`;

const fadeIn = keyframes`from{opacity:0}to{opacity:1}`;
const slideL = keyframes`from{opacity:0;transform:translateX(-32px)}to{opacity:1;transform:translateX(0)}`;
const slideR = keyframes`from{opacity:0;transform:translateX(32px)}to{opacity:1;transform:translateX(0)}`;
const spinAnim = keyframes`from{transform:rotate(0deg)}to{transform:rotate(360deg)}`;

const ModalOverlay = styled.div`
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center;
  z-index: 1000; animation: ${fadeIn} 0.3s ease;
`;

const ModalContent = styled.div`
  background: #fff; padding: 2rem; border-radius: 20px; width: 100%; max-width: 400px;
  box-shadow: 0 20px 40px rgba(0,0,0,0.1);
`;

const ForgotBtn = styled.button`
  background: none; border: none; color: #10b981; font-size: 0.8rem; font-weight: 600;
  cursor: pointer; padding: 0; margin-bottom: 15px; display: block; width: 100%; text-align: right;
  &:hover { text-decoration: underline; }
`;

const Page = styled.div`
  min-height: 100vh;
  display: flex; align-items: center; justify-content: center;
  padding: 2rem; position: relative; z-index: 1; background: #f5f7fa;
  @media(max-width:640px){padding:1rem;}
`;

const Card = styled.div`
  display: flex; width: 100%; max-width: 1020px;
  background: #fff;
  border-radius: 20px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.03), 0 20px 48px rgba(0,0,0,0.07), 0 0 0 1px rgba(0,0,0,0.04);
  overflow: hidden;
  animation: ${fadeIn} 0.6s ease;
  @media(max-width:900px){flex-direction:column;max-width:440px;}
`;

const Left = styled.div`
  flex:1; padding:3.5rem;
  background: linear-gradient(145deg,#f0fdf9 0%,#eff6ff 60%,#fdf4ff 100%);
  border-right: 1px solid #f0f0f0;
  display:flex; flex-direction:column; justify-content:center;
  animation:${slideL} 0.6s ease;
  @media(max-width:900px){display:none;}
`;

const Brand = styled.div`display:flex;align-items:center;gap:10px;margin-bottom:2.5rem;`;
const BrandMark = styled.div`
  width:38px;height:38px;border-radius:10px;
  background:linear-gradient(135deg,#10b981,#0ea5e9);
  display:flex;align-items:center;justify-content:center;
  box-shadow:0 4px 10px rgba(16,185,129,0.28);
`;
const BrandName = styled.span`font-weight:800;font-size:1.2rem;color:#111827;em{color:#10b981;font-style:normal;}`;

const Headline = styled.h2`
  font-size:2.1rem;font-weight:800;line-height:1.2;
  color:#111827;margin:0 0 1rem;letter-spacing:-0.5px;
`;
const GreenSpan = styled.span`color:#10b981;`;
const SubText = styled.p`color:#6b7280;font-size:0.93rem;line-height:1.7;margin:0 0 2.5rem;`;

const FeatureList = styled.div`display:flex;flex-direction:column;gap:9px;`;
const Feature = styled.div`
  display:flex;align-items:center;gap:11px;padding:11px 15px;
  background:#fff;border:1px solid #e5e7eb;border-radius:10px;
  box-shadow:0 1px 3px rgba(0,0,0,0.04);
  opacity:0;animation:${slideL} 0.5s ease forwards;animation-delay:${p => p.$d};
  svg{color:#10b981;font-size:1.05rem;flex-shrink:0;}
  span{color:#374151;font-size:0.86rem;font-weight:500;}
`;

const Right = styled.div`
  flex:0 0 390px;padding:3.5rem;
  background:#fff;display:flex;flex-direction:column;justify-content:center;
  animation:${slideR} 0.6s ease both;animation-delay:0.1s;
  @media(max-width:900px){flex:1;padding:2.5rem;}
  @media(max-width:480px){padding:2rem 1.5rem;}
`;

const FormHead = styled.div`margin-bottom:2rem;`;
const FormTitle = styled.h3`font-size:1.45rem;font-weight:800;color:#111827;margin:0 0 5px;letter-spacing:-0.3px;`;
const FormSub = styled.p`font-size:0.83rem;color:#9ca3af;margin:0;`;

const InputWrap = styled.div`
  position:relative;margin-bottom:13px;
  .ic{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:#9ca3af;font-size:1rem;pointer-events:none;}
`;
const Input = styled.input`
  width:100%;padding:12px 13px 12px 40px;
  background:#f9fafb;border:1.5px solid #e5e7eb;border-radius:10px;
  color:#111827;font-family:'Plus Jakarta Sans',sans-serif;font-size:0.875rem;
  transition:all .2s;outline:none;
  &:focus{border-color:#10b981;background:#fff;box-shadow:0 0 0 3px rgba(16,185,129,0.1);}
  &::placeholder{color:#d1d5db;}
  &:disabled{opacity:.5;cursor:not-allowed;}
`;

const SubmitBtn = styled.button`
  width:100%;padding:13px;margin-top:5px;
  background:linear-gradient(135deg,#10b981,#0ea5e9);
  border:none;border-radius:10px;color:#fff;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:0.92rem;font-weight:700;
  cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;
  transition:all .2s;box-shadow:0 4px 12px rgba(16,185,129,0.28);
  &:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 18px rgba(16,185,129,0.36);}
  &:disabled{opacity:.45;cursor:not-allowed;transform:none;box-shadow:none;}
  .sp{animation:${spinAnim} 1s linear infinite;}
`;

const Alert = styled.div`
  padding:11px 14px;border-radius:9px;font-size:0.84rem;margin-bottom:13px;
  background:${p => p.$err ? '#fef2f2' : '#f0fdf9'};
  border:1px solid ${p => p.$err ? '#fecaca' : '#a7f3d0'};
  color:${p => p.$err ? '#ef4444' : '#059669'};
  animation:${fadeIn} .3s ease;
`;
const Hr = styled.div`height:1px;background:#f5f5f5;margin:20px 0;`;
const Tip = styled.p`
  text-align:center;color:#9ca3af;font-size:0.84rem;margin:14px 0 0;
  button{background:none;border:none;color:#10b981;font-weight:700;cursor:pointer;font-family:inherit;font-size:inherit;
    &:hover{text-decoration:underline;}}
`;

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Forgot Password States
  const [forgotModal, setForgotModal] = useState(false);
  const [forgotStep, setForgotStep] = useState(1); // 1: Email, 2: OTP, 3: New Password
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotOtp, setForgotOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtpField, setShowOtpField] = useState(false);
  const [resetToken, setResetToken] = useState('');

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const normalizedEmail = email.trim().toLowerCase();
      if (!normalizedEmail) throw new Error('Please enter your email.');

      if (!showOtpField) {
        // Step 1: Send OTP
        const res = await fetch(`${BaseUrl}/auth/login/send_email_otp`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email_address: normalizedEmail })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Failed to send OTP');
        
        setShowOtpField(true);
        setSuccess('OTP sent to your email. Please verify.');
      } else {
        // Step 2: Verify OTP
        if (!otp) throw new Error('Please enter the OTP.');
        
        const res = await fetch(`${BaseUrl}/auth/login/verify_email_otp`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email_address: normalizedEmail, otp: otp })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Invalid OTP');

        // Success! Store tokens and navigate
        const authData = {
          user_id: data.user_id,
          role: data.role,
          access_token: data.access_token,
          refresh_token: data.refresh_token,
        };

        dispatch(setAuthData(authData));
        localStorage.setItem('authToken', data.access_token);
        localStorage.setItem('refreshToken', data.refresh_token);
        localStorage.setItem('user_id', data.user_id);
        localStorage.setItem('role', data.role);

        setSuccess('Login successful!');
        navigate(data.role === 'distributor' ? '/distributor-dashboard' : '/retailer-dashboard');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotSendOtp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${BaseUrl}/auth/forgot_password/send_email_otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email_address: forgotEmail })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to send OTP');
      setForgotStep(2);
      setSuccess('OTP sent to your email.');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotVerifyOtp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${BaseUrl}/auth/forgot_password/verify_email_otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email_address: forgotEmail, otp: forgotOtp })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Invalid OTP');
      setResetToken(data.reset_token);
      setForgotStep(3);
      setSuccess('OTP verified. Set your new password.');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotReset = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${BaseUrl}/auth/forgot_password/reset`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ new_password: newPassword, reset_token: resetToken })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to reset password');
      setForgotModal(false);
      setForgotStep(1);
      setSuccess('Password reset successful. You can now login.');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <GlobalStyle />
      <MedicalAnimationCanvas />
      <Page>
        <Card>
          <Left>
            <Brand>
              <BrandMark>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M9 12H15M12 9V15" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" />
                </svg>
              </BrandMark>
              <BrandName>Medi<em>Stox</em></BrandName>
            </Brand>
            <Headline>The smarter way to<br /><GreenSpan>manage pharma stock</GreenSpan></Headline>
            <SubText>Connect with verified distributors, manage inventory, and grow your pharmacy business all in one place.</SubText>
            <FeatureList>
              <Feature $d="0.3s"><FiShoppingCart /><span>Buy and sell pharmacy products</span></Feature>
              <Feature $d="0.4s"><FiPlusSquare /><span>Extensive product catalog</span></Feature>
              <Feature $d="0.5s"><FiUsers /><span>Trusted network of pharmacies</span></Feature>
              <Feature $d="0.6s"><FiAward /><span>Quality and authenticity guaranteed</span></Feature>
            </FeatureList>
          </Left>

          <Right>
            <FormHead>
              <FormTitle>Welcome back</FormTitle>
              <FormSub>Use any test email and the temporary password 123456</FormSub>
            </FormHead>

            {error && <Alert $err>{error}</Alert>}
            {success && <Alert>{success}</Alert>}

            <form onSubmit={handleLogin}>
              <InputWrap>
                <FiMail className="ic" />
                <Input
                  type="email"
                  placeholder="Email address"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  disabled={loading || showOtpField}
                />
              </InputWrap>

              {!showOtpField ? (
                <InputWrap>
                  <FiKey className="ic" />
                  <Input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    disabled={loading}
                  />
                  <div style={{ fontSize: '0.75rem', color: '#9ca3af', marginTop: '5px' }}>
                    Password login is disabled. Please use OTP.
                  </div>
                </InputWrap>
              ) : (
                <InputWrap>
                  <FiShield className="ic" />
                  <Input
                    type="text"
                    placeholder="Enter 6-digit OTP"
                    value={otp}
                    onChange={e => setOtp(e.target.value)}
                    required
                    disabled={loading}
                  />
                </InputWrap>
              )}

              <ForgotBtn type="button" onClick={() => setForgotModal(true)}>
                Forgot Password?
              </ForgotBtn>

              <SubmitBtn type="submit" disabled={loading}>
                {loading && <FiLoader className="sp" />}
                {loading ? 'Processing...' : (showOtpField ? 'Verify & Login' : 'Get Login OTP')}
              </SubmitBtn>

              {showOtpField && (
                <div style={{ textAlign: 'center', marginTop: '1rem' }}>
                  <ForgotBtn type="button" onClick={() => setShowOtpField(false)} style={{ textAlign: 'center' }}>
                    Change Email
                  </ForgotBtn>
                </div>
              )}
            </form>

            <Hr />
            <Tip>
              New to MediStox?{' '}
              <button type="button" onClick={() => navigate('/registration')}>Create an account</button>
            </Tip>
          </Right>
        </Card>

        {forgotModal && (
          <ModalOverlay onClick={() => setForgotModal(false)}>
            <ModalContent onClick={e => e.stopPropagation()}>
              <FormHead>
                <FormTitle>
                  {forgotStep === 1 && 'Reset Password'}
                  {forgotStep === 2 && 'Verify OTP'}
                  {forgotStep === 3 && 'New Password'}
                </FormTitle>
                <FormSub>
                  {forgotStep === 1 && 'Enter your email to receive an OTP'}
                  {forgotStep === 2 && `Enter the 6-digit OTP sent to ${forgotEmail}`}
                  {forgotStep === 3 && 'Create a strong new password'}
                </FormSub>
              </FormHead>

              {error && <Alert $err>{error}</Alert>}
              {success && <Alert>{success}</Alert>}

              {forgotStep === 1 && (
                <form onSubmit={handleForgotSendOtp}>
                  <InputWrap>
                    <FiMail className="ic" />
                    <Input
                      type="email"
                      placeholder="Email address"
                      value={forgotEmail}
                      onChange={e => setForgotEmail(e.target.value)}
                      required
                      disabled={loading}
                    />
                  </InputWrap>
                  <SubmitBtn type="submit" disabled={loading}>
                    {loading && <span className="sp">⟳</span>}
                    {loading ? 'Sending...' : 'Send OTP'}
                  </SubmitBtn>
                </form>
              )}

              {forgotStep === 2 && (
                <form onSubmit={handleForgotVerifyOtp}>
                  <InputWrap>
                    <FiLock className="ic" />
                    <Input
                      type="text"
                      placeholder="Enter 6-digit OTP"
                      value={forgotOtp}
                      onChange={e => setForgotOtp(e.target.value)}
                      required
                      maxLength={6}
                      disabled={loading}
                    />
                  </InputWrap>
                  <SubmitBtn type="submit" disabled={loading}>
                    {loading && <span className="sp">⟳</span>}
                    {loading ? 'Verifying...' : 'Verify OTP'}
                  </SubmitBtn>
                </form>
              )}

              {forgotStep === 3 && (
                <form onSubmit={handleForgotReset}>
                  <InputWrap>
                    <FiLock className="ic" />
                    <Input
                      type="password"
                      placeholder="New Password"
                      value={newPassword}
                      onChange={e => setNewPassword(e.target.value)}
                      required
                      disabled={loading}
                    />
                  </InputWrap>
                  <SubmitBtn type="submit" disabled={loading}>
                    {loading && <span className="sp">⟳</span>}
                    {loading ? 'Resetting...' : 'Reset Password'}
                  </SubmitBtn>
                </form>
              )}

              <Tip>
                <button onClick={() => setForgotModal(false)}>Back to Login</button>
              </Tip>
            </ModalContent>
          </ModalOverlay>
        )}
      </Page>
    </>
  );
};

export default Login;
