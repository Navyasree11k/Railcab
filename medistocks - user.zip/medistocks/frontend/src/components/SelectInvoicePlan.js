import React, { useState } from 'react';
import styled from 'styled-components';

// --- Styled Components ---
const GlassmorphismContainer = styled.div`
  background-color: #fff;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(55, 65, 81, 0.8);
  border-radius: 1rem;
  padding: 1.5rem;
`;

const PlanCard = styled.div`
  background-color: ${({ active }) => active ? 'rgba(56, 189, 248, 0.1)' : 'rgba(31, 41, 55, 0.5)'};
  backdrop-filter: blur(10px);
  border: 1px solid ${({ active }) => active ? '#0ea5e9' : 'rgba(55, 65, 81, 0.8)'};
  border-radius: 1rem;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  position: relative;

  &:hover {
    border-color: #0ea5e9;
  }
`;

const RadioButton = styled.div`
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 2px solid ${({ active }) => active ? '#0ea5e9' : '#6b7280'};
    background-color: ${({ active }) => active ? '#0ea5e9' : 'transparent'};
    display: flex;
    justify-content: center;
    align-items: center;
    transition: all 0.2s ease-in-out;

    &::after {
        content: '';
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #111827;
        transform: ${({ active }) => active ? 'scale(1)' : 'scale(0)'};
        transition: transform 0.2s ease-in-out;
    }
`;

const SaveTag = styled.div`
    position: absolute;
    top: -1px;
    right: 1.5rem;
    background-color: #22c55e;
    color: #fff;
    padding: 0.25rem 0.75rem;
    font-size: 0.75rem;
    font-weight: bold;
    border-radius: 0 0 0.5rem 0.5rem;
`;


// --- Main Invoice Plan Component ---
const InvoicePlan = ({ onBack , navigateTo }) => {
  const [selectedPlan, setSelectedPlan] = useState(2); // Default to Saver Pack

  const plans = [
    { id: 1, name: 'Basic Plan', description: 'Perfect for occasional use', invoices: '1 Invoice', validity: '30 Days', price: 100, buttonColor: '#3b82f6' },
    { id: 2, name: 'Saver Pack', description: 'Most popular choice', invoices: '10 Invoices', validity: '90 Days', price: 900, originalPrice: 1000, saveAmount: 100, buttonColor: '#22c55e' },
    { id: 3, name: 'Unlimited Plan', description: 'For heavy users', invoices: 'Unlimited', validity: '1 Year', price: 4000, buttonColor: '#3b82f6' },
  ];

  return (
    <div className="container" style={{maxWidth: '800px'}}>
        <div className="d-flex justify-content-between align-items-center my-4">
            <div className="d-flex align-items-center">
                <button className="btn btn-link text-white p-0 me-3" onClick={onBack}>
                    <span className="fs-4">←</span>
                </button>
                <div>
                    <h2 className="text-light fw-bold mb-1">Activate Invoice Plan</h2>
                    <p className="text-secondary">Choose your plan to continue</p>
                </div>
            </div>
             <div className="d-flex align-items-center gap-3">
                <button className="btn btn-link text-white fs-4 p-0">🔔</button>
                <img src="https://placehold.co/40x40/ffffff/111827?text=D" alt="User" className="rounded-circle"/>
            </div>
        </div>

        <div className="alert alert-info d-flex align-items-center" role="alert" style={{backgroundColor: 'rgba(56, 189, 248, 0.1)', borderColor: '#0ea5e9', color: '#e0f2fe'}}>
            <span className="fs-4 me-3">ℹ️</span>
            <div>
                <strong>Invoice Plan Required</strong>
                <p className="mb-0 small">You need an active invoice plan to send the invoice to the buyer.</p>
            </div>
        </div>

        <h4 className="text-light my-4">Choose Your Plan</h4>

        {plans.map(plan => (
            <PlanCard key={plan.id} active={selectedPlan === plan.id} onClick={() => setSelectedPlan(plan.id)}>
                {plan.saveAmount && <SaveTag>Save ₹{plan.saveAmount}</SaveTag>}
                <div className="d-flex justify-content-between align-items-start">
                    <div className="d-flex align-items-start">
                        <span className="fs-4 me-3">{plan.id === 1 ? '📄' : plan.id === 2 ? '💰' : '👑'}</span>
                        <div>
                            <h5 className="text-light mb-0">{plan.name}</h5>
                            <p className="text-secondary small">{plan.description}</p>
                        </div>
                    </div>
                    <RadioButton active={selectedPlan === plan.id} />
                </div>
                <hr className="border-secondary"/>
                <div className="row text-center">
                    <div className="col-4">
                        <p className="text-secondary small mb-1">Invoices</p>
                        <p className="text-light fw-bold mb-0">{plan.invoices}</p>
                    </div>
                    <div className="col-4">
                        <p className="text-secondary small mb-1">Validity</p>
                        <p className="text-light fw-bold mb-0">{plan.validity}</p>
                    </div>
                    <div className="col-4">
                        <p className="text-secondary small mb-1">Price</p>
                        <p className="text-light fw-bold mb-0 fs-5">₹{plan.price}</p>
                    </div>
                </div>
                <div className="d-grid mt-3">
                    <button onClick={()=>navigateTo('Buy Invoice Plan')} className="btn text-white fw-bold" style={{backgroundColor: plan.buttonColor}}>Buy Plan</button>
                </div>
            </PlanCard>
        ))}

        <div className="text-secondary small text-center mt-4">
            <p>* All prices are inclusive of taxes.</p>
            <p>* Plans are non-refundable and auto-expire after validity.</p>
        </div>
    </div>
  );
};

export default InvoicePlan;
