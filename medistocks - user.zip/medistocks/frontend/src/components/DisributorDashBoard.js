import React, { useState, useEffect, useRef } from 'react';
import styled, { keyframes } from 'styled-components';
import axios from 'axios';
import BaseUrl from './BaseUrl'; // Make sure this path is correct

// Import other components
import Billing from './DistibutorMyInventory';
import Chat from './DistributorChat';
import AddNewProduct from './DistributorAddNewProduct';
import MyProducts from './DistributorMyProducts';
import IncomingRequests from './DistributorRequests';
import InvoicePlan from './SelectInvoicePlan';
import BuyInvoicePlan from './BuyInvoicePlan';
import GenerateInvoice from './GenerateInvoice';
import AdManagement from './AdManagment';
import DistributorBilling from './DistributorBilling';
import Analytics from './DistributorAnalytics';
import Profile from './DistributorProfile';
import DistributorVideos from './DistributorVideos';
import TermsAndConditions from './TermsAndConditions';
import FAQ from './Faq';
import CustomerSupport from './RetailerCustomerSupport';
import { useDispatch } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { logout } from './redux/authSlice'; 

// --- PHARMACY THEME TOKENS (improved) ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

// --- Keyframes (unchanged) ---
const slideUp = keyframes`
  from { opacity: 0; transform: translateY(15px); }
  to { opacity: 1; transform: translateY(0); }
`;

// --- Styled Components (improved, responsive) ---
const AnimatedContent = styled.div`
  animation: ${slideUp} 0.4s ease-out forwards;
`;

const Card = styled.div`
  background: white;
  border-radius: 1.25rem;
  padding: 1.25rem;
  box-shadow: ${CARD_SHADOW};
  border: 1px solid ${BORDER_GREY};
  animation: ${slideUp} 0.5s ease-out forwards;
  height: 100%;
  transition: all 0.2s;
  &:hover {
    box-shadow: ${HOVER_SHADOW};
  }
  @media (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const SidebarContainer = styled.aside`
  width: 280px;
  background: white;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  padding: 1.25rem;
  display: flex;
  flex-direction: column;
  border-right: 1px solid ${BORDER_GREY};
  z-index: 40;
  transition: transform 0.3s ease-in-out;
  box-shadow: 2px 0 8px rgba(0,0,0,0.02);

  @media (max-width: 992px) {
    transform: translateX(${({ isOpen }) => (isOpen ? '0' : '-100%')});
    width: 260px;
  }
`;

const MainContentContainer = styled.main`
  transition: margin-left 0.3s ease-in-out;
  margin-left: 280px;
  background: ${LIGHT_GREEN};
  min-height: 100vh;

  @media (max-width: 992px) {
    margin-left: 0;
  }
`;

const NavItemButton = styled.button`
  background: transparent;
  border: none;
  color: ${DARK_NAVY};
  transition: all 0.2s ease;
  position: relative;
  font-weight: 500;
  width: 100%;
  text-align: left;
  padding: 0.75rem 1rem;
  border-radius: 12px;
  cursor: pointer;

  &:hover {
    color: ${PHARMACY_GREEN};
    background: ${`${PHARMACY_GREEN}08`};
  }

  &.active {
    color: ${PHARMACY_GREEN};
    background: ${`${PHARMACY_GREEN}10`};
    font-weight: 600;
  }
  &.active::before {
    content: '';
    position: absolute;
    left: -1rem;
    top: 0.5rem;
    height: calc(100% - 1rem);
    width: 3px;
    background: ${PHARMACY_GREEN};
    border-radius: 0 4px 4px 0;
  }
`;

const HeaderContainer = styled.header`
  background: white;
  border-bottom: 1px solid ${BORDER_GREY};
  box-shadow: 0 1px 4px rgba(0,0,0,0.02);
`;

const ProfileSection = styled.div`
  position: relative;
  margin-top: auto;
  padding-top: 1rem;
  border-top: 1px solid ${BORDER_GREY};
`;

const ProfileButton = styled.button`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  width: 100%;
  padding: 0.75rem;
  border-radius: 1rem;
  background: ${LIGHT_GREEN};
  border: 1px solid ${BORDER_GREY};
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background: white;
    border-color: ${PHARMACY_GREEN}40;
    transform: translateY(-1px);
  }
`;

const ProfileIcon = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 40px;
  background: ${PHARMACY_GREEN};
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 1rem;
`;

const DropdownMenu = styled.div`
  position: absolute;
  bottom: calc(100% + 0.5rem);
  left: 0;
  width: 100%;
  background: white;
  border-radius: 1rem;
  box-shadow: ${HOVER_SHADOW};
  border: 1px solid ${BORDER_GREY};
  padding: 0.5rem;
  z-index: 50;
  animation: ${slideUp} 0.2s ease-out;
`;

const DropdownItem = styled.button`
  width: 100%;
  text-align: left;
  padding: 0.6rem 0.75rem;
  border-radius: 0.75rem;
  background: none;
  border: none;
  color: ${DARK_NAVY};
  font-size: 0.85rem;
  transition: 0.15s;
  &:hover {
    background: ${LIGHT_GREEN};
    color: ${PHARMACY_GREEN};
  }
`;

const QuickActionButton = styled.button`
  background: ${({ bgColor }) => bgColor || PHARMACY_GREEN};
  border: none;
  border-radius: 1rem;
  padding: 1.25rem;
  color: white;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  font-weight: 600;
  transition: all 0.2s ease;
  box-shadow: ${CARD_SHADOW};
  &:hover {
    transform: translateY(-4px);
    box-shadow: ${HOVER_SHADOW};
    filter: brightness(1.02);
  }
`;

const StatCard = ({ title, value, icon, iconBg }) => (
  <Card>
    <div className="d-flex justify-content-between align-items-center">
      <div>
        <p className="text-secondary mb-1 fs-6" style={{ fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{title}</p>
        <h3 className="fw-bold mb-0" style={{ color: DARK_NAVY }}>{value}</h3>
      </div>
      <div className="fs-4 p-3 rounded-3" style={{ backgroundColor: iconBg || `${PHARMACY_GREEN}10`, color: PHARMACY_GREEN }}>{icon}</div>
    </div>
  </Card>
);

// --- DistributorHubHome (unchanged logic, improved styling) ---
const DistributorHubHome = ({ navigateTo }) => {
  const [summaryData, setSummaryData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const userId = localStorage.getItem('user_id');

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!userId) {
        setError("User not found. Please log in again.");
        setIsLoading(false);
        return;
      }
      try {
        const response = await axios.get(`${BaseUrl}/dashboard/dashboard-summary/${userId}`);
        setSummaryData(response.data);
      } catch (err) {
        setError("Failed to fetch dashboard data. Please try again later.");
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchDashboardData();
  }, [userId]);

  if (isLoading) return <div className="text-center p-5"><div className="spinner-border" style={{ color: PHARMACY_GREEN }} role="status"><span className="visually-hidden">Loading...</span></div></div>;
  if (error) return <div className="alert alert-danger">{error}</div>;
  if (!summaryData) return <div className="alert alert-warning">No dashboard data available.</div>;

  return (
    <div className='d-flex flex-column gap-4'>
      <div className="row g-4">
        <div className="col-md-6 col-xl-3"><StatCard title="Total Products" value={summaryData.total_products} icon="📦" iconBg={`${PHARMACY_GREEN}10`} /></div>
        <div className="col-md-6 col-xl-3"><StatCard title="Purchase Requests" value={summaryData.total_purchase_requests} icon="🛒" iconBg={`${PHARMACY_GREEN}10`} /></div>
        <div className="col-md-6 col-xl-3"><StatCard title="Total Revenue" value={`₹${(summaryData.total_revenue || 0).toLocaleString('en-IN')}`} icon="₹" iconBg={`${PHARMACY_GREEN}10`} /></div>
        <div className="col-md-6 col-xl-3"><StatCard title="Active Ads" value={`${summaryData.total_ads - summaryData.pending_ads} / ${summaryData.total_ads}`} icon="📢" iconBg={`${PHARMACY_GREEN}10`} /></div>
      </div>
      <div className="row g-3">
        <div className="col-sm-6 col-lg-3"><QuickActionButton onClick={() => navigateTo('Add New Product')} bgColor={PHARMACY_GREEN}><span className="fs-2">+</span> Post New Product</QuickActionButton></div>
        <div className="col-sm-6 col-lg-3"><QuickActionButton onClick={() => navigateTo('Requests')} bgColor="#0f9d4e"><span className="fs-2">📄</span> View Requests</QuickActionButton></div>
        <div className="col-sm-6 col-lg-3"><QuickActionButton onClick={() => navigateTo('Analytics')} bgColor="#f97316"><span className="fs-2">📈</span> View Analytics</QuickActionButton></div>
        <div className="col-sm-6 col-lg-3"><QuickActionButton onClick={() => navigateTo('Ad Management')} bgColor="#a855f7"><span className="fs-2">📢</span> Create an Ad</QuickActionButton></div>
      </div>
      <Card>
        <h4 className="mb-3" style={{ color: DARK_NAVY }}>Today's Purchase Requests ({summaryData.today_purchase_requests_count})</h4>
        {summaryData.today_purchase_requests.length > 0 ? (
          <div className="table-responsive">
            <table className="table table-hover align-middle" style={{ borderCollapse: 'collapse' }}>
              <thead style={{ background: LIGHT_GREEN }}>
                <tr>
                  <th scope="col">Product Name</th><th scope="col">Quantity</th><th scope="col">Status</th><th scope="col">Type</th><th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {summaryData.today_purchase_requests.map(req => (
                  <tr key={req.id}>
                    <td className='fw-medium'>{req.tablet_name}</td>
                    <td>{req.quantity}</td>
                    <td><span className={`badge ${req.status === 'pending' ? 'bg-warning text-dark' : 'bg-success'}`}>{req.status}</span></td>
                    <td>{req.sender_id == userId ? <span className="badge bg-primary bg-opacity-10 text-primary">Sent</span> : <span className="badge bg-success bg-opacity-10 text-success">Received</span>}</td>
                    <td><button className="btn btn-sm" style={{ background: PHARMACY_GREEN, color: 'white', borderRadius: '40px' }} onClick={() => navigateTo('Requests')}>View</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center p-4"><p className="text-secondary mb-0">📨 No purchase requests today.</p></div>
        )}
      </Card>
    </div>
  );
};


// --- DistributorSidebar (defined OUTSIDE dashboard so React never recreates it on re-render) ---
const DistributorSidebar = ({ activeTab, navigateTo, onLogout, isOpen }) => {
  const [isProfileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const NavItem = ({ name, icon }) => (
    <NavItemButton onClick={() => navigateTo(name)} className={activeTab === name ? 'active' : ''}>
      <span className="me-3 fs-5">{icon}</span>
      <span>{name}</span>
    </NavItemButton>
  );

  return (
    <SidebarContainer isOpen={isOpen}>
      <div className="d-flex align-items-center p-2 mb-4">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="me-3">
          <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke={PHARMACY_GREEN} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M2 7L12 12L22 7" stroke={PHARMACY_GREEN} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 12V22" stroke={PHARMACY_GREEN} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <h1 className="h5 fw-bold mb-0" style={{ color: DARK_NAVY }}>MediStox</h1>
      </div>
      <nav className="d-flex flex-column gap-2 flex-grow-1">
        <NavItem name="Dashboard" icon="🏠" />
        <NavItem name="My Products" icon="📦" />
        <NavItem name="Requests" icon="🛒" />
        <NavItem name="Chat" icon="💬" />
        <NavItem name="Ad Management" icon="📢" />
        <NavItem name="Inventory" icon="📈" />
        <hr className="my-2" style={{ borderColor: BORDER_GREY }} />
        <NavItem name="Support" icon="❓" />
      </nav>
      <ProfileSection ref={profileRef}>
        {isProfileOpen && (
          <DropdownMenu>
            <DropdownItem onClick={() => navigateTo('Profile')}>👤 Go to Profile</DropdownItem>
            <DropdownItem onClick={onLogout}>🚪 Log Out</DropdownItem>
          </DropdownMenu>
        )}
        <ProfileButton onClick={() => setProfileOpen(prev => !prev)}>
          <ProfileIcon>D</ProfileIcon>
          <div className='text-start'>
            <p className='mb-0 fw-bold' style={{ color: DARK_NAVY }}>Distributor</p>
            <small className='text-muted'>View Profile</small>
          </div>
        </ProfileButton>
      </ProfileSection>
    </SidebarContainer>
  );
};

// --- Main DistributorDashboard Component ---
const DistributorDashboard = () => {
  const { section } = useParams();
  const navigate = useNavigate();

  // Map URL slugs to Tab Names
  const slugToTab = React.useMemo(() => ({
    'dashboard': 'Dashboard',
    'my-products': 'My Products',
    'requests': 'Requests',
    'chat': 'Chat',
    'ad-management': 'Ad Management',
    'inventory': 'Inventory',
    'analytics': 'Analytics',
    'profile': 'Profile',
    'videos': 'Videos',
    'support': 'Support',
    'faq': 'FAQ',
    'billing': 'Billing',
    'add-product': 'Add New Product',
    'select-plan': 'Select Invoice Plan',
    'buy-plan': 'Buy Invoice Plan',
    'generate-invoice': 'Generate Invoice',
    'terms': 'Terms & Conditions'
  }), []);

  const tabToSlug = React.useMemo(() => 
    Object.fromEntries(Object.entries(slugToTab).map(([s, t]) => [t, s])),
    [slugToTab]
  );

  const activeTab = React.useMemo(() => {
    if (!section) return 'Dashboard';
    return slugToTab[section] || 'Dashboard';
  }, [section, slugToTab]);

  const [navigationHistory, setNavigationHistory] = useState([activeTab]);
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef(null);
  const dispatch = useDispatch();

  // Sync history when URL changes
  useEffect(() => {
    setNavigationHistory(prev => {
      if (prev[prev.length - 1] === activeTab) return prev;
      const TOP_LEVEL_TABS = Object.values(slugToTab);
      if (TOP_LEVEL_TABS.includes(activeTab)) return [activeTab];
      return [...prev, activeTab];
    });
  }, [activeTab, slugToTab]);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const uid = localStorage.getItem('user_id');
        const response = await axios.get(`${BaseUrl}/notifications/list?role=Distributor`);
        const data = Array.isArray(response.data) ? response.data : (response.data.notifications || []);
        setNotifications(uid ? data.filter(n => String(n.user_id) === String(uid) || n.audience_type === 'all') : data);
      } catch (err) {
        console.error('Error fetching notifications:', err);
      }
    };
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 60000);
    return () => clearInterval(interval);
  }, []);

  const dismissNotification = async (id) => {
    try {
      await axios.delete(`${BaseUrl}/notifications/delete/${id}`, {
        headers: { 'X-Admin-Token': 'secret123' }
      });
      setNotifications(prev => prev.filter(n => n.id !== id));
    } catch (err) {
      console.error('Failed to dismiss notification:', err);
      setNotifications(prev => prev.filter(n => n.id !== id));
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notifRef.current && !notifRef.current.contains(event.target)) {
        setNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navigateTo = (tabName) => {
    const slug = tabToSlug[tabName] || tabName.toLowerCase().replace(/ /g, '-');
    navigate(`/distributor-dashboard/${slug}`);
  };

  const handleBack = () => {
    if (navigationHistory.length <= 1) return;
    setNavigationHistory(prev => prev.slice(0, -1));
  };

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login', { replace: true }); 
  };
  const renderContent = () => {
    switch (activeTab) {
      case 'Dashboard': return <DistributorHubHome navigateTo={navigateTo} />;
      case 'My Products': return <MyProducts onAddProduct={() => navigateTo('Add New Product')} />;
      case 'Requests': return <IncomingRequests navigateTo={navigateTo} onBack={handleBack}/>;
      case 'Billing': return <DistributorBilling navigateTo={navigateTo} onBack={handleBack}/>;
      case 'Ad Management': return <AdManagement navigateTo={navigateTo} onBack={handleBack} />;
      case 'Analytics': return <Analytics navigateTo={navigateTo} onBack={handleBack} />;
      case 'Profile': return <Profile navigateTo={navigateTo} onBack={handleBack} />;
      case 'Chat': return <Chat navigateTo={navigateTo} onBack={handleBack} />;
      case 'Add New Product': return <AddNewProduct navigateTo={navigateTo} onBack={handleBack} />;
      case 'Support': return <CustomerSupport onBack={handleBack} />;
      case 'Select Invoice Plan': return <InvoicePlan navigateTo={navigateTo} onBack={handleBack} />;
      case 'Buy Invoice Plan': return <BuyInvoicePlan navigateTo={navigateTo} onBack={handleBack} />;
      case 'Generate Invoice': return <GenerateInvoice navigateTo={navigateTo} onBack={handleBack} />;    
      case 'Terms & Conditions': return <TermsAndConditions onBack={handleBack} />;
      case 'FAQ': return <FAQ onBack={handleBack} />;
      case 'Videos': return <DistributorVideos navigateTo={navigateTo} onBack={handleBack} />;
      case 'Inventory': return <Billing navigateTo={navigateTo} onBack={handleBack} />;
      default: return <DistributorHubHome navigateTo={navigateTo} />;
    }
  };

  return (
    <div style={{ minHeight: '100vh' }}>
      <DistributorSidebar activeTab={activeTab} navigateTo={navigateTo} onLogout={handleLogout} isOpen={isSidebarOpen} />
      <MainContentContainer>
        <HeaderContainer className="sticky-top">
          <div className="p-3 d-flex justify-content-between align-items-center">
            <div className="d-flex align-items-center gap-2">
              <button className="btn" onClick={() => setSidebarOpen(!isSidebarOpen)} style={{ background: 'white', border: `1px solid ${BORDER_GREY}`, borderRadius: '40px' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill={DARK_NAVY} className="bi bi-list" viewBox="0 0 16 16"><path fillRule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" /></svg>
              </button>
              {navigationHistory.length > 1 && (
                <button className="btn" onClick={handleBack} style={{ background: 'white', border: `1px solid ${BORDER_GREY}`, borderRadius: '40px' }}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill={DARK_NAVY} className="bi bi-arrow-left" viewBox="0 0 16 16"><path fillRule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z" /></svg>
                </button>
              )}
              <h1 className="h5 fw-bold mb-0" style={{ color: DARK_NAVY }}>{activeTab}</h1>
            </div>
            <div className="d-flex align-items-center gap-3" ref={notifRef}>
              <button 
                className="btn position-relative" 
                style={{ background: 'white', border: `1px solid ${BORDER_GREY}`, borderRadius: '40px' }}
                onClick={() => setNotifOpen(!notifOpen)}
              >
                🔔
                {notifications.length > 0 && (
                  <span className="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" style={{ width: '8px', height: '8px' }}></span>
                )}
              </button>

              {notifOpen && (
                <div style={{
                  position: 'absolute', top: '60px', right: '20px', width: '320px', background: 'white',
                  borderRadius: '12px', boxShadow: HOVER_SHADOW, border: `1px solid ${BORDER_GREY}`, zIndex: 1000,
                  maxHeight: '400px', overflowY: 'auto'
                }}>
                  <div className="p-3 border-bottom d-flex justify-content-between align-items-center">
                    <span className="fw-bold">Notifications</span>
                    {notifications.length > 0 && <span className="small text-success" style={{ cursor: 'pointer' }} onClick={() => {
                      notifications.forEach(n => dismissNotification(n.id));
                    }}>Mark all read</span>}
                  </div>
                  {notifications.length === 0 ? (
                    <div className="p-4 text-center text-secondary small">No new notifications</div>
                  ) : (
                    notifications.map((n, i) => (
                      <div key={n.id || i} className="p-3 border-bottom d-flex justify-content-between align-items-start">
                        <div>
                          <div className="fw-bold small mb-1">{n.title}</div>
                          <div className="text-secondary small">{n.message}</div>
                          <div className="text-muted" style={{ fontSize: '10px', marginTop: '4px' }}>
                            {new Date(n.created_at).toLocaleString()}
                          </div>
                        </div>
                        <button onClick={(e) => { e.stopPropagation(); dismissNotification(n.id); }} style={{ border: 'none', background: 'transparent', cursor: 'pointer', color: '#8b96a5', fontSize: '1rem', padding: '0 0 0 8px' }}>&times;</button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </HeaderContainer>
        <AnimatedContent className="p-3 p-md-4">
          {renderContent()}
        </AnimatedContent>
      </MainContentContainer>
    </div>
  );
};

export default DistributorDashboard;