import React from 'react';
import styled from 'styled-components';

// --- PHARMACY THEME TOKENS ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

// --- Styled Components (improved, responsive) ---
const GlassmorphismContainer = styled.div`
  background: white;
  backdrop-filter: blur(10px);
  border: 1px solid ${BORDER_GREY};
  border-radius: 1.25rem;
  padding: 1.5rem;
  box-shadow: ${CARD_SHADOW};
  transition: all 0.2s;
  &:hover {
    box-shadow: ${HOVER_SHADOW};
  }
`;

const SupportLayout = styled(GlassmorphismContainer)`
  height: 85vh;
  max-height: 900px;
  padding: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  @media (max-width: 768px) {
    height: 90vh;
    border-radius: 1rem;
  }
`;

const Header = styled.div`
  padding: 1rem;
  border-bottom: 1px solid ${BORDER_GREY};
  display: flex;
  align-items: center;
  gap: 0.75rem;
  background: white;
  @media (min-width: 768px) {
    padding: 1rem 1.5rem;
    gap: 1rem;
  }
  h5 {
    font-size: 1rem;
    font-weight: 700;
    color: ${DARK_NAVY};
    margin: 0;
    @media (min-width: 768px) {
      font-size: 1.1rem;
    }
  }
  p {
    font-size: 0.7rem;
    margin: 0;
    color: #6c757d;
    @media (min-width: 768px) {
      font-size: 0.75rem;
    }
  }
  button {
    background: none;
    border: none;
    cursor: pointer;
    color: ${DARK_NAVY};
    &:hover {
      color: ${PHARMACY_GREEN};
    }
  }
`;

const ReplyTimeBanner = styled.div`
  background: ${LIGHT_GREEN};
  padding: 0.75rem 1rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
  border-bottom: 1px solid ${BORDER_GREY};
  @media (min-width: 768px) {
    padding: 1rem 1.5rem;
    gap: 1rem;
  }
  .fs-4 {
    font-size: 1.5rem;
    @media (min-width: 768px) {
      font-size: 1.8rem;
    }
  }
  p {
    margin: 0;
  }
  .fw-bold {
    font-weight: 700;
    color: ${DARK_NAVY};
    font-size: 0.85rem;
    @media (min-width: 768px) {
      font-size: 0.9rem;
    }
  }
  .text-success {
    color: ${PHARMACY_GREEN} !important;
    font-size: 0.7rem;
    @media (min-width: 768px) {
      font-size: 0.75rem;
    }
  }
`;

const TopicButton = styled.button`
  background: white;
  border: 1.5px solid ${BORDER_GREY};
  color: ${DARK_NAVY};
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem 1rem;
  width: 100%;
  text-align: left;
  border-radius: 1rem;
  transition: all 0.2s;
  font-weight: 500;
  @media (min-width: 768px) {
    padding: 1rem;
    gap: 1rem;
  }
  &:hover {
    background: ${LIGHT_GREEN};
    border-color: ${PHARMACY_GREEN};
    transform: translateX(4px);
  }
  .fs-5 {
    font-size: 1.1rem;
    @media (min-width: 768px) {
      font-size: 1.2rem;
    }
  }
`;

const ChatArea = styled.div`
  flex-grow: 1;
  padding: 1rem;
  overflow-y: auto;
  background: ${LIGHT_GREEN};
  @media (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const MessageBubble = styled.div`
  max-width: 85%;
  padding: 0.6rem 1rem;
  border-radius: 1.25rem;
  color: white;
  background: ${PHARMACY_GREEN};
  border-bottom-left-radius: 0.25rem;
  font-size: 0.85rem;
  line-height: 1.4;
  @media (min-width: 768px) {
    max-width: 80%;
    padding: 0.75rem 1.25rem;
    font-size: 0.9rem;
  }
`;

const MessageInputContainer = styled.div`
  padding: 0.75rem;
  background: white;
  border-top: 1px solid ${BORDER_GREY};
  @media (min-width: 768px) {
    padding: 1rem;
  }
  .input-group {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
    @media (min-width: 576px) {
      flex-wrap: nowrap;
    }
  }
  button {
    background: white;
    border: 1.5px solid ${BORDER_GREY};
    border-radius: 40px;
    color: ${DARK_NAVY};
    padding: 0.5rem 0.75rem;
    transition: all 0.2s;
    &:hover {
      border-color: ${PHARMACY_GREEN};
      color: ${PHARMACY_GREEN};
    }
  }
  input {
    flex: 1;
    border: 1.5px solid ${BORDER_GREY};
    border-radius: 40px;
    padding: 0.6rem 1rem;
    font-size: 0.85rem;
    background: white;
    &:focus {
      outline: none;
      border-color: ${PHARMACY_GREEN};
      box-shadow: 0 0 0 3px ${PHARMACY_GREEN}20;
    }
    @media (min-width: 768px) {
      padding: 0.75rem 1.25rem;
      font-size: 0.9rem;
    }
  }
  .btn-primary {
    background: ${PHARMACY_GREEN};
    border-color: ${PHARMACY_GREEN};
    color: white;
    &:hover {
      background: #0a5e2e;
      border-color: #0a5e2e;
    }
  }
  .small {
    font-size: 0.65rem;
    margin-top: 0.5rem;
    color: #6c757d;
    @media (min-width: 768px) {
      font-size: 0.7rem;
    }
  }
`;

const Footer = styled.div`
  padding: 0.75rem;
  text-align: center;
  border-top: 1px solid ${BORDER_GREY};
  background: white;
  @media (min-width: 768px) {
    padding: 1rem;
  }
  p {
    font-size: 0.7rem;
    margin-bottom: 0.5rem;
    color: #6c757d;
    @media (min-width: 768px) {
      font-size: 0.75rem;
    }
  }
  .btn-outline-secondary {
    background: transparent;
    border: 1.5px solid ${BORDER_GREY};
    border-radius: 40px;
    padding: 0.4rem 1rem;
    font-size: 0.7rem;
    color: ${DARK_NAVY};
    transition: all 0.2s;
    &:hover {
      border-color: ${PHARMACY_GREEN};
      color: ${PHARMACY_GREEN};
      background: ${LIGHT_GREEN};
    }
    @media (min-width: 768px) {
      padding: 0.5rem 1.2rem;
      font-size: 0.8rem;
    }
  }
  .d-flex {
    gap: 0.75rem;
    justify-content: center;
    @media (min-width: 768px) {
      gap: 1rem;
    }
  }
`;

// --- Main Customer Support Component (logic unchanged) ---
const CustomerSupport = ({ onBack }) => {
  const topics = [
    { icon: '📦', text: 'Product Delivery Issue' },
    { icon: '💳', text: 'Payment/Invoice Problem' },
    { icon: '⚙️', text: 'App Bug or Technical Glitch' },
    { icon: '🚩', text: 'Report a User' },
    { icon: '👑', text: 'Subscription & Plans' },
    { icon: '❓', text: 'Other' },
  ];

  return (
    <SupportLayout>
      <Header>
        <button onClick={onBack}>
          <span className="fs-4">←</span>
        </button>
        <div>
          <h5>Customer Support</h5>
          <p>We're here to help</p>
        </div>
        <button className="ms-auto">
          <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
            <path fillRule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
          </svg>
        </button>
      </Header>

      <ReplyTimeBanner>
        <div className="fs-4">🕒</div>
        <div>
          <p className="fw-bold mb-0">Average reply time: 2 minutes</p>
          <p className="text-success mb-0">Our support team is online</p>
        </div>
      </ReplyTimeBanner>

      <ChatArea>
        <p className="text-secondary small mb-3" style={{ color: '#6c757d', fontSize: '0.75rem' }}>What can we help you with?</p>
        <div className="d-flex flex-column gap-2 mb-4">
          {topics.map(topic => (
            <TopicButton key={topic.text}>
              <span className="fs-5">{topic.icon}</span>
              {topic.text}
            </TopicButton>
          ))}
        </div>

        <div className="d-flex align-items-start gap-3">
          <div className="rounded-circle d-flex align-items-center justify-content-center fw-bold" style={{ width: '36px', height: '36px', flexShrink: 0, background: PHARMACY_GREEN, color: 'white' }}>
            S
          </div>
          <div>
            <MessageBubble>
              Hello! I'm here to help you with any issues. Please select a topic above or describe your problem.
            </MessageBubble>
            <p className="small mt-1" style={{ color: '#6c757d', marginBottom: 0 }}>Just now</p>
          </div>
        </div>
      </ChatArea>

      <MessageInputContainer>
        <div className="input-group">
          <button>📎</button>
          <button>📷</button>
          <input type="text" placeholder="Type your message..." />
          <button className="btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
              <path d="M15.964.686a.5.5 0 0 0-.65-.65L.767 5.855H.766l-.452.18a.5.5 0 0 0-.082.887l.41.26.001.002 4.995 3.178 3.178 4.995.002.002.26.41a.5.5 0 0 0 .886-.083l6-15Zm-1.833 1.89L6.637 10.07l-.215-.338a.5.5 0 0 0-.154-.154l-.338-.215 7.494-7.494 1.178-.471-.47 1.178Z"/>
            </svg>
          </button>
        </div>
        <p className="small">Attach screenshot for faster resolution</p>
      </MessageInputContainer>

      <Footer>
        <p>Need immediate assistance?</p>
        <div className="d-flex">
          <button className="btn-outline-secondary">Help Center</button>
          <button className="btn-outline-secondary">FAQ</button>
        </div>
      </Footer>
    </SupportLayout>
  );
};

export default CustomerSupport;