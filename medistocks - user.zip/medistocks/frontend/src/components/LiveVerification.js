import React, { useState, useEffect, useRef } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import { useNavigate } from 'react-router-dom';
import BaseUrl from './BaseUrl';
import { FaCamera, FaCheckCircle, FaLightbulb, FaUserAlt, FaUserSlash, FaLock } from 'react-icons/fa';

// --- Global Styles for a consistent theme ---
const GlobalStyle = createGlobalStyle`
  body, html, #root {
    height: 100%;
    margin: 0;
    background-color: #f8fafc;
    font-family: 'Inter', sans-serif; // A modern, clean font
  }
`;

// --- Styled Components (Full-Width Redesign) ---

const PageContainer = styled.div`
  display: flex;
  width: 100vw;
  height: 100vh;
  overflow: hidden;

  @media (max-width: 992px) {
    flex-direction: column;
    height: auto;
    min-height: 100vh;
  }
`;

const InstructionPanel = styled.div`
  flex: 1;
  background-color: #ffffff;
  padding: 4rem;
  display: flex;
  flex-direction: column;
  justify-content: center;

  @media (max-width: 992px) {
    padding: 2rem;
    flex: none;
  }
`;

const VerificationPanel = styled.div`
  flex: 1.5;
  background-color: #f0f4ff;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
`;

const Header = styled.div`
  max-width: 450px;
  h1 {
    font-size: 2.5rem;
    font-weight: 800;
    color: #111827;
    margin-bottom: 1rem;
  }
  p {
    font-size: 1.1rem;
    color: #475569;
    line-height: 1.6;
  }
`;

const InstructionList = styled.ul`
  list-style: none;
  padding: 0;
  margin-top: 2.5rem;
`;

const InstructionItem = styled.li`
  display: flex;
  align-items: flex-start;
  margin-bottom: 1.5rem;
  font-size: 1rem;
  color: #334155;

  svg {
    flex-shrink: 0;
    margin-right: 1rem;
    margin-top: 0.25rem;
    font-size: 1.25rem;
    color: #4f46e5;
  }
`;

const PrivacyNote = styled.div`
  display: flex;
  align-items: center;
  margin-top: 3rem;
  padding: 1rem;
  background-color: #f1f5f9;
  border-radius: 0.75rem;
  max-width: 450px;

  svg {
    flex-shrink: 0;
    margin-right: 1rem;
    font-size: 1.5rem;
    color: #64748b;
  }

  p {
    font-size: 0.875rem;
    color: #475569;
    margin: 0;
  }
`;

const VerificationPod = styled.div`
  width: 100%;
  max-width: 480px;
  background: #ffffff;
  border-radius: 1.5rem;
  padding: 2rem;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  text-align: center;
`;

const CameraView = styled.div`
  width: 100%;
  height: 360px;
  margin: 0 auto 1.5rem;
  border-radius: 1rem;
  background-color: #1e293b;
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const VideoElement = styled.video` width: 100%; height: 100%; object-fit: cover; transform: scaleX(-1); `;
const SelfiePreview = styled.img` width: 100%; height: 100%; object-fit: cover; transform: scaleX(-1); `;
const FaceOutline = styled.div`
  position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
  width: 60%; height: 75%; border: 4px solid rgba(255, 255, 255, 0.7);
  border-radius: 50%; box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.5);
`;
const ActionButton = styled.button`
  width: 100%; background-color: #4f46e5; border: none; color: white; padding: 1rem; font-size: 1.1rem;
  font-weight: 600; border-radius: 0.75rem; cursor: pointer; transition: all 0.2s ease-in-out;
  display: flex; align-items: center; justify-content: center; gap: 0.5rem;
  &:hover { background-color: #4338ca; }
  &:disabled { background-color: #a5b4fc; cursor: not-allowed; }
`;
const ButtonGroup = styled.div` display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; `;
const SecondaryButton = styled(ActionButton)` background-color: #f1f5f9; color: #475569; &:hover { background-color: #e2e8f0; } `;
const Alert = styled.div`
  padding: 1rem; margin-top: 1.5rem; border-radius: 0.75rem; font-weight: 500;
  color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb;
`;

const spin = keyframes`0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); }`;
const Spinner = styled.div`
  border: 4px solid rgba(255, 255, 255, 0.3);
  border-top: 4px solid #ffffff;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: ${spin} 1s linear infinite;
`;


// --- Main Live Verification Component ---
const LiveVerification = () => {
    const [verificationStatus, setVerificationStatus] = useState('idle'); // idle, streaming, captured, uploading, success
    const [selfie, setSelfie] = useState(null);
    const [location, setLocation] = useState(null);
    const [error, setError] = useState("");
    const navigate = useNavigate();
    const userId = localStorage.getItem('user_id');
    const videoRef = useRef(null);
    const canvasRef = useRef(null);

    const stopCamera = () => { if (videoRef.current && videoRef.current.srcObject) { videoRef.current.srcObject.getTracks().forEach(track => track.stop()); } };
    
    const enableCamera = async () => { 
        setError(""); setVerificationStatus('streaming');
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            if (videoRef.current) videoRef.current.srcObject = stream;
            navigator.geolocation?.getCurrentPosition(p => setLocation(`${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`), () => setLocation("Unavailable"));
        } catch (err) { setError("Camera permission denied. Please enable it in your browser settings."); setVerificationStatus('idle'); }
    };
    
    const takeSelfie = () => { 
        const canvas = canvasRef.current; const video = videoRef.current;
        if (!canvas || !video) return;
        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.translate(canvas.width, 0); ctx.scale(-1, 1); ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(blob => { setSelfie(blob); stopCamera(); setVerificationStatus('captured'); }, 'image/jpeg', 0.9);
    };

    const handleRetake = () => { setSelfie(null); enableCamera(); };

    const handleUpload = async () => {
        setError(""); setVerificationStatus('uploading');
        try {
            const formData = new FormData();
            formData.append("user_id", userId);
            formData.append("location", location || "Not available");
            formData.append("live_image", selfie, `live_image_${userId}.jpg`);
            const response = await fetch(`${BaseUrl}/auth/live_verification`, { method: "PUT", body: formData });
            if (!response.ok) throw new Error("Upload failed. Please try again.");
            setVerificationStatus('success');
            setTimeout(() => navigate("/verification-status"), 2000);
        } catch (err) { setError(err.message); setVerificationStatus('captured'); }
    };

    useEffect(() => {
        // Cleanup function to stop camera when component unmounts
        return () => stopCamera();
    }, []);

  return (
    <>
      <GlobalStyle />
      <PageContainer>
        <InstructionPanel>
          <Header>
            <h1>Final Step: Live Verification</h1>
            <p>To protect your account and ensure security, we need to verify your identity with a quick live photo. Please follow the instructions to complete the process.</p>
          </Header>

          <InstructionList>
            <InstructionItem>
              <FaLightbulb />
              <div>
                <strong>Find a well-lit area</strong><br/>
                Ensure your face is clearly visible and not covered by shadows.
              </div>
            </InstructionItem>
            <InstructionItem>
              <FaUserAlt />
              <div>
                <strong>Center your face</strong><br/>
                Position your face inside the oval guide on the screen and look directly at the camera.
              </div>
            </InstructionItem>
            <InstructionItem>
              <FaUserSlash />
              <div>
                <strong>Remove accessories</strong><br/>
                Please take off any hats, sunglasses, or masks before taking the picture.
              </div>
            </InstructionItem>
          </InstructionList>

          <PrivacyNote>
            <FaLock />
            <p><strong>Your privacy is important.</strong> This image is used solely for identity verification and is protected by our strict privacy policy.</p>
          </PrivacyNote>
        </InstructionPanel>

        <VerificationPanel>
          <VerificationPod>
            <CameraView>
              {verificationStatus === 'streaming' && <><VideoElement ref={videoRef} autoPlay playsInline /><FaceOutline /></>}
              {verificationStatus === 'captured' && selfie && <SelfiePreview src={URL.createObjectURL(selfie)} alt="Selfie Preview" />}
              {verificationStatus === 'idle' && <FaCamera size={80} color="#cbd5e1" />}
              {verificationStatus === 'uploading' && <Spinner />}
              {verificationStatus === 'success' && <FaCheckCircle size={80} color="#34d399" />}
              <canvas ref={canvasRef} style={{ display: 'none' }} />
            </CameraView>
            
            {verificationStatus === 'idle' && <ActionButton onClick={enableCamera}><FaCamera/>Enable Camera</ActionButton>}
            {verificationStatus === 'streaming' && <ActionButton onClick={takeSelfie}>Capture Photo</ActionButton>}
            {verificationStatus === 'captured' && (
                <ButtonGroup>
                    <SecondaryButton onClick={handleRetake}>Retake</SecondaryButton>
                    <ActionButton onClick={handleUpload}>Submit</ActionButton>
                </ButtonGroup>
            )}
            {verificationStatus === 'uploading' && <p className="text-secondary">Uploading, please wait...</p>}
            {verificationStatus === 'success' && <p className="text-success fw-bold">Verification Submitted!</p>}

            {error && <Alert>{error}</Alert>}
          </VerificationPod>
        </VerificationPanel>
      </PageContainer>
    </>
  );
};

export default LiveVerification;