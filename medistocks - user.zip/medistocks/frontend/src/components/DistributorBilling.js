import React, { useState, useEffect, useCallback, useMemo } from 'react';
import styled, { keyframes } from 'styled-components';
import axios from 'axios';
import BaseUrl from './BaseUrl';

const API_URL = BaseUrl;
// In a real app, you would install and import recharts like this:
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// For this preview environment, we'll load it from a script
const { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } = window.Recharts || {};

// --- PHARMACY THEME TOKENS ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

// --- Keyframes for animations ---
const fadeIn = keyframes`
  from { opacity: 0; }
  to { opacity: 1; }
`;

const slideInUp = keyframes`
  from {
    opacity: 0;
    transform: translateY(30px) scale(0.98);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
`;

// --- Styled Components (improved, responsive) ---
const GlassmorphismContainer = styled.div`
  background: white;
  backdrop-filter: blur(10px);
  border: 1px solid ${BORDER_GREY};
  border-radius: 1.25rem;
  padding: 1.25rem;
  margin-bottom: 1.5rem;
  box-shadow: ${CARD_SHADOW};
  transition: all 0.2s;
  &:hover {
    box-shadow: ${HOVER_SHADOW};
  }
  @media (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const FormInput = styled.input`
  background-color: white !important;
  color: ${DARK_NAVY} !important;
  border: 1.5px solid ${BORDER_GREY} !important;
  border-radius: 0.75rem !important;
  padding: 0.75rem 1rem !important;
  font-size: 0.9rem !important;
  transition: all 0.2s !important;
  &::placeholder { color: #adb5bd !important; }
  &:focus {
    box-shadow: 0 0 0 3px ${PHARMACY_GREEN}20 !important;
    border-color: ${PHARMACY_GREEN} !important;
  }
`;

const DiscountButton = styled.button`
  background-color: ${({ active }) => active ? PHARMACY_GREEN : '#f1f5f9'};
  border: 1.5px solid ${({ active }) => active ? PHARMACY_GREEN : BORDER_GREY};
  color: ${({ active }) => active ? 'white' : DARK_NAVY};
  transition: all 0.2s;
  border-radius: 40px;
  padding: 0.5rem 0;
  font-weight: 600;
  &:hover {
    background-color: ${PHARMACY_GREEN};
    border-color: ${PHARMACY_GREEN};
    color: white;
  }
`;

const ModalBackdrop = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(5px);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1050;
  animation: ${fadeIn} 0.3s ease-out;
  padding: 1rem;
`;

const ModalContent = styled(GlassmorphismContainer)`
  width: 90%;
  max-width: 500px;
  animation: ${slideInUp} 0.4s ease-out;
  margin: 0;
`;

const SelectionButton = styled.button`
  background: white;
  border: 1.5px solid ${BORDER_GREY};
  color: ${DARK_NAVY};
  transition: all 0.2s;
  text-align: left;
  width: 100%;
  padding: 1rem;
  border-radius: 1rem;
  &:hover {
    background-color: ${LIGHT_GREEN};
    border-color: ${PHARMACY_GREEN};
  }
`;

const PrimaryButton = styled.button`
  background: ${PHARMACY_GREEN};
  border: none;
  color: white;
  font-weight: 700;
  padding: 0.75rem 1.5rem;
  border-radius: 40px;
  transition: all 0.2s;
  box-shadow: 0 2px 8px rgba(13,124,61,0.2);
  &:hover {
    background: #0a5e2e;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(13,124,61,0.3);
  }
`;

const OutlineButton = styled.button`
  background: transparent;
  border: 1.5px solid ${PHARMACY_GREEN};
  color: ${PHARMACY_GREEN};
  font-weight: 600;
  padding: 0.5rem 1rem;
  border-radius: 40px;
  transition: all 0.2s;
  &:hover {
    background: ${PHARMACY_GREEN}10;
  }
`;

const PageContainer = styled.div`
  background: ${LIGHT_GREEN};
  min-height: 100vh;
  padding: 1rem;
  @media (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const TableWrapper = styled.div`
  overflow-x: auto;
  width: 100%;
`;

const StyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  min-width: 500px;
  th, td {
    padding: 0.75rem 1rem;
    text-align: left;
    vertical-align: middle;
    border-bottom: 1px solid ${BORDER_GREY};
  }
  th {
    background: ${LIGHT_GREEN};
    color: ${DARK_NAVY};
    font-weight: 700;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  tbody tr:hover {
    background: ${LIGHT_GREEN};
  }
`;

// --- Sub-Components (UI improved, logic untouched) ---
const FinancialAnalytics = ({ onBack, onAddNew, invoices }) => {
    const totalRevenue = useMemo(() => invoices.reduce((acc, inv) => acc + inv.total_amount, 0), [invoices]);
    const totalOrders = invoices.length;
    const totalUnits = useMemo(() => invoices.reduce((acc, inv) => acc + inv.quantity, 0), [invoices]);
    
    // Group by day for the chart
    const salesData = useMemo(() => {
        const last7Days = [...Array(7)].map((_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - i);
            return d.toISOString().split('T')[0];
        }).reverse();

        return last7Days.map(date => {
            const dayInvoices = invoices.filter(inv => inv.created_at.startsWith(date));
            return {
                name: new Date(date).toLocaleDateString('en-US', { weekday: 'short' }),
                Revenue: dayInvoices.reduce((acc, inv) => acc + inv.total_amount, 0),
                Profit: dayInvoices.reduce((acc, inv) => acc + (inv.total_amount * 0.2), 0) // Mock 20% profit
            };
        });
    }, [invoices]);

    const topProducts = useMemo(() => {
        const productMap = {};
        invoices.forEach(inv => {
            if (!productMap[inv.product_name]) {
                productMap[inv.product_name] = { name: inv.product_name, units: 0, revenue: 0 };
            }
            productMap[inv.product_name].units += inv.quantity;
            productMap[inv.product_name].revenue += inv.total_amount;
        });
        return Object.values(productMap).sort((a, b) => b.revenue - a.revenue).slice(0, 3);
    }, [invoices]);

    return (
        <div>
            <div className="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
                <div className="d-flex align-items-center">
                    <button className="btn btn-link p-0 me-3" onClick={onBack} style={{ color: DARK_NAVY }}>
                        <span className="fs-4">←</span>
                    </button>
                    <div>
                        <h2 className="fw-bold mb-1" style={{ color: DARK_NAVY }}>Billing Dashboard</h2>
                        <p className="text-secondary" style={{ color: '#6c757d' }}>Sales Analytics</p>
                    </div>
                </div>
                <div className="d-flex align-items-center gap-3">
                    <button className="btn btn-link p-0 fs-4" style={{ color: DARK_NAVY }}>🔔</button>
                    <img src="https://placehold.co/40x40/0d7c3d/white?text=D" alt="User" className="rounded-circle" style={{ width: '40px', height: '40px', objectFit: 'cover' }} />
                </div>
            </div>

            <div className="btn-group mb-4" role="group" style={{ flexWrap: 'wrap', gap: '0.5rem' }}>
                <button type="button" className="btn" style={{ backgroundColor: PHARMACY_GREEN, borderColor: PHARMACY_GREEN, color: 'white', borderRadius: '40px' }}>Last 7 Days</button>
            </div>

            <div className="row g-4">
                <div className="col-md-6 col-xl-3"><GlassmorphismContainer><p className="small mb-1" style={{ color: '#6c757d', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Total Revenue</p><h4 className="fw-bold" style={{ color: DARK_NAVY }}>₹{totalRevenue.toLocaleString()}</h4><p className="small mb-0" style={{ color: PHARMACY_GREEN }}>Real-time</p></GlassmorphismContainer></div>
                <div className="col-md-6 col-xl-3"><GlassmorphismContainer><p className="small mb-1" style={{ color: '#6c757d', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Est. Profit</p><h4 className="fw-bold" style={{ color: PHARMACY_GREEN }}>₹{(totalRevenue * 0.2).toLocaleString()}</h4><p className="small mb-0" style={{ color: PHARMACY_GREEN }}>20% Margin</p></GlassmorphismContainer></div>
                <div className="col-md-6 col-xl-3"><GlassmorphismContainer><p className="small mb-1" style={{ color: '#6c757d', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Orders</p><h4 className="fw-bold" style={{ color: DARK_NAVY }}>{totalOrders}</h4><p className="small mb-0" style={{ color: PHARMACY_GREEN }}>Total Sent</p></GlassmorphismContainer></div>
                <div className="col-md-6 col-xl-3"><GlassmorphismContainer><p className="small mb-1" style={{ color: '#6c757d', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Units Sold</p><h4 className="fw-bold" style={{ color: DARK_NAVY }}>{totalUnits.toLocaleString()}</h4><p className="small mb-0" style={{ color: PHARMACY_GREEN }}>Total Qty</p></GlassmorphismContainer></div>
            </div>

            <GlassmorphismContainer>
                <h5 className="mb-3" style={{ color: DARK_NAVY }}>Sales Trend</h5>
                <div style={{ width: '100%', height: 300 }}>
                    {LineChart && <ResponsiveContainer>
                        <LineChart data={salesData}>
                            <CartesianGrid strokeDasharray="3 3" stroke={BORDER_GREY} />
                            <XAxis dataKey="name" stroke="#6c757d" />
                            <YAxis stroke="#6c757d" />
                            <Tooltip contentStyle={{ backgroundColor: 'white', border: `1px solid ${BORDER_GREY}`, borderRadius: '8px' }} />
                            <Legend />
                            <Line type="monotone" dataKey="Revenue" stroke={PHARMACY_GREEN} strokeWidth={2} />
                            <Line type="monotone" dataKey="Profit" stroke="#f39c12" strokeWidth={2} />
                        </LineChart>
                    </ResponsiveContainer>}
                </div>
            </GlassmorphismContainer>

            <GlassmorphismContainer>
                <h5 className="mb-3" style={{ color: DARK_NAVY }}>Top Products</h5>
                {topProducts.length > 0 ? topProducts.map(product => (
                    <div key={product.name} className="d-flex justify-content-between align-items-center py-2" style={{ borderBottom: `1px solid ${BORDER_GREY}` }}>
                        <div>
                            <p className="fw-bold mb-0" style={{ color: DARK_NAVY }}>{product.name}</p>
                            <small className="text-secondary">{product.units} units sold</small>
                        </div>
                        <div className="text-end">
                            <p className="fw-bold mb-0" style={{ color: PHARMACY_GREEN }}>₹{product.revenue.toLocaleString()}</p>
                        </div>
                    </div>
                )) : <p className="text-center text-muted py-4">No sales data available</p>}
            </GlassmorphismContainer>
            
            <div className="row g-4">
                <div className="col-md-6"><GlassmorphismContainer className="text-center">
                    <button className="btn btn-link p-0 mb-2" onClick={onAddNew} style={{ color: PHARMACY_GREEN, fontSize: '2rem' }}>+</button>
                    <h6 className="fw-bold" style={{ color: DARK_NAVY }}>Create Invoice</h6>
                    <p className="small text-secondary">Manual Entry</p>
                </GlassmorphismContainer></div>
                <div className="col-md-6"><GlassmorphismContainer className="text-center">
                     <button className="btn btn-link p-0 mb-2" style={{ color: PHARMACY_GREEN, fontSize: '2rem' }}>📄</button>
                    <h6 className="fw-bold" style={{ color: DARK_NAVY }}>Generate Report</h6>
                    <p className="small text-secondary">Export Data</p>
                </GlassmorphismContainer></div>
            </div>
        </div>
    );
};

const ManualBillingForm = ({ onBack, onSave }) => {
    const [tabletName, setTabletName] = useState('');
    const [unitCost, setUnitCost] = useState('');
    const [quantity, setQuantity] = useState(1);
    const [discount, setDiscount] = useState(0);

    const subtotal = (Number(unitCost) || 0) * (Number(quantity) || 0);
    const discountAmount = subtotal * (discount / 100);
    const totalAmount = subtotal - discountAmount;

    const handleSave = (e) => {
        e.preventDefault();
        const newRecord = {
            id: `B-${Math.floor(Math.random() * 900) + 100}`,
            tabletName,
            quantity,
            totalAmount,
            saleDate: new Date().toISOString().slice(0, 10),
        };
        onSave(newRecord);
    };

    return (
        <GlassmorphismContainer>
            <div className="d-flex align-items-center mb-4">
                <button className="btn btn-link p-0 me-3" onClick={onBack} style={{ color: DARK_NAVY }}>
                    <span className="fs-4">←</span>
                </button>
                <div>
                    <h4 className="mb-0" style={{ color: DARK_NAVY }}>Manual Billing Entry</h4>
                    <p className="small mb-0" style={{ color: '#6c757d' }}>Add new billing record to your system</p>
                </div>
            </div>
            
            <form onSubmit={handleSave}>
                <div className="mb-3">
                    <label className="form-label small" style={{ color: DARK_NAVY, fontWeight: 600 }}>Tablet Name</label>
                    <FormInput type="text" className="form-control" placeholder="Enter tablet/medicine name" value={tabletName} onChange={(e) => setTabletName(e.target.value)} required />
                </div>
                <div className="mb-3">
                    <label className="form-label small" style={{ color: DARK_NAVY, fontWeight: 600 }}>Quantity</label>
                    <div className="input-group">
                        <button className="btn" type="button" onClick={() => setQuantity(q => Math.max(1, q - 1))} style={{ background: LIGHT_GREEN, border: `1.5px solid ${BORDER_GREY}`, color: DARK_NAVY }}>-</button>
                        <FormInput type="number" className="form-control text-center" value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} required style={{ textAlign: 'center' }} />
                        <button className="btn" type="button" onClick={() => setQuantity(q => q + 1)} style={{ background: LIGHT_GREEN, border: `1.5px solid ${BORDER_GREY}`, color: DARK_NAVY }}>+</button>
                    </div>
                </div>
                <div className="mb-3">
                    <label className="form-label small" style={{ color: DARK_NAVY, fontWeight: 600 }}>Unit Cost (₹)</label>
                    <FormInput type="number" className="form-control" placeholder="Enter cost per unit" value={unitCost} onChange={(e) => setUnitCost(e.target.value)} required />
                </div>
                <div className="mb-3">
                    <label className="form-label small" style={{ color: DARK_NAVY, fontWeight: 600 }}>Discount Percentage</label>
                    <div className="d-flex gap-2 mb-2 flex-wrap">
                        <DiscountButton type="button" className="flex-grow-1" active={discount === 50} onClick={() => setDiscount(50)}>50%</DiscountButton>
                        <DiscountButton type="button" className="flex-grow-1" active={discount === 75} onClick={() => setDiscount(75)}>75%</DiscountButton>
                        <DiscountButton type="button" className="flex-grow-1" active={discount === 90} onClick={() => setDiscount(90)}>90%</DiscountButton>
                    </div>
                </div>
                <GlassmorphismContainer className="mt-4">
                    <h6 className="fw-bold" style={{ color: DARK_NAVY }}>Calculation Summary</h6>
                    <div className="d-flex justify-content-between py-1"><span style={{ color: '#6c757d' }}>Subtotal:</span> <span style={{ color: DARK_NAVY }}>₹{subtotal.toFixed(2)}</span></div>
                    <div className="d-flex justify-content-between py-1"><span style={{ color: '#6c757d' }}>Discount:</span> <span style={{ color: '#c0392b' }}>-₹{discountAmount.toFixed(2)}</span></div>
                    <hr style={{ borderColor: BORDER_GREY }} />
                    <div className="d-flex justify-content-between py-1"><span className="fw-bold" style={{ color: DARK_NAVY }}>Total Amount:</span> <span className="fw-bold fs-5" style={{ color: PHARMACY_GREEN }}>₹{totalAmount.toFixed(2)}</span></div>
                </GlassmorphismContainer>

                <div className="d-grid mt-4">
                    <PrimaryButton type="submit">Save Billing Record</PrimaryButton>
                </div>
            </form>
        </GlassmorphismContainer>
    );
};

const CameraBilling = ({ onBack }) => (
    <GlassmorphismContainer>
        <div className="d-flex align-items-center mb-4">
            <button className="btn btn-link p-0 me-3" onClick={onBack} style={{ color: DARK_NAVY }}>
                <span className="fs-4">←</span>
            </button>
            <div>
                <h4 className="mb-0" style={{ color: DARK_NAVY }}>Camera Billing Extract</h4>
                <p className="small mb-0" style={{ color: '#6c757d' }}>Scan or upload a bill to extract details</p>
            </div>
        </div>
        <div className="text-center p-4 border border-dashed rounded-3" style={{ border: `2px dashed ${BORDER_GREY}`, borderRadius: '1rem' }}>
            <div className="fs-1" style={{ color: PHARMACY_GREEN }}>📷</div>
            <p className="mt-2 mb-1" style={{ color: DARK_NAVY }}>Scan or upload an image of the bill</p>
            <div className="d-flex justify-content-center gap-3 mt-3 flex-wrap">
                <OutlineButton>Scan with Camera</OutlineButton>
                <OutlineButton>Upload Bill</OutlineButton>
            </div>
        </div>
        <div className="mt-4">
            <label className="form-label small" style={{ color: DARK_NAVY, fontWeight: 600 }}>Extracted Text</label>
            <textarea className="form-control" rows="5" placeholder="Extracted bill details will appear here..." style={{ background: 'white', border: `1.5px solid ${BORDER_GREY}`, borderRadius: '0.75rem', padding: '0.75rem', color: DARK_NAVY }}></textarea>
        </div>
        <div className="d-grid mt-4">
            <PrimaryButton>Save Extracted Bill</PrimaryButton>
        </div>
    </GlassmorphismContainer>
);

const SelectionModal = ({ onSelect, onClose }) => (
    <ModalBackdrop onClick={onClose}>
        <ModalContent onClick={(e) => e.stopPropagation()}>
            <h4 className="mb-3" style={{ color: DARK_NAVY }}>Add Billing Record</h4>
            <div className="d-flex flex-column gap-3">
                <SelectionButton onClick={() => onSelect('form')}>
                    <strong>Manual Billing Entry</strong>
                    <p className="small mb-0" style={{ color: '#6c757d' }}>Enter bill details by hand.</p>
                </SelectionButton>
                <SelectionButton onClick={() => onSelect('camera')}>
                    <strong>Camera Billing Extract</strong>
                    <p className="small mb-0" style={{ color: '#6c757d' }}>Scan or upload a bill to auto-fill.</p>
                </SelectionButton>
            </div>
        </ModalContent>
    </ModalBackdrop>
);

const BillingList = ({ invoices, onAddNew, onAnalytics, loading, error }) => (
    <div>
        <div className="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
            <div>
                <h2 className="fw-bold mb-1" style={{ color: DARK_NAVY }}>Sent Invoices</h2>
                <p className="text-secondary" style={{ color: '#6c757d' }}>History of all invoices generated and sent</p>
            </div>
            <div className="d-flex gap-2 flex-wrap">
                <OutlineButton onClick={onAnalytics}>📈 Financial Analytics</OutlineButton>
                <PrimaryButton onClick={onAddNew}>+ Create New Invoice</PrimaryButton>
            </div>
        </div>
        <GlassmorphismContainer>
            <TableWrapper>
                <StyledTable>
                    <thead>
                        <tr>
                            <th>Invoice ID</th>
                            <th>Receiver</th>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Total Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan="7" className="text-center p-5">Loading invoices...</td></tr>
                        ) : error ? (
                            <tr><td colSpan="7" className="text-center p-5 text-danger">{error}</td></tr>
                        ) : (
                            invoices.length > 0 ? invoices.map(inv => (
                                <tr key={inv.id}>
                                    <td className="fw-bold" style={{ color: DARK_NAVY }}>#{inv.id}</td>
                                    <td style={{ color: DARK_NAVY }}>{inv.receiver_shop_name}</td>
                                    <td style={{ color: DARK_NAVY }}>{inv.product_name}</td>
                                    <td style={{ color: DARK_NAVY }}>{inv.quantity}</td>
                                    <td style={{ color: PHARMACY_GREEN, fontWeight: 'bold' }}>₹{inv.total_amount.toFixed(2)}</td>
                                    <td>
                                        <span style={{ 
                                            padding: '4px 12px', 
                                            borderRadius: '20px', 
                                            fontSize: '0.75rem', 
                                            backgroundColor: inv.status === 'completed' ? '#d1e7dd' : '#fff3cd',
                                            color: inv.status === 'completed' ? '#0f5132' : '#856404'
                                        }}>
                                            {inv.status}
                                        </span>
                                    </td>
                                    <td style={{ color: DARK_NAVY }}>{new Date(inv.created_at).toLocaleDateString()}</td>
                                </tr>
                            )) : (
                                <tr><td colSpan="7" className="text-center p-5">No invoices sent yet.</td></tr>
                            )
                        )}
                    </tbody>
                </StyledTable>
            </TableWrapper>
        </GlassmorphismContainer>
    </div>
);

// --- Main DistributorBilling Component (Container) ---
const DistributorBilling = () => {
  const [view, setView] = useState('analytics');
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchInvoices = useCallback(async () => {
    try {
        const userId = localStorage.getItem('user_id');
        if (!userId) {
            setError('User not logged in');
            setLoading(false);
            return;
        }
        setLoading(true);
        const response = await axios.get(`${API_URL}/invoice/sender/${userId}`);
        setInvoices(Array.isArray(response.data) ? response.data : []);
        setError(null);
    } catch (err) {
        setError('Failed to fetch invoices');
        setInvoices([]);
    } finally {
        setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInvoices();
    
    const existingScript = document.getElementById('recharts-script');
    if (!existingScript) {
        const script = document.createElement('script');
        script.id = 'recharts-script';
        script.src = "https://unpkg.com/recharts/umd/Recharts.min.js";
        script.async = true;
        document.body.appendChild(script);
    }
  }, [fetchInvoices]);

  const handleSaveRecord = (newRecord) => {
      // For now, just refresh or manually add. 
      // But manual adding via the mock form won't persist to the DB invoice table without a real POST call.
      // We'll just refresh for now if we were making a real POST.
      fetchInvoices();
      setView('list');
  };
  
  const renderView = () => {
      switch(view) {
          case 'analytics':
              return <FinancialAnalytics invoices={invoices} onBack={() => setView('list')} onAddNew={() => setView('selection')} />;
          case 'list':
              return <BillingList invoices={invoices} loading={loading} error={error} onAddNew={() => setView('selection')} onAnalytics={() => setView('analytics')} />;
          case 'form':
              return <ManualBillingForm onBack={() => setView('list')} onSave={handleSaveRecord} />;
          case 'camera':
              return <CameraBilling onBack={() => setView('list')} />;
          case 'selection':
              return (
                  <>
                      <BillingList invoices={invoices} loading={loading} error={error} onAddNew={() => setView('selection')} onAnalytics={() => setView('analytics')} />
                      <SelectionModal onSelect={(v) => setView(v)} onClose={() => setView('list')} />
                  </>
              );
          default:
              return <FinancialAnalytics invoices={invoices} onBack={() => setView('list')} onAddNew={() => setView('selection')} />;
      }
  };

  return (
    <PageContainer>
      {renderView()}
    </PageContainer>
  );
};

export default DistributorBilling;