import React, { useEffect, useRef } from 'react';
import styled from 'styled-components';

const StyledCanvas = styled.canvas`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
  --gradient-color-1: #6d28d9;
  --gradient-color-2: #4f46e5;
  --gradient-color-3: #2563eb;
  --gradient-color-4: #db2777;
`;

const GradientCanvas = () => {
  const canvasRef = useRef(null);

  useEffect(() => {
    // Check if the Gradient library has been loaded from the CDN
    if (window.Gradient) {
      // If it exists, create a new instance and initialize it
      const gradient = new window.Gradient();
      
      if (canvasRef.current) {
        gradient.initGradient(`#${canvasRef.current.id}`);
      }
    } else {
      // If the library is not found, log an error to the console for debugging
      console.error("The 'whatamesh' gradient script has not loaded yet.");
    }
  }, []); // The empty array ensures this effect runs only once

  return <StyledCanvas id="gradient-canvas" ref={canvasRef} />;
};

export default GradientCanvas;