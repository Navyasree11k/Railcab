import React from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

// --- Styled Components (Self-Contained) ---
const PageWrapper = styled.div`
  min-height: 100vh;
  padding: 2rem;
  background-color: White; /* Dark theme background */
`;

const StatusContainer = styled.div`
  width: 100%;
  max-width: 900px; /* Optimal width for this content */
  margin: 0 auto; /* Center the container */
`;

const GlassmorphismContainer = styled.div`
  background-color: #fff;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(55, 65, 81, 0.8);
  border-radius: 1rem;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
`;

const TimelineItem = styled.div`
    display: flex;
    gap: 1rem;
    position: relative;
    padding-left: 2rem; /* Space for the line and icon */
    padding-bottom: 1.5rem;

    &:before {
        content: '';
        position: absolute;
        left: 10px;
        top: 5px;
        bottom: -5px;
        width: 2px;
        background-color: #4b5563;
    }
    
    &:last-child:before {
        display: none;
    }
`;

const TimelineIcon = styled.div`
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background-color: ${({ active }) => active ? '#22c55e' : '#4b5563'};
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 0.8rem;
    position: absolute;
    left: 0;
    top: 0;
`;


// --- Main Verification Status Component ---
const VerificationStatus = () => {
    const navigate = useNavigate();
  return (
    <PageWrapper>
        <StatusContainer>
            <div className="text-center mb-4">
                <h2 className="fw-bold text-dark">Verification Status</h2>
                <p className="text-secondary">Documents Submitted</p>
            </div>

            <GlassmorphismContainer className="text-center">
                <div className="fs-1 text-warning mb-3">⏳</div>
                <span className="badge bg-warning text-dark fw-bold">Verification Pending</span>
                <h4 className="text-dark mt-3">Documents Under Review</h4>
                <p className="text-secondary">Your documents are being reviewed by our verification team. This process typically takes 24-48 hours.</p>
            </GlassmorphismContainer>

            <div className="alert d-flex align-items-center" role="alert" style={{backgroundColor: 'rgba(50, 150, 238, 0.1)', borderColor: 'transparent', color: '#0c0c0cff'}}>
                <span className="fs-4 me-3">ℹ️</span>
                <div>
                    <strong>Access Temporarily Restricted</strong>
                    <p className="mb-0 small">Full app features will be available once your verification is approved. You can view this status anytime.</p>
                </div>
            </div>

            <div className="row g-4 mt-2">
                <div className="col-lg-6">
                    <GlassmorphismContainer>
                        <h5 className="text-dark mb-3">Submitted Documents</h5>
                        <div className="d-flex justify-content-between align-items-center py-2">
                            <div className="d-flex align-items-center"><span className="fs-5 me-3">💳</span><div><p className="text-dark mb-0">Aadhar Card</p><small className="text-secondary">Front & Back uploaded</small></div></div>
                            <span className="text-success small">✓ Submitted</span>
                        </div>
                        <div className="d-flex justify-content-between align-items-center py-2">
                            <div className="d-flex align-items-center"><span className="fs-5 me-3">📄</span><div><p className="text-dark mb-0">PAN Card</p><small className="text-secondary">Document uploaded</small></div></div>
                            <span className="text-success small">✓ Submitted</span>
                        </div>
                        <div className="d-flex justify-content-between align-items-center py-2">
                            <div className="d-flex align-items-center"><span className="fs-5 me-3">🤳</span><div><p className="text-dark mb-0">Live Verification</p><small className="text-secondary">Selfie with GPS Captured</small></div></div>
                            <span className="text-success small">✓ Completed</span>
                        </div>
                    </GlassmorphismContainer>
                    <GlassmorphismContainer>
                        <h5 className="text-dark mb-3">What's Next?</h5>
                        <ul className="list-unstyled text-secondary ps-3">
                            <li className="mb-2">You'll receive a notification once verification is complete.</li>
                            <li className="mb-2">If approved, you'll gain full access to all features.</li>
                            <li>If rejected, you'll be guided to resubmit documents.</li>
                        </ul>
                    </GlassmorphismContainer>
                </div>
                <div className="col-lg-6">
                    <GlassmorphismContainer>
                        <h5 className="text-dark mb-3">Verification Timeline</h5>
                        <div>
                            <TimelineItem>
                                <TimelineIcon active>✓</TimelineIcon>
                                <div>
                                    <p className="text-dark fw-bold mb-0">Documents Submitted</p>
                                    <small className="text-secondary">Today, 2:30 PM</small>
                                </div>
                            </TimelineItem>
                             <TimelineItem>
                                <TimelineIcon>⏳</TimelineIcon>
                                <div>
                                    <p className="text-dark fw-bold mb-0">Under Review</p>
                                    <small className="text-secondary">In progress - Est. 24-48 hours</small>
                                </div>
                            </TimelineItem>
                             <TimelineItem>
                                <TimelineIcon>👤</TimelineIcon>
                                <div>
                                    <p className="text-dark fw-bold mb-0">Verification Complete</p>
                                    <small className="text-secondary">Pending</small>
                                </div>
                            </TimelineItem>
                        </div>
                    </GlassmorphismContainer>
                </div>
            </div>

            <div className="d-grid mt-4">
                <button 
                    className="btn btn-primary p-3 fw-bold" 
                    style={{backgroundColor: '#0ea5e9', borderColor: '#0ea5e9'}}
                    onClick={() => navigate('/login')}
                >
                    Check Status Again
                </button>
                <p className="text-center text-secondary small mt-3">
                    Need help?{' '}
                    <button
                        type="button"
                        className="btn btn-link text-info p-0 align-baseline"
                        onClick={() => navigate('/login')}
                    >
                        Contact Support
                    </button>
                </p>
            </div>
        </StatusContainer>
    </PageWrapper>
  );
};

export default VerificationStatus;
