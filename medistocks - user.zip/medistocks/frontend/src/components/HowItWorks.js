import React from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
// --- Styled Components (Self-Contained) ---
const PageWrapper = styled.div`
  background-color: White;
  color: #fff;
  min-height: 100vh;
  padding-bottom: 100px; /* Space for the sticky footer */
`;

const Header = styled.header`
  padding: 1rem 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const GlassmorphismCard = styled.div`
  background-color: #fff;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(55, 65, 81, 0.8);
  border-radius: 1rem;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
`;

const VideoPlaceholder = styled(GlassmorphismCard)`
    text-align: center;
    padding: 4rem 1.5rem;
`;

const SectionTitle = styled.h3`
    font-weight: bold;
    color: #fff;
    margin-bottom: 1.5rem;
`;

const BenefitCard = styled(GlassmorphismCard)`
    text-align: center;
    height: 100%;
`;

const StepItem = styled.div`
    display: flex;
    align-items: flex-start;
    gap: 1.5rem;
    margin-bottom: 1.5rem;
`;

const StepNumber = styled.div`
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    background-color: #0ea5e9;
    color: #fff;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
`;

const StickyFooter = styled.footer`
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #fff;
    backdrop-filter: blur(16px);
    padding: 1rem;
    border-top: 1px solid rgba(55, 65, 81, 0.8);
    z-index: 1000;
`;


// --- Main How It Works Component ---
const HowItWorks = ({  }) => {
    const navigate = useNavigate();
  return (
    <PageWrapper>
        <div className="container" style={{maxWidth: '900px'}}>
            <Header>
                <button className="btn btn-link text-black p-0"><span className="fs-4">←</span></button>
                <h4 className="fw-bold mb-0 text-black">How It Works</h4>
                <button className="btn btn-link text-black p-0"><span className="fs-4">🔗</span></button>
            </Header>

            <main className="p-3">
                {/* --- Video Section --- */}
                <VideoPlaceholder>
                    <div className="fs-1 text-info">▶️</div>
                    <h5 className="text-dark mt-2 mb-1">Welcome to Pharmacy Deals</h5>
                    <p className="text-secondary">Tap to watch tutorial</p>
                </VideoPlaceholder>

                {/* --- What You'll Learn --- */}
                <section className="my-5">
                    <SectionTitle>What You'll Learn</SectionTitle>
                    <div className="row g-4">
                        <div className="col-md-6">
                            <GlassmorphismCard>
                                <h5 className="text-dark">For Retail Shops</h5>
                                <p className="text-secondary">Find expiring medicines before expiry, send purchase requests, and manage orders.</p>
                            </GlassmorphismCard>
                        </div>
                        <div className="col-md-6">
                            <GlassmorphismCard>
                                <h5 className="text-dark">For Distributors</h5>
                                <p className="text-secondary">List products with expiry dates, manage requests, generate invoices, and track sales.</p>
                            </GlassmorphismCard>
                        </div>
                    </div>
                </section>

                {/* --- Key Benefits --- */}
                <section className="my-5">
                    <SectionTitle>Key Benefits</SectionTitle>
                    <div className="row g-4">
                        <div className="col-md-6 col-lg-3"><BenefitCard><div className="fs-2 mb-2">💰</div><h6 className="text-dark">Up to 90% Off</h6><p className="text-secondary small">Massive discounts on medicines nearing expiry.</p></BenefitCard></div>
                        <div className="col-md-6 col-lg-3"><BenefitCard><div className="fs-2 mb-2">✅</div><h6 className="text-dark">Verified Users</h6><p className="text-secondary small">All users are document verified for safety.</p></BenefitCard></div>
                        <div className="col-md-6 col-lg-3"><BenefitCard><div className="fs-2 mb-2">🚚</div><h6 className="text-dark">Real-time Tracking</h6><p className="text-secondary small">Track expiry dates with visual progress bars.</p></BenefitCard></div>
                        <div className="col-md-6 col-lg-3"><BenefitCard><div className="fs-2 mb-2">📄</div><h6 className="text-dark">Easy Billing</h6><p className="text-secondary small">Generate invoices and track payments seamlessly.</p></BenefitCard></div>
                    </div>
                </section>

                {/* --- 4-Step Process --- */}
                <section className="my-5">
                    <SectionTitle>Simple 4-Step Process</SectionTitle>
                    <GlassmorphismCard>
                        <StepItem>
                            <StepNumber>1</StepNumber>
                            <div>
                                <h6 className="text-dark">Register & Verify</h6>
                                <p className="text-secondary mb-0">Complete document verification and choose your business type.</p>
                            </div>
                        </StepItem>
                         <StepItem>
                            <StepNumber>2</StepNumber>
                            <div>
                                <h6 className="text-dark">Browse or List Products</h6>
                                <p className="text-secondary mb-0">Retailers browse deals, Distributors list products with expiry dates.</p>
                            </div>
                        </StepItem>
                         <StepItem>
                            <StepNumber>3</StepNumber>
                            <div>
                                <h6 className="text-dark">Connect & Negotiate</h6>
                                <p className="text-secondary mb-0">Send requests, chat with sellers, and finalize deals.</p>
                            </div>
                        </StepItem>
                         <StepItem className="mb-0">
                            <StepNumber>4</StepNumber>
                            <div>
                                <h6 className="text-dark">Complete Transaction</h6>
                                <p className="text-secondary mb-0">Generate invoices, make payments, and track deliveries.</p>
                            </div>
                        </StepItem>
                    </GlassmorphismCard>
                </section>
            </main>
        </div>
        <StickyFooter>
            <div className="container d-grid">
                <button 
                    className="btn btn-primary fw-bold p-3" 
                    style={{ backgroundColor: '#0ea5e9', borderColor: '#0ea5e9' }}
                    onClick={() => navigate('/login')}
                >
                    Continue
                </button>
            </div>
        </StickyFooter>
    </PageWrapper>
  );
};

export default HowItWorks;
