import React, { useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

// --- PHARMACY THEME COLORS (improved) ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

// --- Styled Components (improved, responsive) ---
const PageWrapper = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1.5rem;
  background: ${LIGHT_GREEN};
  @media (min-width: 768px) {
    padding: 2rem;
  }
`;

const SelectionContainer = styled.div`
  width: 100%;
  max-width: 1100px;
  background: white;
  border-radius: 1.5rem;
  box-shadow: ${CARD_SHADOW};
  padding: 1.5rem;
  @media (min-width: 768px) {
    padding: 2rem 2.5rem;
  }
  @media (min-width: 1024px) {
    padding: 2.5rem 3.5rem;
  }
`;

const RoleCard = styled.div`
  background: white;
  border: 2px solid ${({ active }) => active ? PHARMACY_GREEN : BORDER_GREY};
  border-radius: 1.25rem;
  padding: 1.5rem;
  cursor: pointer;
  transition: all 0.25s ease;
  position: relative;
  box-shadow: ${({ active }) => active ? `0 0 0 3px ${PHARMACY_GREEN}20` : 'none'};

  &:hover {
    border-color: ${PHARMACY_GREEN};
    transform: translateY(-4px);
    box-shadow: ${HOVER_SHADOW};
  }
  @media (min-width: 768px) {
    padding: 2rem 1.8rem;
  }
`;

const RadioButton = styled.div`
  width: 24px;
  height: 24px;
  border-radius: 50%;
  border: 2px solid ${({ active }) => active ? PHARMACY_GREEN : '#cbd5e1'};
  background: white;
  position: absolute;
  top: 1rem;
  right: 1rem;
  display: flex;
  justify-content: center;
  align-items: center;
  transition: all 0.2s;
  &::after {
    content: '';
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: ${PHARMACY_GREEN};
    transform: ${({ active }) => active ? 'scale(1)' : 'scale(0)'};
    transition: transform 0.2s;
  }
  @media (min-width: 768px) {
    width: 26px;
    height: 26px;
    top: 1.5rem;
    right: 1.5rem;
    &::after {
      width: 14px;
      height: 14px;
    }
  }
`;

const RoleContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  @media (min-width: 640px) {
    flex-direction: row;
    gap: 1.2rem;
    align-items: flex-start;
  }
`;

const RoleIcon = styled.div`
  font-size: 2rem;
  min-width: 56px;
  text-align: center;
  color: ${PHARMACY_GREEN};
  @media (min-width: 768px) {
    font-size: 2.7rem;
    min-width: 70px;
  }
`;

const RoleDetails = styled.div`
  flex: 1;
  h5 {
    font-size: 1.1rem;
    color: ${DARK_NAVY};
    font-weight: 700;
    margin-bottom: 0.5rem;
    @media (min-width: 768px) {
      font-size: 1.25rem;
    }
  }
  p {
    font-size: 0.85rem;
    color: #6c757d;
    margin-bottom: 0.75rem;
    @media (min-width: 768px) {
      font-size: 0.95rem;
    }
  }
`;

const FeatureList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0.5rem 0 0;
  display: grid;
  grid-template-columns: 1fr;
  gap: 0.4rem;
  @media (min-width: 480px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (min-width: 768px) {
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 0.5rem;
  }
`;

const FeatureItem = styled.li`
  color: ${DARK_NAVY};
  font-size: 0.8rem;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  &::before {
    content: '✓';
    color: ${PHARMACY_GREEN};
    font-weight: 700;
    font-size: 0.9rem;
  }
  @media (min-width: 768px) {
    font-size: 0.9rem;
  }
`;

const CardsGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 1.25rem;
  margin-top: 1.5rem;
  @media (min-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
    gap: 2rem;
    margin-top: 2rem;
  }
`;

const StepProgress = styled.div`
  margin: 1rem auto 0;
  width: 100%;
  max-width: 300px;
  @media (min-width: 768px) {
    max-width: 350px;
  }
`;

// --- Main Choose Business Component (logic unchanged) ---
const ChooseBusiness = () => {
  const [selectedRole, setSelectedRole] = useState(null);
  const navigate = useNavigate();

  return (
    <PageWrapper>
      <SelectionContainer>
        <div style={{ textAlign: 'center' }}>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '70px',
              height: '70px',
              background: `linear-gradient(135deg, ${PHARMACY_GREEN} 0%, #0f9d4e 100%)`,
              borderRadius: '60px',
              marginBottom: '1rem',
              fontSize: '2.2rem',
              boxShadow: '0 4px 12px rgba(13,124,61,0.2)'
            }}
          >
            🏢
          </div>
          <h2 style={{
            fontSize: '1.6rem',
            fontWeight: 800,
            color: DARK_NAVY,
            marginBottom: '0.5rem',
            letterSpacing: '-0.3px'
          }}>
            What best describes your business?
          </h2>
          <p style={{
            fontSize: '0.9rem',
            color: '#6c757d',
            maxWidth: '500px',
            margin: '0 auto 0.75rem'
          }}>
            Select your business type to customize your MediStox experience and unlock relevant features.
          </p>

          <StepProgress>
            <div style={{
              background: BORDER_GREY,
              height: '8px',
              borderRadius: '10px',
              overflow: 'hidden'
            }}>
              <div style={{
                width: '25%',
                background: PHARMACY_GREEN,
                height: '100%',
                borderRadius: '10px'
              }} />
            </div>
            <p style={{
              color: PHARMACY_GREEN,
              fontWeight: 600,
              fontSize: '0.8rem',
              marginTop: '0.5rem'
            }}>
              Step 1 of 4
            </p>
          </StepProgress>
        </div>

        <CardsGrid>
          {/* Retail Card */}
          <RoleCard
            active={selectedRole === 'retail'}
            onClick={() => {
              setSelectedRole('retail');
              navigate('/select-plan', { state: { role: 'retail' } });
            }}
          >
            <RadioButton active={selectedRole === 'retail'} />
            <RoleContent>
              <RoleIcon>🏪</RoleIcon>
              <RoleDetails>
                <h5>Retail Shop</h5>
                <p>I own a pharmacy or medical store and want to buy discounted medicines before expiry.</p>
                <FeatureList>
                  <FeatureItem>Browse available products</FeatureItem>
                  <FeatureItem>Send purchase requests</FeatureItem>
                  <FeatureItem>Chat with distributors</FeatureItem>
                  <FeatureItem>Get discount notifications</FeatureItem>
                  <FeatureItem>Track order history</FeatureItem>
                </FeatureList>
              </RoleDetails>
            </RoleContent>
          </RoleCard>

          {/* Distributor Card */}
          <RoleCard
            active={selectedRole === 'distributor'}
            onClick={() => {
              setSelectedRole('distributor');
              navigate('/select-plan', { state: { role: 'distributor' } });
            }}
          >
            <RadioButton active={selectedRole === 'distributor'} />
            <RoleContent>
              <RoleIcon>🚚</RoleIcon>
              <RoleDetails>
                <h5>Distributor</h5>
                <p>I distribute pharmaceutical products and want to sell excess inventory at discounted rates.</p>
                <FeatureList>
                  <FeatureItem>Post products for sale</FeatureItem>
                  <FeatureItem>Manage buyer requests</FeatureItem>
                  <FeatureItem>Generate invoices & billing</FeatureItem>
                  <FeatureItem>Inventory management</FeatureItem>
                  <FeatureItem>Sales analytics</FeatureItem>
                </FeatureList>
              </RoleDetails>
            </RoleContent>
          </RoleCard>
        </CardsGrid>
      </SelectionContainer>
    </PageWrapper>
  );
};

export default ChooseBusiness;