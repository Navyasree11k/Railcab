import React, { useState } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeUp = keyframes`from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}`;
const ACCENT = '#10b981';

const mockOrders = [
  { id:'ORD001234', items:3, amount:'₹2,450', distributor:'MedSupply Co.', distributorContact:'+91 98765 43210', distributorEmail:'orders@medsupply.com', date:'Dec 18, 2024', status:'Delivered', progress:100, details:[{name:'Paracetamol 500mg (50 strips)',price:'₹1,200'},{name:'Amoxicillin 250mg (30 strips)',price:'₹600'},{name:'Omeprazole 20mg (25 strips)',price:'₹350'}]},
  { id:'ORD001235', items:2, amount:'₹1,800', distributor:'PharmaDist Ltd.', distributorContact:'+91 91234 56789', distributorEmail:'contact@pharmadist.com', date:'Dec 19, 2024', status:'In Transit', progress:75, details:[{name:'Ibuprofen 400mg (20 strips)',price:'₹900'},{name:'Cetirizine 10mg (40 strips)',price:'₹900'}]},
  { id:'ORD001236', items:1, amount:'₹950', distributor:'HealthSupply Inc.', distributorContact:'+91 99887 76655', distributorEmail:'sales@healthsupply.inc', date:'Dec 20, 2024', status:'Pending', progress:10, details:[{name:'Vitamin D3 (15 strips)',price:'₹950'}]},
];

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;background:#f5f7fa;min-height:100%;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 22px;`;

const StatsRow = styled.div`
  display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:22px;
  @media(max-width:700px){grid-template-columns:repeat(2,1fr);}
  @media(max-width:400px){grid-template-columns:1fr;}
`;
const StatCard = styled.div`
  background:#fff;border:1.5px solid #f0f0f0;border-radius:12px;
  padding:16px 18px;display:flex;align-items:center;gap:12px;
  box-shadow:0 1px 4px rgba(0,0,0,.04);animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*60}ms;
`;
const StatIcon  = styled.div`width:38px;height:38px;border-radius:9px;background:${p=>p.$bg||'#f0fdf9'};display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;`;
const StatLabel = styled.div`font-size:.7rem;color:#9ca3af;text-transform:uppercase;letter-spacing:.5px;`;
const StatVal   = styled.div`font-size:1.3rem;font-weight:800;color:${p=>p.$c||'#111827'};`;

const Layout = styled.div`
  display:grid;grid-template-columns:1fr 360px;gap:18px;align-items:start;
  @media(max-width:960px){grid-template-columns:1fr;}
`;

const OrderCard = styled.div`
  background:#fff;border:1.5px solid ${p=>p.$active?ACCENT:'#f0f0f0'};border-radius:12px;
  padding:16px 18px;cursor:pointer;margin-bottom:12px;
  transition:all .2s;box-shadow:${p=>p.$active?`0 0 0 3px rgba(16,185,129,.1)`:' 0 1px 4px rgba(0,0,0,.04)'};
  &:hover{border-color:#d1fae5;}
  animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*80}ms;
`;
const OCardTop = styled.div`display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:10px;`;
const OCardId  = styled.div`font-weight:700;font-size:.9rem;color:#111827;`;
const OCardMeta= styled.div`font-size:.76rem;color:#9ca3af;margin-top:2px;`;

const ProgressTrack = styled.div`height:4px;background:#f0f0f0;border-radius:999px;overflow:hidden;margin:10px 0;`;
const ProgressFill  = styled.div`height:100%;border-radius:999px;background:linear-gradient(90deg,${ACCENT},#0ea5e9);width:${p=>p.$w}%;transition:width .5s ease;`;
const ProgressLabels= styled.div`display:flex;justify-content:space-between;font-size:.68rem;color:#9ca3af;`;

const StatusBadge = styled.span`
  display:inline-flex;font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.4px;
  padding:3px 9px;border-radius:5px;white-space:nowrap;
  background:${p=>p.$s==='Delivered'?'#f0fdf9':p.$s==='In Transit'?'#fffbeb':'#fef2f2'};
  color:${p=>p.$s==='Delivered'?'#059669':p.$s==='In Transit'?'#d97706':'#ef4444'};
  border:1px solid ${p=>p.$s==='Delivered'?'#a7f3d0':p.$s==='In Transit'?'#fde68a':'#fecaca'};
`;

const DetailCard = styled.div`background:#fff;border:1.5px solid #f0f0f0;border-radius:12px;padding:20px;box-shadow:0 1px 4px rgba(0,0,0,.04);`;
const DetailRow  = styled.div`display:flex;justify-content:space-between;font-size:.84rem;color:#6b7280;padding:8px 0;border-bottom:1px solid #f5f5f5;&:last-child{border:none;}span:last-child{font-weight:600;color:#374151;}`;
const DetailSec  = styled.div`font-size:.72rem;text-transform:uppercase;letter-spacing:.6px;color:#9ca3af;font-weight:600;margin:14px 0 6px;`;
const PrimaryBtn = styled.button`
  width:100%;padding:11px;background:linear-gradient(135deg,${ACCENT},#0ea5e9);
  border:none;border-radius:9px;color:#fff;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.88rem;font-weight:700;
  cursor:pointer;transition:all .2s;box-shadow:0 4px 12px rgba(16,185,129,.22);
  &:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(16,185,129,.3);}
`;
const OutlineBtn = styled.button`
  flex:1;padding:9px;background:#fff;border:1.5px solid #e5e7eb;border-radius:9px;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.84rem;font-weight:600;color:#374151;
  cursor:pointer;transition:all .15s;&:hover{background:#f9fafb;}
`;

const Orders = () => {
  const [selectedId, setSelectedId] = useState(mockOrders[0].id);
  const selected = mockOrders.find(o => o.id === selectedId);

  return (
    <Page>
      <PageTitle>My <em>Orders</em></PageTitle>
      <PageSub>Track and manage your pharmaceutical orders.</PageSub>

      <StatsRow>
        {[{label:'Total',val:24,icon:'📦',bg:'#f0fdf9',c:'#111827'},{label:'Delivered',val:18,icon:'✅',bg:'#eff6ff',c:'#2563eb'},{label:'In Transit',val:4,icon:'🚚',bg:'#fffbeb',c:'#d97706'},{label:'Pending',val:2,icon:'⏳',bg:'#fef2f2',c:'#ef4444'}].map((s,i)=>(
          <StatCard key={s.label} $i={i}>
            <StatIcon $bg={s.bg}>{s.icon}</StatIcon>
            <div><StatLabel>{s.label}</StatLabel><StatVal $c={s.c}>{s.val}</StatVal></div>
          </StatCard>
        ))}
      </StatsRow>

      <Layout>
        <div>
          <div style={{fontWeight:700,fontSize:'.9rem',color:'#374151',marginBottom:12}}>Recent Orders</div>
          {mockOrders.map((order, i) => (
            <OrderCard key={order.id} $active={order.id===selectedId} $i={i} onClick={()=>setSelectedId(order.id)}>
              <OCardTop>
                <div>
                  <OCardId>Order #{order.id}</OCardId>
                  <OCardMeta>{order.items} items · {order.amount}</OCardMeta>
                </div>
                <StatusBadge $s={order.status}>{order.status}</StatusBadge>
              </OCardTop>
              <ProgressTrack><ProgressFill $w={order.progress}/></ProgressTrack>
              <ProgressLabels><span>Ordered</span><span>Shipped</span><span>In Transit</span><span>Delivered</span></ProgressLabels>
            </OrderCard>
          ))}
        </div>

        {selected && (
          <div>
            <div style={{fontWeight:700,fontSize:'.9rem',color:'#374151',marginBottom:12}}>Order Details</div>
            <DetailCard>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
                <div>
                  <div style={{fontWeight:700,fontSize:'.95rem',color:'#111827'}}>Order #{selected.id}</div>
                  <div style={{fontSize:'.75rem',color:'#9ca3af',marginTop:2}}>{selected.date}</div>
                </div>
                <StatusBadge $s={selected.status}>{selected.status}</StatusBadge>
              </div>
              <div style={{height:1,background:'#f5f5f5',marginBottom:12}}/>
              {selected.details.map(item=>(
                <DetailRow key={item.name}><span style={{maxWidth:'70%',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{item.name}</span><span>{item.price}</span></DetailRow>
              ))}
              <div style={{height:1,background:'#f5f5f5',margin:'10px 0'}}/>
              <div style={{display:'flex',justifyContent:'space-between',fontWeight:800,fontSize:'1rem',color:'#111827'}}>
                <span>Total</span><span style={{color:ACCENT}}>{selected.amount}</span>
              </div>
              <DetailSec>Distributor</DetailSec>
              <div style={{fontSize:'.84rem',color:'#374151',fontWeight:600,marginBottom:2}}>{selected.distributor}</div>
              <div style={{fontSize:'.78rem',color:'#9ca3af'}}>{selected.distributorContact} · {selected.distributorEmail}</div>
              <div style={{marginTop:16,display:'flex',flexDirection:'column',gap:10}}>
                <PrimaryBtn>📥 Download Invoice</PrimaryBtn>
                <div style={{display:'flex',gap:10}}>
                  <OutlineBtn>↩ Return</OutlineBtn>
                  <OutlineBtn>💬 Chat</OutlineBtn>
                </div>
              </div>
            </DetailCard>
          </div>
        )}
      </Layout>
    </Page>
  );
};

export default Orders;