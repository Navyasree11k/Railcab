import React, { useState, useEffect, useRef, useCallback } from 'react';
import styled, { createGlobalStyle, ThemeProvider, keyframes } from 'styled-components';

/**
 * Edit these constants:
 * - BASE_URL: base URL of your backend (no trailing slash), e.g. https://api.triyeka.in
 */
const { AdminBaseUrl } = require('./BaseUrl'); // Original import
const BASE_URL = AdminBaseUrl;

// --- PHARMACY THEME (improved) ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

const theme = {
  colors: {
    primary: PHARMACY_GREEN,
    primaryHover: '#0a5e2e',
    secondary: LIGHT_GREEN,
    text: DARK_NAVY,
    textSecondary: '#6c757d',
    white: '#ffffff',
    border: BORDER_GREY,
    success: '#28a745',
    successBg: '#e9f7eb',
    warning: '#f39c12',
    warningBg: '#fff9e6',
    info: '#17a2b8',
    infoBg: '#e7f6f8',
  },
  borderRadius: '16px',
  shadow: CARD_SHADOW,
  shadowHover: HOVER_SHADOW,
  transition: 'all 0.25s ease',
};

const GlobalStyle = createGlobalStyle`
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background-color: ${props => props.theme.colors.secondary};
    color: ${props => props.theme.colors.text};
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }
`;

// --- KEYFRAMES (unchanged) ---
const spin = keyframes`
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
`;
const fadeIn = keyframes`
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
`;

// --- ICONS (unchanged) ---
const HelpCircle = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10"></circle>
    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
    <line x1="12" y1="17" x2="12.01" y2="17"></line>
  </svg>
);
const X = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
);
const Send = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="22" y1="2" x2="11" y2="13"></line>
    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
  </svg>
);
const Clock = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10"></circle>
    <polyline points="12 6 12 12 16 14"></polyline>
  </svg>
);
const CheckCircle = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
    <polyline points="22 4 12 14.01 9 11.01"></polyline>
  </svg>
);
const Loader2 = styled.svg`
  animation: ${spin} 1s linear infinite;
`;
const LoaderIcon = ({ className }) => (
  <Loader2 xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
  </Loader2>
);

// --- STYLED HELPER COMPONENTS (improved) ---
const statusColors = {
  pending: { bg: theme.colors.warningBg, text: theme.colors.warning },
  in_progress: { bg: theme.colors.infoBg, text: theme.colors.info },
  resolved: { bg: theme.colors.successBg, text: theme.colors.success },
};

const StatusBadgeContainer = styled.span`
  display: inline-flex;
  align-items: center;
  padding: 6px 14px;
  border-radius: 40px;
  font-size: 0.75rem;
  font-weight: 600;
  letter-spacing: 0.3px;
  background-color: ${props => statusColors[props.status]?.bg || props.theme.colors.secondary};
  color: ${props => statusColors[props.status]?.text || props.theme.colors.textSecondary};
  svg {
    width: 14px;
    height: 14px;
    margin-right: 6px;
  }
`;

const StatusBadge = ({ status }) => {
  const statusIcons = {
    pending: <Clock />,
    in_progress: <LoaderIcon />,
    resolved: <CheckCircle />,
  };
  const statusText = {
    pending: 'Pending',
    in_progress: 'In Progress',
    resolved: 'Resolved',
  };
  return (
    <StatusBadgeContainer status={status}>
      {statusIcons[status] || null}
      {statusText[status] || status}
    </StatusBadgeContainer>
  );
};

// --- STYLED LAYOUT COMPONENTS (improved, responsive) ---
const AppWrapper = styled.div`
  min-height: 100vh;
  position: relative;
  background: ${LIGHT_GREEN};
`;

const MainContainer = styled.div`
  max-width: 900px;
  margin: 0 auto;
  padding: 1.5rem;
  @media (min-width: 768px) {
    padding: 2rem;
  }
`;

const Title = styled.h1`
  font-size: 1.75rem;
  font-weight: 700;
  color: ${DARK_NAVY};
  margin-bottom: 0.5rem;
  @media (min-width: 768px) {
    font-size: 2.25rem;
  }
`;

const Subtitle = styled.p`
  font-size: 0.9rem;
  color: #6c757d;
  margin-bottom: 1.5rem;
  @media (min-width: 768px) {
    font-size: 1rem;
    margin-bottom: 2rem;
  }
`;

const ErrorBanner = styled.div`
  background: #fef2f2;
  border-left: 4px solid #c0392b;
  color: #c0392b;
  padding: 1rem;
  margin-bottom: 1.5rem;
  border-radius: 12px;
  strong {
    display: block;
    font-weight: 700;
    margin-bottom: 4px;
  }
  div {
    font-size: 0.85rem;
  }
`;

const FilterTabsContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  border-bottom: 2px solid ${BORDER_GREY};
  margin-bottom: 1.5rem;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
`;

const FilterTab = styled.button`
  padding: 0.6rem 1rem;
  font-weight: 600;
  font-size: 0.85rem;
  color: ${props => props.active ? PHARMACY_GREEN : '#6c757d'};
  background: none;
  border: none;
  border-bottom: 3px solid ${props => props.active ? PHARMACY_GREEN : 'transparent'};
  margin-bottom: -2px;
  cursor: pointer;
  transition: all 0.2s;
  text-transform: capitalize;
  white-space: nowrap;
  &:hover {
    color: ${PHARMACY_GREEN};
  }
  @media (min-width: 768px) {
    padding: 0.75rem 1.25rem;
    font-size: 0.9rem;
  }
`;

const ChatList = styled.div`
  display: grid;
  gap: 1rem;
`;

const ChatListItem = styled.button`
  width: 100%;
  text-align: left;
  background: white;
  padding: 1.25rem;
  border-radius: 20px;
  box-shadow: ${CARD_SHADOW};
  border: 1px solid ${BORDER_GREY};
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  transition: all 0.25s;
  &:hover {
    box-shadow: ${HOVER_SHADOW};
    transform: translateY(-2px);
    border-color: ${PHARMACY_GREEN}40;
  }
  @media (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const ChatInfo = styled.div`
  overflow: hidden;
  flex: 1;
`;

const ChatTitle = styled.p`
  font-weight: 700;
  color: ${DARK_NAVY};
  margin-bottom: 4px;
  font-size: 0.95rem;
  @media (min-width: 768px) {
    font-size: 1rem;
  }
`;

const ChatSnippet = styled.p`
  font-size: 0.8rem;
  color: #6c757d;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 250px;
  @media (min-width: 768px) {
    max-width: 400px;
  }
`;

const StatusContainer = styled.div`
  flex-shrink: 0;
  margin-left: 1rem;
`;

const EmptyState = styled.div`
  text-align: center;
  padding: 3rem 1rem;
  color: #6c757d;
  background: white;
  border-radius: 20px;
  border: 1px solid ${BORDER_GREY};
`;

const LoadingContainer = styled(EmptyState)`
  font-weight: 500;
`;

// --- Help Button (improved) ---
const HelpButton = styled.button`
  position: fixed;
  bottom: 1.5rem;
  right: 1.5rem;
  background: ${PHARMACY_GREEN};
  color: white;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(13,124,61,0.3);
  cursor: pointer;
  transition: all 0.2s;
  z-index: 20;
  svg {
    width: 28px;
    height: 28px;
  }
  &:hover {
    background: #0a5e2e;
    transform: scale(1.05);
  }
  @media (min-width: 768px) {
    width: 60px;
    height: 60px;
    svg {
      width: 32px;
      height: 32px;
    }
  }
`;

// --- MODAL COMPONENTS (improved) ---
const ModalBackdrop = styled.div`
  position: fixed;
  inset: 0;
  z-index: 40;
  background-color: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1rem;
`;

const ModalContent = styled.div`
  background: white;
  width: 100%;
  max-width: 500px;
  padding: 1.5rem;
  border-radius: 24px;
  box-shadow: ${HOVER_SHADOW};
  position: relative;
  animation: ${fadeIn} 0.2s ease-out;
  @media (min-width: 768px) {
    padding: 2rem;
  }
`;

const ModalCloseButton = styled.button`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: none;
  border: none;
  color: #6c757d;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 50%;
  display: flex;
  &:hover {
    color: ${DARK_NAVY};
    background: ${LIGHT_GREEN};
  }
  svg {
    width: 20px;
    height: 20px;
  }
`;

const ModalTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
  color: ${DARK_NAVY};
`;

const FormLabel = styled.label`
  display: block;
  font-size: 0.8rem;
  font-weight: 600;
  color: ${DARK_NAVY};
  margin-bottom: 0.5rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`;

const StyledInput = styled.input`
  width: 100%;
  padding: 0.75rem 1rem;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 14px;
  font-size: 0.9rem;
  transition: all 0.2s;
  &:focus {
    outline: none;
    border-color: ${PHARMACY_GREEN};
    box-shadow: 0 0 0 3px ${PHARMACY_GREEN}20;
  }
`;

const StyledSelect = styled(StyledInput).attrs({ as: 'select' })`
  appearance: none;
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
  background-position: right 1rem center;
  background-repeat: no-repeat;
  background-size: 1.2rem;
  padding-right: 2.5rem;
`;

const StyledTextArea = styled(StyledInput).attrs({ as: 'textarea' })`
  resize: vertical;
  min-height: 120px;
`;

const PrimaryButton = styled.button`
  width: 100%;
  background: ${PHARMACY_GREEN};
  color: white;
  padding: 0.75rem 1rem;
  font-size: 0.9rem;
  font-weight: 600;
  border: none;
  border-radius: 40px;
  cursor: pointer;
  transition: all 0.2s;
  &:hover {
    background: #0a5e2e;
    transform: translateY(-1px);
  }
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
  }
`;

const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;

// --- CHAT WINDOW COMPONENTS (improved, responsive) ---
const ChatWindowContainer = styled.div`
  position: fixed;
  z-index: 30;
  background: white;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  /* Mobile: full width, 80vh height */
  bottom: 0;
  right: 0;
  left: 0;
  height: 80vh;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
  /* Desktop: floating window */
  @media (min-width: 768px) {
    bottom: 1.5rem;
    right: 1.5rem;
    left: auto;
    height: 520px;
    width: 420px;
    border-radius: 24px;
    box-shadow: ${HOVER_SHADOW};
  }
`;

const ChatHeader = styled.div`
  background: white;
  padding: 1rem 1.5rem;
  border-bottom: 1px solid ${BORDER_GREY};
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
`;

const ChatHeaderTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 700;
  color: ${DARK_NAVY};
`;

const MessageList = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  background: ${LIGHT_GREEN};
  @media (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const MessageRow = styled.div`
  display: flex;
  justify-content: ${props => props.isUser ? 'flex-end' : 'flex-start'};
`;

const MessageBubble = styled.div`
  max-width: 85%;
  padding: 0.75rem 1rem;
  border-radius: 20px;
  background: ${props => props.isUser ? PHARMACY_GREEN : 'white'};
  color: ${props => props.isUser ? 'white' : DARK_NAVY};
  border: ${props => props.isUser ? 'none' : `1px solid ${BORDER_GREY}`};
  border-bottom-right-radius: ${props => props.isUser && '4px'};
  border-bottom-left-radius: ${props => !props.isUser && '4px'};
  box-shadow: 0 1px 2px rgba(0,0,0,0.05);
  p {
    white-space: pre-wrap;
    word-wrap: break-word;
    font-size: 0.85rem;
    line-height: 1.4;
  }
  a {
    color: ${props => props.isUser ? 'white' : PHARMACY_GREEN};
    text-decoration: underline;
    font-size: 0.8rem;
    font-weight: 500;
    margin-top: 6px;
    display: block;
  }
`;

const MessageTimestamp = styled.span`
  display: block;
  font-size: 0.65rem;
  margin-top: 6px;
  color: ${props => props.isUser ? 'rgba(255,255,255,0.7)' : '#8b96a5'};
`;

const ChatForm = styled.form`
  background: white;
  padding: 0.75rem;
  border-top: 1px solid ${BORDER_GREY};
  @media (min-width: 768px) {
    padding: 1rem;
  }
`;

const InputRow = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const ChatInput = styled.input`
  flex: 1;
  padding: 0.7rem 1rem;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 40px;
  font-size: 0.85rem;
  background: ${LIGHT_GREEN};
  &:focus {
    outline: none;
    border-color: ${PHARMACY_GREEN};
    background: white;
  }
`;

const AttachLabel = styled.label`
  display: flex;
  align-items: center;
  padding: 0.5rem 0.8rem;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 40px;
  background: ${LIGHT_GREEN};
  color: #6c757d;
  cursor: pointer;
  font-size: 0.8rem;
  font-weight: 500;
  transition: all 0.2s;
  &:hover {
    background: ${BORDER_GREY};
  }
  input {
    display: none;
  }
`;

const SendButton = styled.button`
  background: ${PHARMACY_GREEN};
  color: white;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  border: none;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s;
  svg {
    width: 18px;
    height: 18px;
  }
  &:hover {
    background: #0a5e2e;
  }
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  @media (min-width: 768px) {
    width: 48px;
    height: 48px;
    svg {
      width: 20px;
      height: 20px;
    }
  }
`;

const ResolvedBanner = styled.div`
  background: ${LIGHT_GREEN};
  padding: 1rem;
  text-align: center;
  border-top: 1px solid ${BORDER_GREY};
  p {
    font-size: 0.8rem;
    font-weight: 500;
    color: #6c757d;
  }
`;

// --- MODAL COMPONENTS (UserIdModal, RequestModal) ---
const UserIdModal = ({ isOpen, onSave }) => {
  const [value, setValue] = useState('');
  useEffect(() => {
    if (!isOpen) setValue('');
  }, [isOpen]);
  if (!isOpen) return null;
  const save = (e) => {
    e.preventDefault();
    const trimmed = (value || '').trim();
    if (!trimmed) return;
    localStorage.setItem('user_id', trimmed);
    onSave(trimmed);
  };
  return (
    <ModalBackdrop>
      <ModalContent as="form" onSubmit={save}>
        <ModalTitle style={{ fontSize: '1.25rem' }}>Enter Your User ID</ModalTitle>
        <p style={{ color: '#6c757d', fontSize: '0.85rem', marginBottom: '1rem' }}>
          Your user_id is required to fetch and create support requests.
        </p>
        <FormGroup>
          <StyledInput
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="user_id (UUID)"
            autoFocus
          />
        </FormGroup>
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <PrimaryButton type="submit" style={{ width: 'auto', padding: '0.5rem 1.5rem' }}>Save</PrimaryButton>
        </div>
      </ModalContent>
    </ModalBackdrop>
  );
};

const RequestModal = ({ isOpen, onClose, onSubmit, loading }) => {
  const [requestType, setRequestType] = useState('technical_issue');
  const [problemDescription, setProblemDescription] = useState('');
  useEffect(() => {
    if (!isOpen) {
      setRequestType('technical_issue');
      setProblemDescription('');
    }
  }, [isOpen]);
  if (!isOpen) return null;
  const handleSubmit = (e) => {
    e.preventDefault();
    if (problemDescription.trim()) {
      onSubmit({
        request_type: requestType,
        title: problemDescription.slice(0, 120),
        description: problemDescription,
        priority: 2,
      });
    }
  };
  return (
    <ModalBackdrop>
      <ModalContent as="form" onSubmit={handleSubmit}>
        <ModalCloseButton onClick={onClose} aria-label="close">
          <X />
        </ModalCloseButton>
        <ModalTitle>New Support Request</ModalTitle>
        <FormGroup>
          <FormLabel htmlFor="requestType">Issue Type</FormLabel>
          <StyledSelect id="requestType" value={requestType} onChange={(e) => setRequestType(e.target.value)}>
            <option value="technical_issue">Technical Issue</option>
            <option value="payment_issue">Payment Issue</option>
            <option value="other">Other Issue</option>
          </StyledSelect>
        </FormGroup>
        <FormGroup>
          <FormLabel htmlFor="problemDescription">Describe your problem</FormLabel>
          <StyledTextArea
            id="problemDescription"
            rows="4"
            value={problemDescription}
            onChange={(e) => setProblemDescription(e.target.value)}
            placeholder="Please provide details about your issue..."
          />
        </FormGroup>
        <PrimaryButton type="submit" disabled={!problemDescription.trim() || loading}>
          {loading ? 'Creating...' : 'Start Chat Request'}
        </PrimaryButton>
      </ModalContent>
    </ModalBackdrop>
  );
};

// --- CHAT WINDOW COMPONENT (improved styling, logic unchanged) ---
const ChatWindow = ({ chat, onClose, onSendMessage, sending, userId }) => {
  const [newMessage, setNewMessage] = useState('');
  const [file, setFile] = useState(null);
  const messagesEndRef = useRef(null);
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);
  useEffect(() => {
    if (chat?.messages) scrollToBottom();
  }, [chat, scrollToBottom]);
  useEffect(() => {
    if (!chat) {
      setNewMessage('');
      setFile(null);
    }
  }, [chat]);
  if (!chat) return null;
  const handleSend = (e) => {
    e.preventDefault();
    if (!newMessage.trim() && !file) return;
    onSendMessage(chat.id, newMessage.trim(), file);
    setNewMessage('');
    setFile(null);
  };
  return (
    <ChatWindowContainer>
      <ChatHeader>
        <div>
          <ChatHeaderTitle>{chat.title || 'Support Chat'}</ChatHeaderTitle>
          <div style={{ marginTop: '4px' }}><StatusBadge status={chat.status} /></div>
        </div>
        <ModalCloseButton onClick={onClose} aria-label="close chat">
          <X />
        </ModalCloseButton>
      </ChatHeader>
      <MessageList>
        {chat.messages.length === 0 && (
          <EmptyState style={{ padding: '1rem' }}>No messages yet — start the conversation.</EmptyState>
        )}
        {chat.messages.map((msg) => (
          <MessageRow key={msg.id} isUser={msg.sender_id === userId}>
            <MessageBubble isUser={msg.sender_id === userId}>
              {msg.message_type === 'text' ? (
                <p>{msg.message}</p>
              ) : (
                <div>
                  <p style={{ fontWeight: 500 }}>{msg.message}</p>
                  {msg.attachments && msg.attachments.length > 0 && msg.attachments.map(a => (
                    <a key={a.id} href={a.url} target="_blank" rel="noopener noreferrer">
                      {a.file_name || 'Attachment'}
                    </a>
                  ))}
                </div>
              )}
              <MessageTimestamp isUser={msg.sender_id === userId}>
                {msg.sender_role === 'system' ? 'System' : 'Support'} • {new Date(msg.created_at || msg.timestamp).toLocaleString()}
              </MessageTimestamp>
            </MessageBubble>
          </MessageRow>
        ))}
        <div ref={messagesEndRef} />
      </MessageList>
      {chat.status !== 'resolved' ? (
        <ChatForm onSubmit={handleSend}>
          <InputRow>
            <ChatInput
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
            />
            <AttachLabel>
              <input type="file" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
              <span>{file ? '📎' : 'Attach'}</span>
            </AttachLabel>
            <SendButton type="submit" disabled={sending}>
              {sending ? <LoaderIcon style={{ width: '18px', height: '18px' }} /> : <Send />}
            </SendButton>
          </InputRow>
          {file && <span style={{ fontSize: '0.7rem', color: '#6c757d', marginLeft: '0.5rem', display: 'block', marginTop: '0.5rem' }}>{file.name}</span>}
        </ChatForm>
      ) : (
        <ResolvedBanner>
          <p>This chat has been resolved.</p>
        </ResolvedBanner>
      )}
    </ChatWindowContainer>
  );
};

// --- MAIN APP COMPONENT (logic untouched, only UI and responsive improvements) ---
function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeChatId, setActiveChatId] = useState(null);
  const [filter, setFilter] = useState('all');
  const [chats, setChats] = useState([]);
  const [loadingChats, setLoadingChats] = useState(false);
  const [creating, setCreating] = useState(false);
  const [sending, setSending] = useState(false);
  const [activeChatDetail, setActiveChatDetail] = useState(null);
  const [error, setError] = useState(null);
  const [userId, setUserId] = useState(null);
  const [needUserIdModal, setNeedUserIdModal] = useState(false);
  const pollRef = useRef(null);

  useEffect(() => {
    const uid = localStorage.getItem('user_id');
    if (uid) setUserId(uid);
    else setNeedUserIdModal(true);
  }, []);

  const fetchRequests = useCallback(async (currentFilter = filter, uid = userId) => {
    if (!uid) {
      setNeedUserIdModal(true);
      return;
    }
    setLoadingChats(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (currentFilter && currentFilter !== 'all') params.append('status', currentFilter);
      params.append('user_id', uid);
      const res = await fetch(`${BASE_URL}/support/requests?${params.toString()}`, {
        headers: { "Content-Type": "application/json" }
      });
      if (!res.ok) throw new Error(`Failed to load requests (${res.status})`);
      const data = await res.json();
      const normalized = (data.items || []).map(it => ({
        id: it.id,
        title: it.title || '',
        type: it.request_type || 'support',
        problem: it.last_message || it.description || '',
        status: it.status || 'pending',
      }));
      setChats(normalized);
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to load requests");
    } finally {
      setLoadingChats(false);
    }
  }, [filter, userId]);

  const handleUserIdSave = (uid) => {
    setUserId(uid);
    setNeedUserIdModal(false);
    fetchRequests(filter, uid);
  };

  useEffect(() => {
    if (userId) fetchRequests(filter, userId);
  }, [fetchRequests, filter, userId]);

  const fetchRequestDetail = useCallback(async (requestId) => {
    if (!requestId) {
      setActiveChatDetail(null);
      return;
    }
    if (!userId) {
      setNeedUserIdModal(true);
      return;
    }
    setError(null);
    try {
      const res = await fetch(`${BASE_URL}/support/requests/${requestId}?role=user&limit=100`, {
        headers: { "Content-Type": "application/json" }
      });
      if (!res.ok) throw new Error(`Failed to load chat (${res.status})`);
      const data = await res.json();
      const messages = (data.messages || []).map(m => ({
        id: m.id,
        message: m.message,
        message_type: m.message_type,
        attachments: m.attachments || [],
        sender_id: m.sender_id,
        sender_role: m.sender_role,
        created_at: m.created_at,
      }));
      setActiveChatDetail({
        id: data.id,
        title: data.title || data.request_type || 'Support',
        status: data.status,
        messages,
      });
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to load chat");
    }
  }, [userId]);

  useEffect(() => {
    if (!activeChatId) {
      setActiveChatDetail(null);
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
      return;
    }
    fetchRequestDetail(activeChatId);
    if (!pollRef.current) {
      pollRef.current = setInterval(() => {
        fetchRequestDetail(activeChatId);
        fetchRequests(filter, userId);
      }, 4000);
    }
    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [activeChatId, fetchRequestDetail, fetchRequests, filter, userId]);

  const handleCreateRequest = async (payload) => {
    if (!userId) {
      setNeedUserIdModal(true);
      return;
    }
    setCreating(true);
    setError(null);
    try {
      const body = { ...payload, user_id: userId };
      const res = await fetch(`${BASE_URL}/support/requests`, {
        method: 'POST',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const errBody = await res.json().catch(() => null);
        throw new Error(errBody?.error || JSON.stringify(errBody) || `Create failed (${res.status})`);
      }
      const data = await res.json();
      await fetchRequests(filter, userId);
      setActiveChatId(data.id);
      setIsModalOpen(false);
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to create request");
    } finally {
      setCreating(false);
    }
  };

  const handleSendMessage = async (requestId, text, file) => {
    if (!userId) {
      setNeedUserIdModal(true);
      return;
    }
    if (!requestId) return;
    setSending(true);
    setError(null);
    try {
      if (file) {
        const form = new FormData();
        form.append('sender_id', userId);
        form.append('sender_role', 'user');
        form.append('message', text || file.name);
        form.append('file', file);
        const res = await fetch(`${BASE_URL}/support/requests/${requestId}/messages`, {
          method: 'POST',
          body: form
        });
        if (!res.ok) {
          const errBody = await res.json().catch(() => null);
          throw new Error(errBody?.error || `Send failed (${res.status})`);
        }
        await fetchRequestDetail(requestId);
        await fetchRequests(filter, userId);
      } else {
        const body = {
          request_id: requestId,
          sender_id: userId,
          sender_role: "user",
          message: text,
          message_type: "text",
          is_internal: false
        };
        const res = await fetch(`${BASE_URL}/support/requests/${requestId}/messages`, {
          method: 'POST',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
        if (!res.ok) {
          const errBody = await res.json().catch(() => null);
          throw new Error(errBody?.error || `Send failed (${res.status})`);
        }
        await fetchRequestDetail(requestId);
        await fetchRequests(filter, userId);
      }
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to send message");
    } finally {
      setSending(false);
    }
  };

  const closeChat = () => {
    setActiveChatId(null);
    setActiveChatDetail(null);
  };

  const openChat = (chat) => {
    if (!userId) {
      setNeedUserIdModal(true);
      return;
    }
    setActiveChatId(chat.id);
  };

  const getRequestTypeName = (type) => {
    switch(type) {
      case 'technical_issue': return 'Technical Issue';
      case 'payment_issue': return 'Payment Issue';
      case 'other': return 'Other Issue';
      default: return 'Support Chat';
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <GlobalStyle />
      <AppWrapper>
        <MainContainer>
          <Title>My Support Tickets</Title>
          <Subtitle>View and manage your support requests with our team.</Subtitle>

          {error && (
            <ErrorBanner>
              <strong>Error</strong>
              <div>{error}</div>
            </ErrorBanner>
          )}

          <FilterTabsContainer>
            {['all', 'pending', 'in_progress', 'resolved'].map(tab => (
              <FilterTab
                key={tab}
                onClick={() => setFilter(tab)}
                active={filter === tab}
              >
                {tab.replace('_', ' ')}
              </FilterTab>
            ))}
          </FilterTabsContainer>

          <ChatList>
            {loadingChats ? (
              <LoadingContainer>Loading...</LoadingContainer>
            ) : (
              <>
                {chats.length > 0 ? (
                  chats.map(chat => (
                    <ChatListItem key={chat.id} onClick={() => openChat(chat)}>
                      <ChatInfo>
                        <ChatTitle>{getRequestTypeName(chat.type)}</ChatTitle>
                        <ChatSnippet>{chat.problem}</ChatSnippet>
                      </ChatInfo>
                      <StatusContainer>
                        <StatusBadge status={chat.status} />
                      </StatusContainer>
                    </ChatListItem>
                  ))
                ) : (
                  <EmptyState>
                    <p>No chats found for this filter.</p>
                  </EmptyState>
                )}
              </>
            )}
          </ChatList>
        </MainContainer>

        {!activeChatId && (
          <HelpButton onClick={() => setIsModalOpen(true)} aria-label="Open support request modal">
            <HelpCircle />
          </HelpButton>
        )}

        <UserIdModal isOpen={needUserIdModal} onSave={handleUserIdSave} />
        <RequestModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSubmit={handleCreateRequest}
          loading={creating}
        />

        {activeChatDetail && (
          <ChatWindow
            chat={activeChatDetail}
            onClose={closeChat}
            onSendMessage={handleSendMessage}
            sending={sending}
            userId={userId}
          />
        )}
      </AppWrapper>
    </ThemeProvider>
  );
}

export default App;