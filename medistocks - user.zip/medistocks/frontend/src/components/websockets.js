import { io } from "socket.io-client";

const webSocketUrl = "https://novelskidev.online"; // Base domain
const socket = io(webSocketUrl, {
  path: "/medistocks_user/socket.io", // This must match the Nginx and Flask-SocketIO path
  transports: ["websocket"],          // Force WebSocket transport to avoid polling errors
  withCredentials: true               // If using cookies/session auth
});

socket.on("connect", () => {
  console.log("Socket connected with id:", socket.id);
});

socket.on("disconnect", () => {
  console.log("Socket disconnected");
});

// Example to emit a message
// socket.emit("send_message", { user_id: 13, message: "Hello" });
