import React, { useState, useEffect, useMemo } from 'react';
import styled, { keyframes } from 'styled-components';
import { FaPlus, FaSearch, FaEdit, FaTrash, FaTimes, FaSpinner } from 'react-icons/fa';
import BaseUrl from './BaseUrl';

const fadeUp = keyframes`from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}`;
const spin   = keyframes`to{transform:rotate(360deg)}`;
const ACCENT = '#10b981';

const fmtDate = d => d ? new Date(d).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}) : 'N/A';
const fmtForInput = d => { if(!d) return ''; return new Date(d).toISOString().split('T')[0]; };
const getStatus = exp => {
  const days = Math.ceil((new Date(exp)-new Date())/(1000*60*60*24));
  if(days<0) return 'Expired'; if(days<=30) return 'Expiring Soon'; return 'Active';
};

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 18px;`;

const TopBar = styled.div`display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap;`;
const SearchWrap = styled.div`display:flex;align-items:center;gap:7px;background:#fff;border:1.5px solid #e5e7eb;border-radius:9px;padding:8px 13px;flex:1;max-width:300px;
  input{background:none;border:none;outline:none;font-family:'Plus Jakarta Sans',sans-serif;font-size:.84rem;color:#374151;width:100%;}
  input::placeholder{color:#d1d5db;}
  &:focus-within{border-color:${ACCENT};box-shadow:0 0 0 3px rgba(16,185,129,.1);}
`;

const FilterRow = styled.div`display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px;`;
const Chip = styled.button`
  padding:6px 14px;border-radius:8px;border:1.5px solid ${p=>p.$active?ACCENT:'#e5e7eb'};
  background:${p=>p.$active?'rgba(16,185,129,.08)':'#fff'};
  color:${p=>p.$active?ACCENT:'#6b7280'};font-family:'Plus Jakarta Sans',sans-serif;
  font-size:.8rem;font-weight:${p=>p.$active?700:500};cursor:pointer;transition:all .15s;
  &:hover{border-color:${ACCENT};}
`;

const PrimaryBtn = styled.button`
  display:inline-flex;align-items:center;gap:7px;padding:9px 18px;
  background:linear-gradient(135deg,${ACCENT},#0ea5e9);border:none;border-radius:9px;color:#fff;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.84rem;font-weight:700;cursor:pointer;
  transition:all .2s;box-shadow:0 4px 12px rgba(16,185,129,.22);
  &:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 18px rgba(16,185,129,.3);}
  &:disabled{opacity:.45;cursor:not-allowed;transform:none;}
`;

const Grid = styled.div`display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;@media(max-width:480px){grid-template-columns:1fr;}`;

const Card = styled.div`
  background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;padding:16px;
  box-shadow:0 1px 4px rgba(0,0,0,.04);cursor:pointer;
  transition:transform .2s,box-shadow .2s,border-color .2s;
  animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*50}ms;
  &:hover{transform:translateY(-3px);box-shadow:0 10px 24px rgba(0,0,0,.08);border-color:#e0e0e0;}
`;
const CardTop = styled.div`display:flex;gap:14px;align-items:flex-start;margin-bottom:14px;`;
const ProdImg = styled.img`width:72px;height:72px;border-radius:10px;object-fit:cover;flex-shrink:0;border:1px solid #f0f0f0;`;
const ProdInfo= styled.div`flex:1;min-width:0;`;
const ProdName= styled.div`font-weight:700;font-size:.9rem;color:#111827;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;`;
const ProdBrand=styled.div`font-size:.76rem;color:#9ca3af;margin-bottom:6px;`;
const StatusBadge = styled.span`
  display:inline-flex;font-size:.67rem;font-weight:700;text-transform:uppercase;letter-spacing:.4px;
  padding:3px 8px;border-radius:5px;
  background:${p=>p.$s==='Active'?'#f0fdf9':p.$s==='Expiring Soon'?'#fffbeb':'#fef2f2'};
  color:${p=>p.$s==='Active'?'#059669':p.$s==='Expiring Soon'?'#d97706':'#ef4444'};
  border:1px solid ${p=>p.$s==='Active'?'#a7f3d0':p.$s==='Expiring Soon'?'#fde68a':'#fecaca'};
`;
const CardFoot= styled.div`display:flex;justify-content:space-between;align-items:center;border-top:1px solid #f5f5f5;padding-top:12px;`;
const Price   = styled.div`font-size:1rem;font-weight:800;color:${ACCENT};`;
const IconBtns= styled.div`display:flex;gap:6px;`;
const IconBtn = styled.button`
  width:32px;height:32px;border-radius:8px;border:1.5px solid #f0f0f0;background:#fff;
  display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:.8rem;
  transition:all .15s;color:#6b7280;
  &:hover{background:${p=>p.$danger?'#fef2f2':'#f0fdf9'};color:${p=>p.$danger?'#ef4444':ACCENT};border-color:${p=>p.$danger?'#fecaca':'#a7f3d0'};}
`;

const SpinWrap = styled.div`display:flex;justify-content:center;padding:60px;`;
const Spin     = styled.div`width:32px;height:32px;border-radius:50%;border:3px solid #e5e7eb;border-top-color:${ACCENT};animation:${spin} .8s linear infinite;`;
const SpinIcon = styled(FaSpinner)`animation:${spin} 1s linear infinite;`;

/* Modal */
const ModalBg  = styled.div`position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(4px);display:flex;justify-content:center;align-items:center;z-index:1050;padding:16px;`;
const ModalBox = styled.div`background:#fff;border-radius:16px;padding:24px;width:100%;max-width:${p=>p.$sm?'400px':'580px'};max-height:90vh;overflow-y:auto;box-shadow:0 20px 40px rgba(0,0,0,.1);`;
const ModalHead= styled.div`display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;border-bottom:1px solid #f5f5f5;padding-bottom:14px;`;
const ModalTitle=styled.div`font-weight:700;font-size:1rem;color:#111827;`;
const CloseBtn = styled.button`background:none;border:none;cursor:pointer;color:#9ca3af;padding:4px;border-radius:6px;&:hover{background:#f5f5f5;color:#374151;}`;

const FormGrid = styled.div`display:grid;grid-template-columns:1fr 1fr;gap:12px;@media(max-width:480px){grid-template-columns:1fr;}`;
const Label    = styled.label`font-size:.72rem;text-transform:uppercase;letter-spacing:.5px;color:#9ca3af;font-weight:600;margin-bottom:4px;display:block;`;
const Input    = styled.input`width:100%;background:#f9fafb;border:1.5px solid #e5e7eb;border-radius:9px;padding:10px 12px;color:#111827;font-family:'Plus Jakarta Sans',sans-serif;font-size:.875rem;outline:none;box-sizing:border-box;
  &:focus{border-color:${ACCENT};background:#fff;box-shadow:0 0 0 3px rgba(16,185,129,.1);}`;
const Field    = styled.div`display:flex;flex-direction:column;`;
const ModalBtns= styled.div`display:flex;justify-content:flex-end;gap:10px;margin-top:18px;`;
const SecBtn   = styled.button`padding:9px 18px;background:#fff;border:1.5px solid #e5e7eb;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:.84rem;font-weight:600;color:#374151;cursor:pointer;transition:all .15s;&:hover{background:#f9fafb;}`;
const DangerBtn= styled.button`padding:9px 18px;background:#fef2f2;border:1.5px solid #fecaca;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:.84rem;font-weight:700;color:#ef4444;cursor:pointer;`;

const MyProducts = ({ onAddProduct }) => {
  const [products, setProducts] = useState([]);
  const [filter, setFilter]     = useState('All');
  const [search, setSearch]     = useState('');
  const [loading, setLoading]   = useState(true);
  const [selected, setSelected] = useState(null);
  const [toUpdate, setToUpdate] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  const [saving, setSaving]     = useState(false);
  const [form, setForm]         = useState({});

  useEffect(() => {
    (async () => {
      const uid = parseInt(localStorage.getItem('user_id'), 10);
      if (!uid) { setLoading(false); return; }
      try {
        const res = await fetch(`${BaseUrl}/products/user/${uid}`);
        const d   = await res.json();
        setProducts((d.data || []).map(p => ({...p, status: p.expiry_date ? getStatus(p.expiry_date) : 'Unknown'})));
      } catch {}
      finally { setLoading(false); }
    })();
  }, []);

  const filtered = useMemo(() =>
    products.filter(p =>
      (filter==='All'||p.status===filter) &&
      p.tablet_name.toLowerCase().includes(search.toLowerCase())
    ), [products, filter, search]);

  const openUpdate = (p, e) => { e.stopPropagation(); setForm({ tablet_name:p.tablet_name, brand:p.brand, quantity:p.quantity, original_price:p.original_price, discount:p.discount, expiry_date:fmtForInput(p.expiry_date) }); setToUpdate(p); };

  const saveUpdate = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${BaseUrl}/products/item/${toUpdate.id}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...form, user_id:localStorage.getItem('user_id'), quantity:parseInt(form.quantity), original_price:parseFloat(form.original_price), discount:parseFloat(form.discount)}) });
      const d   = await res.json();
      if(!res.ok) throw new Error(d.error||'Update failed');
      const updated = {...d.product, status:getStatus(d.product.expiry_date)};
      setProducts(products.map(p => p.id===updated.id ? updated : p));
      setToUpdate(null);
    } catch(e) { alert(e.message); }
    finally { setSaving(false); }
  };

  const doDelete = async () => {
    try {
      const res = await fetch(`${BaseUrl}/products/item/${toDelete.id}`, { method:'DELETE', headers:{'Content-Type':'application/json'}, body:JSON.stringify({user_id:localStorage.getItem('user_id')}) });
      const d   = await res.json();
      if(!res.ok) throw new Error(d.error||'Delete failed');
      setProducts(products.filter(p=>p.id!==toDelete.id));
      setToDelete(null);
    } catch(e) { alert(e.message); }
  };

  const cnt = s => s==='All' ? products.length : products.filter(p=>p.status===s).length;

  return (
    <Page>
      <TopBar>
        <div>
          <PageTitle>My <em>Products</em></PageTitle>
          <PageSub>Manage your listed pharmaceutical inventory.</PageSub>
        </div>
        <PrimaryBtn onClick={onAddProduct}><FaPlus size={12}/> Add Product</PrimaryBtn>
      </TopBar>

      <TopBar style={{marginBottom:0}}>
        <SearchWrap>
          <FaSearch size={12} style={{color:'#9ca3af',flexShrink:0}}/>
          <input placeholder="Search products…" value={search} onChange={e=>setSearch(e.target.value)}/>
        </SearchWrap>
      </TopBar>

      <FilterRow style={{marginTop:12}}>
        {['All','Active','Expiring Soon','Expired'].map(f=>(
          <Chip key={f} $active={filter===f} onClick={()=>setFilter(f)}>{f} ({cnt(f)})</Chip>
        ))}
      </FilterRow>

      {loading && <SpinWrap><Spin/></SpinWrap>}

      {!loading && filtered.length===0 && (
        <div style={{background:'#fff',border:'1.5px dashed #e5e7eb',borderRadius:14,padding:'48px 24px',textAlign:'center'}}>
          <div style={{fontSize:'2rem',opacity:.4,marginBottom:10}}>📦</div>
          <p style={{color:'#9ca3af',fontSize:'.86rem'}}>No products found{search?` matching "${search}"`:''}.</p>
        </div>
      )}

      <Grid>
        {filtered.map((p, i) => (
          <Card key={p.id} $i={i} onClick={()=>setSelected(p)}>
            <CardTop>
              <ProdImg src={p.image_url||'https://placehold.co/72x72/f5f7fa/9ca3af?text=Img'} alt={p.tablet_name} onError={e=>{e.target.src='https://placehold.co/72x72/f5f7fa/9ca3af?text=Img';}}/>
              <ProdInfo>
                <ProdName title={p.tablet_name}>{p.tablet_name}</ProdName>
                <ProdBrand>{p.brand||'Generic'}</ProdBrand>
                <StatusBadge $s={p.status}>{p.status}</StatusBadge>
              </ProdInfo>
            </CardTop>
            <CardFoot>
              <Price>₹{(p.original_price*(1-(p.discount||0)/100)).toFixed(2)}</Price>
              <IconBtns>
                <IconBtn onClick={e=>openUpdate(p,e)} title="Edit"><FaEdit size={11}/></IconBtn>
                <IconBtn $danger onClick={e=>{e.stopPropagation();setToDelete(p);}} title="Delete"><FaTrash size={11}/></IconBtn>
              </IconBtns>
            </CardFoot>
          </Card>
        ))}
      </Grid>

      {/* Detail modal */}
      {selected && (
        <ModalBg onClick={()=>setSelected(null)}>
          <ModalBox onClick={e=>e.stopPropagation()}>
            <ModalHead>
              <ModalTitle>{selected.tablet_name}</ModalTitle>
              <CloseBtn onClick={()=>setSelected(null)}><FaTimes size={14}/></CloseBtn>
            </ModalHead>
            <FormGrid>
              <Field><Label>Brand</Label><div style={{fontSize:'.875rem',color:'#374151'}}>{selected.brand||'—'}</div></Field>
              <Field><Label>Quantity</Label><div style={{fontSize:'.875rem',color:'#374151'}}>{selected.quantity} {selected.unit_type}</div></Field>
              <Field><Label>Batch No.</Label><div style={{fontSize:'.875rem',color:'#374151'}}>{selected.batch_number||'—'}</div></Field>
              <Field><Label>Discount</Label><div style={{fontSize:'.875rem',color:'#374151'}}>{selected.discount||0}%</div></Field>
              <Field><Label>Mfg. Date</Label><div style={{fontSize:'.875rem',color:'#374151'}}>{fmtDate(selected.manufacturing_date)}</div></Field>
              <Field><Label>Expiry Date</Label><div style={{fontSize:'.875rem',color:'#374151'}}>{fmtDate(selected.expiry_date)}</div></Field>
            </FormGrid>
            {selected.usage_instructions && <div style={{marginTop:14}}><Label>Usage</Label><p style={{fontSize:'.86rem',color:'#6b7280',margin:0}}>{selected.usage_instructions}</p></div>}
          </ModalBox>
        </ModalBg>
      )}

      {/* Update modal */}
      {toUpdate && (
        <ModalBg onClick={()=>setToUpdate(null)}>
          <ModalBox onClick={e=>e.stopPropagation()}>
            <ModalHead>
              <ModalTitle>Update Product</ModalTitle>
              <CloseBtn onClick={()=>setToUpdate(null)}><FaTimes size={14}/></CloseBtn>
            </ModalHead>
            <FormGrid>
              <Field style={{gridColumn:'1/-1'}}><Label>Tablet Name</Label><Input value={form.tablet_name} onChange={e=>setForm({...form,tablet_name:e.target.value})}/></Field>
              <Field><Label>Brand</Label><Input value={form.brand} onChange={e=>setForm({...form,brand:e.target.value})}/></Field>
              <Field><Label>Quantity</Label><Input type="number" value={form.quantity} onChange={e=>setForm({...form,quantity:e.target.value})}/></Field>
              <Field><Label>Price (₹)</Label><Input type="number" value={form.original_price} onChange={e=>setForm({...form,original_price:e.target.value})}/></Field>
              <Field><Label>Discount (%)</Label><Input type="number" value={form.discount} onChange={e=>setForm({...form,discount:e.target.value})}/></Field>
              <Field style={{gridColumn:'1/-1'}}><Label>Expiry Date</Label><Input type="date" value={form.expiry_date} onChange={e=>setForm({...form,expiry_date:e.target.value})}/></Field>
            </FormGrid>
            <ModalBtns>
              <SecBtn onClick={()=>setToUpdate(null)}>Cancel</SecBtn>
              <PrimaryBtn onClick={saveUpdate} disabled={saving}>{saving&&<SpinIcon size={12}/>} Save Changes</PrimaryBtn>
            </ModalBtns>
          </ModalBox>
        </ModalBg>
      )}

      {/* Delete confirm */}
      {toDelete && (
        <ModalBg onClick={()=>setToDelete(null)}>
          <ModalBox $sm onClick={e=>e.stopPropagation()}>
            <ModalTitle style={{marginBottom:10}}>Delete Product?</ModalTitle>
            <p style={{color:'#6b7280',fontSize:'.86rem',margin:'0 0 20px'}}>Are you sure you want to delete "<strong>{toDelete.tablet_name}</strong>"? This cannot be undone.</p>
            <ModalBtns>
              <SecBtn onClick={()=>setToDelete(null)}>Cancel</SecBtn>
              <DangerBtn onClick={doDelete}>Delete</DangerBtn>
            </ModalBtns>
          </ModalBox>
        </ModalBg>
      )}
    </Page>
  );
};

export default MyProducts;