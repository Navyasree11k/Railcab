import React, { useState, useEffect, useRef } from 'react';
import styled, { createGlobalStyle } from 'styled-components';
import { FiEdit2, FiCamera, FiPhone, FiMail, FiFileText, FiCheckCircle } from 'react-icons/fi';
import BaseUrl from './BaseUrl';

// --- Global Styles & Theming ---
const GlobalStyle = createGlobalStyle`
  body {
    background-color: #f0f4f8;
    background-image: radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.05) 0px, transparent 50%), 
                      radial-gradient(at 100% 0%, rgba(16, 185, 129, 0.05) 0px, transparent 50%);
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    min-height: 100vh;
  }
`;

// --- Styled Components ---
const ProfileWrapper = styled.div`
  padding: 1.5rem 1rem;
  max-width: 1100px;
  margin: auto;

  @media (min-width: 768px) {
    padding: 3rem 2rem;
  }
`;

const GlassmorphismCard = styled.div`
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 1);
  border-radius: 1.25rem;
  padding: 1.5rem;
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
  height: 100%;
  transition: transform 0.2s ease;

  &:hover {
    transform: translateY(-2px);
  }
`;

const ProfileHeader = styled(GlassmorphismCard)`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 2.5rem 1.5rem;
`;

const AvatarContainer = styled.div`
  position: relative;
  cursor: pointer;
  margin-bottom: 1.5rem;
  
  &:hover > div {
    opacity: 1;
  }
`;

const ProfileAvatar = styled.img`
  width: 130px;
  height: 130px;
  border-radius: 50%;
  border: 5px solid #ffffff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.1);
  object-fit: cover;
`;

const AvatarOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: rgba(99, 102, 241, 0.8);
  color: white;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: all 0.3s ease;
`;

const InfoRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  padding: 1rem 0;
  border-bottom: 1px solid #f1f5f9;

  &:last-child {
    border-bottom: none;
  }
`;

const EditButton = styled.button`
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  color: #6366f1;
  cursor: pointer;
  padding: 0.6rem;
  border-radius: 0.75rem;
  display: flex;
  transition: all 0.2s ease;
  
  &:hover {
    background: #6366f1;
    color: white;
    border-color: #6366f1;
  }
`;

const DocumentItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #ffffff;
  padding: 1rem 1.25rem;
  border: 1px solid #e2e8f0;
  border-radius: 1rem;
  margin-bottom: 0.75rem;
  
  svg {
    color: #6366f1;
    margin-right: 10px;
  }
`;

// --- Main Profile Component ---
const Profile = () => {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isEditProfileModalOpen, setEditProfileModalOpen] = useState(false);
  const [isEditContactModalOpen, setEditContactModalOpen] = useState(false);
  const [editName, setEditName] = useState('');
  const [editProfilePic, setEditProfilePic] = useState(null);
  const [contactType, setContactType] = useState(''); 
  const [newContactValue, setNewContactValue] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [isEditBusinessModalOpen, setEditBusinessModalOpen] = useState(false);
  const [businessData, setBusinessData] = useState({
    shop_name: '',
    gst_in_number: '',
    shop_address: '',
    city_name: '',
    pin_code: '',
  });

  const fileInputRef = useRef(null);

  useEffect(() => {
    const fetchUserData = async () => {
      const userId = localStorage.getItem('user_id');
      if (!userId) {
        setError("User not logged in. Please log in again.");
        setLoading(false);
        return;
      }
      try {
        setLoading(true);
        const response = await fetch(`${BaseUrl}/auth/get-user/${userId}`);
        const result = await response.json();
        if (response.ok && result.status === 'success') {
          setUserData(result.data);
          setEditName(result.data.user_name);
          setBusinessData({
            shop_name: result.data.shop_name || '',
            gst_in_number: result.data.gst_in_number || '',
            shop_address: result.data.shop_address || '',
            city_name: result.data.city_name || '',
            pin_code: result.data.pin_code || '',
          });
        } else {
          throw new Error(result.message || "Failed to fetch user data.");
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUserData();
  }, []);

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    const userId = localStorage.getItem('user_id');
    setLoading(true);
    const formData = new FormData();
    if (editName !== userData.user_name) formData.append('user_name', editName);
    if (editProfilePic) formData.append('profile_pic', editProfilePic);

    try {
      const response = await fetch(`${BaseUrl}/auth/update-user/${userId}`, {
        method: 'PUT',
        body: formData,
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Update failed");
      setUserData(prev => ({ ...prev, ...result.data }));
      setEditProfileModalOpen(false);
      setEditProfilePic(null);
      window.location.reload(); 
    } catch (err) {
      setError(err.message);
    }
  };

  const handleSaveBusiness = async (e) => {
    e.preventDefault();
    const userId = localStorage.getItem('user_id');
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${BaseUrl}/auth/update-user-details`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId, ...businessData })
      });
      const result = await response.json();
      if (result.status !== 'success') throw new Error(result.message);
      setUserData(prev => ({ ...prev, ...businessData }));
      setEditBusinessModalOpen(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSendUpdateOtp = async () => {
    const userId = localStorage.getItem('user_id');
    setLoading(true);
    setError('');
    const payload = {
        user_id: userId,
        [contactType === 'mobile' ? 'mobile_number' : 'email_address']: newContactValue
    };
    try {
        const response = await fetch(`${BaseUrl}/auth/update_contact/send_otp`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        setOtpSent(true);
    } catch (err) {
        setError(err.message);
    } finally {
        setLoading(false);
    }
  };

  const handleVerifyUpdateOtp = async () => {
    const userId = localStorage.getItem('user_id');
    setLoading(true);
    setError('');
    const payload = {
        user_id: userId,
        otp: otp,
        [contactType === 'mobile' ? 'mobile_number' : 'email_address']: newContactValue
    };
    try {
        const response = await fetch(`${BaseUrl}/auth/update_contact/verify_otp`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        setEditContactModalOpen(false);
        resetContactModal();
        window.location.reload(); 
    } catch (err) {
        setError(err.message);
    } finally {
        setLoading(false);
    }
  };

  const openContactModal = (type) => {
    setContactType(type);
    setError('');
    setEditContactModalOpen(true);
  };
  
  const resetContactModal = () => {
    setNewContactValue('');
    setOtp('');
    setOtpSent(false);
    setError('');
  };

  if (loading && !userData) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <div className="spinner-grow text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <>
      <GlobalStyle />
      <ProfileWrapper>
        <div className="row mb-5 align-items-center">
          <div className="col-md-8">
            <h2 className="text-dark fw-bold mb-1">MediStocks Profile</h2>
            <p className="text-muted">Manage your pharmacy credentials and business verification.</p>
          </div>
          <div className="col-md-4 text-md-end">
             <span className="badge bg-success-subtle text-success p-2 px-3 border border-success-subtle">
               <FiCheckCircle className="me-1" /> Active Account
             </span>
          </div>
        </div>

        <div className="row g-4">
          {/* Left: Quick Glance */}
          <div className="col-lg-4">
            <ProfileHeader>
              <AvatarContainer onClick={() => setEditProfileModalOpen(true)}>
                <ProfileAvatar 
                  src={userData?.profile_pic_url || `https://ui-avatars.com/api/?name=${userData?.user_name}&background=6366f1&color=fff`} 
                  alt={userData?.user_name} 
                />
                <AvatarOverlay>
                    <FiCamera size={24} />
                    <small className="mt-1">Update Photo</small>
                </AvatarOverlay>
              </AvatarContainer>
              <h4 className="text-dark fw-bold mb-1">{userData?.user_name}</h4>
              <p className="text-primary fw-medium mb-3">{userData?.shop_name || 'Pharmacist'}</p>
              
              <div className="w-100 mt-2">
                <div className="d-flex align-items-center mb-2 text-muted small">
                   <FiMail className="me-2" /> {userData?.email_address}
                </div>
                <div className="d-flex align-items-center text-muted small">
                   <FiPhone className="me-2" /> {userData?.mobile_number}
                </div>
              </div>
            </ProfileHeader>
          </div>

          {/* Right: Details */}
          <div className="col-lg-8">
            <GlassmorphismCard>
              <h5 className="text-dark fw-bold mb-4">Contact Details</h5>
              {error && <div className="alert alert-danger border-0 small py-2">{error}</div>}

              <InfoRow>
                <div>
                  <label className="text-muted small fw-bold text-uppercase">Full Name</label>
                  <p className="text-dark mb-0 fw-medium">{userData?.user_name}</p>
                </div>
                <EditButton onClick={() => setEditProfileModalOpen(true)}><FiEdit2 size={16} /></EditButton>
              </InfoRow>
              <InfoRow>
                <div>
                  <label className="text-muted small fw-bold text-uppercase">Email Address</label>
                  <p className="text-dark mb-0 fw-medium">{userData?.email_address}</p>
                </div>
                <EditButton onClick={() => openContactModal('email')}><FiMail size={16} /></EditButton>
              </InfoRow>
              <InfoRow>
                <div>
                  <label className="text-muted small fw-bold text-uppercase">Mobile Number</label>
                  <p className="text-dark mb-0 fw-medium">{userData?.mobile_number}</p>
                </div>
                <EditButton onClick={() => openContactModal('mobile')}><FiPhone size={16} /></EditButton>
              </InfoRow>
            </GlassmorphismCard>
          </div>
        
          <div className="col-md-7">
             <GlassmorphismCard>
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h5 className="text-dark fw-bold mb-0">Business Information</h5>
                  <EditButton onClick={() => setEditBusinessModalOpen(true)}><FiEdit2 size={16} /></EditButton>
                </div>
                <div className="row g-4">
                    <div className="col-sm-6">
                        <label className="text-muted small fw-bold text-uppercase">Pharmacy Name</label>
                        <p className="text-dark fw-medium mb-0">{userData?.shop_name || 'N/A'}</p>
                    </div>
                    <div className="col-sm-6">
                        <label className="text-muted small fw-bold text-uppercase">GSTIN</label>
                        <p className="text-dark fw-medium mb-0">{userData?.gst_in_number || 'N/A'}</p>
                    </div>
                    <div className="col-12">
                        <label className="text-muted small fw-bold text-uppercase">Registered Address</label>
                        <p className="text-dark fw-medium mb-0">{`${userData?.shop_address}, ${userData?.city_name} - ${userData?.pin_code}`}</p>
                    </div>
                </div>
            </GlassmorphismCard>
          </div>

          {/* Documents */}
          <div className="col-md-5">
             <GlassmorphismCard>
                <h5 className="text-dark fw-bold mb-4">Verification Documents</h5>
                {userData?.documents && Object.keys(userData.documents).length > 0 ? (
                    Object.entries(userData.documents).map(([key, value]) => value && (
                        <DocumentItem key={key}>
                            <div className="d-flex align-items-center">
                                <FiFileText size={20} />
                                <span className="text-dark small fw-bold text-capitalize">{key.replace(/_/g, ' ')}</span>
                            </div>
                            <a href={value} target="_blank" rel="noopener noreferrer" className="btn btn-sm btn-link text-decoration-none fw-bold">View</a>
                        </DocumentItem>
                    ))
                ) : <p className='text-muted small italic'>No documents uploaded yet.</p>}
            </GlassmorphismCard>
          </div>
        </div>
      </ProfileWrapper>

      {/* --- MODALS --- */}
      {/* Modernized Profile Modal */}
      {isEditProfileModalOpen && (
        <div className="modal show d-block" style={{backgroundColor: 'rgba(15, 23, 42, 0.4)', backdropFilter: 'blur(4px)'}}>
            <div className="modal-dialog modal-dialog-centered">
                <div className="modal-content border-0 shadow-lg" style={{borderRadius: '1.25rem'}}>
                    <div className="modal-header border-0 pb-0">
                        <h5 className="modal-title fw-bold">Edit Profile</h5>
                        <button type="button" className="btn-close" onClick={() => setEditProfileModalOpen(false)}></button>
                    </div>
                    <form onSubmit={handleProfileUpdate}>
                        <div className="modal-body py-4">
                            <div className="mb-3">
                                <label className="form-label small fw-bold">Full Name</label>
                                <input type="text" className="form-control form-control-lg border-light-subtle" value={editName} onChange={(e) => setEditName(e.target.value)} style={{fontSize: '1rem'}} />
                            </div>
                            <div className="mb-3">
                                <label className="form-label small fw-bold">New Profile Picture</label>
                                <input type="file" className="form-control" accept="image/*" onChange={(e) => setEditProfilePic(e.target.files[0])} ref={fileInputRef} />
                            </div>
                            {error && <div className="alert alert-danger small py-2">{error}</div>}
                        </div>
                        <div className="modal-footer border-0 pt-0">
                            <button type="button" className="btn btn-light px-4" onClick={() => setEditProfileModalOpen(false)}>Cancel</button>
                            <button type="submit" className="btn btn-primary px-4 shadow-sm" disabled={loading}>{loading ? 'Saving...' : 'Save Changes'}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      )}

      {/* Contact Modal Logic Remains Same but Styled */}
      {isEditContactModalOpen && (
         <div className="modal show d-block" style={{backgroundColor: 'rgba(15, 23, 42, 0.4)', backdropFilter: 'blur(4px)'}}>
            <div className="modal-dialog modal-dialog-centered">
                <div className="modal-content border-0 shadow-lg" style={{borderRadius: '1.25rem'}}>
                    <div className="modal-header border-0 pb-0">
                        <h5 className="modal-title fw-bold">Update {contactType === 'mobile' ? 'Mobile' : 'Email'}</h5>
                        <button type="button" className="btn-close" onClick={() => { setEditContactModalOpen(false); resetContactModal(); }}></button>
                    </div>
                    <div className="modal-body py-4">
                        {error && <div className="alert alert-danger small py-2">{error}</div>}
                        {!otpSent ? (
                            <div>
                                <label className="form-label small fw-bold">New {contactType === 'mobile' ? 'Mobile Number' : 'Email Address'}</label>
                                <input 
                                    type={contactType === 'mobile' ? 'tel' : 'email'} 
                                    className="form-control form-control-lg" 
                                    value={newContactValue}
                                    onChange={(e) => setNewContactValue(e.target.value)}
                                    placeholder={contactType === 'mobile' ? 'e.g. +91 9876543210' : 'name@pharmacy.com'}
                                />
                                <div className="d-grid mt-4">
                                    <button className="btn btn-primary btn-lg shadow-sm" onClick={handleSendUpdateOtp} disabled={loading || !newContactValue}>
                                        {loading ? 'Sending...' : 'Send Verification OTP'}
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <div className="text-center">
                                <div className="mb-3">
                                    <span className="badge bg-info-subtle text-info p-2 px-3 mb-3">OTP Sent to {newContactValue}</span>
                                    <input type="text" className="form-control form-control-lg text-center fw-bold" placeholder="Enter 6-digit OTP" value={otp} onChange={(e) => setOtp(e.target.value)} maxLength="6" style={{letterSpacing: '4px'}} />
                                </div>
                                <div className="d-grid mt-4">
                                    <button className="btn btn-success btn-lg shadow-sm" onClick={handleVerifyUpdateOtp} disabled={loading || !otp}>
                                        {loading ? 'Verifying...' : 'Verify & Update'}
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
      )}

      {/* Edit Business Modal */}
      {isEditBusinessModalOpen && (
        <div className="modal show d-block" style={{backgroundColor: 'rgba(15, 23, 42, 0.4)', backdropFilter: 'blur(4px)'}}>
            <div className="modal-dialog modal-dialog-centered">
                <div className="modal-content border-0 shadow-lg" style={{borderRadius: '1.25rem'}}>
                    <div className="modal-header border-0 pb-0">
                        <h5 className="modal-title fw-bold">Edit Business Details</h5>
                        <button type="button" className="btn-close" onClick={() => setEditBusinessModalOpen(false)}></button>
                    </div>
                    <form onSubmit={handleSaveBusiness}>
                        <div className="modal-body py-4">
                            <div className="row g-3">
                                <div className="col-md-6">
                                    <label className="form-label small fw-bold">Business Name</label>
                                    <input type="text" className="form-control" value={businessData.shop_name} onChange={e => setBusinessData({...businessData, shop_name: e.target.value})} />
                                </div>
                                <div className="col-md-6">
                                    <label className="form-label small fw-bold">GSTIN</label>
                                    <input type="text" className="form-control" value={businessData.gst_in_number} onChange={e => setBusinessData({...businessData, gst_in_number: e.target.value})} />
                                </div>
                                <div className="col-12">
                                    <label className="form-label small fw-bold">Address</label>
                                    <input type="text" className="form-control" value={businessData.shop_address} onChange={e => setBusinessData({...businessData, shop_address: e.target.value})} />
                                </div>
                                <div className="col-md-6">
                                    <label className="form-label small fw-bold">City</label>
                                    <input type="text" className="form-control" value={businessData.city_name} onChange={e => setBusinessData({...businessData, city_name: e.target.value})} />
                                </div>
                                <div className="col-md-6">
                                    <label className="form-label small fw-bold">Pin Code</label>
                                    <input type="text" className="form-control" value={businessData.pin_code} onChange={e => setBusinessData({...businessData, pin_code: e.target.value})} />
                                </div>
                            </div>
                            {error && <div className="alert alert-danger small py-2 mt-3">{error}</div>}
                        </div>
                        <div className="modal-footer border-0 pt-0">
                            <button type="button" className="btn btn-light px-4" onClick={() => setEditBusinessModalOpen(false)}>Cancel</button>
                            <button type="submit" className="btn btn-primary px-4 shadow-sm" disabled={loading}>{loading ? 'Saving...' : 'Save Details'}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      )}
    </>
  );
};

export default Profile;