import React, { useState } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import { useNavigate } from 'react-router-dom';
import BaseUrl from './BaseUrl';

const GlobalStyle = createGlobalStyle`
  *, *::before, *::after { box-sizing: border-box; }
  body { margin: 0; background: #f5f7fa; font-family: 'Plus Jakarta Sans', sans-serif; }
`;

const fadeUp = keyframes`from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}`;
const spin   = keyframes`from{transform:rotate(0deg)}to{transform:rotate(360deg)}`;

const Page = styled.div`min-height:100vh;padding:32px 16px 56px;display:flex;flex-direction:column;align-items:center;background:#f5f7fa;`;

const TopBar = styled.div`display:flex;align-items:center;gap:10px;margin-bottom:32px;`;
const Mark = styled.div`width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,#10b981,#0ea5e9);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 10px rgba(16,185,129,0.25);`;
const Name = styled.span`font-weight:800;font-size:1.15rem;color:#111827;em{color:#10b981;font-style:normal;}`;

const Wrap = styled.div`width:100%;max-width:600px;animation:${fadeUp} .5s ease;`;

const PageTitle = styled.h2`font-size:1.65rem;font-weight:800;color:#111827;text-align:center;margin:0 0 5px;letter-spacing:-0.4px;`;
const PageSub   = styled.p`text-align:center;color:#9ca3af;font-size:0.87rem;margin:0 0 26px;`;

/* Steps indicator */
const StepRow = styled.div`display:flex;align-items:center;margin-bottom:26px;`;
const Dot = styled.div`
  width:30px;height:30px;border-radius:50%;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  font-weight:700;font-size:0.78rem;transition:all .3s;
  background:${p=>p.$done?'linear-gradient(135deg,#10b981,#0ea5e9)':p.$active?'#fff':'#f3f4f6'};
  border:1.5px solid ${p=>p.$done?'transparent':p.$active?'#10b981':'#e5e7eb'};
  color:${p=>p.$done?'#fff':p.$active?'#10b981':'#9ca3af'};
  box-shadow:${p=>p.$active?'0 0 0 4px rgba(16,185,129,0.1)':'none'};
`;
const Line  = styled.div`flex:1;height:2px;margin:0 7px;background:${p=>p.$done?'linear-gradient(90deg,#10b981,#0ea5e9)':'#e5e7eb'};transition:background .4s;`;
const SLabel = styled.span`font-size:0.7rem;color:${p=>p.$active?'#10b981':'#9ca3af'};font-weight:${p=>p.$active?700:400};margin-left:5px;white-space:nowrap;`;

/* Card */
const Card = styled.div`
  background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;
  padding:22px;margin-bottom:14px;
  opacity:${p=>p.$dim?0.45:1};pointer-events:${p=>p.$dim?'none':'auto'};
  transition:all .25s;box-shadow:0 1px 4px rgba(0,0,0,0.04);
`;
const CardHead = styled.div`display:flex;align-items:center;gap:12px;margin-bottom:${p=>p.$nm?0:18}px;`;
const Badge    = styled.div`width:36px;height:36px;border-radius:9px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:0.95rem;background:${p=>p.$done?'#f0fdf9':'#f9fafb'};border:1px solid ${p=>p.$done?'#a7f3d0':'#e5e7eb'};`;
const CTitle   = styled.h5`font-weight:700;font-size:0.92rem;color:#111827;margin:0 0 2px;`;
const CSub     = styled.p`font-size:0.78rem;color:#9ca3af;margin:0;`;
const VBadge   = styled.span`display:inline-flex;align-items:center;gap:3px;background:#f0fdf9;border:1px solid #a7f3d0;color:#059669;font-size:0.68rem;font-weight:700;padding:2px 8px;border-radius:5px;margin-left:7px;`;

/* Inputs */
const Lbl = styled.label`display:block;font-size:0.72rem;text-transform:uppercase;letter-spacing:.5px;color:#9ca3af;font-weight:600;margin-bottom:5px;`;
const Inp = styled.input`
  width:100%;background:#f9fafb;border:1.5px solid #e5e7eb;border-radius:9px;
  padding:11px 13px;color:#111827;font-family:'Plus Jakarta Sans',sans-serif;font-size:0.875rem;
  transition:all .2s;outline:none;
  &:focus{border-color:#10b981;background:#fff;box-shadow:0 0 0 3px rgba(16,185,129,0.1);}
  &::placeholder{color:#d1d5db;} &:disabled{opacity:.5;cursor:not-allowed;}
`;
const Sel = styled.select`
  width:100%;background:#f9fafb;border:1.5px solid #e5e7eb;border-radius:9px;
  padding:11px 13px;color:#111827;font-family:'Plus Jakarta Sans',sans-serif;font-size:0.875rem;
  transition:all .2s;outline:none;appearance:none;
  &:focus{border-color:#10b981;background:#fff;box-shadow:0 0 0 3px rgba(16,185,129,0.1);}
`;
const PhRow = styled.div`display:flex;`;
const PhPfx = styled.div`background:#f3f4f6;border:1.5px solid #e5e7eb;border-right:none;border-radius:9px 0 0 9px;padding:11px 13px;color:#6b7280;font-size:0.875rem;display:flex;align-items:center;flex-shrink:0;`;
const PhInp = styled(Inp)`border-radius:0 9px 9px 0;`;
const Grid2 = styled.div`display:grid;grid-template-columns:${p=>p.$t||'1fr 1fr'};gap:12px;@media(max-width:540px){grid-template-columns:1fr;}`;
const Fld   = styled.div`display:flex;flex-direction:column;`;

const Btn = styled.button`
  width:100%;padding:12px;margin-top:8px;
  background:linear-gradient(135deg,#10b981,#0ea5e9);
  border:none;border-radius:10px;color:#fff;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:0.9rem;font-weight:700;
  cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;
  transition:all .2s;box-shadow:0 4px 12px rgba(16,185,129,0.24);
  &:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 18px rgba(16,185,129,0.32);}
  &:disabled{opacity:.4;cursor:not-allowed;transform:none;box-shadow:none;}
  .sp{animation:${spin} 1s linear infinite;}
`;
const SectionHdr = styled.div`font-weight:700;font-size:0.72rem;text-transform:uppercase;letter-spacing:.8px;color:#10b981;margin:18px 0 11px;display:flex;align-items:center;gap:8px;&::after{content:'';flex:1;height:1px;background:#e5e7eb;}`;
const ErrMsg = styled.div`background:#fef2f2;border:1px solid #fecaca;color:#ef4444;border-radius:9px;padding:11px 14px;font-size:0.84rem;margin-bottom:13px;text-align:center;`;

const states = ["Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Andaman and Nicobar Islands","Chandigarh","Dadra and Nagar Haveli and Daman and Diu","Delhi","Jammu and Kashmir","Ladakh","Lakshadweep","Puducherry"];

const Registration = () => {
  const [mobile, setMobile] = useState(''); const [mOtp, setMOtp] = useState('');
  const [email,  setEmail]  = useState(''); const [eOtp, setEOtp] = useState('');
  const [det, setDet] = useState({ user_name:'', date_of_birth:'', gender:'', shop_name:'', gst_in_number:'', pan_number:'', address_line1:'', address_line2:'', shop_location:'', city_name:'', state:'', pin_code:'', address_line3:'' });
  const [mOtpSent, setMOtpSent] = useState(false); const [eOtpSent, setEOtpSent] = useState(false);
  const [mVerified, setMVerified] = useState(false); const [eVerified, setEVerified] = useState(false);
  const [loading, setLoading] = useState(false); const [error, setError] = useState('');
  const navigate = useNavigate();
  const step = eVerified ? 3 : mVerified ? 2 : 1;

  const api = async (url, body) => { const r = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) }); const d = await r.json(); if (!r.ok) throw new Error(d.error || d.message || 'Error'); return d; };
  const wrap = async (fn) => { setLoading(true); setError(''); try { await fn(); } catch(e){ setError(e.message); } finally { setLoading(false); } };

  const sendMobile = e => { e.preventDefault(); wrap(async() => { await api(`${BaseUrl}/auth/register/send_otp`, {mobile_number:mobile}); setMOtpSent(true); }); };
  const verifyMobile = e => { e.preventDefault(); wrap(async() => { const d = await api(`${BaseUrl}/auth/register/verify_otp`, {mobile_number:mobile, mobile_otp:mOtp}); setMVerified(true); if(d.user_id) localStorage.setItem('user_id',d.user_id); }); };
  const sendEmail = e => { e.preventDefault(); wrap(async() => { await api(`${BaseUrl}/auth/send_email`, {email_address:email}); setEOtpSent(true); }); };
  const verifyEmail = e => { e.preventDefault(); wrap(async() => { await api(`${BaseUrl}/auth/verify_email`, {email_address:email, otp:eOtp}); setEVerified(true); }); };
  const onChange = e => { const{name,value}=e.target; setDet(p=>({...p,[name]:value})); };
  const submit = e => { e.preventDefault(); wrap(async() => { const uid=localStorage.getItem('user_id'); if(!uid) throw new Error('Session expired.'); await api(`${BaseUrl}/auth/update-user-details`, {user_id:uid,...det}); navigate('/choose-business'); }); };

  return (
    <>
      <GlobalStyle />
      <Page>
        <TopBar>
          <Mark><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/><path d="M9 12H15M12 9V15" stroke="#fff" strokeWidth="2.2" strokeLinecap="round"/></svg></Mark>
          <Name>Medi<em>Stox</em></Name>
        </TopBar>

        <Wrap>
          <PageTitle>Create your account</PageTitle>
          <PageSub>Join thousands of pharmacies on MediStox</PageSub>

          <StepRow>
            <Dot $done={step>1} $active={step===1}>{step>1?'✓':'1'}</Dot>
            <SLabel $active={step===1}>Mobile</SLabel>
            <Line $done={step>1}/>
            <Dot $done={step>2} $active={step===2}>{step>2?'✓':'2'}</Dot>
            <SLabel $active={step===2}>Email</SLabel>
            <Line $done={step>2}/>
            <Dot $active={step===3}>3</Dot>
            <SLabel $active={step===3}>Profile</SLabel>
          </StepRow>

          {error && <ErrMsg>{error}</ErrMsg>}

          {/* Step 1 Mobile */}
          <Card>
            <CardHead><Badge $done={mVerified}>{mVerified?'✅':'📱'}</Badge>
              <div><CTitle>Mobile Verification{mVerified&&<VBadge>✓ Verified</VBadge>}</CTitle>{!mVerified&&<CSub>We'll send an OTP</CSub>}</div></CardHead>
            {!mVerified && (!mOtpSent ? (
              <form onSubmit={sendMobile}>
                <Fld style={{marginBottom:8}}><Lbl>Mobile Number</Lbl><PhRow><PhPfx>+91</PhPfx><PhInp type="tel" placeholder="10-digit number" value={mobile} onChange={e=>setMobile(e.target.value)} required disabled={loading}/></PhRow></Fld>
                <Btn type="submit" disabled={loading}>{loading&&<span className="sp">⟳</span>}{loading?'Sending…':'Send OTP →'}</Btn>
              </form>
            ) : (
              <form onSubmit={verifyMobile}>
                <Fld style={{marginBottom:8}}><Lbl>OTP sent to +91 {mobile}</Lbl><Inp type="text" placeholder="6-digit OTP" value={mOtp} onChange={e=>setMOtp(e.target.value)} required disabled={loading} maxLength={6}/></Fld>
                <Btn type="submit" disabled={loading}>{loading&&<span className="sp">⟳</span>}{loading?'Verifying…':'Verify Mobile →'}</Btn>
              </form>
            ))}
          </Card>

          {/* Step 2 Email */}
          <Card $dim={!mVerified}>
            <CardHead><Badge $done={eVerified}>{eVerified?'✅':'✉️'}</Badge>
              <div><CTitle>Email Verification{eVerified&&<VBadge>✓ Verified</VBadge>}</CTitle>{!eVerified&&<CSub>Required for notifications & security</CSub>}</div></CardHead>
            {!eVerified && mVerified && (!eOtpSent ? (
              <form onSubmit={sendEmail}>
                <Fld style={{marginBottom:8}}><Lbl>Email Address</Lbl><Inp type="email" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)} required disabled={loading}/></Fld>
                <Btn type="submit" disabled={loading}>{loading&&<span className="sp">⟳</span>}{loading?'Sending…':'Send OTP →'}</Btn>
              </form>
            ) : (
              <form onSubmit={verifyEmail}>
                <Fld style={{marginBottom:8}}><Lbl>OTP sent to {email}</Lbl><Inp type="text" placeholder="6-digit OTP" value={eOtp} onChange={e=>setEOtp(e.target.value)} required disabled={loading} maxLength={6}/></Fld>
                <Btn type="submit" disabled={loading}>{loading&&<span className="sp">⟳</span>}{loading?'Verifying…':'Verify Email →'}</Btn>
              </form>
            ))}
          </Card>

          {/* Step 3 Profile */}
          {eVerified && (
            <Card>
              <CardHead><Badge>👤</Badge><div><CTitle>Complete Your Profile</CTitle><CSub>Tell us about you and your business</CSub></div></CardHead>
              <form onSubmit={submit}>
                <SectionHdr>Personal Details</SectionHdr>
                <Fld style={{marginBottom:12}}><Lbl>Full Name *</Lbl><Inp type="text" name="user_name" placeholder="e.g. Ravi Kumar" value={det.user_name} onChange={onChange} required/></Fld>
                <Grid2>
                  <Fld><Lbl>Date of Birth *</Lbl><Inp type="date" name="date_of_birth" value={det.date_of_birth} onChange={onChange} required/></Fld>
                  <Fld><Lbl>Gender *</Lbl><Sel name="gender" value={det.gender} onChange={onChange} required><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></Sel></Fld>
                </Grid2>

                <SectionHdr>Business Details</SectionHdr>
                <Fld style={{marginBottom:12}}><Lbl>Shop Name *</Lbl><Inp type="text" name="shop_name" placeholder="Krishna Medical Store" value={det.shop_name} onChange={onChange} required/></Fld>
                <Grid2>
                  <Fld><Lbl>GSTIN (Optional)</Lbl><Inp type="text" name="gst_in_number" placeholder="22AAAAA0000A1Z5" value={det.gst_in_number} onChange={onChange}/></Fld>
                  <Fld><Lbl>PAN (Optional)</Lbl><Inp type="text" name="pan_number" placeholder="ABCDE1234F" value={det.pan_number} onChange={onChange}/></Fld>
                </Grid2>

                <SectionHdr>Address Details</SectionHdr>
                <div style={{display:'flex',flexDirection:'column',gap:11}}>
                  <Fld><Lbl>Address Line 1 *</Lbl><Inp type="text" name="address_line1" placeholder="House No., Building" value={det.address_line1} onChange={onChange} required/></Fld>
                  <Fld><Lbl>Address Line 2 *</Lbl><Inp type="text" name="address_line2" placeholder="Street, Area" value={det.address_line2} onChange={onChange} required/></Fld>
                  <Fld><Lbl>Landmark *</Lbl><Inp type="text" name="shop_location" placeholder="Near City Hospital" value={det.shop_location} onChange={onChange} required/></Fld>
                  <Grid2 $t="1fr 1fr 1fr">
                    <Fld><Lbl>City *</Lbl><Inp type="text" name="city_name" placeholder="Hyderabad" value={det.city_name} onChange={onChange} required/></Fld>
                    <Fld><Lbl>State *</Lbl><Sel name="state" value={det.state} onChange={onChange} required><option value="">State</option>{states.map(s=><option key={s}>{s}</option>)}</Sel></Fld>
                    <Fld><Lbl>PIN *</Lbl><Inp type="text" name="pin_code" placeholder="500001" value={det.pin_code} onChange={onChange} required/></Fld>
                  </Grid2>
                </div>
                <Btn type="submit" disabled={loading} style={{marginTop:20}}>{loading&&<span className="sp">⟳</span>}{loading?'Saving…':'Complete Registration →'}</Btn>
              </form>
            </Card>
          )}
        </Wrap>
      </Page>
    </>
  );
};

export default Registration;