import React, {useState, useEffect, useMemo,useCallback} from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import { FaPlus, FaEdit, FaTrash, FaTimes, FaSearch, FaShoppingCart } from 'react-icons/fa';
import axios from 'axios';
import BaseUrl from './BaseUrl';

// --- Global Styles ---
const GlobalStyle = createGlobalStyle`
  body {
    background-color: #f8f9fa;
    color: #343a40;
  }
`;

// --- Animations ---
const fadeIn = keyframes`from { opacity: 0; } to { opacity: 1; }`;
const slideUp = keyframes`from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; }`;

// --- Styled Components ---
const PageContainer = styled.div`
  padding: 2rem;
  max-width: 1600px;
  margin: auto;
  animation: ${fadeIn} 0.5s ease-in-out;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
`;

const Title = styled.h1`
  font-size: 2.25rem;
  font-weight: 700;
`;

const AddButton = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background-color: #0d6efd;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s, transform 0.2s;
  &:hover {
    background-color: #0b5ed7;
    transform: translateY(-2px);
  }
`;

const FilterControls = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 1.5rem;
  padding: 1rem;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
`;

const SearchInputContainer = styled.div`
  position: relative;
  flex-grow: 1;
`;

const SearchInput = styled.input`
  width: 100%;
  padding: 0.75rem 1rem 0.75rem 2.5rem;
  border: 1px solid #ced4da;
  border-radius: 8px;
  font-size: 1rem;
  &:focus {
    outline: none;
    border-color: #86b7fe;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }
`;

const SearchIcon = styled(FaSearch)`
  position: absolute;
  left: 1rem;
  top: 50%;
  transform: translateY(-50%);
  color: #6c757d;
`;

const ToggleContainer = styled.label`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-weight: 500;
  cursor: pointer;
`;

const TableContainer = styled.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.06);
  overflow-x: auto;
`;

const StyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  th, td {
    padding: 1rem 1.25rem;
    text-align: left;
    vertical-align: middle;
  }
  th {
    background-color: #f8f9fa;
    font-weight: 600;
    color: #495057;
  }
  tbody tr {
    border-top: 1px solid #dee2e6;
    transition: background-color 0.2s;
    &:hover {
      background-color: #e9ecef;
    }
  }
`;

const StatusBadge = styled.span`
  padding: 0.3rem 0.8rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 700;
  color: white;
  text-transform: capitalize;
  background-color: ${({ status }) => {
    if (status === 'near_expiry') return '#ffc107';
    if (status === 'expired') return '#dc3545';
    return '#198754';
  }};
`;

const ProductImage = styled.img`
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 8px;
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 0.5rem;
`;

const ActionButton = styled.button`
  background: none; border: none; cursor: pointer; color: #6c757d;
  font-size: 1.1rem; padding: 0.5rem; border-radius: 50%;
  transition: color 0.2s, background-color 0.2s;
  &:hover {
    &.edit { color: #0d6efd; background-color: #e7f1ff; }
    &.delete { color: #dc3545; background-color: #fbe7e9; }
    &.sell { color: #198754; background-color: #e8f3eb; }
  }
`;

const ModalBackdrop = styled.div`
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  background-color: rgba(0, 0, 0, 0.5); backdrop-filter: blur(5px);
  display: flex; justify-content: center; align-items: center; z-index: 1000;
  animation: ${fadeIn} 0.3s;
`;

const ModalContent = styled.div`
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 650px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  animation: ${slideUp} 0.4s;
  display: flex;
  flex-direction: column;
  max-height: 90vh;
`;

const ModalHeader = styled.div`
  padding: 1.5rem 2rem;
  border-bottom: 1px solid #e9ecef;
  position: relative;
  h2 {
    margin: 0;
    font-size: 1.5rem;
  }
`;

const ModalBody = styled.div`
  padding: 2rem;
  overflow-y: auto;
`;

const ModalFooter = styled.div`
  padding: 1rem 2rem;
  border-top: 1px solid #e9ecef;
  background-color: #f8f9fa;
`;

const CloseButton = styled.button`
  position: absolute; top: 50%; right: 1.5rem; transform: translateY(-50%);
  background: none; border: none; font-size: 1.5rem; color: #6c757d; cursor: pointer;
  &:hover { color: #343a40; }
`;

const FormGroup = styled.div` margin-bottom: 1.5rem; `;
const FormLabel = styled.label` display: block; margin-bottom: 0.5rem; font-weight: 600; color: #495057; `;
const FormInput = styled.input`
  width: 100%; padding: 0.75rem; border: 1px solid #ced4da;
  border-radius: 8px; font-size: 1rem;
  &:focus {
    outline: none; border-color: #86b7fe;
    box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
  }
`;
const FormRow = styled.div` display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; `;
const SubmitButton = styled(AddButton)` width: 100%; justify-content: center; `;

const API_URL = BaseUrl;

const InvoiceTable = () => {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchInvoices = useCallback(async () => {
    try {
      const userId = localStorage.getItem('user_id');
      if (!userId) {
        setError('User not logged in');
        setLoading(false);
        return;
      }
      setLoading(true);
      const response = await axios.get(`${API_URL}/invoice/receiver/${userId}`);
      setInvoices(Array.isArray(response.data) ? response.data : []);
      setError(null);
    } catch (err) {
      setError('Failed to fetch invoices. Please try again later.');
      setInvoices([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInvoices();
  }, [fetchInvoices]);

  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => 
      inv.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.sender_shop_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.id.toString().includes(searchTerm)
    );
  }, [invoices, searchTerm]);

  const handleOpenDetails = (invoice) => {
    setSelectedInvoice(invoice);
    setIsDetailsModalOpen(true);
  };

  return (
    <>
      <GlobalStyle />
      <PageContainer>
        <Header>
          <Title>Billing & Invoices</Title>
        </Header>

        <FilterControls>
          <SearchInputContainer>
            <SearchIcon />
            <SearchInput
              type="text"
              placeholder="Search by product, distributor or invoice ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </SearchInputContainer>
        </FilterControls>
        
        <TableContainer>
          <StyledTable>
            <thead>
              <tr>
                <th>Invoice ID</th>
                <th>Distributor</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total Amount</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="9" className="text-center p-5">Loading...</td></tr>
              ) : error ? (
                <tr><td colSpan="9" className="text-center p-5 text-danger">{error}</td></tr>
              ) : (
                filteredInvoices.length > 0 ? filteredInvoices.map(inv => (
                  <tr key={inv.id}>
                    <td className="fw-bold">#{inv.id}</td>
                    <td>{inv.sender_shop_name}</td>
                    <td>{inv.product_name}</td>
                    <td>{inv.quantity}</td>
                    <td>₹{inv.unit_price.toFixed(2)}</td>
                    <td className="fw-bold text-primary">₹{inv.total_amount.toFixed(2)}</td>
                    <td>
                        <StatusBadge status={inv.status === 'completed' ? 'paid' : inv.status}>
                            {inv.status}
                        </StatusBadge>
                    </td>
                    <td>{new Date(inv.created_at).toLocaleDateString()}</td>
                    <td>
                      <ActionButtons>
                        <ActionButton className="edit" title="View Details" onClick={() => handleOpenDetails(inv)}>
                            <FaSearch />
                        </ActionButton>
                      </ActionButtons>
                    </td>
                  </tr>
                )) : (
                  <tr><td colSpan="9" className="text-center p-5">No invoices found.</td></tr>
                )
              )}
            </tbody>
          </StyledTable>
        </TableContainer>
      </PageContainer>

      {isDetailsModalOpen && selectedInvoice && (
        <ModalBackdrop onClick={() => setIsDetailsModalOpen(false)}>
          <ModalContent onClick={e => e.stopPropagation()} style={{maxWidth: '800px'}}>
            <ModalHeader>
              <h2>Invoice Details #{selectedInvoice.id}</h2>
              <CloseButton onClick={() => setIsDetailsModalOpen(false)}><FaTimes /></CloseButton>
            </ModalHeader>
            <ModalBody>
              <div className="row g-4">
                  <div className="col-md-6">
                      <h6 className="text-muted small fw-bold text-uppercase border-bottom pb-2">Sender (Distributor)</h6>
                      <p className="mb-1 fw-bold">{selectedInvoice.sender_shop_name}</p>
                      <p className="mb-1 small">{selectedInvoice.sender_address}</p>
                      <p className="mb-1 small"><strong>GSTIN:</strong> {selectedInvoice.sender_gst}</p>
                      <p className="mb-0 small"><strong>PAN:</strong> {selectedInvoice.sender_pan}</p>
                  </div>
                  <div className="col-md-6">
                      <h6 className="text-muted small fw-bold text-uppercase border-bottom pb-2">Receiver (You)</h6>
                      <p className="mb-1 fw-bold">{selectedInvoice.receiver_shop_name}</p>
                      <p className="mb-1 small">{selectedInvoice.receiver_address}</p>
                      <p className="mb-1 small"><strong>GSTIN:</strong> {selectedInvoice.receiver_gst}</p>
                      <p className="mb-0 small"><strong>PAN:</strong> {selectedInvoice.receiver_pan}</p>
                  </div>
                  <div className="col-12">
                      <h6 className="text-muted small fw-bold text-uppercase border-bottom pb-2">Order Summary</h6>
                      <div className="table-responsive">
                          <table className="table table-sm mt-2">
                              <thead>
                                  <tr>
                                      <th>Product</th>
                                      <th className="text-center">Qty</th>
                                      <th className="text-end">Unit Price</th>
                                      <th className="text-end">Discount</th>
                                      <th className="text-end">Total</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <tr>
                                      <td>{selectedInvoice.product_name}</td>
                                      <td className="text-center">{selectedInvoice.quantity}</td>
                                      <td className="text-end">₹{selectedInvoice.unit_price.toFixed(2)}</td>
                                      <td className="text-end text-danger">-₹{selectedInvoice.discount.toFixed(2)}</td>
                                      <td className="text-end fw-bold">₹{selectedInvoice.total_amount.toFixed(2)}</td>
                                  </tr>
                              </tbody>
                          </table>
                      </div>
                  </div>
                  {selectedInvoice.description && (
                      <div className="col-12">
                          <h6 className="text-muted small fw-bold text-uppercase">Notes</h6>
                          <p className="small mb-0">{selectedInvoice.description}</p>
                      </div>
                  )}
              </div>
            </ModalBody>
            <ModalFooter className="d-flex justify-content-end">
                <button className="btn btn-secondary px-4 me-2" onClick={() => setIsDetailsModalOpen(false)}>Close</button>
                <button className="btn btn-primary px-4" onClick={() => window.print()}>Print Invoice</button>
            </ModalFooter>
          </ModalContent>
        </ModalBackdrop>
      )}
    </>
  );
};

export default InvoiceTable;
ryTable;