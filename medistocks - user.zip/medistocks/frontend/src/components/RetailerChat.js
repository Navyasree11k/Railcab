import React, { useState, useEffect, useMemo } from 'react';
import styled, { keyframes } from 'styled-components';
import { io } from 'socket.io-client';
import axios from 'axios';
import { useSelector, useDispatch } from 'react-redux';
import {
  setConversations,
  setAllMessages,
  addMessage,
  setActiveChat,
  setLoading
} from './redux/chatSlice';
import BaseUrl, { webSocketUrl } from './BaseUrl';
import { 
  FiMessageSquare, 
  FiX,            
  FiPhone,        
  FiMail,         
  FiCoffee
} from 'react-icons/fi';
import { FaWhatsapp, FaTicketAlt } from 'react-icons/fa'; 


/**
 * Placeholder avatar as an inline SVG data-URL.
 */
const PLACEHOLDER_SVG =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 24 24'>
      <rect width='100%' height='100%' fill='%23e2e8f0' rx='24' />
      <g transform='translate(4,3)' fill='%2364748b'>
        <circle cx='8' cy='6' r='4' fill='%23ffffff' />
        <path d='M0 20c0-4.418 3.582-8 8-8s8 3.582 8 8' fill='%23ffffff'/>
      </g>
    </svg>`
  );

// --- Animations ---
const slideIn = keyframes`
  from { transform: translateX(100%); }
  to { transform: translateX(0); }
`;
const slideOut = keyframes`
  from { transform: translateX(0); }
  to { transform: translateX(100%); }
`;
const fadeIn = keyframes`
  from { opacity: 0; }
  to { opacity: 1; }
`;

// --- Styled Components (responsive + avatars + sticky header) ---

// --- NEW ---
// This container is the new parent. It calculates the correct height
// by subtracting your app's header height.
const ChatPageContainer = styled.div`
  /* Set --app-header-height in your global CSS.
    We default to 60px.
  */
  height: calc(100vh - var(--app-header-height, 60px));
  width: 100%;
  
  /* On mobile, we might have a different header height.
    Defaulting to 50px.
  */
  @media (max-width: 768px) {
    height: calc(100vh - var(--app-header-height, 50px));
  }
`;
// --- END NEW ---

const PageLayout = styled.div`
  display: flex;
  /* --- MODIFIED --- */
  height: 100%; /* Changed from 100vh to 100% to fill parent */
  /* --- END MODIFIED --- */
  background: #fff;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  font-family: 'Inter', sans-serif;
  position: relative; /* For modal/panel context */

  @media (max-width: 768px) {
    flex-direction: column;
    border-radius: 0;
  }
`;

/*
const Sidebar = styled.div`
  width: 320px;
  border-right: 1px solid #e2e8f0;
  display: flex;
  flex-direction: column;
  background-color: #ffffff;
  transition: transform 0.2s ease, opacity 0.2s ease;
  min-height: 0;

  @media (max-width: 768px) {
    width: 100%;
    ${({ active }) => (active ? 'display: none;' : 'display: flex;')}
    height: 100%;
  }
`;

const SidebarHeader = styled.div`
  padding: 1.5rem;
  border-bottom: 1px solid #e2e8f0;
  font-weight: 700;
  font-size: 1.25rem;
  color: #1e293b;
  background: #fff;
  z-index: 20;
`;

const ConversationList = styled.div`
  overflow-y: auto;
  flex-grow: 1;
  min-height: 0;
`;

const ConversationItem = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem 1.5rem;
  cursor: pointer;
  border-bottom: 1px solid #e2e8f0;
  background-color: ${({ active }) => (active ? '#f0fdf4' : 'transparent')};
  border-left: 4px solid ${({ active }) => (active ? '#22c55e' : 'transparent')};
  transition: background-color 0.15s ease;
  &:hover {
    background-color: #f1f5f9;
  }

  @media (max-width: 420px) {
    padding: 0.75rem 1rem;
    gap: 0.75rem;
  }
`;
*/

const Avatar = styled.div`
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background-color: #e2e8f0;
  color: #64748b;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 1.25rem;
  flex-shrink: 0;
  overflow: hidden;

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
  }

  @media (max-width: 420px) {
    width: 40px;
    height: 40px;
    font-size: 1rem;
  }
`;

/*
const ConversationDetails = styled.div`
  flex-grow: 1;
  overflow: hidden;
  h6 { font-weight: 600; margin-bottom: 0.25rem; color: #1e293b; display: flex; align-items: center; gap: 0.5rem; margin: 0; }
  p { font-size: 0.875rem; color: #64748b; margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

  @media (max-width: 420px) {
    h6 { font-size: 0.95rem; }
    p { font-size: 0.8rem; }
  }
`;

const Timestamp = styled.span`
  font-size: 0.75rem;
  color: #94a3b8;
  margin-left: auto;
  flex-shrink: 0;

  @media (max-width: 420px) {
    font-size: 0.7rem;
  }
`;

const ChatWindow = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  background-color: #f1f5f9;
  min-height: 0;

  @media (max-width: 768px) {
    ${({ active }) => (!active ? 'display: none;' : 'display: flex;')}
    height: 100%;
    width: 100%;
  }
`;

const ChatHeader = styled.div`
  position: sticky;
  top: 0;
  z-index: 30;
  padding: 1rem 1.5rem;
  border-bottom: 1px solid #e2e8f0;
  background-color: #fff;
  display: flex;
  align-items: center;
  gap: 1rem;
  box-shadow: 0 1px 0 rgba(0,0,0,0.04);
  justify-content: space-between; 
`;

const ChatHeaderUser = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-grow: 1; 
  min-width: 0; 

  div {
    min-width: 0;
  }
  
  h5 {
    margin: 0;
    font-weight: 700;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  small {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: block; 
  }
`;

const ChatHeaderActions = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0; 
`;
*/

const IconButton = styled.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  color: #475569;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 50%;
  font-size: 1.25rem;

  &:hover { 
    background: #f1f5f9; 
    color: #1e293b;
  }
`;

/*
const IconLinkButton = styled.a`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  color: #475569;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 50%;
  font-size: 1.25rem;
  text-decoration: none;

  &:hover { 
    background: #f1f5f9; 
    color: #1e293b;
  }

  display: none; 
  @media (min-width: 768.01px) {
    display: inline-flex; 
  }
`;

const BackButton = styled(IconButton)`
  display: none;
  padding: 0.25rem;
  font-size: 1.1rem;

  @media (max-width: 768px) {
    display: inline-flex;
  }
`;

const MessageList = styled.div`
  flex: 1 1 auto;
  padding: 1.5rem;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  background: linear-gradient(#f1f5f9, #f8fafc);
  min-height: 0;

  @media (max-width: 420px) {
    padding-bottom: 2.5rem;
  }
`;

const MessageBubble = styled.div`
  max-width: 75%;
  padding: 0.75rem 1.25rem;
  border-radius: 1.25rem;
  line-height: 1.5;
  align-self: ${({ sent }) => (sent ? 'flex-end' : 'flex-start')};
  background: ${({ sent }) => (sent ? '#16a34a' : '#ffffff')};
  color: ${({ sent }) => (sent ? '#fff' : '#1e293b')};
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  border-bottom-left-radius: ${({ sent }) => (sent ? '1.25rem' : '0.25rem')};
  border-bottom-right-radius: ${({ sent }) => (sent ? '0.25rem' : '1.25rem')};
  word-wrap: break-word;
  white-space: pre-wrap;
`;

const MessageInput = styled.form`
  padding: 1rem 1.5rem;
  border-top: 1px solid #e2e8f0;
  display: flex;
  gap: 0.75rem;
  background: #fff;
  position: sticky;
  bottom: 0;


  input {
    flex-grow: 1;
    border-radius: 9999px;
    padding: 0.75rem 1.25rem;
    border: 1px solid #cbd5e1;
    background-color: #f8fafc;
    &:focus { outline: none; border-color: #22c55e; box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.2); }
  }
  button {
    border-radius: 50%;
    width: 48px;
    height: 48px;
    flex-shrink: 0;
    background-color: #16a34a;
    border: none;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    &:hover { background-color: #15803d; }
  }

  @media (max-width: 420px) {
    padding: 0.75rem 1rem;
    input { padding: 0.6rem 1rem; }
    button { width: 44px; height: 44px; }
  }
`;

const EmptyStateContainer = styled.div`
  display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; text-align: center; color: #94a3b8; padding: 2rem;
  svg { font-size: 4rem; opacity: 0.5; }
`;
*/

const ComingSoonContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  width: 100%;
  background: #f8fafc;
  color: #64748b;
  text-align: center;
  padding: 2rem;
  
  h2 { 
    font-size: 2.5rem; 
    font-weight: 800; 
    color: #1e293b; 
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #1e293b 0%, #475569 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  
  p { 
    font-size: 1.25rem; 
    max-width: 500px;
    line-height: 1.6;
  }

  .icon-wrapper {
    font-size: 5rem;
    margin-bottom: 2rem;
    color: #0D7C3D;
    animation: bounce 2s infinite;
  }

  @keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
  }
`;

const RaiseTicketButton = styled.button`
  margin-top: 2rem;
  padding: 0.8rem 2.5rem;
  background: linear-gradient(135deg, #0D7C3D 0%, #0F9D4E 100%);
  color: white;
  border: none;
  border-radius: 12px;
  font-weight: 700;
  font-size: 1rem;
  font-family: 'Inter', sans-serif;
  display: flex;
  align-items: center;
  gap: 0.75rem;
  cursor: pointer;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 4px 12px rgba(13, 124, 61, 0.2);

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(13, 124, 61, 0.3);
    background: linear-gradient(135deg, #0a6631 0%, #0d7c3d 100%);
  }

  &:active {
    transform: translateY(0);
    box-shadow: 0 2px 6px rgba(13, 124, 61, 0.2);
  }

  svg {
    font-size: 1.1rem;
  }
`;



const ModalBackdrop = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(5px);
  z-index: 100;
  animation: ${fadeIn} 0.2s ease;
  
  @media (max-width: 768px) {
    background: rgba(0, 0, 0, 0.5);
  }
`;

const UserDetailsPanel = styled.div`
  position: absolute;
  top: 0;
  right: 0;
  width: 350px;
  height: 100%;
  background: #ffffff;
  z-index: 101;
  box-shadow: -10px 0 30px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  animation: ${fadeIn} 0.3s ease; /* Desktop animation */

  /* Mobile-first: Full-width panel sliding in */
  @media (max-width: 768px) {
    width: 90%;
    max-width: 350px;
    animation: ${slideIn} 0.3s ease-out forwards;
    
    &.closing {
      animation: ${slideOut} 0.3s ease-out forwards;
    }
  }

  /* Desktop: Centered Modal */
  @media (min-width: 768.01px) {
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    height: auto;
    width: 90%;
    max-width: 400px;
    border-radius: 1rem;
  }
`;

const DetailsHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  border-bottom: 1px solid #e2e8f0;
  
  h5 {
    margin: 0;
    font-size: 1.25rem;
    font-weight: 700;
    color: #1e293b;
  }
`;

const DetailsBody = styled.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const ProfileInfo = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  text-align: center;
  
  h4 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 700;
    color: #111827;
  }
  
  p {
    margin: 0;
    color: #64748b;
    font-size: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
`;

const ActionButton = styled.a`
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  border-radius: 0.75rem;
  background-color: #f1f5f9;
  color: #1e293b;
  font-weight: 600;
  text-decoration: none;
  transition: background-color 0.2s ease;

  svg {
    color: #4f46e5;
    font-size: 1.25rem;
  }
  
  &:hover {
    background-color: #e2e8f0;
  }
`;

/*
// Helper to format timestamps (IST +5:30)
const formatTimestamp = (isoString) => {
  if (!isoString) return '';
  // The backend sends UTC. We force an offset of +5:30 for IST.
  const date = new Date(isoString);
  const istDate = new Date(date.getTime() + (5.5 * 60 * 60 * 1000));
  return istDate.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true, timeZone: 'UTC' });
};
*/


/**
 * UserDetailsModal Component
 */
/*
const UserDetailsModal = ({ user, onClose }) => {
  const [isClosing, setIsClosing] = useState(false);

  const handleClose = () => {
    if (window.innerWidth <= 768) {
      setIsClosing(true);
      setTimeout(onClose, 300); 
    } else {
      onClose();
    }
  };

  const formattedWhatsApp = (mobile) => {
    if (!mobile) return '';
    let num = mobile.replace(/[\s+-]/g, '');
    if (num.length === 10) {
      num = `91${num}`; 
    }
    return `https://wa.me/${num}`;
  };

  const safeUser = user || {}; 

  return (
    <ModalBackdrop onClick={handleClose}>
      <UserDetailsPanel 
        onClick={e => e.stopPropagation()}
        className={isClosing ? 'closing' : ''}
      >
        <DetailsHeader>
          <h5>Contact Details</h5>
          <IconButton onClick={handleClose}><FiX /></IconButton>
        </DetailsHeader>
        <DetailsBody>
          <ProfileInfo>
            <Avatar style={{ width: '100px', height: '100px' }}>
              <img src={safeUser.image || PLACEHOLDER_SVG} alt={safeUser.name || `User ${safeUser.id}`} />
            </Avatar>
            <h4>{safeUser.name || `User ID: ${safeUser.id}`}</h4>
            {safeUser.shop_name && (
              <p><FiCoffee size={16} /> {safeUser.shop_name}</p>
            )}
          </ProfileInfo>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {safeUser.mobile && (
              <ActionButton href={`tel:${safeUser.mobile}`}>
                <FiPhone />
                <span>Call {safeUser.mobile}</span>
              </ActionButton>
            )}
            {safeUser.mobile && (
              <ActionButton href={formattedWhatsApp(safeUser.mobile)} target="_blank" rel="noopener noreferrer">
                <FaWhatsapp style={{ color: '#25D366' }} />
                <span>WhatsApp {safeUser.mobile}</span>
              </ActionButton>
            )}
            {safeUser.email && (
              <ActionButton href={`mailto:${safeUser.email}`}>
                <FiMail />
                <span>Email {safeUser.email}</span>
              </ActionButton>
            )}
          </div>
        </DetailsBody>
      </UserDetailsPanel>
    </ModalBackdrop>
  );
};
*/


// Support System Constants
const SUPPORT_USER_ID = 3; // MediStox Support User

// --- The Main Component ---
const RetailerChat = () => {
  const dispatch = useDispatch();
  const { conversations, allMessages, activeChatUserId /*, selectedProduct, error */ } = useSelector(
    (state) => state.chat
  );
  const myUserId = parseInt(localStorage.getItem('user_id'), 10);
  // const [newMessage, setNewMessage] = useState('');
  const [socket, setSocket] = useState(null);
  // const messageListRef = useRef(null);
  
  // const [showDetails, setShowDetails] = useState(false);

  // Establish Socket connection
  useEffect(() => {
    if (!myUserId) return;
    const s = io(webSocketUrl, {
      path: '/medistocks_user/socket.io',
      transports: ['websocket'],
      query: { user_id: myUserId },
      withCredentials: true,
    });
    setSocket(s);
    s.on('connect', () => console.log('Socket connected:', s.id));
    s.on('connect_error', (err) => console.error('Socket connection error:', err));
    
    const handleReceiveMessage = (msg) => {
      console.log('Received message:', msg);
      dispatch(addMessage(msg));
    };
    
    s.on('receive_message', handleReceiveMessage);
    
    return () => {
      s.off('receive_message', handleReceiveMessage);
      s.disconnect();
    };
  }, [myUserId, dispatch]);

  // Initial fetch of messages to populate conversations
  useEffect(() => {
    if (!myUserId) return;

    const fetchAndProcessData = async () => {
      dispatch(setLoading(true));
      try {
        const res = await axios.get(`${BaseUrl}/chat/messages/${myUserId}`);
        const messages = res.data;
        dispatch(setAllMessages(messages));

        const conversationsMap = new Map();
        
        messages.forEach(msg => {
          const otherUserId = msg.sender_id === myUserId ? msg.receiver_id : msg.sender_id;
          
          const otherUser = msg.sender_id === myUserId ? 
            { // This is the RECEIVER
                id: msg.receiver_id,
                name: msg.receiver_name,
                mobile: msg.receiver_mobile,
                email: msg.receiver_email,
                image: msg.receiver_image,
                shop_name: msg.receiver_shop_name,
            } : 
            { // This is the SENDER
                id: msg.sender_id,
                name: msg.sender_name,
                mobile: msg.sender_mobile,
                email: msg.sender_email,
                image: msg.sender_image,
                shop_name: msg.sender_shop_name,
            };

          if (!conversationsMap.has(otherUserId) || new Date(msg.timestamp) > new Date(conversationsMap.get(otherUserId).timestamp)) {
            conversationsMap.set(otherUserId, {
              id: otherUserId,
              user: otherUser,
              lastMessage: msg.message_text,
              timestamp: msg.timestamp,
            });
          }
        });

        const derivedConversations = Array.from(conversationsMap.values())
          .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        dispatch(setConversations(derivedConversations));

      } catch (err) {
        dispatch(setAllMessages([]));
        dispatch(setConversations([]));
        console.error('Failed to fetch messages:', err);
      } finally {
        dispatch(setLoading(false));
      }
    };
    
    fetchAndProcessData();
  }, [myUserId, dispatch]);

  const filteredMessages = useMemo(() => {
    if (!activeChatUserId) return [];
    return (allMessages || []).filter(m =>
      (m.sender_id === myUserId && m.receiver_id === activeChatUserId) ||
      (m.sender_id === activeChatUserId && m.receiver_id === myUserId)
    );
  }, [allMessages, activeChatUserId, myUserId]);


  /*
  useEffect(() => {
    if (messageListRef.current) {
      messageListRef.current.scrollTop = messageListRef.current.scrollHeight;
    }
  }, [filteredMessages]);
  */

  /*
  const handleSend = (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeChatUserId || !socket) return;

    const msgData = { 
      sender_id: myUserId, 
      receiver_id: activeChatUserId, 
      message_text: newMessage, 
    };
    
    socket.emit('send_message', msgData);
    setNewMessage('');
  };
  */
  
  /*
  const handleConversationClick = (userId) => {
    dispatch(setActiveChat(userId));
    setShowDetails(false); // Close details panel when switching chats
  };
  */

  // const activeChatPartner = useMemo(() => (conversations || []).find((c) => c.id === activeChatUserId), [conversations, activeChatUserId]);

  /*
  const handleBack = () => {
    dispatch(setActiveChat(null));
  };
  */

  const handleRaiseTicket = async () => {
    // Initiate chat with support admin
    try {
      // Check if conversation already exists in local state
      const supportConvo = (conversations || []).find(c => c.id === SUPPORT_USER_ID);
      
      if (!supportConvo) {
        // If no convo, send an initial message to establish it
        const initMsg = {
          sender_id: myUserId,
          receiver_id: SUPPORT_USER_ID,
          message_text: "I would like to raise a ticket regarding a technical issue.",
        };
        
        if (socket) {
          socket.emit('send_message', initMsg);
        }
      }
      
      // Switch to the support chat
      dispatch(setActiveChat(SUPPORT_USER_ID));
    } catch (err) {
      console.error("Failed to raise ticket:", err);
    }
  };

  return (
    <ChatPageContainer>

      <ComingSoonContainer>
        <div className="icon-wrapper">
          <FiMessageSquare />
        </div>
        <h2>Chat Feature Coming Soon</h2>
        <p>
          We are currently integrating our professional administrative support module. 
          Soon you will be able to communicate directly with our verified distributors.
        </p>
        <RaiseTicketButton onClick={handleRaiseTicket}>
           <FaTicketAlt /> Raise Ticket
        </RaiseTicketButton>

        <div style={{ marginTop: '2rem', display: 'flex', gap: '1rem' }}>
           <div style={{ padding: '0.5rem 1rem', background: '#e2e8f0', borderRadius: '0.5rem', fontSize: '0.875rem', fontWeight: 600 }}>Phase 1: Admin Integration</div>
           <div style={{ padding: '0.5rem 1rem', background: '#f1f5f9', borderRadius: '0.5rem', fontSize: '0.875rem', fontWeight: 600, color: '#94a3b8' }}>Phase 2: Live Support</div>
        </div>
      </ComingSoonContainer>

      {/* Hidden layout for future use if needed, but for now we show placeholder */}
      {false && (
        <PageLayout>
          {/* ... existing content ... */}
        </PageLayout>
      )}

      {/* 
       showDetails && activeChatPartner && (
        <UserDetailsModal 
          user={activeChatPartner.user} 
          onClose={() => setShowDetails(false)} 
        />
      )
      */}
    </ChatPageContainer>
  );
};

export default RetailerChat;