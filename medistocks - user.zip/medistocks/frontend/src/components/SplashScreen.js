import React, { useState, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeUp   = keyframes`from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}`;
const fadeOut  = keyframes`from{opacity:1}to{opacity:0}`;
const spinRing = keyframes`to{transform:rotate(360deg)}`;
const bounce   = keyframes`0%,80%,100%{transform:translateY(0);opacity:.35}40%{transform:translateY(-9px);opacity:1}`;

const Wrap = styled.div`
  position:fixed;inset:0;z-index:9999;
  background:#ffffff;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  animation:${p=>p.$exit?fadeOut:'none'} 0.5s ease forwards;
`;

const Card = styled.div`
  display:flex;flex-direction:column;align-items:center;text-align:center;
  animation:${fadeUp} 0.8s cubic-bezier(0.16,1,0.3,1) forwards;
  padding:0 24px;
`;

const Ring = styled.div`
  width:86px;height:86px;border-radius:50%;
  border:2px solid #e5e7eb;
  background:linear-gradient(135deg,#f0fdf9,#eff6ff);
  display:flex;align-items:center;justify-content:center;
  margin-bottom:26px;position:relative;
  &::after{
    content:'';position:absolute;inset:-2px;border-radius:50%;
    border:2.5px solid transparent;
    border-top-color:#10b981;
    animation:${spinRing} 1.6s linear infinite;
  }
`;

const Title = styled.h1`
  font-family:'Plus Jakarta Sans','Segoe UI',sans-serif;
  font-size:2rem;font-weight:800;letter-spacing:-.5px;
  color:#111827;margin:0 0 7px;
  em{color:#10b981;font-style:normal;}
`;

const Sub = styled.p`color:#9ca3af;font-size:0.9rem;margin:0 0 34px;font-family:'Plus Jakarta Sans',sans-serif;`;

const Dots = styled.div`
  display:flex;gap:7px;
  div{width:7px;height:7px;border-radius:50%;background:#10b981;animation:${bounce} 1.2s ease-in-out infinite;}
  div:nth-child(2){animation-delay:.15s;background:#0ea5e9;}
  div:nth-child(3){animation-delay:.3s;background:#6366f1;}
`;

const Ver = styled.div`position:absolute;bottom:24px;font-size:0.68rem;color:#d1d5db;letter-spacing:1px;`;

const SplashScreen = ({ onFinished }) => {
  const [exit, setExit] = useState(false);
  useEffect(() => {
    const t1 = setTimeout(() => setExit(true), 2600);
    const t2 = setTimeout(() => { if (onFinished) onFinished(); }, 3100);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [onFinished]);

  return (
    <Wrap $exit={exit}>
      <Card>
        <Ring>
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="#10b981" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M9 12H15M12 9V15" stroke="#10b981" strokeWidth="1.8" strokeLinecap="round"/>
          </svg>
        </Ring>
        <Title>Medi<em>Stox</em></Title>
        <Sub>Connecting pharmacies with care 💊</Sub>
        <Dots><div/><div/><div/></Dots>
      </Card>
      <Ver>MEDISTOX PLATFORM · v2.0</Ver>
    </Wrap>
  );
};

export default SplashScreen;