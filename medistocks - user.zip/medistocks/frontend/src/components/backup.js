import React, { useState, useEffect, useMemo } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';

// --- Global Styles (improved) ---
const GlobalStyle = createGlobalStyle`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  body {
    margin: 0;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    background: linear-gradient(135deg, #0a1f1a 0%, #0c2a1a 100%);
    color: #ffffff;
    overflow-x: hidden;
  }
  ::-webkit-scrollbar {
    width: 6px;
  }
  ::-webkit-scrollbar-track {
    background: #1a2e2a;
  }
  ::-webkit-scrollbar-thumb {
    background: #0d7c3d;
    border-radius: 10px;
  }
`;

// --- Keyframes (unchanged) ---
const bounce = keyframes`
  0%, 100% { transform: translateY(-25%); animation-timing-function: cubic-bezier(0.8, 0, 1, 1); }
  50% { transform: translateY(0); animation-timing-function: cubic-bezier(0, 0, 0.2, 1); }
`;
const pulse = keyframes`
  50% { opacity: .5; }
`;
const slideUp = keyframes`
  from { opacity: 0; transform: translateY(2rem); }
  to { opacity: 1; transform: translateY(0); }
`;

// --- Styled Components for Splash (improved) ---
const SplashScreenContainer = styled.div`
  position: fixed;
  inset: 0;
  background: linear-gradient(135deg, #0a1f1a 0%, #0c2a1a 100%);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  transition: opacity 0.5s;
  z-index: 100;
  opacity: ${({ exit }) => (exit ? 0 : 1)};
`;

const LogoContainer = styled.div`
  animation: ${pulse} 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
`;

const BounceContainer = styled.div`
  position: absolute;
  bottom: 3rem;
  display: flex;
  gap: 0.6rem;

  div {
    width: 0.75rem;
    height: 0.75rem;
    background-color: #0d7c3d;
    border-radius: 9999px;
    animation: ${bounce} 1s infinite;
  }
  div:nth-child(2) { animation-delay: -0.15s; }
  div:nth-child(1) { animation-delay: -0.3s; }
`;

// --- Dashboard Styled Components (pharmacy theme) ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN_BG = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_BG = 'rgba(255, 255, 255, 0.95)';
const SIDEBAR_BG = 'rgba(26, 46, 42, 0.95)';

const DashboardWrapper = styled.div`
  min-height: 100vh;
  background: radial-gradient(ellipse 80% 80% at 50% -20%, rgba(13,124,61,0.15), rgba(10,31,26,0.95));
`;

const SidebarContainer = styled.aside`
  width: 280px;
  background: ${SIDEBAR_BG};
  backdrop-filter: blur(16px);
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  border-right: 1px solid rgba(13,124,61,0.3);
  z-index: 40;
  transition: transform 0.3s ease-in-out;

  @media (max-width: 992px) {
    transform: translateX(${({ isOpen }) => (isOpen ? '0' : '-100%')});
    width: 260px;
  }
`;

const MainContentContainer = styled.main`
  transition: margin-left 0.3s ease-in-out;
  margin-left: 280px;
  position: relative;
  z-index: 10;

  @media (max-width: 992px) {
    margin-left: 0;
  }
`;

const NavItemButton = styled.button`
  background: transparent;
  border: none;
  color: #cbd5e1;
  transition: all 0.2s ease;
  position: relative;
  width: 100%;
  text-align: left;
  padding: 0.75rem 1rem;
  border-radius: 12px;
  font-weight: 500;
  cursor: pointer;
  &:hover {
    color: white;
    background: rgba(13,124,61,0.2);
  }
  &.active {
    color: white;
    background: ${PHARMACY_GREEN};
    box-shadow: 0 4px 12px rgba(13,124,61,0.3);
  }
`;

const HeaderContainer = styled.header`
  background: rgba(26, 46, 42, 0.85);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(13,124,61,0.3);
`;

const ExpiryProgressBarContainer = styled.div`
  width: 100%;
  background-color: #e2e8f0;
  border-radius: 20px;
  height: 6px;
  overflow: hidden;
`;

const ExpiryProgressBarFill = styled.div`
  height: 100%;
  border-radius: 20px;
  transition: width 0.5s ease-out;
  background-color: ${({ percentage }) => (percentage > 70 ? '#ef4444' : percentage > 50 ? '#f59e0b' : PHARMACY_GREEN)};
`;

const ProductCardContainer = styled.div`
  background: ${CARD_BG};
  backdrop-filter: blur(4px);
  border: 1px solid ${BORDER_GREY};
  border-radius: 1.5rem;
  overflow: hidden;
  transition: all 0.3s ease;
  transform: translateY(0);
  opacity: 0;
  animation: ${slideUp} 0.5s ease-out forwards;
  animation-delay: ${({ index }) => index * 80}ms;
  box-shadow: 0 8px 20px rgba(0,0,0,0.05);
  &:hover {
    transform: translateY(-6px);
    box-shadow: 0 20px 30px rgba(13,124,61,0.15);
    border-color: ${PHARMACY_GREEN};
  }
`;

const FilterCard = styled.div`
  background: rgba(255, 255, 255, 0.95);
  border-radius: 1.5rem;
  padding: 1.5rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  border: 1px solid ${BORDER_GREY};
`;

const BannerAdContainer = styled.div`
  background: linear-gradient(135deg, ${PHARMACY_GREEN}, #0f9d4e);
  border-radius: 1.5rem;
  padding: 1.5rem;
  margin-bottom: 2rem;
  color: white;
  box-shadow: 0 8px 20px rgba(13,124,61,0.2);
`;

// --- Reusable Components (unchanged logic, improved styling) ---
const ExpiryProgressBar = ({ percentage }) => (
  <ExpiryProgressBarContainer>
    <ExpiryProgressBarFill percentage={percentage} style={{ width: `${percentage}%` }} />
  </ExpiryProgressBarContainer>
);

const ProductCard = ({ product, index }) => (
  <ProductCardContainer index={index}>
    <div style={{ position: 'relative' }}>
      <img
        src={product.image}
        alt={product.name}
        style={{ width: '100%', height: '180px', objectFit: 'cover' }}
        onError={(e) => { e.target.src = 'https://placehold.co/300x200/1e293b/FFFFFF?text=Error'; }}
      />
      <div style={{
        position: 'absolute',
        top: '12px',
        right: '12px',
        background: '#c0392b',
        color: 'white',
        fontSize: '0.75rem',
        fontWeight: 'bold',
        padding: '4px 12px',
        borderRadius: '30px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
      }}>
        {product.discount}% OFF
      </div>
    </div>
    <div style={{ padding: '1.25rem' }}>
      <h3 style={{ fontSize: '1rem', fontWeight: 700, color: DARK_NAVY, marginBottom: '0.5rem' }}>{product.name}</h3>
      <p style={{ fontSize: '0.75rem', color: '#6c757d', marginBottom: '0.5rem' }}>Expiry Status</p>
      <ExpiryProgressBar percentage={product.expiryPercentage} />
      <button style={{
        width: '100%',
        marginTop: '1rem',
        background: PHARMACY_GREEN,
        border: 'none',
        color: 'white',
        fontWeight: 600,
        padding: '10px',
        borderRadius: '40px',
        cursor: 'pointer',
        transition: '0.2s'
      }}>Send Request</button>
    </div>
  </ProductCardContainer>
);

const Sidebar = ({ activeTab, setActiveTab, isOpen }) => {
  const NavItem = ({ name, icon }) => (
    <NavItemButton onClick={() => setActiveTab(name)} className={activeTab === name ? 'active' : ''}>
      <span style={{ marginRight: '12px', display: 'inline-flex', alignItems: 'center' }}>{icon}</span>
      <span>{name}</span>
    </NavItemButton>
  );

  return (
    <SidebarContainer isOpen={isOpen}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem', padding: '0 0.5rem' }}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ marginRight: '12px' }}>
          <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="#0d7c3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M2 7L12 12L22 7" stroke="#0d7c3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M12 12V22" stroke="#0d7c3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <h1 style={{ fontSize: '1.25rem', fontWeight: 700, color: 'white', margin: 0 }}>MediStox</h1>
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', flex: 1 }}>
        <NavItem name="Products" icon={<svg width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M1 2a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V2zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1V2zM1 7a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V7zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1V7zM1 12a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1v-2zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-2zm5 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-2z"/></svg>} />
        <NavItem name="Chat" icon={<svg width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M16 8c0 3.866-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.584.296-1.925.864-4.181 1.234-.2.032-.352-.176-.273-.362.354-.836.674-1.95.77-2.966C.744 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7zM5 8a1 1 0 1 0-2 0 1 1 0 0 0 2 0zm4 0a1 1 0 1 0-2 0 1 1 0 0 0 2 0zm3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/></svg>} />
        <NavItem name="Videos" icon={<svg width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M0 12V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm6.79-6.907A.5.5 0 0 0 6 5.5v5a.5.5 0 0 0 .79.407l3.5-2.5a.5.5 0 0 0 0-.814l-3.5-2.5z"/></svg>} />
        <NavItem name="Requests" icon={<svg width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M9.293 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4.707A1 1 0 0 0 13.707 4L10 .293A1 1 0 0 0 9.293 0zM9.5 3.5v-2l3 3h-2a1 1 0 0 1-1-1zm1.354 4.354-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708.708z"/></svg>} />
      </nav>
      <div style={{
        marginTop: 'auto',
        background: 'rgba(255,255,255,0.1)',
        borderRadius: '1rem',
        padding: '1rem',
        display: 'flex',
        alignItems: 'center',
        gap: '12px'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          borderRadius: '40px',
          background: PHARMACY_GREEN,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontWeight: 'bold',
          color: 'white'
        }}>U</div>
        <div>
          <p style={{ fontWeight: 600, margin: 0, color: 'white' }}>John Doe</p>
          <p style={{ fontSize: '0.7rem', margin: 0, color: '#cbd5e1' }}>Retailer Account</p>
        </div>
      </div>
    </SidebarContainer>
  );
};

const BannerAd = () => (
  <BannerAdContainer>
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '1rem' }}>
      <div>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem' }}>Exclusive Deals on Top Brands</h2>
        <p style={{ margin: 0, opacity: 0.9 }}>Get up to 40% off on your next bulk order. Limited time offer!</p>
      </div>
      <button style={{
        background: 'white',
        border: 'none',
        color: PHARMACY_GREEN,
        fontWeight: 600,
        padding: '8px 20px',
        borderRadius: '40px',
        cursor: 'pointer'
      }}>Learn More</button>
    </div>
  </BannerAdContainer>
);

// --- Mock Data (unchanged) ---
const mockProducts = [
  { id: 1, name: 'Paracetamol 500mg', image: 'https://placehold.co/300x200/00a896/FFFFFF?text=P-500', discount: 50, expiryPercentage: 25 },
  { id: 2, name: 'Amoxicillin 250mg', image: 'https://placehold.co/300x200/0077b6/FFFFFF?text=Amox', discount: 75, expiryPercentage: 65 },
  { id: 3, name: 'Cetirizine 10mg', image: 'https://placehold.co/300x200/d62828/FFFFFF?text=C-10', discount: 90, expiryPercentage: 80 },
  { id: 4, name: 'Ibuprofen 400mg', image: 'https://placehold.co/300x200/f77f00/FFFFFF?text=Ibu', discount: 50, expiryPercentage: 55 },
  { id: 5, name: 'Loratadine 10mg', image: 'https://placehold.co/300x200/6a4c93/FFFFFF?text=Lora', discount: 75, expiryPercentage: 40 },
  { id: 6, name: 'Omeprazole 20mg', image: 'https://placehold.co/300x200/2a9d8f/FFFFFF?text=Ome', discount: 90, expiryPercentage: 95 },
];

// --- Main Dashboard Component (logic untouched, UI improved) ---
const RetailDashboard = () => {
  const [activeTab, setActiveTab] = useState('Products');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterByExpiry, setFilterByExpiry] = useState(100);
  const [sortByDiscount, setSortByDiscount] = useState('none');
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const filteredProducts = useMemo(() => {
    return mockProducts
      .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
      .filter(p => p.expiryPercentage <= filterByExpiry)
      .sort((a, b) => {
        if (sortByDiscount === 'desc') return b.discount - a.discount;
        if (sortByDiscount === 'asc') return a.discount - b.discount;
        return 0;
      });
  }, [searchTerm, filterByExpiry, sortByDiscount]);

  const renderContent = () => {
    switch (activeTab) {
      case 'Products':
        return (
          <div>
            <BannerAd />
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
              <button style={{ flex: 1, background: 'rgba(13,124,61,0.2)', border: '1px solid #0d7c3d', padding: '12px', borderRadius: '40px', color: 'white', fontWeight: 600 }}>🔮 AI Demand Forecast</button>
              <button style={{ flex: 1, background: 'rgba(13,124,61,0.2)', border: '1px solid #0d7c3d', padding: '12px', borderRadius: '40px', color: 'white', fontWeight: 600 }}>🗺️ Nearby Inventory</button>
            </div>
            <FilterCard>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center' }}>
                <div style={{ flex: 2, minWidth: '180px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', background: '#f1f5f9', borderRadius: '40px', padding: '4px 12px' }}>
                    <span style={{ marginRight: '8px' }}>🔍</span>
                    <input type="text" placeholder="Search products..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ width: '100%', border: 'none', background: 'transparent', outline: 'none', padding: '10px 0', color: DARK_NAVY }} />
                  </div>
                </div>
                <div style={{ flex: 1, minWidth: '150px' }}>
                  <label style={{ fontSize: '0.7rem', color: '#6c757d', display: 'block', marginBottom: '4px' }}>Expiry Filter</label>
                  <input type="range" min="0" max="100" value={filterByExpiry} onChange={(e) => setFilterByExpiry(Number(e.target.value))} style={{ width: '100%' }} />
                  <span style={{ fontSize: '0.7rem', color: PHARMACY_GREEN }}>{filterByExpiry}%</span>
                </div>
                <div style={{ flex: 1, minWidth: '150px' }}>
                  <select value={sortByDiscount} onChange={(e) => setSortByDiscount(e.target.value)} style={{ width: '100%', padding: '8px', borderRadius: '40px', border: '1px solid #dee2e6', background: 'white', color: DARK_NAVY }}>
                    <option value="none">Sort by Discount</option>
                    <option value="desc">Highest First</option>
                    <option value="asc">Lowest First</option>
                  </select>
                </div>
              </div>
            </FilterCard>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.5rem' }}>
              {filteredProducts.length > 0 ? filteredProducts.map((product, index) => (
                <ProductCard key={product.id} product={product} index={index} />
              )) : <div style={{ textAlign: 'center', padding: '3rem', color: '#cbd5e1' }}>No products match your criteria.</div>}
            </div>
          </div>
        );
      default:
        return <div style={{ padding: '3rem', textAlign: 'center', color: '#cbd5e1' }}>Content for {activeTab} coming soon.</div>;
    }
  };

  return (
    <DashboardWrapper>
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} isOpen={isSidebarOpen} />
      <MainContentContainer>
        <HeaderContainer style={{ position: 'sticky', top: 0, zIndex: 20 }}>
          <div style={{ padding: '1rem 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <button onClick={() => setSidebarOpen(!isSidebarOpen)} style={{ background: 'none', border: 'none', color: 'white', fontSize: '1.5rem', display: 'none', cursor: 'pointer' }} className="menu-button">
              ☰
            </button>
            <h1 style={{ fontSize: '1.5rem', fontWeight: 700, margin: 0 }}>{activeTab}</h1>
            <div style={{ display: 'flex', gap: '1rem' }}>
              <button style={{ background: 'none', border: 'none', color: 'white', cursor: 'pointer' }}>
                <svg width="24" height="24" fill="currentColor" viewBox="0 0 16 16"><path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/></svg>
              </button>
              <button style={{ background: 'none', border: 'none', color: 'white', cursor: 'pointer' }}>
                <svg width="24" height="24" fill="currentColor" viewBox="0 0 16 16"><path d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5l2.404.961L10.404 2l-2.218-.887zm3.564 1.426L5.596 5 8 5.961 14.154 3.5l-2.404-.961zm3.25 1.7-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923l6.5 2.6zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464L7.443.184z"/></svg>
              </button>
            </div>
          </div>
        </HeaderContainer>
        <div style={{ padding: '1.5rem' }}>
          {renderContent()}
        </div>
      </MainContentContainer>
      <style>{`
        @media (max-width: 992px) {
          .menu-button { display: block !important; }
        }
      `}</style>
    </DashboardWrapper>
  );
};

// --- Splash Screen Component (unchanged logic, improved styling) ---
const SplashScreen = ({ onFinished }) => {
  const [exit, setExit] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => {
      setExit(true);
      setTimeout(onFinished, 500);
    }, 3000);
    return () => clearTimeout(timer);
  }, [onFinished]);

  const Logo = () => (
    <svg width="80" height="80" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="#0d7c3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M2 7L12 12L22 7" stroke="#0d7c3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 12V22" stroke="#0d7c3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M17 4.5L7 9.5" stroke="#0a5e2e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );

  return (
    <SplashScreenContainer exit={exit}>
      <LogoContainer><Logo /></LogoContainer>
      <h1 style={{ fontSize: '1.8rem', fontWeight: 700, color: 'white', marginTop: '1rem', letterSpacing: '-0.5px' }}>MediStox</h1>
      <BounceContainer>
        <div /><div /><div />
      </BounceContainer>
    </SplashScreenContainer>
  );
};

// --- Main App Component (unchanged) ---
function App() {
  const [currentScreen, setCurrentScreen] = useState('splash');
  const handleSplashFinished = () => { setCurrentScreen('dashboard'); };

  useEffect(() => {
    // Bootstrap CSS is not required but kept for compatibility (no changes)
    const link = document.createElement('link');
    link.href = "https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css";
    link.rel = "stylesheet";
    document.head.appendChild(link);
    return () => { document.head.removeChild(link); };
  }, []);

  switch (currentScreen) {
    case 'splash': return <SplashScreen onFinished={handleSplashFinished} />;
    case 'dashboard': return <RetailDashboard />;
    default: return <SplashScreen onFinished={handleSplashFinished} />;
  }
}

export default App;