import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import styled, { keyframes } from 'styled-components';
import BaseUrl from './BaseUrl';

/* ─────────────────────────────────────────────────────────────────────────────
   RAZORPAY HOOK (unchanged)
───────────────────────────────────────────────────────────────────────────── */
const useRazorpay = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  useEffect(() => {
    if (window.Razorpay) { setIsLoaded(true); return; }
    const s = document.createElement('script');
    s.src = 'https://checkout.razorpay.com/v1/checkout.js';
    s.async = true;
    s.onload = () => setIsLoaded(true);
    s.onerror = () => setIsLoaded(false);
    document.body.appendChild(s);
    return () => {
      const ex = document.querySelector('script[src="https://checkout.razorpay.com/v1/checkout.js"]');
      if (ex) document.body.removeChild(ex);
    };
  }, []);
  return isLoaded;
};

/* ─────────────────────────────────────────────────────────────────────────────
   ANIMATIONS (unchanged)
───────────────────────────────────────────────────────────────────────────── */
const fadeUp   = keyframes`from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}`;
const spinAnim = keyframes`to{transform:rotate(360deg)}`;

/* ─────────────────────────────────────────────────────────────────────────────
   PHARMACY THEME TOKENS + RESPONSIVE BREAKPOINTS
───────────────────────────────────────────────────────────────────────────── */
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN    = '#E8F5E9';
const DANGER_RED     = '#C0392B';
const AMBER          = '#F39C12';
const DARK_NAVY      = '#1A2E4A';
const BORDER_GREY    = '#DEE2E6';
const CARD_SHADOW    = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW   = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

const ACCENT_GRADIENT = `linear-gradient(135deg, ${PHARMACY_GREEN} 0%, #0F9D4E 100%)`;

const breakpoints = {
  mobile:  '480px',
  tablet:  '768px',
  desktop: '1024px',
};

/* ─────────────────────────────────────────────────────────────────────────────
   SHARED STYLED COMPONENTS (improved + responsive)
───────────────────────────────────────────────────────────────────────────── */
const Page = styled.div`
  font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
  background: ${LIGHT_GREEN};
  min-height: 100vh;
  padding: 20px;
  @media (min-width: 768px) { padding: 32px; }
  @media (min-width: 1024px) { padding: 40px; }
`;

const PageHeader = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-bottom: 28px;
  @media (min-width: 768px) {
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
  }
`;

const HeaderLeft = styled.div``;

const PageTitleText = styled.h2`
  font-size: 1.5rem;
  font-weight: 700;
  color: ${DARK_NAVY};
  margin: 0 0 4px;
  letter-spacing: -0.3px;
  @media (min-width: 768px) { font-size: 1.6rem; }
  em { color: ${PHARMACY_GREEN}; font-style: normal; }
`;

const PageSubText = styled.p`
  font-size: 0.8rem;
  color: #6c757d;
  margin: 0;
  @media (min-width: 768px) { font-size: 0.85rem; }
`;

const StatsRow = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
  margin-bottom: 32px;
  @media (min-width: 640px) { grid-template-columns: repeat(3, 1fr); }
  @media (min-width: 1024px) { gap: 24px; }
`;

const StatCard = styled.div`
  background: white;
  border-radius: 20px;
  padding: 16px 20px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: ${CARD_SHADOW};
  border: 1px solid ${BORDER_GREY};
  transition: all 0.2s;
  &:hover { transform: translateY(-2px); box-shadow: ${HOVER_SHADOW}; }
  @media (min-width: 768px) { padding: 20px 24px; gap: 16px; }
`;

const StatIcon = styled.div`
  width: 44px; height: 44px;
  border-radius: 16px;
  background: ${p => p.$bg || `${PHARMACY_GREEN}10`};
  display: flex; align-items: center; justify-content: center;
  font-size: 1.4rem;
  flex-shrink: 0;
  @media (min-width: 768px) { width: 52px; height: 52px; font-size: 1.6rem; }
`;

const StatLabel = styled.div`
  font-size: 0.65rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.8px;
  color: #6c757d;
  margin-bottom: 4px;
  @media (min-width: 768px) { font-size: 0.7rem; }
`;
const StatValue = styled.div`
  font-size: 1.5rem;
  font-weight: 800;
  color: ${p => p.$color || DARK_NAVY};
  line-height: 1.2;
  @media (min-width: 768px) { font-size: 1.8rem; }
`;

const AdGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 20px;
  @media (min-width: 640px) { grid-template-columns: repeat(2, 1fr); }
  @media (min-width: 1024px) { grid-template-columns: repeat(3, 1fr); gap: 28px; }
`;

const AdCard = styled.div`
  background: white;
  border-radius: 24px;
  overflow: hidden;
  transition: all 0.25s ease;
  animation: ${fadeUp} 0.4s ease both;
  animation-delay: ${p => p.$i * 60}ms;
  box-shadow: ${CARD_SHADOW};
  border: 1px solid ${BORDER_GREY};
  display: flex;
  flex-direction: column;
  &:hover {
    transform: translateY(-4px);
    box-shadow: ${HOVER_SHADOW};
    border-color: ${PHARMACY_GREEN}40;
  }
`;

const AdCardImg = styled.img`
  width: 100%;
  height: 160px;
  object-fit: cover;
  display: block;
  background: #f8f9fa;
  @media (min-width: 768px) { height: 180px; }
`;

const AdCardBody = styled.div`
  padding: 16px;
  flex: 1;
  @media (min-width: 768px) { padding: 20px 22px; }
`;

const AdCardTop = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 8px;
  flex-wrap: wrap;
`;

const AdCardTitle = styled.div`
  font-size: 0.9rem;
  font-weight: 700;
  color: ${DARK_NAVY};
  line-height: 1.35;
  @media (min-width: 768px) { font-size: 1rem; }
`;

const AdCardLoc = styled.div`
  font-size: 0.75rem;
  color: #6c757d;
  margin-bottom: 14px;
  display: flex;
  align-items: center;
  gap: 4px;
  @media (min-width: 768px) { font-size: 0.8rem; }
`;

const AdMetaRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.75rem;
  color: #495057;
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
  &:last-child { border-bottom: none; }
  @media (min-width: 768px) { font-size: 0.82rem; padding: 10px 0; }
`;

const AdMetaVal = styled.span`
  font-weight: 700;
  color: ${p => p.$green ? PHARMACY_GREEN : DARK_NAVY};
`;

const AdCardFooter = styled.div`
  padding: 10px 16px;
  border-top: 1px solid #f0f0f0;
  font-size: 0.65rem;
  color: #8b96a5;
  background: #fefefe;
  @media (min-width: 768px) { padding: 12px 22px; font-size: 0.7rem; }
`;

const Badge = styled.span`
  display: inline-flex;
  align-items: center;
  font-size: 0.65rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  padding: 3px 10px;
  border-radius: 30px;
  white-space: nowrap;
  background: ${p =>
    p.$v === 'paid'             ? `${PHARMACY_GREEN}10` :
    p.$v === 'active'           ? '#E3F2FD' :
    p.$v === 'pending_approval' ? '#FFF3E0' : '#F2F4F8'};
  color: ${p =>
    p.$v === 'paid'             ? PHARMACY_GREEN :
    p.$v === 'active'           ? '#1565C0' :
    p.$v === 'pending_approval' ? AMBER : '#6c757d'};
  border: none;
  @media (min-width: 768px) { font-size: 0.7rem; padding: 4px 12px; }
`;

const EmptyBox = styled.div`
  background: white;
  border-radius: 28px;
  padding: 48px 20px;
  text-align: center;
  box-shadow: ${CARD_SHADOW};
  border: 1px solid ${BORDER_GREY};
  @media (min-width: 768px) { padding: 64px 32px; }
`;

const EmptyIcon = styled.div`
  font-size: 3rem;
  margin-bottom: 16px;
  opacity: 0.6;
  @media (min-width: 768px) { font-size: 3.5rem; }
`;
const EmptyTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 700;
  color: ${DARK_NAVY};
  margin: 0 0 8px;
  @media (min-width: 768px) { font-size: 1.3rem; }
`;
const EmptyText = styled.p`
  font-size: 0.8rem;
  color: #6c757d;
  margin: 0 0 20px;
  @media (min-width: 768px) { font-size: 0.88rem; }
`;

const SpinnerWrap = styled.div`
  display: flex;
  justify-content: center;
  padding: 60px 20px;
  @media (min-width: 768px) { padding: 80px; }
`;
const SpinRing = styled.div`
  width: 36px; height: 36px;
  border-radius: 50%;
  border: 3px solid #e9ecef;
  border-top-color: ${PHARMACY_GREEN};
  animation: ${spinAnim} 0.8s linear infinite;
  @media (min-width: 768px) { width: 40px; height: 40px; }
`;

const Alert = styled.div`
  padding: 12px 16px;
  border-radius: 14px;
  font-size: 0.8rem;
  margin-bottom: 24px;
  background: #FEF3F2;
  border-left: 4px solid ${DANGER_RED};
  color: ${DANGER_RED};
  @media (min-width: 768px) { padding: 14px 18px; font-size: 0.85rem; }
`;

const PrimaryBtn = styled.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: ${p => p.$lg ? '10px 20px' : '8px 16px'};
  background: ${ACCENT_GRADIENT};
  border: none;
  border-radius: 40px;
  color: white;
  font-family: inherit;
  font-size: ${p => p.$lg ? '0.85rem' : '0.8rem'};
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 10px rgba(13,124,61,0.25);
  white-space: nowrap;
  width: 100%;
  @media (min-width: 480px) { width: auto; }
  &:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(13,124,61,0.35); }
  &:disabled { opacity: 0.5; cursor: not-allowed; transform: none; box-shadow: none; }
  @media (min-width: 768px) {
    padding: ${p => p.$lg ? '12px 28px' : '10px 20px'};
    font-size: ${p => p.$lg ? '0.9rem' : '0.85rem'};
  }
`;

const BackBtn = styled.button`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  color: ${PHARMACY_GREEN};
  font-family: inherit;
  font-size: 0.8rem;
  font-weight: 600;
  cursor: pointer;
  padding: 0;
  margin-bottom: 20px;
  transition: color 0.15s;
  &:hover { color: ${DARK_NAVY}; }
  @media (min-width: 768px) { font-size: 0.85rem; margin-bottom: 24px; }
`;

/* ─────────────────────────────────────────────────────────────────────────────
   FORM STYLED COMPONENTS (responsive)
───────────────────────────────────────────────────────────────────────────── */
const FormWrap = styled.div`
  max-width: 100%;
  @media (min-width: 768px) { max-width: 720px; margin: 0 auto; }
`;

const FormSection = styled.div`
  background: white;
  border-radius: 24px;
  overflow: hidden;
  margin-bottom: 20px;
  box-shadow: ${CARD_SHADOW};
  border: 1px solid ${BORDER_GREY};
`;

const FormSectionHead = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 20px;
  border-bottom: 1px solid #f0f0f0;
  @media (min-width: 768px) { padding: 18px 24px; }
`;

const StepNum = styled.div`
  width: 28px; height: 28px;
  border-radius: 10px;
  background: ${`${PHARMACY_GREEN}10`};
  border: 1px solid ${`${PHARMACY_GREEN}30`};
  display: flex; align-items: center; justify-content: center;
  font-size: 0.8rem; font-weight: 800; color: ${PHARMACY_GREEN};
  @media (min-width: 768px) { width: 30px; height: 30px; font-size: 0.85rem; }
`;

const FormSectionTitle = styled.h5`
  font-size: 0.9rem;
  font-weight: 700;
  color: ${DARK_NAVY};
  margin: 0;
  @media (min-width: 768px) { font-size: 1rem; }
`;

const FormBody = styled.div`
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  @media (min-width: 768px) { padding: 24px; }
`;

const FieldGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  @media (min-width: 640px) {
    display: grid;
    grid-template-columns: ${p => p.$cols || '1fr 1fr'};
    gap: 20px;
  }
`;

const Field = styled.div`display: flex; flex-direction: column; gap: 6px;`;

const Label = styled.label`
  font-size: 0.65rem;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: #6c757d;
  font-weight: 700;
  @media (min-width: 768px) { font-size: 0.7rem; }
`;

const Input = styled.input`
  width: 100%;
  background: white;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 14px;
  padding: 10px 14px;
  color: ${DARK_NAVY};
  font-family: inherit;
  font-size: 0.85rem;
  outline: none;
  transition: all 0.2s;
  box-sizing: border-box;
  &:focus { border-color: ${PHARMACY_GREEN}; box-shadow: 0 0 0 3px ${`${PHARMACY_GREEN}20`}; background: white; }
  &::placeholder { color: #adb5bd; }
  @media (min-width: 768px) { padding: 12px 16px; font-size: 0.9rem; }
`;

const Select = styled.select`
  width: 100%;
  background: white;
  border: 1.5px solid ${BORDER_GREY};
  border-radius: 14px;
  padding: 10px 14px;
  color: ${DARK_NAVY};
  font-family: inherit;
  font-size: 0.85rem;
  outline: none;
  appearance: none;
  transition: all 0.2s;
  box-sizing: border-box;
  &:focus { border-color: ${PHARMACY_GREEN}; box-shadow: 0 0 0 3px ${`${PHARMACY_GREEN}20`}; background: white; }
  @media (min-width: 768px) { padding: 12px 16px; font-size: 0.9rem; }
`;

const FileHint = styled.div`
  font-size: 0.7rem;
  color: ${PHARMACY_GREEN};
  margin-top: 4px;
  display: flex;
  align-items: center;
  gap: 6px;
  font-weight: 500;
`;

const DurationGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  @media (min-width: 768px) { gap: 12px; }
`;

const DurationCard = styled.div`
  background: ${p => p.$active ? `${PHARMACY_GREEN}08` : 'white'};
  border: 1.5px solid ${p => p.$active ? PHARMACY_GREEN : BORDER_GREY};
  border-radius: 18px;
  padding: 12px 6px;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s;
  box-shadow: ${p => p.$active ? `0 0 0 2px ${`${PHARMACY_GREEN}20`}` : 'none'};
  &:hover { border-color: ${PHARMACY_GREEN}; background: ${`${PHARMACY_GREEN}05`}; }
  @media (min-width: 768px) { padding: 14px 10px; border-radius: 20px; }
`;

const DurDays = styled.div`
  font-size: 0.9rem;
  font-weight: 800;
  color: ${DARK_NAVY};
  @media (min-width: 768px) { font-size: 1rem; }
`;
const DurPrice = styled.div`
  font-size: 0.7rem;
  color: ${p => p.$active ? PHARMACY_GREEN : '#8b96a5'};
  margin-top: 4px;
  font-weight: 600;
  @media (min-width: 768px) { font-size: 0.8rem; margin-top: 5px; }
`;

const CtaBar = styled.div`
  background: white;
  border-radius: 24px;
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  align-items: stretch;
  box-shadow: ${CARD_SHADOW};
  border: 1px solid ${BORDER_GREY};
  @media (min-width: 640px) {
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    padding: 20px 28px;
  }
`;

const TotalLabel = styled.div`
  font-size: 0.65rem;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: #6c757d;
  margin-bottom: 4px;
  @media (min-width: 768px) { font-size: 0.7rem; }
`;
const TotalValue = styled.div`
  font-size: 1.6rem;
  font-weight: 800;
  color: ${PHARMACY_GREEN};
  letter-spacing: -0.5px;
  @media (min-width: 768px) { font-size: 2rem; }
`;

/* ─────────────────────────────────────────────────────────────────────────────
   STATUS BADGE COMPONENT (unchanged)
───────────────────────────────────────────────────────────────────────────── */
const STATUS_LABELS = {
  paid:             'Paid',
  active:           'Active',
  pending_approval: 'Pending Approval',
  pending:          'Pending Payment',
};

const StatusBadge = ({ status }) => (
  <Badge $v={status}>{STATUS_LABELS[status] || status || 'Unknown'}</Badge>
);

/* ─────────────────────────────────────────────────────────────────────────────
   COST MAP (unchanged)
───────────────────────────────────────────────────────────────────────────── */
const COST_MAP = {
  'Dashboard Banner': { 7: 350,  15: 600,  30: 1000 },
  'Search Results':   { 7: 500,  15: 850,  30: 1500 },
};

/* ─────────────────────────────────────────────────────────────────────────────
   AD FORM (logic untouched, UI + responsive)
───────────────────────────────────────────────────────────────────────────── */
const AdForm = ({ onBack, API_BASE_URL }) => {
  const [adTitle,      setAdTitle]      = useState('');
  const [location,     setLocation]     = useState('Dashboard Banner');
  const [duration,     setDuration]     = useState(7);
  const [bannerFile,   setBannerFile]   = useState(null);
  const [scheduleDate, setScheduleDate] = useState(new Date().toISOString().split('T')[0]);
  const [error,        setError]        = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isRazorpayLoaded = useRazorpay();
  const RAZORPAY_KEY     = 'rzp_test_RJ8BApOSPnF5hq';
  const today            = new Date().toISOString().split('T')[0];
  const totalCost        = COST_MAP[location]?.[duration] || 0;

  const handlePay = () => {
    setError('');
    if (!adTitle || !bannerFile || !scheduleDate) {
      setError('All fields including a schedule date are required.');
      return;
    }
    setIsSubmitting(true);

    const options = {
      key:         RAZORPAY_KEY,
      amount:      totalCost * 100,
      currency:    'INR',
      name:        'MediStox Ads',
      description: `Campaign: ${adTitle}`,
      handler: async (response) => {
        try {
          const userId = localStorage.getItem('user_id');
          if (!userId) throw new Error('User not logged in.');
          
          // 1. Create ad request and get presigned URL
          const res = await axios.post(`${API_BASE_URL}/ads/request-ad`, {
            user_id:               userId,
            ad_title:              adTitle,
            banner_filename:       bannerFile.name,
            duration_days:         duration,
            location,
            payment_amount:        totalCost,
            payment_id:            response.razorpay_payment_id,
            payment_status:        'paid',
            payment_schedule_date: scheduleDate,
          });

          // 2. Upload file to S3 using presigned URL
          if (res.data.presigned_upload_url) {
            await axios.put(res.data.presigned_upload_url, bannerFile, {
              headers: {
                'Content-Type': bannerFile.type || 'application/octet-stream'
              }
            });
          }

          alert('Payment successful and banner uploaded! Your ad has been submitted for review.');
          onBack();
        } catch (err) {
          console.error('Ad submission error:', err);
          setError('Payment done but submission/upload failed. Please contact support with Payment ID: ' + response.razorpay_payment_id);
          setIsSubmitting(false);
        }
      },
      prefill: { name: 'MediStox User', email: 'user@example.com' },
      theme:   { color: PHARMACY_GREEN },
      modal:   { ondismiss: () => setIsSubmitting(false) },
    };

    const rzp = new window.Razorpay(options);
    rzp.on('payment.failed', r => {
      setError(`Payment failed: ${r.error.description}`);
      setIsSubmitting(false);
    });
    rzp.open();
  };

  return (
    <FormWrap>
      <BackBtn onClick={onBack}>← Back to Campaigns</BackBtn>
      {error && <Alert>⚠ {error}</Alert>}

      <FormSection>
        <FormSectionHead>
          <StepNum>1</StepNum>
          <FormSectionTitle>Ad Details</FormSectionTitle>
        </FormSectionHead>
        <FormBody>
          <Field>
            <Label>Ad Title</Label>
            <Input
              type="text"
              placeholder="e.g., Summer Sale Campaign"
              value={adTitle}
              onChange={e => setAdTitle(e.target.value)}
            />
          </Field>
          <Field>
            <Label>Banner Image (PNG or JPG)</Label>
            <Input
              type="file"
              accept="image/png,image/jpeg"
              onChange={e => setBannerFile(e.target.files[0])}
            />
            {bannerFile && <FileHint>✓ {bannerFile.name}</FileHint>}
          </Field>
        </FormBody>
      </FormSection>

      <FormSection>
        <FormSectionHead>
          <StepNum>2</StepNum>
          <FormSectionTitle>Targeting & Schedule</FormSectionTitle>
        </FormSectionHead>
        <FormBody>
          <FieldGroup $cols="1fr 1fr">
            <Field>
              <Label>Display Location</Label>
              <Select value={location} onChange={e => setLocation(e.target.value)}>
                <option>Dashboard Banner</option>
                <option>Search Results</option>
              </Select>
            </Field>
            <Field>
              <Label>Schedule Start Date</Label>
              <Input
                type="date"
                value={scheduleDate}
                min={today}
                onChange={e => setScheduleDate(e.target.value)}
              />
            </Field>
          </FieldGroup>

          <Field>
            <Label>Campaign Duration</Label>
            <DurationGrid>
              {[7, 15, 30].map(d => (
                <DurationCard key={d} $active={duration === d} onClick={() => setDuration(d)}>
                  <DurDays>{d} Days</DurDays>
                  <DurPrice $active={duration === d}>₹{COST_MAP[location]?.[d]}</DurPrice>
                </DurationCard>
              ))}
            </DurationGrid>
          </Field>
        </FormBody>
      </FormSection>

      <CtaBar>
        <div>
          <TotalLabel>Total Cost</TotalLabel>
          <TotalValue>₹{totalCost}</TotalValue>
        </div>
        <PrimaryBtn
          $lg
          disabled={!isRazorpayLoaded || isSubmitting}
          onClick={handlePay}
        >
          {!isRazorpayLoaded
            ? '⏳ Loading…'
            : isSubmitting
              ? '⏳ Processing…'
              : '⚡ Pay & Launch Campaign'}
        </PrimaryBtn>
      </CtaBar>
    </FormWrap>
  );
};

/* ─────────────────────────────────────────────────────────────────────────────
   MAIN AD MANAGEMENT COMPONENT (logic untouched, UI + responsive)
───────────────────────────────────────────────────────────────────────────── */
const AdManagement = () => {
  const [view,      setView]      = useState('list');
  const [ads,       setAds]       = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error,     setError]     = useState('');

  const API_BASE_URL = BaseUrl;
  const userId       = localStorage.getItem('user_id');

  const fetchAds = useCallback(async () => {
    if (!userId) {
      setError('You must be logged in to manage your ads.');
      setIsLoading(false);
      setAds([]);
      return;
    }
    try {
      setIsLoading(true);
      const res = await axios.get(`${API_BASE_URL}/ads/user/${userId}`);
      setAds(res.data);
      setError('');
    } catch {
      setError('Failed to fetch your ads. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [API_BASE_URL, userId]);

  useEffect(() => {
    if (view === 'list') fetchAds();
  }, [view, fetchAds]);

  const activeCount  = ads.filter(a => a.status === 'active').length;
  const pendingCount = ads.filter(a => a.status?.includes('pending')).length;

  if (view === 'form') {
    return (
      <Page>
        <PageHeader>
          <HeaderLeft>
            <PageTitleText>New <em>Campaign</em></PageTitleText>
            <PageSubText>Fill in the details to launch your ad</PageSubText>
          </HeaderLeft>
        </PageHeader>
        <AdForm onBack={() => setView('list')} API_BASE_URL={API_BASE_URL} />
      </Page>
    );
  }

  return (
    <Page>
      <PageHeader>
        <HeaderLeft>
          <PageTitleText>Ad <em>Campaigns</em></PageTitleText>
          <PageSubText>Create and manage your advertising campaigns on MediStox.</PageSubText>
        </HeaderLeft>
        <PrimaryBtn onClick={() => setView('form')} disabled={!userId}>
          ＋ New Campaign
        </PrimaryBtn>
      </PageHeader>

      {!isLoading && ads.length > 0 && (
        <StatsRow>
          <StatCard>
            <StatIcon $bg={`${PHARMACY_GREEN}10`}>📊</StatIcon>
            <div>
              <StatLabel>Total Ads</StatLabel>
              <StatValue>{ads.length}</StatValue>
            </div>
          </StatCard>
          <StatCard>
            <StatIcon $bg="#E3F2FD">✅</StatIcon>
            <div>
              <StatLabel>Active</StatLabel>
              <StatValue $color="#1565C0">{activeCount}</StatValue>
            </div>
          </StatCard>
          <StatCard>
            <StatIcon $bg="#FFF3E0">⏳</StatIcon>
            <div>
              <StatLabel>Pending</StatLabel>
              <StatValue $color={AMBER}>{pendingCount}</StatValue>
            </div>
          </StatCard>
        </StatsRow>
      )}

      {isLoading && (
        <SpinnerWrap><SpinRing /></SpinnerWrap>
      )}

      {error && <Alert>⚠ {error}</Alert>}

      {!isLoading && !error && ads.length === 0 && (
        <EmptyBox>
          <EmptyIcon>📢</EmptyIcon>
          <EmptyTitle>{userId ? 'No campaigns yet' : 'Please log in'}</EmptyTitle>
          <EmptyText>
            {userId
              ? 'Launch your first ad campaign to reach more customers on MediStox.'
              : 'You need to be logged in to create and view ad campaigns.'}
          </EmptyText>
          {userId && (
            <PrimaryBtn onClick={() => setView('form')} style={{ margin: '0 auto' }}>
              ＋ Create Your First Ad
            </PrimaryBtn>
          )}
        </EmptyBox>
      )}

      {!isLoading && ads.length > 0 && (
        <AdGrid>
          {ads.map((ad, i) => (
            <AdCard key={ad.id} $i={i}>
              <AdCardImg
                src={ad.banner_image_url || 'https://placehold.co/400x170/f5f7fa/9ca3af?text=Banner+Pending'}
                alt={ad.ad_title}
                onError={e => { e.target.src = 'https://placehold.co/400x170/f5f7fa/9ca3af?text=Banner+Pending'; }}
              />
              <AdCardBody>
                <AdCardTop>
                  <AdCardTitle>{ad.ad_title}</AdCardTitle>
                  <StatusBadge status={ad.status} />
                </AdCardTop>
                <AdCardLoc>📍 {ad.location}</AdCardLoc>
                <AdMetaRow>
                  <span>Duration</span>
                  <AdMetaVal>{ad.duration_days} Days</AdMetaVal>
                </AdMetaRow>
                <AdMetaRow>
                  <span>Amount</span>
                  <AdMetaVal $green>₹{ad.payment_amount}</AdMetaVal>
                </AdMetaRow>
                <AdMetaRow>
                  <span>Payment</span>
                  <StatusBadge status={ad.payment_status} />
                </AdMetaRow>
              </AdCardBody>
              <AdCardFooter>🕒 Created {ad.created_at}</AdCardFooter>
            </AdCard>
          ))}
        </AdGrid>
      )}
    </Page>
  );
};

export default AdManagement;