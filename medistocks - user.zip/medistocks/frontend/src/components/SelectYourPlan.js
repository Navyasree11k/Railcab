import React, { useState } from 'react';
import styled, { createGlobalStyle } from 'styled-components';
import { useNavigate, useLocation } from 'react-router-dom';

// --- Global Styles for a modern theme ---
const GlobalStyle = createGlobalStyle`
  body {
    background-color: #f0f4f8; // Fallback background
    background-image: linear-gradient(to top right, #e0e7ff, #f8fafc);
  }
`;

// --- Styled Components (Enhanced for better UI/UX) ---
const PageWrapper = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  padding-bottom: 120px; /* Space for the sticky footer */
`;

const PlanContainer = styled.div`
  width: 100%;
  max-width: 950px;
`;

const PlansGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
`;

const PlanCard = styled.div`
  background: #ffffff;
  border: 2px solid ${({ active }) => (active ? '#4f46e5' : '#e5e7eb')};
  border-radius: 1rem;
  padding: 1.5rem;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  box-shadow: ${({ active }) =>
    active
      ? '0 10px 25px -5px rgba(79, 70, 229, 0.2), 0 8px 10px -6px rgba(79, 70, 229, 0.2)'
      : '0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05)'};

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
  }
`;

const PopularTag = styled.div`
  position: absolute;
  top: 15px;
  right: -45px;
  background-color: #f59e0b;
  color: #fff;
  padding: 0.3rem 3rem;
  font-size: 0.75rem;
  font-weight: 600;
  transform: rotate(45deg);
  letter-spacing: 0.5px;
`;

// NEW: Checkmark for selected card
const SelectedCheckmark = styled.div`
  position: absolute;
  top: 1rem;
  left: 1rem;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background-color: #4f46e5;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
  opacity: ${({ active }) => (active ? 1 : 0)};
  transform: ${({ active }) => (active ? 'scale(1)' : 'scale(0.5)')};
  transition: opacity 0.3s ease, transform 0.3s ease;
`;

const PlanButton = styled.button`
  width: 100%;
  padding: 0.75rem;
  border-radius: 0.5rem;
  font-weight: 600;
  margin-top: 1.5rem;
  transition: all 0.2s ease-in-out;
  background-color: ${({ active }) => (active ? '#4f46e5' : '#f3f4f6')};
  color: ${({ active }) => (active ? '#fff' : '#374151')};
  border: 1px solid ${({ active }) => (active ? '#4f46e5' : '#d1d5db')};

  &:hover {
    background-color: ${({ active }) => (active ? '#4338ca' : '#e5e7eb')};
  }
`;

const StickyFooter = styled.footer`
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(10px);
    padding: 1.5rem 1rem;
    border-top: 1px solid #e5e7eb;
    z-index: 1000;
    box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.05);
`;

const ContinueButton = styled.button`
  width: 100%;
  background-color: #4f46e5;
  border-color: #4f46e5;
  font-weight: 600;
  padding: 1rem;
  font-size: 1.1rem;
  transition: background-color 0.2s;
  &:hover {
    background-color: #4338ca;
    border-color: #4338ca;
  }
  &:disabled {
    background-color: #a5b4fc;
    border-color: #a5b4fc;
    cursor: not-allowed;
  }
`;

// --- Main Plan Selection Component ---
const PlanSelection = () => {
  const [selectedPlan, setSelectedPlan] = useState('gold'); // Default to popular plan
  const navigate = useNavigate();
  const location = useLocation();
  const role = location.state?.role || 'user'; // Default role if not passed

  const plans = [
    { id: 'silver', name: 'Silver', price: '₹999', icon: '🛡️', features: ['25 Chat Messages/Month', 'Static Product Search', '5 Purchase Requests/Day', 'Email Support'] },
    { id: 'gold', name: 'Gold', price: '₹1,999', icon: '👑', popular: true, features: ['50 Chat Messages/Month', 'Advanced Product Search', '20 Purchase Requests/Day', 'Priority Email Support', 'Invoice Generation'] },
    { id: 'platinum', name: 'Platinum', price: '₹3,999', icon: '💎', features: ['Unlimited Chat Messages', 'AI-Powered Search', 'Unlimited Purchase Requests', '24/7 Priority Support', 'Dedicated Account Manager'] },
  ];

  return (
    <>
      <GlobalStyle />
      <PageWrapper>
        <PlanContainer>
          <div className="text-center mb-5">
            <p className="text-primary fw-bold" style={{ color: '#4f46e5' }}>Step 3 of 5</p>
            <h1 className="fw-bolder text-dark">Select Your Perfect Plan</h1>
            <p className="text-secondary fs-5">Choose the plan that best fits your business needs.</p>
          </div>

          <PlansGrid>
            {plans.map(plan => {
              const isActive = selectedPlan === plan.id;
              return (
                <PlanCard 
                  key={plan.id} 
                  active={isActive} 
                  onClick={() => setSelectedPlan(plan.id)}
                >
                  {plan.popular && <PopularTag>POPULAR</PopularTag>}
                  <SelectedCheckmark active={isActive}>✓</SelectedCheckmark>
                  
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <h3 className="fw-bold text-dark mb-0">{plan.name}</h3>
                    <div style={{fontSize: '2.5rem'}}>{plan.icon}</div>
                  </div>
                  
                  <h2 className="text-dark fw-bolder mb-3">{plan.price}<span className="text-secondary fw-normal fs-6">/month</span></h2>
                  
                  <ul className="list-unstyled text-secondary" style={{ paddingLeft: '5px' }}>
                    {plan.features.map(feature => (
                      <li key={feature} className="d-flex align-items-center mb-2">
                        <span className="text-success me-2">✔</span> {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <PlanButton active={isActive}>
                    {isActive ? 'Plan Selected' : 'Choose Plan'}
                  </PlanButton>
                </PlanCard>
              );
            })}
          </PlansGrid>
        </PlanContainer>

        <StickyFooter>
          <div className="container d-grid" style={{ maxWidth: '740px' }}>
            <ContinueButton 
              className="btn btn-primary" 
              disabled={!selectedPlan}
              onClick={() => navigate('/plan-purchase', { state: { role, plan: selectedPlan } })}
            >
              Continue with {plans.find(p => p.id === selectedPlan)?.name} Plan
            </ContinueButton>
          </div>
        </StickyFooter>
      </PageWrapper>
    </>
  );
};

export default PlanSelection;