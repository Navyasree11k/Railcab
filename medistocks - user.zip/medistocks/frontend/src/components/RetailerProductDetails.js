import React, { useState } from 'react';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import axios from 'axios';
import { 
    FaShoppingCart, FaInfoCircle, FaCalendarTimes, FaTags, FaPaperPlane, 
    FaSpinner, FaExclamationCircle, FaComments, FaBuilding, FaMapMarkerAlt,
    FaFlask, FaWeightHanging, FaCalendarAlt, FaCalendarCheck,
    FaCartPlus 
} from 'react-icons/fa';
import BaseUrl from './BaseUrl';
import { useDispatch, useSelector } from 'react-redux';
import { startNewChat } from './redux/chatSlice';
// We no longer need to import addToCart from cartSlice
// import { addToCart } from './redux/cartSlice'; 

// --- Global Styles & Animations ---
const GlobalStyle = createGlobalStyle`
  body {
    background-color: #f8fafc;
    font-family: 'Inter', sans-serif;
  }
`;
const fadeIn = keyframes`from { opacity: 0; } to { opacity: 1; }`;
const spin = keyframes`from { transform: rotate(0deg); } to { transform: rotate(360deg); }`;
const slideUp = keyframes`from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; }`;

// --- NEW ---
// Added a spinner icon component for the button
const SpinnerIcon = styled(FaSpinner)`
  animation: ${spin} 1s linear infinite;
`;

// Added an error message component
const ErrorMessage = styled.p`
  color: #dc3545;
  font-size: 0.9rem;
  text-align: center;
  margin-top: 0.5rem;
  margin-bottom: 0;
`;

// --- Styled Components (Unchanged) ---
const PageContainer = styled.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
  animation: ${fadeIn} 0.6s ease-out;
`;
const ProductGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1.2fr;
  gap: 3rem;
  align-items: flex-start;
  @media (max-width: 992px) {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
`;
const ImageGallery = styled.div`
  background: white;
  border-radius: 1rem;
  padding: 1rem;
  border: 1px solid #e2e8f0;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  position: sticky;
  top: 2rem;
`;
const MainImage = styled.img`
  width: 100%;
  height: auto;
  aspect-ratio: 1 / 1;
  object-fit: contain;
  border-radius: 0.75rem;
`;
const ProductDetailsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;
const ProductCard = styled.div`
  background: white;
  border-radius: 1rem;
  padding: 2rem;
  border: 1px solid #e2e8f0;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  animation: ${slideUp} 0.5s ease-out backwards;
  animation-delay: ${props => props.$delay || '0s'};
`;
const ProductHeader = styled.div`
  border-bottom: 1px solid #e9ecef;
  padding-bottom: 1.5rem;
  margin-bottom: 1.5rem;
  h1 { font-size: 2.25rem; font-weight: 800; color: #111827; margin: 0; }
  p { font-size: 1.1rem; color: #64748b; margin-top: 0.5rem; }
`;
const PriceSection = styled.div`
  display: flex; align-items: baseline; gap: 1rem; margin: 1.5rem 0;
`;
const FinalPrice = styled.span` font-size: 2.75rem; font-weight: 800; color: #4f46e5; `;
const OriginalPrice = styled.s` font-size: 1.5rem; color: #94a3b8; `;
const DiscountBadge = styled.span` background-color: #10b981; color: white; padding: 0.4rem 0.8rem; border-radius: 99px; font-weight: 600; font-size: 0.875rem; `;
const ActionButton = styled.button`
  width: 100%; padding: 1rem; font-size: 1.1rem; font-weight: 600; border: none; border-radius: 0.75rem;
  cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 0.75rem;
  transition: all 0.2s ease-in-out;
  background-color: ${props => props.$primary ? '#4f46e5' : '#ffffff'};
  color: ${props => props.$primary ? 'white' : '#334155'};
  border: 2px solid ${props => props.$primary ? '#4f46e5' : '#cbd5e1'};

  &:hover { 
    transform: translateY(-3px); 
    box-shadow: 0 6px 20px rgba(0,0,0,0.1); 
    border-color: #4338ca;
    background-color: ${props => props.$primary ? '#4338ca' : '#f8fafc'};
  }
  &:disabled { background-color: #e2e8f0; color: #94a3b8; border-color: #e2e8f0; cursor: not-allowed; }
`;
const ActionButtonsContainer = styled.div`
  display: flex; flex-direction: column; gap: 1rem; margin-top: 1.5rem;
`;
const AlreadyRequestedInfo = styled.div`
    text-align: center;
    padding: 1.25rem;
    border: 2px dashed #a5b4fc;
    background-color: #eef2ff;
    border-radius: 0.75rem;
    color: #4338ca;
    animation: ${fadeIn} 0.5s;
    
    p {
        margin: 0 0 1rem 0;
        font-weight: 500;
        font-size: 0.95rem;
    }

    button {
        padding: 0.5rem 1.5rem;
        border-radius: 0.5rem;
        background-color: #4f46e5;
        color: white;
        border: none;
        cursor: pointer;
        font-weight: 600;
        transition: background-color 0.2s ease;

        &:hover {
            background-color: #4338ca;
        }
    }
`;
const InfoGrid = styled.div`
  display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem;
`;
const InfoBlock = styled.div`
  display: flex; align-items: flex-start; gap: 1rem; font-size: 1rem; color: #334155;
  svg { color: #4f46e5; margin-top: 5px; flex-shrink: 0; }
  strong { color: #1e293b; }
`;
const ExpiryBar = styled.div`
  width: 100%; height: 8px; background-color: #e9ecef; border-radius: 4px; overflow: hidden; margin-top: 0.5rem;
`;
const ExpiryFill = styled.div`
  height: 100%;
  background-color: ${p => p.$percentage > 80 ? '#ef4444' : p.$percentage > 50 ? '#f59e0b' : '#10b981'};
  width: ${p => p.$percentage}%;
  transition: width 0.5s ease;
`;
const ModalBackdrop = styled.div`
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  background-color: rgba(0, 0, 0, 0.6); backdrop-filter: blur(8px);
  display: flex; justify-content: center; align-items: center; z-index: 1050; animation: ${fadeIn} 0.3s;
`;
const ModalContent = styled.div`
  background: white; border-radius: 16px; width: 90%; max-width: 450px; padding: 2rem;
  box-shadow: 0 10px 40px rgba(0,0,0,0.1); animation: ${slideUp} 0.4s; text-align: center;
`;
const AnimatedIcon = styled.div`
  svg { font-size: 3rem; color: #4f46e5; margin-bottom: 1rem; animation: ${p => p.isLoading && spin} 1s linear infinite; }
`;
const CardHeader = styled.h5`
  font-weight: 700;
  font-size: 1.25rem;
  color: #111827;
  margin-bottom: 1.5rem;
`;

// --- Helper Functions (Unchanged) ---
const calculateExpiryPercentage = (mfgDate, expiryDate) => {
  if (!mfgDate || !expiryDate) return 0;
  const mfg = new Date(mfgDate); const expiry = new Date(expiryDate); const today = new Date();
  if (today >= expiry) return 100; if (today <= mfg) return 0;
  return Math.min(100, ((today - mfg) / (expiry - mfg)) * 100);
};
const formatDate = (dateString) => {
  if (!dateString) return 'N/A';
  return new Date(dateString).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

// --- Confirmation Modal Component (Unchanged) ---
const ConfirmationModal = ({ onConfirm, onCancel, loading, error }) => (
  <ModalBackdrop>
    <ModalContent>
      <AnimatedIcon isLoading={loading}>
        {loading ? <FaSpinner /> : error ? <FaExclamationCircle style={{ color: '#dc3545' }} /> : <FaPaperPlane />}
      </AnimatedIcon>
      <h4 style={{ fontWeight: 700 }}>{error ? "Request Failed" : loading ? "Sending Request..." : "Confirm Purchase"}</h4>
      <p style={{ color: '#6c757d', marginBottom: '2rem' }}>
        {error ? error : loading ? "Please wait while we send your request." : "A purchase request will be sent for this item. Do you want to proceed?"}
      </p>
      <div style={{ display: 'flex', gap: '1rem' }}>
        <button className="btn btn-secondary w-100" onClick={onCancel} disabled={loading}>Cancel</button>
        <button className="btn btn-primary w-100" style={{backgroundColor: '#4f46e5'}} onClick={onConfirm} disabled={loading}>
          {error ? "Try Again" : "Yes, Send Request"}
        </button>
      </div>
    </ModalContent>
  </ModalBackdrop>
);


// --- Main Product Details Component ---
const ProductDetails = ({ product, navigateTo }) => {
  // State for Purchase Request Modal
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // --- NEW ---
  // State for "Add to Cart" button
  const [isCartLoading, setIsCartLoading] = useState(false);
  const [cartError, setCartError] = useState(null);
  
  const dispatch = useDispatch();
  const loggedInUserId = useSelector(state => state.auth.userId);

  if (!product || !product.user) {
    return <div className="text-center py-5">Product details are incomplete or not found.</div>;
  }
  
  const isOwnProduct = loggedInUserId === product.user_id;

  const {
    tablet_name, brand, quantity, unit_type, original_price, discount, user,
    manufacturing_date, expiry_date, best_before_date, image_url, usage_instructions,
    storage_instructions, batch_number, id, has_requested
  } = product;

  const finalPrice = original_price * (1 - (discount / 100));
  const expiryPercentage = calculateExpiryPercentage(manufacturing_date, expiry_date);

  // Unchanged
  const handleConfirmPurchase = async () => {
    setLoading(true); setError(null);
    try {
      const senderId = loggedInUserId;
      if (!senderId) throw new Error("You must be logged in to send a purchase request.");
      const requestData = {
        sender_id: senderId,
        receiver_id: user.user_id,
        tablet_name,
        product_id: product.product_id || id,
        quantity,
        unit_price: finalPrice,
        description: `Purchase request for ${quantity} units of ${tablet_name}.`
      };
      await axios.post(`${BaseUrl}/purchase-requests/send-purchase-request`, requestData);
      setLoading(false); setShowConfirmModal(false);
      alert("Purchase request sent successfully!");
      navigateTo('Purchase Requests');
    } catch (err) {
      setError(err.response?.data?.error || err.message || "An unknown error occurred.");
      setLoading(false);
    }
  };

  // Unchanged
  const handleChat = () => {
    dispatch(startNewChat({ receiverId: user.user_id, product }));
    navigateTo('Chat');
  };

  // --- MODIFIED ---
  // This function now calls your API
  const handleAddToCart = async () => {
    setIsCartLoading(true);
    setCartError(null);

    try {
      if (!loggedInUserId) {
        throw new Error("You must be logged in to add items to your cart.");
      }

      const cartData = {
        user_id: loggedInUserId,
        product_id: product.product_id || id,
        tablet_name: tablet_name,
        image_url: image_url || 'https://placehold.co/600x600/e9ecef/212529?text=No+Image',
        amount: finalPrice,
        quantity: 1, // We send 1, your backend logic will handle incrementing
        seller_id: product.user_id
      };
      
      // Make the API call as per your Flask route
      await axios.post(`${BaseUrl}/cart/add-to-cart`, cartData);

      // On success, navigate to the cart page as requested
      navigateTo('Cart');

    } catch (err) {
      const errorMsg = err.response?.data?.error || err.message || "Could not add item to cart.";
      setCartError(errorMsg);
      // We can also alert the user for immediate feedback
      // alert(errorMsg); 
    } finally {
      setIsCartLoading(false);
    }
  };

  const openModal = () => { setError(null); setShowConfirmModal(true); }

  return (
    <>
      <GlobalStyle />
      {showConfirmModal &&
        <ConfirmationModal
          onConfirm={handleConfirmPurchase}
          onCancel={() => setShowConfirmModal(false)}
          loading={loading}
          error={error}
        />
      }
      <PageContainer>
        <ProductGrid>
          <ImageGallery>
            <MainImage src={image_url || 'https://placehold.co/600x600/e9ecef/212529?text=No+Image'} alt={tablet_name} />
          </ImageGallery>
          <ProductDetailsContainer>
            <ProductCard>
              <ProductHeader>
                <h1>{tablet_name}</h1>
                <p>by {brand || 'N/A'}</p>
              </ProductHeader>
              <PriceSection>
                <FinalPrice>₹{(finalPrice || 0).toFixed(2)}</FinalPrice>
                <OriginalPrice>₹{(original_price || 0).toFixed(2)}</OriginalPrice>
                <DiscountBadge>{discount || 0}% OFF</DiscountBadge>
              </PriceSection>
              {!isOwnProduct && (
                <ActionButtonsContainer>
                    {has_requested ? (
                        <AlreadyRequestedInfo>
                            <p>You've already sent a request, waiting for confirmation.</p>
                            <button onClick={() => navigateTo('Purchase Requests')}>OK</button>
                        </AlreadyRequestedInfo>
                    ) : (
                        <ActionButton $primary onClick={openModal} disabled={loading}>
                            {/* This button uses the modal for loading state */}
                            <FaShoppingCart /> Send Purchase Request
                        </ActionButton>
                    )}
                  
                  {/* --- MODIFIED BUTTON --- */}
                  <ActionButton onClick={handleAddToCart} disabled={isCartLoading}>
                    {isCartLoading ? <SpinnerIcon /> : <FaCartPlus />}
                    {isCartLoading ? 'Adding to Cart...' : 'Add to Cart'}
                  </ActionButton>
                  
                  {/* --- NEW ERROR MESSAGE --- */}
                  {cartError && <ErrorMessage>{cartError}</ErrorMessage>}

                  <ActionButton onClick={handleChat}>
                    <FaComments /> Chat with Seller
                  </ActionButton>
                </ActionButtonsContainer>
              )}
            </ProductCard>

            {/* ... Rest of the component (Seller Info, Specs, etc.) is unchanged ... */}
            <ProductCard $delay="0.1s">
              <CardHeader>Seller Information</CardHeader>
              <InfoBlock>
                  <FaBuilding size={20} />
                  <div><strong>Shop Name:</strong><p className="mb-0 text-secondary">{user.shop_name}</p></div>
              </InfoBlock>
              <hr className="my-3"/>
              <InfoBlock>
                  <FaMapMarkerAlt size={20} />
                  <div><strong>Address:</strong><p className="mb-0 text-secondary">{user.full_address}</p></div>
              </InfoBlock>
            </ProductCard>
            
            <ProductCard $delay="0.2s">
              <CardHeader>Product Specifications</CardHeader>
              <InfoGrid>
                <InfoBlock><FaFlask size={16} /><p><strong>Brand:</strong> {brand || 'N/A'}</p></InfoBlock>
                <InfoBlock><FaTags size={16} /><p><strong>Batch No:</strong> {batch_number || 'N/A'}</p></InfoBlock>
                <InfoBlock><FaWeightHanging size={16} /><p><strong>Stock:</strong> {quantity} {unit_type}</p></InfoBlock>
                <InfoBlock><FaCalendarAlt size={16} /><p><strong>MFG Date:</strong> {formatDate(manufacturing_date)}</p></InfoBlock>
                <InfoBlock><FaCalendarCheck size={16} /><p><strong>Best Before:</strong> {formatDate(best_before_date)}</p></InfoBlock>
                <InfoBlock>
                    <FaCalendarTimes size={16} />
                    <div>
                      <strong>Expiry Details</strong>
                      <p style={{ fontSize: '0.9rem', color: '#6c757d', margin: '0.25rem 0' }}>
                        Expires on {formatDate(expiry_date)}
                      </p>
                      <ExpiryBar><ExpiryFill $percentage={expiryPercentage} /></ExpiryBar>
                    </div>
                </InfoBlock>
              </InfoGrid>
            </ProductCard>

            <ProductCard $delay="0.3s">
              <CardHeader>Instructions</CardHeader>
              <InfoBlock>
                  <FaInfoCircle size={20} />
                  <div><strong>Usage Instructions:</strong><p className="mb-0 text-secondary">{usage_instructions || 'Follow physician\'s advice.'}</p></div>
              </InfoBlock>
              <hr className="my-3"/>
              <InfoBlock>
                  <FaInfoCircle size={20} />
                  <div><strong>Storage Instructions:</strong><p className="mb-0 text-secondary">{storage_instructions || 'Store in a cool, dry place.'}</p></div>
              </InfoBlock>
            </ProductCard>
          </ProductDetailsContainer>
        </ProductGrid>
      </PageContainer>
    </>
  );
};

export default ProductDetails;