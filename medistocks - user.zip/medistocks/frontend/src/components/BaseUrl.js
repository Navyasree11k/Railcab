const BaseUrl = 'http://127.0.0.1:5006/medistocks_user';
const webSocketUrl = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' 
  ? 'http://127.0.0.1:5006' 
  : "https://novelskidev.online";
const GOOGLE_MAPS_API_KEY = 'AIzaSyDhIBlr2sIikXFn2q48bmPELhUPjv6Se3s'; // Replace with your key from a secure source
const AdminBaseUrl = 'http://127.0.0.1:5007/medistocks_admin/chat_support';

export default BaseUrl;
export {webSocketUrl,GOOGLE_MAPS_API_KEY,AdminBaseUrl};
