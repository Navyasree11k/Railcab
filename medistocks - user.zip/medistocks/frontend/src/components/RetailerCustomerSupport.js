import React, { useState } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeUp = keyframes`from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}`;
const ACCENT = '#10b981';

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 22px;`;

const ReplyBanner = styled.div`
  background:linear-gradient(135deg,#ecfdf5,#eff6ff);border:1.5px solid #a7f3d0;
  border-radius:12px;padding:14px 18px;display:flex;align-items:center;gap:14px;margin-bottom:20px;
`;
const StatusDot = styled.div`width:8px;height:8px;border-radius:50%;background:#10b981;flex-shrink:0;box-shadow:0 0 0 3px rgba(16,185,129,.2);`;

const TopicsGrid = styled.div`
  display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;margin-bottom:22px;
  @media(max-width:480px){grid-template-columns:1fr 1fr;}
`;
const TopicBtn = styled.button`
  background:#fff;border:1.5px solid ${p=>p.$active?ACCENT:'#f0f0f0'};border-radius:12px;
  padding:14px 12px;display:flex;align-items:center;gap:10px;cursor:pointer;text-align:left;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.84rem;font-weight:500;color:#374151;
  transition:all .15s;box-shadow:0 1px 4px rgba(0,0,0,.04);
  animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*50}ms;
  &:hover{border-color:${ACCENT};background:rgba(16,185,129,.04);}
  ${p=>p.$active&&`border-color:${ACCENT};background:rgba(16,185,129,.06);color:${ACCENT};font-weight:700;`}
`;
const TopicIcon = styled.span`font-size:1.2rem;flex-shrink:0;`;

const ChatArea = styled.div`background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.04);`;
const ChatBody = styled.div`padding:20px;min-height:160px;`;

const Bubble = styled.div`
  display:inline-flex;align-items:flex-start;gap:10px;max-width:80%;
  @media(max-width:480px){max-width:95%;}
`;
const BubbleAvatar = styled.div`
  width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,${ACCENT},#0ea5e9);
  display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.8rem;flex-shrink:0;
`;
const BubbleText = styled.div`
  background:#f5f7fa;border:1px solid #f0f0f0;border-radius:12px 12px 12px 0;
  padding:12px 16px;font-size:.875rem;color:#374151;line-height:1.6;
`;
const BubbleTime = styled.div`font-size:.7rem;color:#9ca3af;margin-top:4px;`;

const ChatInput = styled.div`
  padding:14px 16px;border-top:1px solid #f0f0f0;display:flex;align-items:center;gap:10px;background:#fafafa;
`;
const Input = styled.input`
  flex:1;background:#fff;border:1.5px solid #e5e7eb;border-radius:9px;padding:10px 14px;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.875rem;color:#374151;outline:none;
  transition:all .2s;
  &:focus{border-color:${ACCENT};box-shadow:0 0 0 3px rgba(16,185,129,.1);}
  &::placeholder{color:#d1d5db;}
`;
const IconBtn = styled.button`
  width:38px;height:38px;border-radius:9px;border:1.5px solid #e5e7eb;background:#fff;
  display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:1rem;
  transition:all .15s;&:hover{background:#f5f7fa;}
`;
const SendBtn = styled.button`
  width:38px;height:38px;border-radius:9px;border:none;
  background:linear-gradient(135deg,${ACCENT},#0ea5e9);color:#fff;
  display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:.9rem;
  transition:all .2s;&:hover{transform:translateY(-1px);box-shadow:0 4px 10px rgba(16,185,129,.3);}
`;

const FooterRow = styled.div`display:flex;justify-content:center;gap:10px;margin-top:20px;flex-wrap:wrap;`;
const OutlineBtn = styled.button`
  padding:8px 18px;background:#fff;border:1.5px solid #e5e7eb;border-radius:9px;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.84rem;font-weight:600;color:#374151;
  cursor:pointer;transition:all .15s;&:hover{background:#f9fafb;}
`;

const TOPICS = [
  { icon:'📦', text:'Delivery Issue' },
  { icon:'💳', text:'Payment/Invoice' },
  { icon:'⚙️', text:'App Bug' },
  { icon:'🚩', text:'Report a User' },
  { icon:'👑', text:'Subscription' },
  { icon:'❓', text:'Other' },
];

const CustomerSupport = ({ navigateTo }) => {
  const [activeTopic, setActiveTopic] = useState(null);
  const [message, setMessage] = useState('');

  return (
    <Page>
      <PageTitle>Customer <em>Support</em></PageTitle>
      <PageSub>Our team typically replies within 2 minutes.</PageSub>

      <ReplyBanner>
        <StatusDot />
        <div>
          <div style={{fontWeight:700,fontSize:'.9rem',color:'#111827'}}>Support team is online</div>
          <div style={{fontSize:'.78rem',color:'#6b7280'}}>Average reply time: 2 minutes</div>
        </div>
      </ReplyBanner>

      <div style={{fontWeight:700,fontSize:'.84rem',color:'#374151',marginBottom:12}}>What can we help you with?</div>
      <TopicsGrid>
        {TOPICS.map((t,i) => (
          <TopicBtn key={t.text} $i={i} $active={activeTopic===t.text} onClick={()=>setActiveTopic(t.text)}>
            <TopicIcon>{t.icon}</TopicIcon>
            {t.text}
          </TopicBtn>
        ))}
      </TopicsGrid>

      <ChatArea>
        <ChatBody>
          <Bubble>
            <BubbleAvatar>S</BubbleAvatar>
            <div>
              <BubbleText>
                {activeTopic
                  ? `Got it! You need help with "${activeTopic}". Please describe your issue and we'll get back to you right away.`
                  : "Hello! I'm here to help. Please select a topic above or type your question below."}
              </BubbleText>
              <BubbleTime>Just now</BubbleTime>
            </div>
          </Bubble>
        </ChatBody>
        <ChatInput>
          <IconBtn title="Attach file">📎</IconBtn>
          <IconBtn title="Attach photo">📷</IconBtn>
          <Input
            placeholder="Type your message…"
            value={message}
            onChange={e=>setMessage(e.target.value)}
            onKeyDown={e=>{ if(e.key==='Enter'&&message.trim()){ setMessage(''); } }}
          />
          <SendBtn title="Send" onClick={()=>setMessage('')}>➤</SendBtn>
        </ChatInput>
      </ChatArea>

      <FooterRow>
        <OutlineBtn onClick={()=>navigateTo('FAQs')}>❓ Help Center</OutlineBtn>
        <OutlineBtn onClick={()=>navigateTo('FAQs')}>📋 FAQ</OutlineBtn>
      </FooterRow>
    </Page>
  );
};

export default CustomerSupport;