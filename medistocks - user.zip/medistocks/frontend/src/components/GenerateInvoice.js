import React, { useState, useRef, useEffect } from 'react';
import styled, { keyframes, createGlobalStyle, css } from 'styled-components';
import axios from 'axios';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { FaFileInvoiceDollar, FaCheckCircle, FaSpinner, FaDownload, FaPrint, FaUser, FaBuilding } from 'react-icons/fa';
import { useSelector, useDispatch } from 'react-redux';
import { clearInvoiceState } from './redux/invoiceSlice'; // Make sure this path is correct
import BaseUrl from './BaseUrl'; // Make sure this path is correct

// --- Global Styles & Animations (No changes) ---
const GlobalStyle = createGlobalStyle`
  body {
    background-color: #f4f7fa;
    font-family: 'Inter', sans-serif;
  }
`;
const fadeIn = keyframes`from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); }`;

// --- Styled Components (MOBILE-FIRST REFINEMENTS ADDED) ---
const PageWrapper = styled.div`
  display: grid;
  grid-template-columns: 450px 1fr;
  min-height: 100vh;
  
  /* Stacks the control panel on top of the preview on tablets and mobile */
  @media (max-width: 992px) { 
    grid-template-columns: 1fr; 
  }
`;

const ControlPanel = styled.div`
  background-color: #ffffff;
  padding: 2rem;
  border-right: 1px solid #e2e8f0;
  display: flex; 
  flex-direction: column; 
  gap: 1.5rem;
  
  @media (max-width: 992px) {
    border-right: none;
    border-bottom: 1px solid #e2e8f0;
  }
  @media (max-width: 768px) {
    /* Reduced padding for mobile */
    padding: 1.5rem 1rem;
  }
`;

const InvoicePreview = styled.div`
  padding: 3rem; 
  overflow: auto; 
  background-color: #e2e8f0;

  @media (max-width: 768px) {
    /* MOBILE CHANGE: Removed outer padding and background for a cleaner look */
    padding: 0;
    background-color: #f4f7fa; /* Match body background */
  }
`;

const SummaryWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 2rem; /* Added more padding for larger screens */
  animation: ${css`${fadeIn} 0.5s ease-out`};
  
  @media (max-width: 768px) {
    /* MOBILE CHANGE: Reduced padding for a tighter fit on small screens */
    padding: 1rem;
  }
`;

const SummaryCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2.5rem;
  width: 100%;
  max-width: 800px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.08);

  @media (max-width: 768px) {
    padding: 1.5rem;
  }
`;

const CardHeader = styled.h2`
  font-size: 1.75rem; 
  font-weight: 700; 
  color: #1a202c;
  margin: 0 0 2rem 0; 
  text-align: center;
  
  @media (max-width: 768px) {
    /* MOBILE CHANGE: Smaller font size and less margin */
    font-size: 1.4rem;
    margin-bottom: 1.5rem;
  }
`;

const DetailsGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  border-top: 1px solid #e2e8f0;
  border-bottom: 1px solid #e2e8f0;
  padding: 2rem 0;
  margin-bottom: 2rem;

  @media (max-width: 768px) {
    /* Stacks sender/receiver details on mobile */
    grid-template-columns: 1fr;
    gap: 1.5rem;
    padding: 1.5rem 0;
    margin-bottom: 1.5rem;
  }
`;

const DetailSection = styled.div`
  h4 { 
    font-size: 1.1rem; color: #4a5568; margin-bottom: 1rem; 
    display: flex; align-items: center; gap: 0.5rem; 
  }
  p { margin: 0.25rem 0; color: #718096; }
  strong { color: #1a202c; }
`;

const ProductSummary = styled.div`
  background: #f8fafc;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 2rem;
  text-align: center;
  p { margin: 0.25rem 0; }
  .total { font-size: 1.5rem; font-weight: 700; color: #2563eb; margin-top: 0.5rem; }
  
  @media (max-width: 768px) {
    margin-bottom: 1.5rem;
    .total { font-size: 1.25rem; }
  }
`;

const ActionButton = styled.button`
  width: 100%; padding: 1rem; font-size: 1.1rem; font-weight: 600;
  border: none; border-radius: 12px; cursor: pointer; display: flex;
  align-items: center; justify-content: center; gap: 0.75rem;
  transition: all 0.2s ease-in-out; background-color: #2563eb; color: white;
  &:hover { background-color: #1d4ed8; }
  &:disabled { background-color: #9ca3af; cursor: not-allowed; }
`;

// --- CRITICAL MOBILE FIX ---
const InvoicePaper = styled.div`
  background: white; 
  /* A4 paper dimensions for desktop */
  width: 210mm; 
  min-height: 297mm; 
  margin: 0 auto;
  padding: 20mm; 
  box-shadow: 0 0 20px rgba(0,0,0,0.1); 
  box-sizing: border-box; 
  color: #333;

  @media (max-width: 768px) {
    /* MOBILE CHANGE: Makes the invoice fluid */
    width: 100%;
    min-height: auto; /* Height adjusts to content */
    padding: 1.5rem;
    box-shadow: none; /* Remove shadow to blend with the background */
    margin: 0;
  }
  
  @media (max-width: 480px) {
    /* Tighter padding on very small phones */
    padding: 1rem;
  }
`;

const ModalBackdrop = styled.div`
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  background-color: rgba(0,0,0,0.6); backdrop-filter: blur(5px);
  display: flex; justify-content: center; align-items: center; 
  z-index: 1000; padding: 1rem;
  animation: ${css`${fadeIn} 0.3s`};
`;

const ModalContent = styled.div`
  background: white; padding: 2.5rem; border-radius: 16px;
  width: 100%; max-width: 450px; text-align: center; 
  box-shadow: 0 10px 30px rgba(0,0,0,0.1);
  h3 { margin-top: 0; font-size: 1.5rem; }
  p { color: #718096; margin-bottom: 2rem; }
  @media (max-width: 768px) {
    padding: 2rem 1.5rem;
  }
`;

const ModalActions = styled.div`
  display: flex; 
  gap: 1rem;
  button { flex: 1; }
  .cancel-btn { background-color: #e2e8f0; color: #4a5568; &:hover { background-color: #cbd5e1; } }
  @media (max-width: 480px) {
    /* Stacks modal buttons vertically */
    flex-direction: column;
  }
`;

const InvoiceHeader = styled.div`
  display: flex; 
  justify-content: space-between; 
  align-items: flex-start;
  border-bottom: 2px solid #3b82f6; 
  padding-bottom: 1rem; 
  margin-bottom: 2rem;
  
  @media (max-width: 480px) {
    /* MOBILE CHANGE: Stacks header info for better readability on small screens */
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
  }
`;

const AddressBlock = styled.div`
    p { 
      margin: 0; 
      line-height: 1.6; 
      font-size: 0.9rem;
    }
    strong { 
      font-weight: 600; 
      color: #111;
    }
`;

const InvoiceTable = styled.table`
  width: 100%; 
  border-collapse: collapse; 
  margin-top: 2rem;
  th, td { 
    padding: 0.85rem 1rem; 
    text-align: left; 
    font-size: 0.9rem;
  }
  thead { 
    background-color: #f4f7fa; 
    th { 
      font-weight: 600; 
      color: #4a5568; 
    } 
  }
  tbody tr { 
    border-bottom: 1px solid #e2e8f0; 
  }
  tfoot td { 
    text-align: right; 
    font-weight: 600; 
  }
  tfoot .grand-total td { 
    font-size: 1.2rem; 
    color: #3b82f6; 
    border-top: 2px solid #333; 
  }

  @media (max-width: 768px) {
    /* MOBILE CHANGE: More compact table for mobile */
    th, td {
        padding: 0.75rem 0.5rem;
        font-size: 0.85rem;
    }
    tfoot .grand-total td {
        font-size: 1.1rem;
    }
  }
`;

const InvoiceFooter = styled.div`
  border-top: 1px solid #e2e8f0; 
  padding-top: 1.5rem; 
  margin-top: 2rem;
  color: #718096; 
  font-size: 0.9rem; 
  text-align: center;
`;

const DownloadButtons = styled.div`
  display: flex; 
  gap: 1rem; 
  margin-top: 2rem;
  button { 
    flex: 1; 
    background-color: #fff; 
    border: 1px solid #cbd5e1; 
    color: #4a5568;
    &:hover { 
      background-color: #f8fafc; 
    }
  }
  @media (max-width: 480px) {
    flex-direction: column;
  }
`;

const FullPageLoader = styled.div`
    display: flex;
    flex-direction: column;
    height: 100vh;
    align-items: center;
    justify-content: center;
    text-align: center;
    gap: 1rem;
    font-size: 1.2rem;
    color: #4a5568;
`;

// --- Main Component (No changes to logic) ---
const GenerateInvoice = () => {
    const dispatch = useDispatch();
    const invoiceRef = useRef();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [generatedInvoice, setGeneratedInvoice] = useState(null);
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [isChecking, setIsChecking] = useState(true);
    const purchaseRequest = useSelector((state) => state.invoice.generateInvoiceState);
    
    useEffect(() => {
        const hasRequiredIds = purchaseRequest?.id && purchaseRequest?.sender_id && purchaseRequest?.receiver_id;

        if (!hasRequiredIds) {
            setIsChecking(false);
            return;
        }

        const checkForInvoice = async () => {
            try {
                const response = await axios.get(`${BaseUrl}/invoice/get-invoice/product`, {
                    params: {
                        product_id: purchaseRequest.id,
                        sender_id: purchaseRequest.sender_id,
                        receiver_id: purchaseRequest.receiver_id,
                    }
                });
                
                if (response.data && response.data.length > 0) {
                    setGeneratedInvoice(response.data[0]);
                }
            } catch (err) {
                if (err.response && err.response.status === 404) {
                    console.log("No invoice found (404), proceeding to generation screen.");
                } else {
                    setError("Could not check for an existing invoice.");
                    console.error("Error checking for invoice:", err);
                }
            } finally {
                setIsChecking(false);
            }
        };

        checkForInvoice();

        return () => { 
            dispatch(clearInvoiceState()); 
        }; 
    }, [purchaseRequest, dispatch]);

    const handleGenerateInvoice = async () => {
        setShowConfirmModal(false);
        if (!purchaseRequest) { 
            setError("Data is missing."); 
            return; 
        }
        setLoading(true);
        setError(null);
        
        const payload = {
            sender_id: purchaseRequest.sender_id,
            receiver_id: purchaseRequest.receiver_id,
            product_id: purchaseRequest.id,
            product_name: purchaseRequest.tablet_name,
            quantity: purchaseRequest.quantity,
            unit_price: purchaseRequest.unit_price,
            tax_percentage: purchaseRequest.tax_percentage || 0,
            discount: purchaseRequest.discount || 0,
            description: purchaseRequest.description,
        };

        try {
            const response = await axios.post(`${BaseUrl}/invoice/invoice`, payload);
            setGeneratedInvoice(response.data.invoice || response.data);
        } catch (err) {
            setError(err.response?.data?.error || "Failed to create invoice.");
        } finally {
            setLoading(false);
        }
    };

    const handleDownloadPDF = () => {
        const input = invoiceRef.current;
        if (!input) return;
        html2canvas(input, { scale: 2, useCORS: true }).then((canvas) => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            pdf.save(`invoice-${generatedInvoice?.id || 'download'}.pdf`);
        });
    };

    // --- RENDER LOGIC (No changes) ---

    if (!purchaseRequest?.id) {
        return (
            <div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
                <div>
                    <h2>No Data Found</h2>
                    <p style={{ color: '#718096' }}>Please select a purchase request to generate an invoice.</p>
                </div>
            </div>
        );
    }

    if (isChecking) {
        return (
            <FullPageLoader>
                <FaSpinner className="fa-spin" style={{ fontSize: '2rem' }} />
                <p>Checking for existing invoice...</p>
            </FullPageLoader>
        );
    }

    if (!generatedInvoice) {
        const { sender_details, receiver_details } = purchaseRequest;
        return (
            <>
                <GlobalStyle />
                <SummaryWrapper>
                    <SummaryCard>
                        <CardHeader>Generate a New Invoice</CardHeader>
                        <DetailsGrid>
                            <DetailSection>
                                <h4><FaBuilding /> Sender Details</h4>
                                <p><strong>{sender_details.shop_name || 'N/A'}</strong></p>
                                <p>{sender_details.email}</p>
                            </DetailSection>
                            <DetailSection>
                                <h4><FaUser /> Receiver Details</h4>
                                <p><strong>{receiver_details.shop_name || 'N/A'}</strong></p>
                                <p>{receiver_details.email}</p>
                            </DetailSection>
                        </DetailsGrid>
                        <ProductSummary>
                            <p>Product: <strong>{purchaseRequest.tablet_name}</strong></p>
                            <p>Quantity: <strong>{purchaseRequest.quantity}</strong></p>
                            <p className="total">Total Amount: ₹{parseFloat(purchaseRequest.total_amount).toFixed(2)}</p>
                        </ProductSummary>
                        <ActionButton onClick={() => setShowConfirmModal(true)} disabled={loading}>
                            {loading ? <FaSpinner className="fa-spin" /> : <FaFileInvoiceDollar />}
                            {loading ? 'Generating...' : 'Generate Invoice'}
                        </ActionButton>
                        {error && <p style={{ color: '#dc3545', textAlign: 'center', marginTop: '1rem' }}>{error}</p>}
                    </SummaryCard>
                </SummaryWrapper>

                {showConfirmModal && (
                    <ModalBackdrop>
                        <ModalContent>
                            <h3>Confirm Generation</h3>
                            <p>This will create a formal invoice for this purchase request. Are you sure you want to proceed?</p>
                            <ModalActions>
                                <ActionButton className="cancel-btn" onClick={() => setShowConfirmModal(false)}>Cancel</ActionButton>
                                <ActionButton onClick={handleGenerateInvoice}>Yes, Generate</ActionButton>
                            </ModalActions>
                        </ModalContent>
                    </ModalBackdrop>
                )}
            </>
        );
    }

    const dataToShow = generatedInvoice;
    return (
        <>
            <GlobalStyle />
            <PageWrapper>
                <ControlPanel>
                    <SummaryCard style={{padding: '2rem', boxShadow: 'none', border: '1px solid #e2e8f0'}}>
                       <div style={{ textAlign: 'center' }}>
                           <FaCheckCircle style={{ color: '#22c55e', fontSize: '2.5rem', marginBottom: '1rem' }} />
                           <h3 style={{ margin: 0, fontWeight: 700 }}>Invoice Ready!</h3>
                           <p>Invoice #{dataToShow.id} has been loaded.</p>
                       </div>
                    </SummaryCard>
                    <DownloadButtons>
                        <ActionButton onClick={handleDownloadPDF}><FaDownload /> Download as PDF</ActionButton>
                        <ActionButton onClick={() => window.print()}><FaPrint /> Print Invoice</ActionButton>
                    </DownloadButtons>
                </ControlPanel>
                <InvoicePreview>
                    <InvoicePaper ref={invoiceRef}>
                        <InvoiceHeader>
                            <div>
                               <h1 style={{ color: '#3b82f6', margin: 0 }}>INVOICE</h1>
                               <p><strong>Invoice #:</strong> {dataToShow.id}</p>
                               <p><strong>Date:</strong> {new Date(dataToShow.created_at || dataToShow.issue_date).toLocaleDateString()}</p>
                            </div>
                            <AddressBlock>
                                <p><strong>{dataToShow.sender_shop_name || 'N/A'}</strong></p>
                                <p>{dataToShow.sender_address || 'Address not available'}</p>
                                <p>GSTIN: {dataToShow.sender_gst || 'N/A'}</p>
                                <p>PAN: {dataToShow.sender_pan || 'N/A'}</p>
                            </AddressBlock>
                        </InvoiceHeader>
                        <AddressBlock>
                           <h5 style={{ color: '#718096', marginBottom: '0.5rem' }}>Bill To:</h5>
                           <p><strong>{dataToShow.receiver_shop_name || 'N/A'}</strong></p>
                           <p>{dataToShow.receiver_address || 'Address not available'}</p>
                           <p>GSTIN: {dataToShow.receiver_gst || 'N/A'}</p>
                           <p>PAN: {dataToShow.receiver_pan || 'N/A'}</p>
                        </AddressBlock>
                        <InvoiceTable>
                            <thead>
                                <tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{dataToShow.product_name}</td>
                                    <td>{dataToShow.quantity}</td>
                                    <td>₹{parseFloat(dataToShow.unit_price).toFixed(2)}</td>
                                    <td>₹{parseFloat(dataToShow.sub_total || (dataToShow.quantity * dataToShow.unit_price)).toFixed(2)}</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr><td colSpan="3">Sub-total</td><td>₹{parseFloat(dataToShow.sub_total || (dataToShow.quantity * dataToShow.unit_price)).toFixed(2)}</td></tr>
                                <tr><td colSpan="3">Discount</td><td>- ₹{parseFloat(dataToShow.discount).toFixed(2)}</td></tr>
                                <tr><td colSpan="3">Tax ({dataToShow.tax_percentage}%)</td><td>+ ₹{((dataToShow.sub_total || (dataToShow.quantity * dataToShow.unit_price)) * dataToShow.tax_percentage / 100).toFixed(2)}</td></tr>
                                <tr className="grand-total"><td colSpan="3">Grand Total</td><td>₹{parseFloat(dataToShow.total_amount).toFixed(2)}</td></tr>
                            </tfoot>
                        </InvoiceTable>
                         <div style={{ marginTop: '2rem' }}>
                            <h5 style={{ color: '#718096' }}>Notes:</h5>
                            <p style={{ fontSize: '0.9rem' }}>{dataToShow.description || 'No additional notes.'}</p>
                        </div>
                        <InvoiceFooter>
                            <p>Thank you for your business!</p>
                            <p>This is a computer-generated invoice and does not require a signature.</p>
                        </InvoiceFooter>
                    </InvoicePaper>
                </InvoicePreview>
            </PageWrapper>
        </>
    );
};

export default GenerateInvoice;
