// RetailerChat.js
import React, { useState, useEffect, useMemo, useRef } from 'react';
import styled from 'styled-components';
import { io } from 'socket.io-client';
import axios from 'axios';
import { useSelector, useDispatch } from 'react-redux';
import {
  setConversations,
  setAllMessages,
  addMessage,
  setActiveChat,
  setLoading,
  setError,
} from './redux/chatSlice';
import BaseUrl, { webSocketUrl } from './BaseUrl';
import { FiSend } from 'react-icons/fi';

// --- PHARMACY THEME TOKENS ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';
const CARD_SHADOW = '0 8px 20px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.02)';
const HOVER_SHADOW = '0 12px 28px rgba(13,124,61,0.12), 0 4px 12px rgba(0,0,0,0.06)';

// --- Styled Components (improved, responsive) ---
const PageLayout = styled.div`
  display: flex;
  flex-direction: column;
  height: 85vh;
  background: white;
  border-radius: 1.25rem;
  box-shadow: ${CARD_SHADOW};
  overflow: hidden;
  @media (min-width: 768px) {
    flex-direction: row;
  }
`;

const Sidebar = styled.div`
  width: 100%;
  border-right: none;
  border-bottom: 1px solid ${BORDER_GREY};
  display: flex;
  flex-direction: column;
  background: white;
  @media (min-width: 768px) {
    width: 320px;
    border-right: 1px solid ${BORDER_GREY};
    border-bottom: none;
  }
`;

const SidebarHeader = styled.div`
  padding: 1rem 1.25rem;
  border-bottom: 1px solid ${BORDER_GREY};
  font-weight: 700;
  font-size: 1.1rem;
  color: ${DARK_NAVY};
  background: white;
  @media (min-width: 768px) {
    padding: 1.25rem 1.5rem;
    font-size: 1.2rem;
  }
`;

const ConversationList = styled.div`
  overflow-y: auto;
  flex-grow: 1;
`;

const ConversationItem = styled.div`
  padding: 0.75rem 1rem;
  cursor: pointer;
  border-bottom: 1px solid ${BORDER_GREY};
  background: ${({ active }) => (active ? `${PHARMACY_GREEN}10` : 'white')};
  transition: all 0.2s;
  &:hover {
    background: ${LIGHT_GREEN};
  }
  @media (min-width: 768px) {
    padding: 1rem 1.5rem;
  }
  h6 {
    font-weight: 600;
    margin-bottom: 0.25rem;
    color: ${DARK_NAVY};
    font-size: 0.9rem;
    @media (min-width: 768px) {
      font-size: 1rem;
    }
  }
  p {
    font-size: 0.75rem;
    color: #6c757d;
    margin-bottom: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    @media (min-width: 768px) {
      font-size: 0.8rem;
    }
  }
`;

const ChatWindow = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  background: ${LIGHT_GREEN};
`;

const ChatHeader = styled.div`
  padding: 0.75rem 1rem;
  border-bottom: 1px solid ${BORDER_GREY};
  background: white;
  @media (min-width: 768px) {
    padding: 1rem 1.5rem;
  }
  h5 {
    font-weight: 700;
    color: ${DARK_NAVY};
    margin-bottom: 0;
    font-size: 1rem;
    @media (min-width: 768px) {
      font-size: 1.1rem;
    }
  }
  small {
    color: #6c757d;
    font-size: 0.7rem;
    @media (min-width: 768px) {
      font-size: 0.8rem;
    }
  }
`;

const MessageList = styled.div`
  flex-grow: 1;
  padding: 1rem;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  background: ${LIGHT_GREEN};
  @media (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const MessageBubble = styled.div`
  max-width: 85%;
  padding: 0.6rem 1rem;
  border-radius: 1.25rem;
  line-height: 1.4;
  align-self: ${({ sent }) => (sent ? 'flex-end' : 'flex-start')};
  background: ${({ sent }) => (sent ? PHARMACY_GREEN : 'white')};
  color: ${({ sent }) => (sent ? 'white' : DARK_NAVY)};
  box-shadow: 0 1px 2px rgba(0,0,0,0.05);
  font-size: 0.85rem;
  word-break: break-word;
  border: ${({ sent }) => (sent ? 'none' : `1px solid ${BORDER_GREY}`)};
  border-bottom-right-radius: ${({ sent }) => (sent ? '4px' : '1.25rem')};
  border-bottom-left-radius: ${({ sent }) => (sent ? '1.25rem' : '4px')};
  @media (min-width: 768px) {
    max-width: 75%;
    padding: 0.75rem 1.25rem;
    font-size: 0.9rem;
  }
`;

const MessageInput = styled.form`
  padding: 0.75rem 1rem;
  border-top: 1px solid ${BORDER_GREY};
  display: flex;
  gap: 0.5rem;
  background: white;
  @media (min-width: 768px) {
    padding: 1rem 1.5rem;
    gap: 0.75rem;
  }
  input {
    flex-grow: 1;
    border-radius: 40px;
    padding: 0.6rem 1rem;
    border: 1.5px solid ${BORDER_GREY};
    background: white;
    font-size: 0.85rem;
    transition: all 0.2s;
    &:focus {
      outline: none;
      border-color: ${PHARMACY_GREEN};
      box-shadow: 0 0 0 3px ${PHARMACY_GREEN}20;
    }
    @media (min-width: 768px) {
      padding: 0.75rem 1.25rem;
      font-size: 0.9rem;
    }
  }
  button {
    border-radius: 50%;
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    background: ${PHARMACY_GREEN};
    border: none;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
    &:hover {
      background: #0a5e2e;
      transform: scale(1.02);
    }
    @media (min-width: 768px) {
      width: 48px;
      height: 48px;
    }
  }
`;

const EmptyStateContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  text-align: center;
  color: #6c757d;
  padding: 2rem;
  span {
    font-size: 3rem;
    opacity: 0.5;
    @media (min-width: 768px) {
      font-size: 4rem;
    }
  }
  h5 {
    font-size: 1rem;
    font-weight: 700;
    color: ${DARK_NAVY};
    margin-top: 1rem;
    @media (min-width: 768px) {
      font-size: 1.2rem;
    }
  }
  p {
    font-size: 0.8rem;
    margin-top: 0.5rem;
    @media (min-width: 768px) {
      font-size: 0.9rem;
    }
  }
`;

// --- The Main Component (logic unchanged) ---
const DistributorChat = () => {
  const dispatch = useDispatch();
  const { conversations, allMessages, activeChatUserId, selectedProduct, isLoading, error } = useSelector(
    (state) => state.chat
  );
  const myUserId = parseInt(localStorage.getItem('user_id'), 10);
  const [socket, setSocket] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const messageListRef = useRef(null);

  // 1. Establish Socket connection (No Changes)
  useEffect(() => {
    if (!myUserId) return;
    const s = io(webSocketUrl, {
      path: '/medistocks_user/socket.io', transports: ['websocket'], query: { user_id: myUserId }, withCredentials: true,
    });
    setSocket(s);
    s.on('connect', () => console.log('Socket connected:', s.id));
    s.on('connect_error', (err) => console.error('Socket connection error:', err));
    const handleReceiveMessage = (msg) => dispatch(addMessage(msg));
    s.on('receive_message', handleReceiveMessage);
    return () => { s.off('receive_message', handleReceiveMessage); s.disconnect(); };
  }, [myUserId, dispatch]);

  // 2. Fetch all data and process on frontend
  useEffect(() => {
    if (!myUserId) return;
    const fetchAndProcessData = async () => {
      dispatch(setLoading(true));
      try {
        const res = await axios.get(`${BaseUrl}/chat/messages/${myUserId}`);
        const messages = res.data;
        dispatch(setAllMessages(messages));

        const conversationsMap = new Map();
        messages.forEach(msg => {
          const otherUserId = msg.sender_id === myUserId ? msg.receiver_id : msg.sender_id;
          
          const otherUser = msg.sender_id === myUserId ? 
            { // This is the RECEIVER
                id: msg.receiver_id,
                name: msg.receiver_name,
                image: msg.receiver_image,
                shop_name: msg.receiver_shop_name,
            } : 
            { // This is the SENDER
                id: msg.sender_id,
                name: msg.sender_name,
                image: msg.sender_image,
                shop_name: msg.sender_shop_name,
            };

          if (!conversationsMap.has(otherUserId) || new Date(msg.timestamp) > new Date(conversationsMap.get(otherUserId).timestamp)) {
            conversationsMap.set(otherUserId, {
              id: otherUserId,
              user: otherUser,
              name: otherUser.name,
              lastMessage: msg.message_text,
              timestamp: msg.timestamp,
            });
          }
        });
        const derivedConversations = Array.from(conversationsMap.values())
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        dispatch(setConversations(derivedConversations));
      } catch (err) {
        dispatch(setAllMessages([]));
        dispatch(setConversations([]));
        console.error('Failed to fetch messages:', err);
      } finally {
        dispatch(setLoading(false));
      }
    };
    fetchAndProcessData();
  }, [myUserId, dispatch]);
  
  // 3. Filter messages for active chat
  const filteredMessages = useMemo(() => {
    if (!activeChatUserId) return [];
    return (allMessages || []).filter(m =>
        (m.sender_id === myUserId && m.receiver_id === activeChatUserId) ||
        (m.sender_id === activeChatUserId && m.receiver_id === myUserId)
    );
  }, [allMessages, activeChatUserId, myUserId]);

  // 4. Auto-scroll
  useEffect(() => {
    if (messageListRef.current) {
      messageListRef.current.scrollTop = messageListRef.current.scrollHeight;
    }
  }, [filteredMessages]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeChatUserId) return;
    const msgData = { sender_id: myUserId, receiver_id: activeChatUserId, message_text: newMessage };
    setNewMessage('');
    try {
      socket?.emit('send_message', msgData);
    } catch (err) {
      dispatch(setError('Message failed to send.'));
    }
  };
  
  const handleConversationClick = (userId) => {
    dispatch(setActiveChat(userId));
  };

  const activeChatPartner = useMemo(() => (conversations || []).find((c) => c.id === activeChatUserId), [conversations, activeChatUserId]);

  return (
    <PageLayout>
      <Sidebar>
        <SidebarHeader>Conversations</SidebarHeader>
        <ConversationList>
          {(conversations || []).length > 0 ? (
            (conversations || []).map((convo) => (
              <ConversationItem
                key={convo.id}
                active={convo.id === activeChatUserId}
                onClick={() => handleConversationClick(convo.id)}
              >
                <h6>{convo.name || `User ${convo.id}`}</h6>
                <p>{convo.lastMessage}</p>
              </ConversationItem>
            ))
          ) : (
            <EmptyStateContainer>
              <p style={{ padding: '1rem', color: '#6c757d', textAlign: 'center' }}>
                No conversations yet. <br /> Start a chat from a product page!
              </p>
            </EmptyStateContainer>
          )}
        </ConversationList>
      </Sidebar>

      <ChatWindow>
        {!activeChatUserId ? (
          <EmptyStateContainer>
            <span>💬</span>
            <h5>Select a conversation</h5>
            <p>Choose a chat from the side panel to see the messages.</p>
          </EmptyStateContainer>
        ) : (
          <>
            <ChatHeader>
              <div>
                <h5>{activeChatPartner?.name || `Chat with User ${activeChatUserId}`}</h5>
                {selectedProduct && (<small>Regarding: <strong>{selectedProduct.tablet_name}</strong></small>)}
              </div>
            </ChatHeader>
            <MessageList ref={messageListRef}>
              {isLoading && <p style={{ textAlign: 'center', color: '#6c757d' }}>Loading chat...</p>}
              {error && <p className="text-danger" style={{ textAlign: 'center', color: '#c0392b' }}>{error}</p>}
              {filteredMessages.map((msg, i) => (
                <MessageBubble key={msg.id || i} sent={msg.sender_id === myUserId}>
                  {msg.message_text}
                </MessageBubble>
              ))}
            </MessageList>
            <MessageInput onSubmit={handleSend}>
              <input type="text" placeholder="Type your message..." value={newMessage} onChange={(e) => setNewMessage(e.target.value)} />
              <button type="submit"><FiSend size={18} /></button>
            </MessageInput>
          </>
        )}
      </ChatWindow>
    </PageLayout>
  );
};

export default DistributorChat;