import React, { useState } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeUp = keyframes`from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}`;
const ACCENT = '#10b981';

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 22px;`;

const Grid = styled.div`
  display:grid;grid-template-columns:1fr 320px;gap:18px;align-items:start;
  @media(max-width:900px){grid-template-columns:1fr;}
`;

const Section = styled.div`
  background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;
  overflow:hidden;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,.04);
  animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*60}ms;
`;
const SectionHead = styled.div`
  padding:14px 20px;border-bottom:1px solid #f5f5f5;display:flex;align-items:center;gap:10px;
`;
const SectionIcon = styled.div`
  width:30px;height:30px;border-radius:8px;background:${p=>p.$bg||'#f0fdf9'};
  display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0;
`;
const SectionTitle = styled.h5`font-family:'Plus Jakarta Sans',sans-serif;font-size:.88rem;font-weight:700;color:#111827;margin:0;`;

const SettingItem = styled.div`
  display:flex;justify-content:space-between;align-items:center;
  padding:14px 20px;border-bottom:1px solid #f5f5f5;
  &:last-child{border-bottom:none;}
  @media(max-width:480px){flex-direction:column;align-items:flex-start;gap:8px;}
`;
const ItemLeft  = styled.div``;
const ItemLabel = styled.div`font-size:.875rem;font-weight:600;color:#111827;margin-bottom:2px;`;
const ItemSub   = styled.div`font-size:.76rem;color:#9ca3af;`;

const ActionBtn = styled.button`
  background:none;border:none;color:${p=>p.$danger?'#ef4444':ACCENT};
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.82rem;font-weight:700;
  cursor:pointer;padding:6px 12px;border-radius:7px;transition:background .15s;
  &:hover{background:${p=>p.$danger?'#fef2f2':'#f0fdf9'};}
`;

const Toggle = styled.label`
  position:relative;display:inline-block;width:42px;height:24px;cursor:pointer;
  input{opacity:0;width:0;height:0;}
  span{
    position:absolute;inset:0;background:${p=>p.$on?ACCENT:'#e5e7eb'};border-radius:999px;transition:background .2s;
    &::before{content:'';position:absolute;width:18px;height:18px;border-radius:50%;background:#fff;
      top:3px;left:${p=>p.$on?'21px':'3px'};transition:left .2s;box-shadow:0 1px 3px rgba(0,0,0,.15);}
  }
`;

const DangerZone = styled(Section)`border-color:#fecaca;`;
const DangerHead = styled(SectionHead)`background:#fef2f2;`;

const Settings = ({ navigateTo }) => {
  const [notifs, setNotifs] = useState(true);
  const [twoFA,  setTwoFA]  = useState(false);

  return (
    <Page>
      <PageTitle><em>Settings</em></PageTitle>
      <PageSub>Manage your account and app preferences.</PageSub>

      <Grid>
        <div>
          {/* Account */}
          <Section $i={0}>
            <SectionHead><SectionIcon $bg="#f0fdf9">👤</SectionIcon><SectionTitle>Account</SectionTitle></SectionHead>
            <SettingItem>
              <ItemLeft><ItemLabel>Edit Profile</ItemLabel><ItemSub>Update your name, email, and contact number</ItemSub></ItemLeft>
              <ActionBtn onClick={()=>navigateTo('Profile')}>Manage →</ActionBtn>
            </SettingItem>
            <SettingItem>
              <ItemLeft><ItemLabel>Change Password</ItemLabel><ItemSub>Update your login credentials</ItemSub></ItemLeft>
              <ActionBtn>Change →</ActionBtn>
            </SettingItem>
          </Section>

          {/* Subscription */}
          <Section $i={1}>
            <SectionHead><SectionIcon $bg="#eff6ff">💳</SectionIcon><SectionTitle>Subscription & Billing</SectionTitle></SectionHead>
            <SettingItem>
              <ItemLeft><ItemLabel>Manage Plan</ItemLabel><ItemSub>Currently on the <span style={{color:ACCENT,fontWeight:700}}>Gold Plan</span></ItemSub></ItemLeft>
              <ActionBtn>Upgrade →</ActionBtn>
            </SettingItem>
            <SettingItem>
              <ItemLeft><ItemLabel>Payment History</ItemLabel><ItemSub>View past transactions and invoices</ItemSub></ItemLeft>
              <ActionBtn onClick={()=>navigateTo('Billing')}>View →</ActionBtn>
            </SettingItem>
          </Section>

          {/* Preferences */}
          <Section $i={2}>
            <SectionHead><SectionIcon $bg="#fffbeb">⚙️</SectionIcon><SectionTitle>Preferences</SectionTitle></SectionHead>
            <SettingItem>
              <ItemLeft><ItemLabel>Notifications</ItemLabel><ItemSub>Manage how you receive alerts</ItemSub></ItemLeft>
              <Toggle $on={notifs} onClick={()=>setNotifs(p=>!p)}>
                <input type="checkbox" readOnly checked={notifs}/><span/>
              </Toggle>
            </SettingItem>
            <SettingItem>
              <ItemLeft><ItemLabel>Two-Factor Authentication</ItemLabel><ItemSub>Keep your account extra secure</ItemSub></ItemLeft>
              <Toggle $on={twoFA} onClick={()=>setTwoFA(p=>!p)}>
                <input type="checkbox" readOnly checked={twoFA}/><span/>
              </Toggle>
            </SettingItem>
          </Section>
        </div>

        <div>
          {/* Help */}
          <Section $i={3}>
            <SectionHead><SectionIcon $bg="#f5f3ff">🎧</SectionIcon><SectionTitle>Help & Support</SectionTitle></SectionHead>
            <SettingItem>
              <ItemLabel>FAQ & Help Center</ItemLabel>
              <ActionBtn onClick={()=>navigateTo('FAQs')}>View →</ActionBtn>
            </SettingItem>
            <SettingItem>
              <ItemLabel>Contact Support</ItemLabel>
              <ActionBtn onClick={()=>navigateTo('Support')}>Contact →</ActionBtn>
            </SettingItem>
          </Section>

          {/* About */}
          <Section $i={4}>
            <SectionHead><SectionIcon $bg="#f9fafb">ℹ️</SectionIcon><SectionTitle>About</SectionTitle></SectionHead>
            <SettingItem>
              <ItemLabel>Privacy Policy</ItemLabel>
              <ActionBtn>View →</ActionBtn>
            </SettingItem>
            <SettingItem>
              <ItemLabel>Terms of Service</ItemLabel>
              <ActionBtn onClick={()=>navigateTo('Terms and Conditions')}>View →</ActionBtn>
            </SettingItem>
            <SettingItem>
              <ItemLeft><ItemLabel>App Version</ItemLabel><ItemSub>v2.0.0</ItemSub></ItemLeft>
            </SettingItem>
          </Section>

          {/* Danger */}
          <DangerZone $i={5}>
            <DangerHead><SectionIcon $bg="#fef2f2">⚠️</SectionIcon><SectionTitle style={{color:'#ef4444'}}>Danger Zone</SectionTitle></DangerHead>
            <SettingItem>
              <ItemLeft><ItemLabel>Delete Account</ItemLabel><ItemSub>Permanently delete all your data</ItemSub></ItemLeft>
              <ActionBtn $danger>Delete</ActionBtn>
            </SettingItem>
          </DangerZone>
        </div>
      </Grid>
    </Page>
  );
};

export default Settings;