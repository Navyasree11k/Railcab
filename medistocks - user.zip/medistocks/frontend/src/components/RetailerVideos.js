import React, { useState, useEffect } from 'react';
import axios from 'axios';
import styled, { keyframes } from 'styled-components';
import Baseurl from './BaseUrl';
import { FaPlay, FaCalendarAlt } from 'react-icons/fa';

const fadeUp = keyframes`from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}`;
const spin   = keyframes`to{transform:rotate(360deg)}`;
const ACCENT = '#10b981';

const fmtDate = d => d ? new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}) : 'N/A';

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 22px;`;

const Grid = styled.div`
  display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:18px;
  @media(max-width:480px){grid-template-columns:1fr;}
`;

const VideoCard = styled.div`
  background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;overflow:hidden;cursor:pointer;
  transition:transform .2s,box-shadow .2s,border-color .2s;
  box-shadow:0 1px 4px rgba(0,0,0,.04);
  animation:${fadeUp} .5s ease both;animation-delay:${p=>p.$i*60}ms;
  &:hover{transform:translateY(-4px);box-shadow:0 12px 28px rgba(0,0,0,.09);border-color:#e0e0e0;}
`;

const ThumbWrap = styled.div`
  position:relative;width:100%;padding-top:56.25%;background:#f5f7fa;
  overflow:hidden;
`;
const Thumb = styled.img`position:absolute;inset:0;width:100%;height:100%;object-fit:cover;`;
const PlayOverlay = styled.div`
  position:absolute;inset:0;background:rgba(0,0,0,.45);
  display:flex;align-items:center;justify-content:center;
  opacity:0;transition:opacity .2s;
  ${VideoCard}:hover &{opacity:1;}
`;
const PlayCircle = styled.div`
  width:52px;height:52px;border-radius:50%;background:#fff;
  display:flex;align-items:center;justify-content:center;
  font-size:1.2rem;color:${ACCENT};
`;

const CardBody = styled.div`padding:14px 16px;`;
const VTitle   = styled.div`font-weight:700;font-size:.9rem;color:#111827;margin-bottom:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;`;
const VMeta    = styled.div`display:flex;align-items:center;gap:6px;font-size:.76rem;color:#9ca3af;`;

/* Modal */
const ModalBg = styled.div`position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(8px);display:flex;justify-content:center;align-items:center;z-index:1050;padding:16px;animation:${fadeUp} .25s ease;`;
const ModalBox = styled.div`background:#fff;border-radius:16px;width:100%;max-width:860px;max-height:90vh;overflow:hidden;display:flex;flex-direction:column;`;
const VideoWrap= styled.div`width:100%;padding-top:56.25%;position:relative;background:#000;`;
const VideoEl  = styled.video`position:absolute;inset:0;width:100%;height:100%;`;
const ModalInfo= styled.div`padding:20px 22px;background:#fafafa;border-top:1px solid #f0f0f0;overflow-y:auto;`;
const CloseBtn = styled.button`position:absolute;top:12px;right:12px;width:38px;height:38px;border-radius:50%;background:rgba(0,0,0,.5);border:none;color:#fff;font-size:1.1rem;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:10;&:hover{background:rgba(239,68,68,.8);}`;

const SpinWrap = styled.div`display:flex;justify-content:center;padding:80px;`;
const Spin     = styled.div`width:32px;height:32px;border-radius:50%;border:3px solid #e5e7eb;border-top-color:${ACCENT};animation:${spin} .8s linear infinite;`;
const ErrBox   = styled.div`background:#fef2f2;border:1px solid #fecaca;color:#ef4444;border-radius:10px;padding:12px 16px;font-size:.86rem;`;
const Empty    = styled.div`background:#fff;border:1.5px dashed #e5e7eb;border-radius:14px;padding:60px;text-align:center;color:#9ca3af;font-size:.875rem;`;

const Videos = () => {
  const [videos,   setVideos]   = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState(null);

  useEffect(() => {
    axios.get(`${Baseurl}/api/videos/videos`)
      .then(r => setVideos(r.data))
      .catch(() => setError('Failed to load videos.'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Page>
      <PageTitle>Tutorials &amp; <em>Guides</em></PageTitle>
      <PageSub>Watch videos to discover features and grow your pharmacy business.</PageSub>

      {loading && <SpinWrap><Spin /></SpinWrap>}
      {error   && <ErrBox>⚠ {error}</ErrBox>}

      {!loading && !error && videos.length === 0 && (
        <Empty>
          <div style={{fontSize:'2rem',opacity:.4,marginBottom:10}}>▶️</div>
          No videos available yet.
        </Empty>
      )}

      {!loading && videos.length > 0 && (
        <Grid>
          {videos.map((v, i) => (
            <VideoCard key={v.id} $i={i} onClick={()=>setSelected(v)}>
              <ThumbWrap>
                <Thumb src={v.image_url} alt={v.title} onError={e=>{e.target.src='https://placehold.co/400x225/f5f7fa/9ca3af?text=No+Thumb';}}/>
                <PlayOverlay><PlayCircle><FaPlay size={16}/></PlayCircle></PlayOverlay>
              </ThumbWrap>
              <CardBody>
                <VTitle title={v.title}>{v.title}</VTitle>
                <VMeta><FaCalendarAlt size={10}/> {fmtDate(v.uploaded_at)}</VMeta>
              </CardBody>
            </VideoCard>
          ))}
        </Grid>
      )}

      {selected && (
        <ModalBg onClick={()=>setSelected(null)}>
          <ModalBox onClick={e=>e.stopPropagation()}>
            <div style={{position:'relative'}}>
              <CloseBtn onClick={()=>setSelected(null)}>×</CloseBtn>
              <VideoWrap>
                <VideoEl src={selected.video_url} controls autoPlay />
              </VideoWrap>
            </div>
            <ModalInfo>
              <div style={{fontWeight:800,fontSize:'1.05rem',color:'#111827',marginBottom:6}}>{selected.title}</div>
              <div style={{fontSize:'.76rem',color:'#9ca3af',marginBottom:10,display:'flex',alignItems:'center',gap:5}}><FaCalendarAlt size={10}/>{fmtDate(selected.uploaded_at)}</div>
              <p style={{color:'#6b7280',fontSize:'.86rem',lineHeight:1.7,margin:0}}>{selected.description}</p>
            </ModalInfo>
          </ModalBox>
        </ModalBg>
      )}
    </Page>
  );
};

export default Videos;