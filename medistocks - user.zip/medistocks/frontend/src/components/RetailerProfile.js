import React, { useState, useEffect, useRef } from 'react';
import styled, { keyframes } from 'styled-components';
import { FiEdit2, FiCamera, FiPhone, FiMail, FiMessageCircle } from 'react-icons/fi';
import BaseUrl from './BaseUrl';

const fadeUp = keyframes`from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}`;
const spin   = keyframes`to{transform:rotate(360deg)}`;
const ACCENT = '#10b981';

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 22px;`;

const Grid = styled.div`
  display:grid;grid-template-columns:280px 1fr;gap:18px;align-items:start;
  @media(max-width:860px){grid-template-columns:1fr;}
`;

const Card = styled.div`background:#fff;border:1.5px solid #f0f0f0;border-radius:14px;padding:20px;box-shadow:0 1px 4px rgba(0,0,0,.04);animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*80}ms;`;

const AvatarWrap = styled.div`position:relative;width:96px;height:96px;margin:0 auto 14px;cursor:pointer;
  &:hover .overlay{opacity:1;}
`;
const AvatarImg = styled.img`width:96px;height:96px;border-radius:50%;object-fit:cover;border:3px solid ${ACCENT};`;
const AvatarOverlay = styled.div`
  position:absolute;inset:0;border-radius:50%;background:rgba(0,0,0,.5);
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  opacity:0;transition:opacity .2s;color:#fff;font-size:.7rem;
  &.overlay{}
`;

const SectionTitle = styled.div`font-weight:700;font-size:.78rem;text-transform:uppercase;letter-spacing:.8px;color:${ACCENT};margin:0 0 12px;display:flex;align-items:center;gap:7px;&::after{content:'';flex:1;height:1px;background:rgba(16,185,129,.15);}`;
const InfoRow = styled.div`display:flex;justify-content:space-between;align-items:center;padding:11px 0;border-bottom:1px solid #f5f5f5;&:last-child{border:none;}`;
const InfoLabel= styled.div`font-size:.74rem;color:#9ca3af;margin-bottom:2px;`;
const InfoVal  = styled.div`font-size:.875rem;font-weight:600;color:#374151;`;
const EditBtn  = styled.button`width:32px;height:32px;border-radius:8px;border:1.5px solid #f0f0f0;background:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0;transition:all .15s;color:#9ca3af;&:hover{background:#f0fdf9;border-color:#a7f3d0;color:${ACCENT};}`;

const DetailGrid = styled.div`display:grid;grid-template-columns:1fr 1fr;gap:12px;@media(max-width:480px){grid-template-columns:1fr;}`;
const DetailItem = styled.div``;
const DetailLabel= styled.div`font-size:.72rem;color:#9ca3af;margin-bottom:3px;text-transform:uppercase;letter-spacing:.5px;`;
const DetailVal  = styled.div`font-size:.86rem;font-weight:600;color:#374151;`;

const DocItem = styled.div`display:flex;justify-content:space-between;align-items:center;background:#f9fafb;border:1px solid #f0f0f0;border-radius:10px;padding:10px 14px;margin-bottom:8px;`;
const DocName  = styled.div`font-size:.86rem;font-weight:600;color:#374151;text-transform:capitalize;`;
const ViewLink = styled.a`font-size:.8rem;font-weight:700;color:${ACCENT};text-decoration:none;&:hover{text-decoration:underline;}`;

const FloatBtn = styled.button`
  position:fixed;bottom:28px;right:28px;
  display:flex;align-items:center;gap:8px;
  padding:12px 20px;border-radius:999px;border:none;
  background:linear-gradient(135deg,${ACCENT},#0ea5e9);color:#fff;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.875rem;font-weight:700;
  cursor:pointer;box-shadow:0 6px 20px rgba(16,185,129,.35);
  transition:all .2s;z-index:100;
  &:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(16,185,129,.4);}
`;

const SpinWrap = styled.div`display:flex;justify-content:center;padding:60px;`;
const Spin     = styled.div`width:32px;height:32px;border-radius:50%;border:3px solid #e5e7eb;border-top-color:${ACCENT};animation:${spin} .8s linear infinite;`;

/* Modal */
const ModalBg  = styled.div`position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(4px);display:flex;justify-content:center;align-items:center;z-index:1050;padding:16px;`;
const ModalBox = styled.div`background:#fff;border-radius:16px;padding:24px;width:100%;max-width:420px;box-shadow:0 20px 40px rgba(0,0,0,.1);`;
const ModalTitle=styled.div`font-weight:700;font-size:1rem;color:#111827;margin-bottom:16px;`;
const Label    = styled.label`font-size:.72rem;text-transform:uppercase;letter-spacing:.5px;color:#9ca3af;font-weight:600;margin-bottom:5px;display:block;`;
const Input    = styled.input`width:100%;background:#f9fafb;border:1.5px solid #e5e7eb;border-radius:9px;padding:11px 13px;color:#111827;font-family:'Plus Jakarta Sans',sans-serif;font-size:.875rem;outline:none;box-sizing:border-box;transition:all .2s;&:focus{border-color:${ACCENT};background:#fff;box-shadow:0 0 0 3px rgba(16,185,129,.1);}&::placeholder{color:#d1d5db;}`;
const ModalBtns= styled.div`display:flex;gap:10px;margin-top:18px;`;
const PrimaryBtn=styled.button`flex:1;padding:11px;background:linear-gradient(135deg,${ACCENT},#0ea5e9);border:none;border-radius:9px;color:#fff;font-family:'Plus Jakarta Sans',sans-serif;font-size:.88rem;font-weight:700;cursor:pointer;transition:all .2s;&:hover:not(:disabled){transform:translateY(-1px);}& :disabled{opacity:.45;cursor:not-allowed;}`;
const SecBtn   = styled.button`flex:1;padding:11px;background:#fff;border:1.5px solid #e5e7eb;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:.88rem;font-weight:600;color:#374151;cursor:pointer;`;
const Alert    = styled.div`background:#fef2f2;border:1px solid #fecaca;color:#ef4444;border-radius:8px;padding:10px 13px;font-size:.82rem;margin-bottom:12px;`;

const Profile = ({ navigateTo }) => {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState('');
  const [editProfileOpen, setEditProfileOpen] = useState(false);
  const [editContactOpen, setEditContactOpen] = useState(false);
  const [editBusinessOpen, setEditBusinessOpen] = useState(false);
  const [editName, setEditName] = useState('');
  const [editPic,  setEditPic]  = useState(null);
  const [businessData, setBusinessData] = useState({
    shop_name: '',
    gst_in_number: '',
    shop_address: '',
    city_name: '',
    pin_code: '',
  });
  const [contactType, setContactType] = useState('');
  const [newContact, setNewContact]   = useState('');
  const [otp, setOtp]   = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [saving, setSaving]   = useState(false);
  const fileRef = useRef(null);

  useEffect(() => {
    const uid = localStorage.getItem('user_id');
    if (!uid) { setError('Not logged in.'); setLoading(false); return; }
    fetch(`${BaseUrl}/auth/get-user/${uid}`)
      .then(r=>r.json())
      .then(d=>{ 
        if(d.status==='success'){
          setUserData(d.data);
          setEditName(d.data.user_name);
          setBusinessData({
            shop_name: d.data.shop_name || '',
            gst_in_number: d.data.gst_in_number || '',
            shop_address: d.data.shop_address || '',
            city_name: d.data.city_name || '',
            pin_code: d.data.pin_code || '',
          });
        }else throw new Error(d.message); 
      })
      .catch(e=>setError(e.message))
      .finally(()=>setLoading(false));
  }, []);

  const saveProfile = async e => {
    e.preventDefault(); setSaving(true);
    const uid = localStorage.getItem('user_id');
    const fd  = new FormData();
    if(editName!==userData.user_name) fd.append('user_name',editName);
    if(editPic) fd.append('profile_pic',editPic);
    try {
      const r = await fetch(`${BaseUrl}/auth/update-user/${uid}`,{method:'PUT',body:fd});
      const d = await r.json();
      if(!r.ok) throw new Error(d.message);
      setUserData(p=>({...p,...d.data})); setEditProfileOpen(false); setEditPic(null);
    } catch(e){ setError(e.message); }
    finally{ setSaving(false); }
  };

  const sendContactOtp = async () => {
    setSaving(true); setError('');
    const uid = localStorage.getItem('user_id');
    const payload = {user_id:uid,[contactType==='mobile'?'mobile_number':'email_address']:newContact};
    try {
      const r = await fetch(`${BaseUrl}/auth/update_contact/send_otp`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const d = await r.json();
      if(!r.ok) throw new Error(d.message);
      setOtpSent(true);
    } catch(e){ setError(e.message); }
    finally{ setSaving(false); }
  };

  const verifyContactOtp = async () => {
    setSaving(true); setError('');
    const uid = localStorage.getItem('user_id');
    const payload = {user_id:uid,otp,[contactType==='mobile'?'mobile_number':'email_address']:newContact};
    try {
      const r = await fetch(`${BaseUrl}/auth/update_contact/verify_otp`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const d = await r.json();
      if(!r.ok) throw new Error(d.message);
      setEditContactOpen(false); setNewContact(''); setOtp(''); setOtpSent(false);
      window.location.reload();
    } catch(e){ setError(e.message); }
    finally{ setSaving(false); }
  };

  const handleSaveBusiness = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    const uid = localStorage.getItem('user_id');
    try {
      const r = await fetch(`${BaseUrl}/auth/update-user-details`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: uid, ...businessData })
      });
      const d = await r.json();
      if (d.status !== 'success') throw new Error(d.message);
      setUserData(p => ({ ...p, ...businessData }));
      setEditBusinessOpen(false);
    } catch (e) { setError(e.message); }
    finally { setSaving(false); }
  };

  const openContact = t => { setContactType(t); setError(''); setEditContactOpen(true); };
  const closeContact= () => { setEditContactOpen(false); setNewContact(''); setOtp(''); setOtpSent(false); setError(''); };

  if(loading) return <SpinWrap><Spin/></SpinWrap>;
  if(error&&!userData) return <div style={{background:'#fef2f2',border:'1px solid #fecaca',color:'#ef4444',borderRadius:10,padding:'14px 18px',fontSize:'.86rem'}}>{error}</div>;
  if(!userData) return null;

  return (
    <Page>
      <PageTitle>My <em>Profile</em></PageTitle>
      <PageSub>Manage your account details and business information.</PageSub>

      <Grid>
        {/* Left: avatar + quick info */}
        <Card $i={0} style={{textAlign:'center'}}>
          <AvatarWrap onClick={()=>setEditProfileOpen(true)}>
            <AvatarImg src={userData.profile_pic_url||`https://ui-avatars.com/api/?name=${userData.user_name}&background=10b981&color=fff`} alt={userData.user_name}/>
            <AvatarOverlay className="overlay"><FiCamera size={16}/><span style={{marginTop:3}}>Change</span></AvatarOverlay>
          </AvatarWrap>
          <div style={{fontWeight:800,fontSize:'1rem',color:'#111827',marginBottom:2}}>{userData.user_name}</div>
          <div style={{fontSize:'.8rem',color:'#9ca3af',marginBottom:4}}>{userData.email_address}</div>
          <div style={{fontSize:'.8rem',color:'#9ca3af'}}>{userData.mobile_number}</div>
        </Card>

        {/* Right: details */}
        <div>
          <Card $i={1} style={{marginBottom:16}}>
            <SectionTitle>Contact Information</SectionTitle>
            <InfoRow>
              <div><InfoLabel>Full Name</InfoLabel><InfoVal>{userData.user_name}</InfoVal></div>
              <EditBtn onClick={()=>setEditProfileOpen(true)}><FiEdit2 size={12}/></EditBtn>
            </InfoRow>
            <InfoRow>
              <div><InfoLabel>Email Address</InfoLabel><InfoVal>{userData.email_address}</InfoVal></div>
              <EditBtn onClick={()=>openContact('email')}><FiMail size={12}/></EditBtn>
            </InfoRow>
            <InfoRow>
              <div><InfoLabel>Mobile Number</InfoLabel><InfoVal>{userData.mobile_number}</InfoVal></div>
              <EditBtn onClick={()=>openContact('mobile')}><FiPhone size={12}/></EditBtn>
            </InfoRow>
          </Card>

          <Card $i={2} style={{marginBottom:16}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
              <SectionTitle style={{marginBottom:0}}>Business Details</SectionTitle>
              <EditBtn onClick={()=>setEditBusinessOpen(true)}><FiEdit2 size={12}/></EditBtn>
            </div>
            <DetailGrid>
              <DetailItem><DetailLabel>Shop Name</DetailLabel><DetailVal>{userData.shop_name||'—'}</DetailVal></DetailItem>
              <DetailItem><DetailLabel>GSTIN</DetailLabel><DetailVal>{userData.gst_in_number||'—'}</DetailVal></DetailItem>
              <DetailItem style={{gridColumn:'1/-1'}}><DetailLabel>Address</DetailLabel><DetailVal>{`${userData.shop_address||''} ${userData.city_name||''} ${userData.pin_code||''}`.trim()||'—'}</DetailVal></DetailItem>
            </DetailGrid>
          </Card>

          {userData.documents && Object.keys(userData.documents).length > 0 && (
            <Card $i={3}>
              <SectionTitle>Documents</SectionTitle>
              {Object.entries(userData.documents).map(([k,v]) => v && (
                <DocItem key={k}>
                  <DocName>{k.replace(/_/g,' ')}</DocName>
                  <ViewLink href={v} target="_blank" rel="noopener noreferrer">View →</ViewLink>
                </DocItem>
              ))}
            </Card>
          )}
        </div>
      </Grid>

      {/* Edit profile modal */}
      {editProfileOpen && (
        <ModalBg onClick={()=>setEditProfileOpen(false)}>
          <ModalBox onClick={e=>e.stopPropagation()}>
            <ModalTitle>Edit Profile</ModalTitle>
            {error && <Alert>{error}</Alert>}
            <form onSubmit={saveProfile}>
              <div style={{marginBottom:12}}><Label>Full Name</Label><Input value={editName} onChange={e=>setEditName(e.target.value)}/></div>
              <div style={{marginBottom:4}}><Label>Profile Picture</Label><Input type="file" accept="image/*" onChange={e=>setEditPic(e.target.files[0])} ref={fileRef}/></div>
              <ModalBtns>
                <SecBtn type="button" onClick={()=>setEditProfileOpen(false)}>Cancel</SecBtn>
                <PrimaryBtn type="submit" disabled={saving}>{saving?'Saving…':'Save Changes'}</PrimaryBtn>
              </ModalBtns>
            </form>
          </ModalBox>
        </ModalBg>
      )}

      {/* Edit business modal */}
      {editBusinessOpen && (
        <ModalBg onClick={()=>setEditBusinessOpen(false)}>
          <ModalBox onClick={e=>e.stopPropagation()} style={{maxWidth:500}}>
            <ModalTitle>Edit Business Details</ModalTitle>
            {error && <Alert>{error}</Alert>}
            <form onSubmit={handleSaveBusiness}>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                <div style={{marginBottom:12}}><Label>Shop Name</Label><Input value={businessData.shop_name} onChange={e=>setBusinessData({...businessData,shop_name:e.target.value})}/></div>
                <div style={{marginBottom:12}}><Label>GSTIN</Label><Input value={businessData.gst_in_number} onChange={e=>setBusinessData({...businessData,gst_in_number:e.target.value})}/></div>
              </div>
              <div style={{marginBottom:12}}><Label>Shop Address</Label><Input value={businessData.shop_address} onChange={e=>setBusinessData({...businessData,shop_address:e.target.value})}/></div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                <div style={{marginBottom:12}}><Label>City</Label><Input value={businessData.city_name} onChange={e=>setBusinessData({...businessData,city_name:e.target.value})}/></div>
                <div style={{marginBottom:12}}><Label>Pin Code</Label><Input value={businessData.pin_code} onChange={e=>setBusinessData({...businessData,pin_code:e.target.value})}/></div>
              </div>
              <ModalBtns>
                <SecBtn type="button" onClick={()=>setEditBusinessOpen(false)}>Cancel</SecBtn>
                <PrimaryBtn type="submit" disabled={saving}>{saving?'Saving…':'Save Business Details'}</PrimaryBtn>
              </ModalBtns>
            </form>
          </ModalBox>
        </ModalBg>
      )}
      {editContactOpen && (
        <ModalBg onClick={closeContact}>
          <ModalBox onClick={e=>e.stopPropagation()}>
            <ModalTitle>Update {contactType==='mobile'?'Mobile Number':'Email Address'}</ModalTitle>
            {error && <Alert>{error}</Alert>}
            {!otpSent ? (
              <>
                <Label>New {contactType==='mobile'?'Mobile':'Email'}</Label>
                <Input type={contactType==='mobile'?'tel':'email'} placeholder={contactType==='mobile'?'+91…':'name@example.com'} value={newContact} onChange={e=>setNewContact(e.target.value)}/>
                <ModalBtns>
                  <SecBtn onClick={closeContact}>Cancel</SecBtn>
                  <PrimaryBtn disabled={saving||!newContact} onClick={sendContactOtp}>{saving?'Sending…':'Send OTP'}</PrimaryBtn>
                </ModalBtns>
              </>
            ) : (
              <>
                <p style={{fontSize:'.84rem',color:'#6b7280',margin:'0 0 12px'}}>OTP sent to {newContact}.</p>
                <Label>Enter OTP</Label>
                <Input type="text" value={otp} onChange={e=>setOtp(e.target.value)} maxLength={6}/>
                <ModalBtns>
                  <SecBtn onClick={closeContact}>Cancel</SecBtn>
                  <PrimaryBtn disabled={saving||!otp} onClick={verifyContactOtp}>{saving?'Verifying…':'Verify & Update'}</PrimaryBtn>
                </ModalBtns>
              </>
            )}
          </ModalBox>
        </ModalBg>
      )}

      <FloatBtn onClick={()=>navigateTo('Chat')}>
        <FiMessageCircle size={16}/> Chat Support
      </FloatBtn>
    </Page>
  );
};

export default Profile;