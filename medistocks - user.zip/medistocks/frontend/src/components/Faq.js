import React, { useState, useMemo, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';
import axios from 'axios';
import BaseUrl from './BaseUrl';

const fadeUp = keyframes`from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}`;
const ACCENT = '#10b981';

const faqData = [
  { category:'Getting Started', question:'How do I register on MediStox?', answer:'Click "Sign Up", fill in your details, and follow the on-screen steps to verify your mobile number and email address.' },
  { category:'Verification', question:'What happens if I don\'t complete KYC?', answer:'KYC is mandatory for full access. Without it, you cannot send purchase requests or interact with distributors.' },
  { category:'Plans & Pricing', question:'Can I change my plan later?', answer:'Yes, upgrade anytime through "Subscription & Plans" in your profile. Downgrades take effect at end of the current billing cycle.' },
  { category:'Getting Started', question:'How is product expiry tracked?', answer:'Each product listing includes an expiry progress bar that visually shows how close it is to its expiry date. Products are removed automatically once expired.' },
  { category:'Verification', question:'What if I pay but the invoice isn\'t generated?', answer:'Contact support with your transaction ID and we will resolve it promptly.' },
  { category:'Plans & Pricing', question:'What payment methods are accepted?', answer:'We accept UPI, credit/debit cards, and net banking via Razorpay for all plan purchases and ad campaigns.' },
];

const Page = styled.div`font-family:'Plus Jakarta Sans',sans-serif;`;
const PageTitle = styled.h2`font-size:1.4rem;font-weight:800;color:#111827;margin:0 0 4px;letter-spacing:-.4px;em{color:${ACCENT};font-style:normal;}`;
const PageSub   = styled.p`font-size:.84rem;color:#9ca3af;margin:0 0 22px;`;

const SearchBox = styled.div`
  display:flex;align-items:center;gap:8px;background:#fff;border:1.5px solid #e5e7eb;
  border-radius:10px;padding:10px 14px;margin-bottom:16px;
  input{background:none;border:none;outline:none;font-family:'Plus Jakarta Sans',sans-serif;font-size:.875rem;color:#374151;width:100%;}
  input::placeholder{color:#d1d5db;}
  &:focus-within{border-color:${ACCENT};box-shadow:0 0 0 3px rgba(16,185,129,.1);}
`;

const FilterRow = styled.div`display:flex;flex-wrap:wrap;gap:8px;margin-bottom:20px;`;
const FilterChip = styled.button`
  padding:6px 14px;border-radius:8px;border:1.5px solid ${p=>p.$active?ACCENT:'#e5e7eb'};
  background:${p=>p.$active?'linear-gradient(135deg,rgba(16,185,129,.1),rgba(14,165,233,.06))':'#fff'};
  color:${p=>p.$active?ACCENT:'#6b7280'};font-family:'Plus Jakarta Sans',sans-serif;
  font-size:.8rem;font-weight:${p=>p.$active?700:500};cursor:pointer;transition:all .15s;
  &:hover{border-color:${ACCENT};}
`;

const AccordCard = styled.div`background:#fff;border:1.5px solid #f0f0f0;border-radius:12px;overflow:hidden;margin-bottom:10px;box-shadow:0 1px 4px rgba(0,0,0,.04);animation:${fadeUp} .4s ease both;animation-delay:${p=>p.$i*50}ms;`;
const AccordBtn  = styled.button`
  width:100%;display:flex;justify-content:space-between;align-items:center;
  padding:16px 20px;background:none;border:none;text-align:left;cursor:pointer;transition:background .15s;
  &:hover{background:#f9fafb;}
`;
const AccordQ    = styled.span`font-size:.9rem;font-weight:600;color:#111827;`;
const AccordIcon = styled.span`font-size:1.1rem;color:${p=>p.$open?ACCENT:'#9ca3af'};flex-shrink:0;margin-left:12px;transition:transform .2s;transform:${p=>p.$open?'rotate(45deg)':'none'};`;
const AccordAns  = styled.div`padding:0 20px 16px;font-size:.86rem;color:#6b7280;line-height:1.7;border-top:1px solid #f5f5f5;`;

const ContactCard = styled.div`background:linear-gradient(135deg,#ecfdf5,#eff6ff);border:1.5px solid #a7f3d0;border-radius:14px;padding:24px;text-align:center;margin-top:20px;`;
const PrimaryBtn  = styled.button`
  padding:11px 28px;background:linear-gradient(135deg,${ACCENT},#0ea5e9);
  border:none;border-radius:9px;color:#fff;
  font-family:'Plus Jakarta Sans',sans-serif;font-size:.88rem;font-weight:700;
  cursor:pointer;transition:all .2s;box-shadow:0 4px 12px rgba(16,185,129,.22);
  &:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(16,185,129,.3);}
`;

const FAQ = ({ navigateTo }) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const [openIdx, setOpenIdx] = useState(null);
  const [faqs, setFaqs] = useState(faqData);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFaqs = async () => {
      try {
        const response = await axios.get(`${BaseUrl}/guideline/latest`);
        if (response.data && response.data.content) {
          try {
            const parsed = JSON.parse(response.data.content);
            if (Array.isArray(parsed)) {
              setFaqs(parsed);
            } else {
              // If it's a string but not JSON array, create a single entry
              setFaqs([{ category: 'General', question: 'Guidelines', answer: response.data.content }]);
            }
          } catch (e) {
            // Not JSON, just display as one entry
            setFaqs([{ category: 'General', question: 'Latest Guidelines', answer: response.data.content }]);
          }
        }
      } catch (err) {
        console.error('Error fetching FAQs:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchFaqs();
  }, []);

  const categories = useMemo(() => {
    const cats = ['All', ...new Set(faqs.map(f => f.category))];
    return cats.filter(c => c);
  }, [faqs]);

  const filtered = useMemo(() =>
    faqs.filter(f =>
      (filter === 'All' || f.category === filter) &&
      (f.question?.toLowerCase().includes(search.toLowerCase()) || 
       f.answer?.toLowerCase().includes(search.toLowerCase()))
    ), [search, filter, faqs]);

  return (
    <Page>
      <PageTitle>FAQ &amp; <em>Help</em></PageTitle>
      <PageSub>Find quick answers to common questions.</PageSub>

      <SearchBox>
        <span style={{color:'#9ca3af'}}>🔍</span>
        <input placeholder="Search FAQs…" value={search} onChange={e=>setSearch(e.target.value)}/>
      </SearchBox>

      <FilterRow>
        {categories.map(c=>(
          <FilterChip key={c} $active={filter===c} onClick={()=>setFilter(c)}>{c}</FilterChip>
        ))}
      </FilterRow>

      {filtered.length === 0 && (
        <div style={{textAlign:'center',padding:'40px',color:'#9ca3af',background:'#fff',borderRadius:12,border:'1.5px dashed #e5e7eb'}}>
          <div style={{fontSize:'2rem',marginBottom:10}}>🔎</div>
          <p>No results found for "<strong>{search}</strong>"</p>
        </div>
      )}

      {filtered.map((faq, i) => (
        <AccordCard key={i} $i={i}>
          <AccordBtn onClick={()=>setOpenIdx(openIdx===i?null:i)}>
            <AccordQ>{faq.question}</AccordQ>
            <AccordIcon $open={openIdx===i}>+</AccordIcon>
          </AccordBtn>
          {openIdx === i && <AccordAns>{faq.answer}</AccordAns>}
        </AccordCard>
      ))}

      <ContactCard>
        <div style={{fontSize:'1.5rem',marginBottom:8}}>💬</div>
        <div style={{fontWeight:700,fontSize:'1rem',color:'#111827',marginBottom:4}}>Still have questions?</div>
        <p style={{color:'#6b7280',fontSize:'.86rem',margin:'0 0 16px'}}>Our support team is ready to help you.</p>
        <PrimaryBtn onClick={()=>navigateTo('Support')}>Contact Support</PrimaryBtn>
      </ContactCard>
    </Page>
  );
};

export default FAQ;