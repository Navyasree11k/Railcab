import React, { useState } from 'react';
import styled from 'styled-components';

// --- Styled Components (improved with pharmacy theme) ---
const PHARMACY_GREEN = '#0D7C3D';
const LIGHT_GREEN = '#E8F5E9';
const DARK_NAVY = '#1A2E4A';
const BORDER_GREY = '#DEE2E6';

const GlassmorphismContainer = styled.div`
  background: white;
  backdrop-filter: blur(10px);
  border: 1px solid ${BORDER_GREY};
  border-radius: 1.5rem;
  padding: 1.5rem;
  box-shadow: 0 8px 20px rgba(0,0,0,0.05);
  transition: all 0.2s;

  @media (max-width: 768px) {
    padding: 1.25rem;
  }
`;

const PaymentMethodCard = styled.div`
  background: ${({ active }) => active ? `${PHARMACY_GREEN}08` : 'white'};
  border: 1.5px solid ${({ active }) => active ? PHARMACY_GREEN : BORDER_GREY};
  border-radius: 1rem;
  padding: 1rem 1.25rem;
  margin-bottom: 1rem;
  cursor: pointer;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 1rem;
  box-shadow: ${({ active }) => active ? `0 0 0 2px ${PHARMACY_GREEN}20` : 'none'};

  &:hover {
    border-color: ${PHARMACY_GREEN};
    transform: translateX(4px);
  }

  @media (max-width: 480px) {
    padding: 0.75rem 1rem;
    gap: 0.75rem;
  }
`;

const RadioButton = styled.div`
  width: 22px;
  height: 22px;
  border-radius: 50%;
  border: 2px solid ${({ active }) => active ? PHARMACY_GREEN : '#cbd5e1'};
  background-color: ${({ active }) => active ? PHARMACY_GREEN : 'transparent'};
  display: flex;
  justify-content: center;
  align-items: center;
  transition: all 0.2s;
  flex-shrink: 0;

  &::after {
    content: '';
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background-color: white;
    transform: ${({ active }) => active ? 'scale(1)' : 'scale(0)'};
    transition: transform 0.2s;
  }
`;

const StickyFooter = styled.div`
  position: sticky;
  bottom: 0;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(16px);
  padding: 1rem;
  border-top: 1px solid ${BORDER_GREY};
  margin-top: 2rem;
  z-index: 10;

  @media (max-width: 768px) {
    padding: 0.75rem;
  }
`;

const PrimaryButton = styled.button`
  width: 100%;
  background: ${PHARMACY_GREEN};
  border: none;
  border-radius: 40px;
  padding: 14px;
  color: white;
  font-weight: 700;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 12px rgba(13,124,61,0.25);

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(13,124,61,0.35);
  }

  @media (max-width: 480px) {
    padding: 12px;
    font-size: 0.9rem;
  }
`;

const PlanCard = styled(GlassmorphismContainer)`
  background: white;
  border-left: 4px solid ${PHARMACY_GREEN};
`;

const Badge = styled.span`
  background: ${PHARMACY_GREEN};
  color: white;
  font-size: 0.7rem;
  font-weight: 600;
  padding: 4px 10px;
  border-radius: 30px;
  margin-left: 8px;
  display: inline-block;
`;

// --- Main Buy Invoice Plan Component (logic untouched) ---
const BuyInvoicePlan = ({ onBack, navigateTo }) => {
  const [selectedPayment, setSelectedPayment] = useState('upi');
  const planPrice = 900;
  const gst = planPrice * 0.18;
  const totalPayable = planPrice + gst;

  const paymentMethods = [
    { id: 'upi', icon: '💳', title: 'UPI Payment', description: 'GooglePay, PhonePe, Paytm', recommended: true },
    { id: 'card', icon: '📄', title: 'Debit/Credit Card', description: 'Visa, Mastercard, RuPay' },
    { id: 'netbanking', icon: '🏦', title: 'Net Banking', description: 'All major banks supported' },
  ];

  return (
    <div style={{ 
      maxWidth: '800px', 
      margin: '0 auto', 
      padding: '0 1rem 1rem',
      background: LIGHT_GREEN,
      minHeight: '100vh'
    }}>
      {/* Header Section */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        padding: '1rem 0 1.5rem',
        flexWrap: 'wrap',
        gap: '1rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button 
            onClick={onBack} 
            style={{ 
              background: 'none', 
              border: 'none', 
              fontSize: '1.5rem', 
              cursor: 'pointer',
              color: DARK_NAVY,
              padding: '4px 8px',
              borderRadius: '40px',
              transition: '0.2s'
            }}
          >
            ←
          </button>
          <div>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 700, margin: 0, color: DARK_NAVY }}>
              Confirm Your Invoice Plan
            </h2>
            <p style={{ fontSize: '0.85rem', color: '#6c757d', margin: '4px 0 0' }}>
              Review and complete payment
            </p>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button style={{ background: 'none', border: 'none', fontSize: '1.2rem', cursor: 'pointer' }}>🔔</button>
          <img 
            src="https://placehold.co/40x40/0d7c3d/white?text=D" 
            alt="User" 
            style={{ width: '40px', height: '40px', borderRadius: '50%', objectFit: 'cover' }}
          />
        </div>
      </div>

      {/* Plan Summary */}
      <PlanCard style={{ marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ 
            background: PHARMACY_GREEN, 
            padding: '12px', 
            borderRadius: '16px', 
            fontSize: '1.5rem',
            display: 'inline-flex'
          }}>💰</div>
          <div>
            <h5 style={{ fontSize: '1.1rem', fontWeight: 700, margin: 0, color: DARK_NAVY }}>
              Saver Pack 
              <Badge>Save ₹100</Badge>
            </h5>
            <button 
              style={{ background: 'none', border: 'none', color: PHARMACY_GREEN, fontSize: '0.8rem', cursor: 'pointer', padding: 0, marginTop: '4px' }}
            >
              Change Plan
            </button>
          </div>
        </div>
        <hr style={{ margin: '1rem 0', borderColor: BORDER_GREY }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '8px' }}>
          <span style={{ color: '#6c757d' }}>Invoices Included</span>
          <span style={{ fontWeight: 600, color: DARK_NAVY }}>10 Invoices</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '8px' }}>
          <span style={{ color: '#6c757d' }}>Validity</span>
          <span style={{ fontWeight: 600, color: DARK_NAVY }}>90 Days</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
          <span style={{ color: '#6c757d' }}>Price</span>
          <span style={{ fontWeight: 700, color: PHARMACY_GREEN }}>
            ₹{planPrice} <span style={{ textDecoration: 'line-through', color: '#adb5bd', fontSize: '0.75rem' }}>₹1000</span>
          </span>
        </div>
      </PlanCard>

      {/* Payment Method */}
      <h4 style={{ fontSize: '1.1rem', fontWeight: 700, margin: '1.5rem 0 1rem', color: DARK_NAVY }}>
        Choose Payment Method
      </h4>
      {paymentMethods.map(method => (
        <PaymentMethodCard 
          key={method.id} 
          active={selectedPayment === method.id} 
          onClick={() => setSelectedPayment(method.id)}
        >
          <RadioButton active={selectedPayment === method.id} />
          <div style={{ flex: 1 }}>
            <h6 style={{ fontWeight: 600, margin: 0, color: DARK_NAVY }}>{method.title}</h6>
            <p style={{ fontSize: '0.75rem', margin: '2px 0 0', color: '#6c757d' }}>{method.description}</p>
          </div>
          {method.recommended && (
            <span style={{ 
              background: PHARMACY_GREEN, 
              color: 'white', 
              fontSize: '0.65rem', 
              fontWeight: 600, 
              padding: '3px 10px', 
              borderRadius: '30px' 
            }}>
              Recommended
            </span>
          )}
        </PaymentMethodCard>
      ))}

      {/* Payment Summary */}
      <GlassmorphismContainer style={{ margin: '1.5rem 0' }}>
        <h4 style={{ fontSize: '1rem', fontWeight: 700, margin: '0 0 1rem', color: DARK_NAVY }}>Payment Summary</h4>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: `1px solid ${BORDER_GREY}` }}>
          <span style={{ color: '#6c757d' }}>Plan Price</span>
          <span style={{ color: DARK_NAVY }}>₹{planPrice.toFixed(2)}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: `1px solid ${BORDER_GREY}` }}>
          <span style={{ color: '#6c757d' }}>GST (18%)</span>
          <span style={{ color: DARK_NAVY }}>₹{gst.toFixed(2)}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0 0', fontWeight: 700, fontSize: '1.1rem' }}>
          <span style={{ color: DARK_NAVY }}>Total Payable</span>
          <span style={{ color: PHARMACY_GREEN }}>₹{totalPayable.toFixed(2)}</span>
        </div>
      </GlassmorphismContainer>

      <p style={{ fontSize: '0.7rem', textAlign: 'center', color: '#6c757d', margin: '1rem 0 2rem' }}>
        🔒 Payments are securely processed. All prices are inclusive of taxes.
      </p>

      <StickyFooter>
        <PrimaryButton onClick={() => navigateTo('Generate Invoice')}>
          Proceed to Pay ₹{totalPayable.toFixed(2)}
        </PrimaryButton>
      </StickyFooter>
    </div>
  );
};

export default BuyInvoicePlan;