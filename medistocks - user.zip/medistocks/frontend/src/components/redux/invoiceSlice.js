import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  generateInvoiceState: null,
};

const invoiceSlice = createSlice({
  name: 'invoice',
  initialState,
  reducers: {
    setInvoiceState: (state, action) => {
      state.generateInvoiceState = action.payload;
    },
    clearInvoiceState: (state) => {
      state.generateInvoiceState = null;
    },
  },
});

export const { setInvoiceState, clearInvoiceState } = invoiceSlice.actions;
export default invoiceSlice.reducer;
