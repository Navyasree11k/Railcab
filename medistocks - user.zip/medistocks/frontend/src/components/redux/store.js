import { configureStore } from '@reduxjs/toolkit';
import { combineReducers } from 'redux';
import storage from 'redux-persist/lib/storage';
import { persistReducer, persistStore } from 'redux-persist';
import invoiceReducer from './invoiceSlice';
import chatReducer from './chatSlice'; // <-- Make sure this import path is correct
import authReducer from './authSlice';
// Persist config
const persistConfig = {
  key: 'root',
  storage,
};

// Combine all slices
const rootReducer = combineReducers({
  invoice: invoiceReducer,
  chat: chatReducer, // 👈 include chat slice
  auth: authReducer,
});

// Persisted reducer
const persistedReducer = persistReducer(persistConfig, rootReducer);

// Configure store
export const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false, // required for redux-persist
    }),
});

// Persistor
export const persistor = persistStore(store);
