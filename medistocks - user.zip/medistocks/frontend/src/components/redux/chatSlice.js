// chatSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  conversations: [],     // This will be created on the frontend
  allMessages: [],       // We will store ALL messages for the user here
  activeChatUserId: null,
  selectedProduct: null,
  isLoading: false,
  error: null,
};

const chatSlice = createSlice({
  name: 'chat',
  initialState,
  reducers: {
    setConversations: (state, action) => {
      state.conversations = action.payload;
    },
    // NEW: Reducer to store all messages from the API
    setAllMessages: (state, action) => {
        state.allMessages = action.payload;
    },
    // MODIFIED: addMessage now adds to the main 'allMessages' list
    addMessage: (state, action) => {
      const newMessage = action.payload;
      if (!state.allMessages) state.allMessages = [];
      state.allMessages.push(newMessage);

      // This logic to update the conversation sidebar in real-time is still good
      if (!state.conversations) state.conversations = [];
      const conversationIndex = state.conversations.findIndex(
        (convo) => convo.id === newMessage.sender_id || convo.id === newMessage.receiver_id
      );

      if (conversationIndex > -1) {
        const updatedConversation = {
          ...state.conversations[conversationIndex],
          lastMessage: newMessage.message_text,
          timestamp: newMessage.timestamp,
        };
        state.conversations.splice(conversationIndex, 1);
        state.conversations.unshift(updatedConversation);
      } else {
        // If it's a new conversation, add it to the list
         const myUserId = parseInt(localStorage.getItem('user_id'), 10);
         const otherUserId = newMessage.sender_id === myUserId ? newMessage.receiver_id : newMessage.sender_id;
         state.conversations.unshift({
            id: otherUserId,
            name: `User ${otherUserId}`, // You might need a way to get the real name
            lastMessage: newMessage.message_text,
            timestamp: newMessage.timestamp,
         });
      }
    },
    startNewChat: (state, action) => {
      const { receiverId, product } = action.payload;
      state.activeChatUserId = receiverId;
      state.selectedProduct = product;

      if (!state.conversations) state.conversations = [];
      const conversationExists = state.conversations.some(convo => convo.id === receiverId);

      if (!conversationExists) {
          const newConversation = {
              id: receiverId,
              name: product.brand || `Distributor ${receiverId}`, 
              lastMessage: `Regarding: ${product.tablet_name}`,
              timestamp: new Date().toISOString(),
          };
          state.conversations.unshift(newConversation);
      }
    },
    setActiveChat: (state, action) => {
      state.activeChatUserId = action.payload;
      state.selectedProduct = null;
    },
    setLoading: (state, action) => {
      state.isLoading = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
  },
});

export const {
  setConversations,
  setAllMessages, // Export the new action
  addMessage,
  startNewChat,
  setActiveChat,
  setLoading,
  setError,
} = chatSlice.actions;

export default chatSlice.reducer;