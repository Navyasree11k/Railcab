import React, { useRef, useMemo, useEffect, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as random from 'maath/random/dist/maath-random.esm';

/* --------------------------------------------------------------------------
   Responsive particle count: fewer on mobile for better performance
-------------------------------------------------------------------------- */
const getParticleCount = () => {
  if (typeof window === 'undefined') return 3000;
  const width = window.innerWidth;
  if (width < 640) return 1200;      // mobile
  if (width < 1024) return 2500;     // tablet
  return 4000;                       // desktop
};

/* --------------------------------------------------------------------------
   Stars component with improved visuals and responsive rotation speed
-------------------------------------------------------------------------- */
function Stars(props) {
  const ref = useRef();
  const [particleCount, setParticleCount] = useState(getParticleCount());

  // Regenerate particles on window resize
  useEffect(() => {
    const handleResize = () => setParticleCount(getParticleCount());
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Generate random positions within a sphere (radius based on screen size)
  const sphere = useMemo(() => {
    const radius = window.innerWidth < 768 ? 1.2 : 1.5;
    return random.inSphere(new Float32Array(particleCount), { radius });
  }, [particleCount]);

  useFrame((state, delta) => {
    if (!ref.current) return;
    // Slower rotation on mobile for better performance
    const speedFactor = window.innerWidth < 768 ? 0.6 : 1;
    ref.current.rotation.x -= delta / 12 * speedFactor;
    ref.current.rotation.y -= delta / 18 * speedFactor;
    
    // Subtle mouse interaction (less sensitive on mobile)
    const mouseSensitivity = window.innerWidth < 768 ? 0.003 : 0.01;
    ref.current.rotation.y += state.mouse.x * mouseSensitivity;
    ref.current.rotation.x += state.mouse.y * mouseSensitivity;
  });

  // Color scheme: pharmacy green + soft purple gradient (can be customized)
  const particleColor = '#4ade80'; // vibrant green to match Medistocks
  // Alternative: use a dynamic color based on time or props

  return (
    <group rotation={[0, 0, Math.PI / 4]}>
      <Points ref={ref} positions={sphere} stride={3} frustumCulled={false} {...props}>
        <PointMaterial
          transparent
          color={particleColor}
          size={window.innerWidth < 640 ? 0.003 : 0.005}
          sizeAttenuation={true}
          depthWrite={false}
          blending={2} // Additive blending for glow effect
          opacity={0.8}
        />
      </Points>
    </group>
  );
}

/* --------------------------------------------------------------------------
   Main Canvas with responsive background and performance tuning
-------------------------------------------------------------------------- */
export default function AnimationCanvas() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: -1,
        background: 'linear-gradient(135deg, #0a0f1a 0%, #0c1a1a 100%)',
        // fallback for older browsers
        backgroundColor: '#0c0c14',
      }}
    >
      <Canvas
        camera={{ position: [0, 0, 1], fov: 75 }}
        dpr={isMobile ? [1, 1.5] : [1, 2]} // limit pixel ratio on mobile
        performance={{ min: 0.5 }} // allow lower framerate on slow devices
        gl={{ powerPreference: 'low-power' }}
      >
        <Stars />
      </Canvas>
    </div>
  );
}