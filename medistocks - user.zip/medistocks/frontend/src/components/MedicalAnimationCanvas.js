import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { PointMaterial, Float } from '@react-three/drei';
import * as THREE from 'three'; // Import THREE to create custom shapes

// Extend THREE to include custom geometries if needed, or use default ones
// Here we'll use a simple sphere for particles and might hint at medical shapes

function MedicalParticles({ count, medicalIcons }) {
  const meshRef = useRef();
  
  // Generate random positions for the particles
  const positions = useMemo(() => {
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      // Random positions within a sphere
      positions[i3] = (Math.random() - 0.5) * 10;
      positions[i3 + 1] = (Math.random() - 0.5) * 10;
      positions[i3 + 2] = (Math.random() - 0.5) * 10;
    }
    return positions;
  }, [count]);

  // Animate the particles
  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += delta * 0.05;
      meshRef.current.rotation.y += delta * 0.03;
      
      // Subtle reaction to mouse movement
      meshRef.current.rotation.y += state.mouse.x * 0.005;
      meshRef.current.rotation.x += state.mouse.y * 0.005;
    }
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          array={positions}
          count={positions.length / 3}
          itemSize={3}
        />
      </bufferGeometry>
      <PointMaterial
        transparent
        color="#c4b5fd" // A lighter purple for the main particles
        size={0.08} // Larger size for better visibility
        sizeAttenuation={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

// Medical Icon Meshes - these will be abstract representations
function MedicalIcon({ position, iconType }) {
  // We can choose different geometries based on iconType, or just randomize
  const geometry = useMemo(() => {
    if (iconType === 'pill') {
      return new THREE.CylinderGeometry(0.1, 0.1, 0.4, 8); // Simple capsule shape
    } else if (iconType === 'cross') {
      // A simple '+' shape from two boxes
      const group = new THREE.Group();
      const box1 = new THREE.BoxGeometry(0.3, 0.1, 0.1);
      const box2 = new THREE.BoxGeometry(0.1, 0.3, 0.1);
      group.add(new THREE.Mesh(box1));
      group.add(new THREE.Mesh(box2));
      return group; // Return the group directly as geometry is not an array
    }
    return new THREE.SphereGeometry(0.15, 16, 16); // Default to sphere
  }, [iconType]);

  const material = useMemo(() => new THREE.MeshStandardMaterial({
    color: iconType === 'pill' ? '#a78bfa' : '#8b5cf6', // Different colors
    emissive: iconType === 'pill' ? '#a78bfa' : '#8b5cf6', // Glowing effect
    emissiveIntensity: 0.8,
    metalness: 0.1,
    roughness: 0.3,
  }), [iconType]);

  const ref = useRef();
  useFrame((state, delta) => {
    if (ref.current) {
      ref.current.rotation.y += delta * 0.5;
      ref.current.rotation.x += delta * 0.2;
    }
  });

  return (
    <Float floatIntensity={0.5} speed={1.5} rotationIntensity={0.5}>
      {/* If geometry is a Group, we need to iterate over its children */}
      {geometry instanceof THREE.Group ? (
        <group position={position} ref={ref}>
          {geometry.children.map((child, index) => (
            <mesh key={index} geometry={child.geometry} material={material} />
          ))}
        </group>
      ) : (
        <mesh position={position} ref={ref} geometry={geometry} material={material} />
      )}
    </Float>
  );
}

export default function MedicalAnimationCanvas() {
  const iconPositions = useMemo(() => {
    const positions = [];
    const iconTypes = ['pill', 'cross', 'sphere'];
    for (let i = 0; i < 20; i++) { // Generate 20 medical icons
      positions.push({
        position: [(Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8],
        iconType: iconTypes[Math.floor(Math.random() * iconTypes.length)],
      });
    }
    return positions;
  }, []);

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: -1, background: '#0a0a1a' }}>
      <Canvas camera={{ position: [0, 0, 8], fov: 75 }}>
        <color attach="background" args={['#0a0a1a']} /> {/* Dark background for space effect */}
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} color="#a78bfa" />
        <pointLight position={[-10, -10, -10]} intensity={0.8} color="#8b5cf6" />

        <MedicalParticles count={1000} /> {/* Many small particles */}
        {iconPositions.map((icon, index) => (
          <MedicalIcon key={index} position={icon.position} iconType={icon.iconType} />
        ))}
      </Canvas>
    </div>
  );
}
