import React from 'react';
import styled from 'styled-components';

// --- Mock Data based on the image ---
const mockPredictions = [
  {
    id: 1,
    name: 'Paracetamol 500mg',
    category: 'Pain Relief',
    image: 'https://placehold.co/100x100/d62828/ffffff?text=P-500',
    demandLevel: 85,
    demandTag: 'High',
    suggestedStock: 500,
  },
  {
    id: 2,
    name: 'Cough Syrup',
    category: 'Respiratory',
    image: 'https://placehold.co/100x100/f77f00/ffffff?text=Syrup',
    demandLevel: 65,
    demandTag: 'Moderate',
    suggestedStock: 200,
  },
  {
    id: 3,
    name: 'Vitamin C Tablets',
    category: 'Immunity',
    image: 'https://placehold.co/100x100/00a896/ffffff?text=Vit-C',
    demandLevel: 78,
    demandTag: 'High',
    suggestedStock: 350,
  },
  {
    id: 4,
    name: 'Antiseptic Solution',
    category: 'Wound Care',
    image: 'https://placehold.co/100x100/0077b6/ffffff?text=Solution',
    demandLevel: 45,
    demandTag: 'Low',
    suggestedStock: 80,
  },
];

// --- Styled Components ---
const GlassmorphismContainer = styled.div`
  background-color: #fff;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(55, 65, 81, 0.8);
  border-radius: 1rem;
  padding: 1.5rem;
`;

const DemandProgressBar = styled.div`
  width: 100%;
  background-color: #374151;
  border-radius: 9999px;
  height: 0.5rem;
  overflow: hidden;
`;

const DemandProgressBarFill = styled.div`
  height: 100%;
  border-radius: 9999px;
  transition: width 0.5s ease-out;
  background-color: ${({ level }) => {
    if (level > 75) return '#ef4444'; // High
    if (level > 50) return '#f59e0b'; // Moderate
    return '#22c55e'; // Low
  }};
`;

const DemandTag = styled.span`
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-weight: 600;
  font-size: 0.75rem;
  color: #fff;
  background-color: ${({ tag }) => {
    if (tag === 'High') return '#ef4444';
    if (tag === 'Moderate') return '#f59e0b';
    return '#22c55e';
  }};
`;

// --- Sub-Components ---
const PredictionCard = ({ item }) => (
  <GlassmorphismContainer className="h-100 d-flex flex-column">
    <div className="d-flex align-items-center mb-3">
      <img src={item.image} alt={item.name} className="rounded me-3" style={{ width: '60px', height: '60px' }}/>
      <div>
        <h5 className="mb-0 text-dark">{item.name}</h5>
        <small className="text-secondary">{item.category}</small>
      </div>
      <DemandTag className="ms-auto">{item.demandTag}</DemandTag>
    </div>
    <div>
      <div className="d-flex justify-content-between small text-secondary mb-1">
        <span>Demand Level</span>
        <span>+{item.demandLevel}% Increase</span>
      </div>
      <DemandProgressBar>
        <DemandProgressBarFill level={item.demandLevel} style={{ width: `${item.demandLevel}%` }} />
      </DemandProgressBar>
    </div>
    <div className="mt-auto pt-3">
        <div className="d-flex justify-content-between align-items-center">
            <div>
                <small className="text-secondary">Suggested Stock</small>
                <p className="fw-bold text-dark fs-5 mb-0">{item.suggestedStock} units</p>
            </div>
            <button className="btn btn-outline-info">Add to List</button>
        </div>
    </div>
  </GlassmorphismContainer>
);

const AiInsights = () => (
    <GlassmorphismContainer className="h-100">
        <h5 className="text-dark mb-3">💡 AI Insights</h5>
        
        <div className="mb-4">
            <h6 className="text-secondary small">Top Categories in Your Area</h6>
            <div className="d-flex justify-content-between text-dark"><span>Pain Relief</span> <span className="text-success">+65%</span></div>
            <div className="d-flex justify-content-between text-dark"><span>Immunity</span> <span className="text-success">+65%</span></div>
            <div className="d-flex justify-content-between text-dark"><span>Respiratory</span> <span className="text-warning">+45%</span></div>
        </div>

        <div className="p-3 rounded-3 mb-4" style={{backgroundColor: 'rgba(56, 189, 248, 0.1)'}}>
            <h6 className="text-info small">🌦 Weather Alert</h6>
            <p className="small text-dark mb-0">Monsoon season approaching. Expect 40% increase in cold & flu medicines.</p>
        </div>

        <div className="mb-4">
            <h6 className="text-secondary small">Last Year's Top Sellers</h6>
            <ol className="text-dark ps-3 mb-0">
                <li>Paracetamol 500mg</li>
                <li>Vitamin C Tablets</li>
                <li>Cough Syrup</li>
            </ol>
        </div>
        
        <div className="d-grid gap-2">
            <button className="btn btn-success">Export as PDF</button>
            <button className="btn btn-outline-secondary">Notify Next Month</button>
        </div>
    </GlassmorphismContainer>
);


// --- Main AI Demand Forecast Component ---
const AiDemandForecast = () => {
  return (
    <div className="container-fluid">
      {/* --- Filters Section --- */}
      <GlassmorphismContainer className="mb-4">
        <div className="row g-3 align-items-center">
          <div className="col-md-3">
            <label className="form-label text-secondary small">Location</label>
            <input type="text" className="form-control bg-light text-black border-secondary" defaultValue="Auto-detected: Mumbai, MH" />
          </div>
          <div className="col-md-3">
            <label className="form-label text-secondary small">Date Range</label>
            <select className="form-select bg-dark text-white border-secondary">
              <option>Next Month (Feb 2025)</option>
              <option>Next 3 Months</option>
              <option>Next 6 Months</option>
            </select>
          </div>
          <div className="col-md-3 d-flex align-items-end">
            <div className="form-check">
              <input className="form-check-input" type="checkbox" id="includeFestivals" defaultChecked />
              <label className="form-check-label text-dark" htmlFor="includeFestivals">
                Include Festivals
              </label>
            </div>
          </div>
          <div className="col-md-3 d-grid">
            <button className="btn btn-primary fw-bold" style={{ backgroundColor: '#0ea5e9', borderColor: '#0ea5e9' }}>Generate Demand Forecast</button>
          </div>
        </div>
      </GlassmorphismContainer>

      <div className="row g-4">
        {/* --- Main Content: Predictions & Chart --- */}
        <div className="col-lg-8">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h4 className="text-dark mb-0">High-Demand Predictions</h4>
            <div>
                {/* View toggle can be implemented here */}
            </div>
          </div>
          <div className="row g-4">
            {mockPredictions.map(item => (
              <div className="col-md-6" key={item.id}>
                <PredictionCard item={item} />
              </div>
            ))}
          </div>

          <GlassmorphismContainer className="mt-4">
             <h4 className="text-dark mb-3">Historical vs Predicted Demand</h4>
             <div className="d-flex justify-content-center align-items-center bg-dark rounded p-5">
                <p className="text-secondary">Chart placeholder - a library like Recharts or Chart.js would be integrated here.</p>
             </div>
          </GlassmorphismContainer>
        </div>

        {/* --- Sidebar: AI Insights --- */}
        <div className="col-lg-4">
          <AiInsights />
        </div>
      </div>
    </div>
  );
};

export default AiDemandForecast;