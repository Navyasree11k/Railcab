from flask_cors import CORS
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import inspect

from app import create_app, db, socketio
from app.schema_sync import sync_legacy_schema


app = create_app()

CORS(
    app,
    resources={r"/*": {"origins": [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
        "https://novelskidev.online",
        "https://www.novelskidev.online"
    ]}},
    supports_credentials=True
)


if __name__ == "__main__":
    with app.app_context():
        try:
            # Create tables
            db.create_all()

            # Sync legacy schema
            sync_legacy_schema()

            # Show all tables in DB
            inspector = inspect(db.engine)
            tables = inspector.get_table_names()

            print("\n[SUCCESS] Tables created in database:")
            for table in tables:
                print(f" - {table}")

        except SQLAlchemyError as exc:
            raise SystemExit(
                "Database initialization failed. Update DATABASE_URL or enable "
                "DATABASE_ALLOW_SQLITE_FALLBACK=true in .env.\n"
                f"Original error: {exc}"
            ) from exc

    socketio.run(app, host='0.0.0.0', port=5006, debug=False)