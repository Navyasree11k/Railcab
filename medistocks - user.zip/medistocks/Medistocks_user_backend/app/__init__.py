import os
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask
from sqlalchemy import create_engine, text
from app.config import Config
from app.extension import db, jwt,mail  # ✅ import from extensions
from app.routes.register import auth_bp
from app.routes.BillingRoute import  billing_bp  # ✅ import billing blueprint
from app.routes.InvoiceRoute import invoice_bp 
from app.routes.InvoiceGenerationRoute import invoicegeneration_bp
from app.routes.PaymentRoute import payment_bp
from app.routes.PurchaseRoute import purchase_bp
from app.routes.AdminRoute import admin_bp
from app.routes.RetailerRouteChat import retailer_chat_bp
from app.routes.DistributorChatRoute import distributor_chat_bp
from app.routes.VideoRoute import videos_bp
from app.routes.MyProductsRoute import products_bp
from app.routes.GuidelineRoute import guidelines_bp
from app.routes.NotificationRoute import notifications_bp
from app.routes.TermsRoute import terms_bp
from app.routes.socket_routes import socketio  # Import socketio instance
from app.routes.chat import chat_bp  # Import chat blueprint
from app.routes.ad_requests import ads_bp  # Import ad requests blueprint
from app.routes.dashboard import dashboard_bp
from app.routes.cart_routes import cart_bp
import redis


load_dotenv()
# redis_client = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)


def _env_flag(name, default=False):
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _default_sqlite_uri():
    sqlite_path = Path(__file__).resolve().parent.parent / "medistocks_local.db"
    return f"sqlite:///{sqlite_path.as_posix()}"


def _engine_options_for(database_url):
    engine_options = {"pool_pre_ping": True}

    if database_url.startswith("postgresql"):
        connect_timeout = int(os.getenv("DATABASE_CONNECT_TIMEOUT", "5"))
        engine_options["connect_args"] = {"connect_timeout": connect_timeout}

    return engine_options


def _is_database_reachable(database_url, engine_options):
    if database_url.startswith("sqlite:"):
        return True, None

    probe_engine = None
    try:
        probe_engine = create_engine(database_url, **engine_options)
        with probe_engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return True, None
    except Exception as exc:
        return False, exc
    finally:
        if probe_engine is not None:
            probe_engine.dispose()

def create_app():
    app = Flask(__name__)

    configured_database_url = os.getenv("DATABASE_URL", _default_sqlite_uri())
    fallback_database_url = os.getenv("DATABASE_FALLBACK_URL", _default_sqlite_uri())
    selected_database_url = configured_database_url
    engine_options = _engine_options_for(configured_database_url)

    is_reachable, database_error = _is_database_reachable(
        configured_database_url,
        engine_options,
    )
    if not is_reachable and _env_flag("DATABASE_ALLOW_SQLITE_FALLBACK", default=True):
        selected_database_url = fallback_database_url
        engine_options = _engine_options_for(selected_database_url)
        app.config["DATABASE_FALLBACK_ACTIVE"] = True
        app.config["DATABASE_FALLBACK_SOURCE"] = configured_database_url
        app.config["DATABASE_FALLBACK_REASON"] = str(database_error)

    # Load .env variables first
    app.config["SQLALCHEMY_DATABASE_URI"] = selected_database_url
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = engine_options
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "super-secret-key")
    app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "jwt-super-secret")

    # Load your Config class **before initializing extensions**
    app.config.from_object(Config)

    # Initialize extensions **after config is loaded**
    db.init_app(app)
    jwt.init_app(app)
    mail.init_app(app)
    socketio.init_app(app)

    # Redis
    # redis_client = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

    # Register Blueprints
    app.register_blueprint(auth_bp, url_prefix="/medistocks_user/auth")
    app.register_blueprint(billing_bp, url_prefix="/medistocks_user/billing")
    app.register_blueprint(invoice_bp, url_prefix="/medistocks_user/invoice")
    app.register_blueprint(invoicegeneration_bp, url_prefix="/medistocks_user/invoicegeneration")
    app.register_blueprint(payment_bp, url_prefix="/medistocks_user/payment")
    app.register_blueprint(purchase_bp, url_prefix="/medistocks_user/purchase-requests")
    app.register_blueprint(admin_bp, url_prefix="/medistocks_user/admin")
    app.register_blueprint(retailer_chat_bp, url_prefix="/medistocks_user/retailer")
    app.register_blueprint(distributor_chat_bp, url_prefix="/medistocks_user/distributor")
    app.register_blueprint(videos_bp, url_prefix="/medistocks_user/api/videos")
    app.register_blueprint(products_bp, url_prefix="/medistocks_user/products")
    app.register_blueprint(guidelines_bp, url_prefix="/medistocks_user/guideline")
    app.register_blueprint(notifications_bp, url_prefix="/medistocks_user/notifications")
    app.register_blueprint(terms_bp, url_prefix="/medistocks_user/terms")
    app.register_blueprint(chat_bp, url_prefix="/medistocks_user/chat")
    app.register_blueprint(ads_bp, url_prefix="/medistocks_user/ads")
    app.register_blueprint(dashboard_bp, url_prefix="/medistocks_user/dashboard")
    app.register_blueprint(cart_bp, url_prefix="/medistocks_user/cart")

    if app.config.get("DATABASE_FALLBACK_ACTIVE"):
        app.logger.warning(
            "Primary database is unreachable. Falling back to local SQLite database at %s. "
            "Original error: %s",
            app.config["SQLALCHEMY_DATABASE_URI"],
            app.config.get("DATABASE_FALLBACK_REASON", "unknown error"),
        )

    return app
