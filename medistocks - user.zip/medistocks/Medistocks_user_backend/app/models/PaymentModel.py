from app.extension import db

class InvoicePayment(db.Model):
    __tablename__ = 'payment'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # points to product_invoices table
    invoice_id = db.Column(db.Integer, db.ForeignKey("product_invoices.id"), nullable=False)
    user_id = db.Column(db.Integer, nullable=False)
    payment_type = db.Column(db.String(50), nullable=True)
    payment_mode = db.Column(db.String(50), nullable=True)
    payment_status = db.Column(db.String(50), nullable=True)
    total_amount = db.Column(db.Float, nullable=True)
    discount_amount = db.Column(db.Float, nullable=True)
    gst = db.Column(db.Float, nullable=True)

    # relationship back to ProductInvoice
    invoice = db.relationship("ProductInvoice", back_populates="payments", foreign_keys=[invoice_id])

    def to_dict(self):
        return {
            'id': self.id,
            'invoice_id': self.invoice_id,
            'user_id': self.user_id,
            'payment_type': self.payment_type,
            'payment_mode': self.payment_mode,
            'payment_status': self.payment_status,
            'total_amount': self.total_amount,
            'discount_amount': self.discount_amount,
            'gst': self.gst
        }
