from app.utils.time_utils import get_ist_time
from app import db
from datetime import datetime

class Guideline(db.Model):
    __tablename__ = "guidelines"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    version = db.Column(db.String(50), nullable=False)
    content = db.Column(db.Text, nullable=False)
    updated_at = db.Column(db.DateTime, default=get_ist_time)

    def to_dict(self):
        return {
            "id": self.id,
            "version": self.version,
            "content": self.content,
            "updatedAt": self.updated_at
        }
