from app.utils.time_utils import get_ist_time
from app.extension import db
from datetime import datetime


class DistributorChat(db.Model):
    __tablename__ = "distributor_chat"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sender = db.Column(db.String(100), nullable=False)
    receiver = db.Column(db.String(100), nullable=False)
    message = db.Column(db.Text, nullable=False)
    delivered = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, default=get_ist_time)

    def to_dict(self):
        return {
            "id": self.id,
            "sender": self.sender,
            "receiver": self.receiver,
            "message": self.message,
            "delivered": self.delivered,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        }
