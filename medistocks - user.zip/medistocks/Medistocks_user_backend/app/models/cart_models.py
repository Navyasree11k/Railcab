from app.utils.time_utils import get_ist_time
from datetime import datetime
from app import db

class Cart(db.Model):
    __tablename__ = "cart"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("myproductable.id"), nullable=False)
    tablet_name = db.Column(db.String(100), nullable=False)
    image_url = db.Column(db.String(255))
    amount = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, default=1)
    seller_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=get_ist_time)

    user = db.relationship("User", foreign_keys=[user_id], backref="cart_items")
    seller = db.relationship("User", foreign_keys=[seller_id], backref="sold_cart_items")
    product = db.relationship("MyProducts", backref="cart_entries")

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "seller_id": self.seller_id,
            "product_id": self.product_id,
            "tablet_name": self.tablet_name,
            "image_url": self.image_url,
            "amount": self.amount,
            "quantity": self.quantity,
            "created_at": self.created_at.isoformat(),
        }
