from app.utils.time_utils import get_ist_time
from app.extension import db
from datetime import datetime

class ProductInvoice(db.Model):
    __tablename__ = "product_invoices"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False) 
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("myproductable.id"), nullable=False)

    product_name = db.Column(db.String(255), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Float, nullable=False)
    sub_total = db.Column(db.Float, nullable=False)
    tax_percentage = db.Column(db.Float, default=0.0)
    discount = db.Column(db.Float, default=0.0)
    total_amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(500), nullable=True)
    status = db.Column(db.String(50), default="pending")

    sender_gst = db.Column(db.String(20))
    sender_pan = db.Column(db.String(20))
    sender_shop_name = db.Column(db.String(255))
    sender_address = db.Column(db.String(255))
    receiver_gst = db.Column(db.String(20))
    receiver_pan = db.Column(db.String(20))
    receiver_shop_name = db.Column(db.String(255))
    receiver_address = db.Column(db.String(255))

    created_at = db.Column(db.DateTime, default=get_ist_time)
    updated_at = db.Column(db.DateTime, default=get_ist_time, onupdate=get_ist_time)

    sender = db.relationship(
        "User",
        foreign_keys=[sender_id],
        back_populates="sent_invoices"
    )
    receiver = db.relationship(
        "User",
        foreign_keys=[receiver_id],
        back_populates="received_invoices"
    )
    product = db.relationship("MyProducts", back_populates="invoices")

    # Fixed: must back_populates the attribute name defined on InvoicePayment ('invoice')
    payments = db.relationship(
        "InvoicePayment",
        back_populates="invoice",
        cascade="all, delete-orphan",
        lazy="select"
    )

    def to_dict(self):
        return {
            "id": self.id,
            "sender_id": self.sender_id,
            "receiver_id": self.receiver_id,
            "product_id": self.product_id,
            "product_name": self.product_name,
            "quantity": self.quantity,
            "unit_price": self.unit_price,
            "sub_total": self.sub_total,
            "tax_percentage": self.tax_percentage,
            "discount": self.discount,
            "total_amount": self.total_amount,
            "description": self.description,
            "status": self.status,
            "sender_gst": self.sender_gst,
            "sender_pan": self.sender_pan,
            "sender_shop_name": self.sender_shop_name,
            "sender_address": self.sender_address,
            "receiver_gst": self.receiver_gst,
            "receiver_pan": self.receiver_pan,
            "receiver_shop_name": self.receiver_shop_name,
            "receiver_address": self.receiver_address,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
