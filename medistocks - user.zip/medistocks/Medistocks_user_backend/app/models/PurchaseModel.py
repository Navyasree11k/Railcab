from app.utils.time_utils import get_ist_time
from datetime import datetime
from app.extension import db

class PurchaseRequest(db.Model):
    __tablename__ = "purchase_requests"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)  # Retailer
    receiver_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)  # Distributor
    product_id = db.Column(db.Integer, db.ForeignKey("myproductable.id"), nullable=False) 
    # Product Info
    tablet_name = db.Column(db.String(255), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    unit_price = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(500), nullable=True)

    # Status & verification
    status = db.Column(db.String(20), default="pending")  # pending | accepted | rejected
    created_at = db.Column(db.DateTime, default=get_ist_time)

    product = db.relationship("MyProducts", backref="purchase_requests", lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "sender_id": self.sender_id,
            "receiver_id": self.receiver_id,
            "tablet_name": self.tablet_name,
            "quantity": self.quantity,
            "unit_price": self.unit_price,
            "description": self.description,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class InvoicePlanPurchase(db.Model):
    __tablename__ = "invoice_plan_purchases"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    plan_name = db.Column(db.String(150), nullable=False)
    plan_type = db.Column(db.String(100), nullable=False)  # e.g., Monthly, Yearly, Custom
    amount = db.Column(db.Float, nullable=False)
    payment_mode = db.Column(db.String(50), nullable=False)  # e.g., UPI, Card, Wallet
    transaction_id = db.Column(db.String(100), nullable=True)
    start_date = db.Column(db.DateTime, default=get_ist_time)
    end_date = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(50), default="active")  # active | expired | cancelled

    # Relationship
    user = db.relationship("User", back_populates="plan_purchases")

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "plan_name": self.plan_name,
            "plan_type": self.plan_type,
            "amount": self.amount,
            "payment_mode": self.payment_mode,
            "transaction_id": self.transaction_id,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "status": self.status
        }


