
from datetime import datetime
from app.extension import db
from app.utils.time_utils import get_ist_time


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    mobile_number = db.Column(db.String(20), unique=True, nullable=True)
    email_address = db.Column(db.String(255), unique=True, nullable=True)
    mobile_otp = db.Column(db.String(10), nullable=True)
    email_otp = db.Column(db.String(10), nullable=True)
    role = db.Column(db.String(50), nullable=True)
    image = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime, default=get_ist_time)

    user_name = db.Column(db.String(255), nullable=True)
    shop_name = db.Column(db.String(255), nullable=True)
    shop_address = db.Column(db.String(500), nullable=True)
    gst_in_number = db.Column(db.String(50), nullable=True)
    pan_number = db.Column(db.String(50), nullable=True)
    city_name = db.Column(db.String(255), nullable=True) 
    pin_code = db.Column(db.String(10), nullable=True)

    date_of_birth = db.Column(db.Date, nullable=True)
    address_line1 = db.Column(db.String(255), nullable=True)
    address_line2 = db.Column(db.String(255), nullable=True)
    address_line3 = db.Column(db.String(255), nullable=True)
    shop_location = db.Column(db.String(255), nullable=True)
    gender = db.Column(db.String(20), nullable=True)
    state = db.Column(db.String(100), nullable=True)

    updated_at = db.Column(
        db.DateTime, default=get_ist_time, onupdate=get_ist_time
    )
    is_verified = db.Column(db.String(20), default="pending", nullable=False)

    plans = db.relationship(
        "PlanPurchasing", back_populates="user", cascade="all, delete-orphan"
    )
    documents = db.relationship(
        "UserDocuments",
        back_populates="user",
        uselist=False,
        cascade="all, delete-orphan",
    )
    billing_records = db.relationship(   # ✅ moved here
        "BillingRecord",
        back_populates="user",
        cascade="all, delete-orphan"
    )
    plan_purchases = db.relationship("InvoicePlanPurchase", back_populates="user", cascade="all, delete-orphan")
    sent_invoices = db.relationship(
        "ProductInvoice",
        foreign_keys="ProductInvoice.sender_id",
        back_populates="sender",
        lazy=True
    )

    received_invoices = db.relationship(
        "ProductInvoice",
        foreign_keys="ProductInvoice.receiver_id",
        back_populates="receiver",
        lazy=True
    )


class PlanPurchasing(db.Model):
    __tablename__ = "plan_purchasing"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    selected_role = db.Column(db.String(50), nullable=False)
    selected_plan = db.Column(db.String(100), nullable=False)
    plan_benefits = db.Column(db.Text, nullable=False)
    payment_mode = db.Column(db.String(50), nullable=False)
    payment_type = db.Column(db.String(50), nullable=False)
    payment_status = db.Column(db.String(50), nullable=False)
    payment_id = db.Column(db.String(100), nullable=False, unique=True)
    coupon_code = db.Column(db.String(100), nullable=True)
    payment_summary = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=get_ist_time)

    user = db.relationship("User", back_populates="plans")
    


class UserDocuments(db.Model):
    __tablename__ = "user_documents"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    aadhar_card_front = db.Column(db.String(500), nullable=True)
    aadhar_card_back = db.Column(db.String(500), nullable=True)
    pancard_front = db.Column(db.String(500), nullable=True)
    pancard_back = db.Column(db.String(500), nullable=True)
    pharmacy_license = db.Column(db.String(500), nullable=True)
    live_image_pic_url = db.Column(db.String(800), nullable=True)
    timestamp = db.Column(db.DateTime, nullable=True)
    location = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=get_ist_time)
    updated_at = db.Column(
        db.DateTime, default=get_ist_time, onupdate=get_ist_time
    )

    user = db.relationship("User", back_populates="documents")



class LoginAudits(db.Model):
    __tablename__ = "login_audits"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    mobile_number = db.Column(db.String(20), nullable=True)      # now optional
    email_address = db.Column(db.String(255), nullable=True)     # new column
    otp = db.Column(db.String(10), nullable=False)
    timestamp = db.Column(db.DateTime, default=get_ist_time)
