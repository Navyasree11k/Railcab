from app.utils.time_utils import get_ist_time
from datetime import datetime
from app.extension import db


class AdvertisementRequest(db.Model):
    __tablename__ = "advertisement_requests"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # Automatically linked to user table
    user = db.relationship("User", backref=db.backref("ads", cascade="all, delete-orphan"))

    banner_image_url = db.Column(db.Text, nullable=False)
    ad_title = db.Column(db.String(100), nullable=False)
    distributor_email = db.Column(db.String(100), nullable=False)
    distributor_phone = db.Column(db.String(20))
    duration_days = db.Column(db.Integer, nullable=False)
    location = db.Column(db.String(50), nullable=False)
    payment_id = db.Column(db.String(100))
    payment_amount = db.Column(db.Numeric(10,2), nullable=False)
    payment_status = db.Column(db.String(20), default='pending')
    payment_schedule_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), default="pending")
    created_at = db.Column(db.DateTime, default=get_ist_time)
    updated_at = db.Column(db.DateTime, default=get_ist_time, onupdate=get_ist_time)
