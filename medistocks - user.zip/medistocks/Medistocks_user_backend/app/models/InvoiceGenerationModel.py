from app.extension import db

class Invoice(db.Model):
    __tablename__ = "invoiceGeneration"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)  # ✅ integer ID
    buyer_name = db.Column(db.String(255), nullable=True)
    product_name = db.Column(db.String(255), nullable=True)
    quantity = db.Column(db.Integer, nullable=True)
    total_amount = db.Column(db.Numeric(10, 2), nullable=True)
    product_information = db.Column(db.Text)
    buyer_verification = db.Column(db.Boolean, default=False)
    user_otp = db.Column(db.String(10))

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "buyer_name": self.buyer_name,
            "product_name": self.product_name,
            "quantity": self.quantity,
            "total_amount": str(self.total_amount),
            "product_information": self.product_information,
            "buyer_verification": self.buyer_verification,
            "user_otp": self.user_otp,
            "payments": [payment.to_dict() for payment in self.payments] if hasattr(self, "payments") else []
        }
