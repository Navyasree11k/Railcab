from app.extension import db

class MyProducts(db.Model):
    __tablename__ = "myproductable"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)  # linked to users table
    image_url = db.Column(db.String(255))
    location = db.Column(db.String(150))

    tablet_name = db.Column(db.String(100), nullable=False)
    brand = db.Column(db.String(100))
    quantity = db.Column(db.Integer)
    unit_type = db.Column(db.String(50))

    manufacturing_date = db.Column(db.Date)
    best_before_date = db.Column(db.Date)
    expiry_date = db.Column(db.Date)

    usage_instructions = db.Column(db.Text)
    storage_instructions = db.Column(db.Text)

    original_price = db.Column(db.Float)
    discount = db.Column(db.Float)

    batch_number = db.Column(db.String(100))
    invoices = db.relationship("ProductInvoice", back_populates="product")



    def to_dict(self):
        return {
            "id": self.id,
            "distribution_id": self.user_id,
            "image_url": self.image_url,
            "location": self.location,
            "tablet_name": self.tablet_name,
            "brand": self.brand,
            "quantity": self.quantity,
            "unit_type": self.unit_type,
            "manufacturing_date": self.manufacturing_date,
            "best_before_date": self.best_before_date,
            "expiry_date": self.expiry_date,
            "usage_instructions": self.usage_instructions,
            "storage_instructions": self.storage_instructions,
            "original_price": self.original_price,
            "discount": self.discount,
            "batch_number": self.batch_number,
        }

    def to_dict_basic(self):
        return {
            "id": self.id,
            "tablet_name": self.tablet_name,
            "brand": self.brand,
            "quantity": self.quantity,
            "location": self.location,
        }
