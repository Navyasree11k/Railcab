from app.utils.time_utils import get_ist_time
from datetime import datetime
from app.extension import db

class BillingRecord(db.Model):
    __tablename__ = "billing_records"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    # Product Information
    tablet_name = db.Column(db.String(255), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    unit_cost = db.Column(db.Float, nullable=False)
    brand = db.Column(db.String(255), nullable=True)
    # Pricing
    discount_percentage = db.Column(db.Float, nullable=True, default=0.0)
    subtotal = db.Column(db.Float, nullable=False, default=0.0)
    discount = db.Column(db.Float, nullable=False, default=0.0)
    total_amount = db.Column(db.Float, nullable=False, default=0.0)

    # Inventory Management
    expiry_date = db.Column(db.DateTime, nullable=True)
    image_url = db.Column(db.String(500), nullable=True)
    location = db.Column(db.String(255), nullable=True)
    batch_number = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(50), nullable=False, default="active")  
    # status can be: active | near_expiry | expired | sold

    # Audit Info
    created_at = db.Column(db.DateTime, default=get_ist_time)
    updated_at = db.Column(db.DateTime, default=get_ist_time, onupdate=get_ist_time)

    # Relationship
    user = db.relationship("User", back_populates="billing_records")

    # ---------- Helper Functions ---------- #
    def calculate_totals(self):
        """Recalculate subtotal, discount, and total"""
        self.subtotal = float(self.quantity) * float(self.unit_cost)
        self.discount = (float(self.discount_percentage) / 100.0) * self.subtotal
        self.total_amount = self.subtotal - self.discount

    def update_status(self):
        """Update status based on expiry date"""
        if not self.expiry_date:
            self.status = "active"
            return

        days_left = (self.expiry_date - get_ist_time()).days
        if days_left <= 0:
            self.status = "expired"
        elif days_left <= 30:
            self.status = "near_expiry"
        else:
            self.status = "active"

    def to_dict(self):
        """Convert model to dictionary (for JSON response)"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "tablet_name": self.tablet_name,
            "quantity": self.quantity,
            "unit_cost": self.unit_cost,
            "discount_percentage": self.discount_percentage,
            "subtotal": self.subtotal,
            "discount": self.discount,
            "total_amount": self.total_amount,
            "expiry_date": self.expiry_date.isoformat() if self.expiry_date else None,
            "image_url": self.image_url,
            "location": self.location,
            "batch_number": self.batch_number,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "brand": self.brand,
        }
