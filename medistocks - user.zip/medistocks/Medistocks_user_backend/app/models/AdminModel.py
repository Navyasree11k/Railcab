from app.utils.time_utils import get_ist_time
from app.extension import db
from datetime import datetime


class AdminChat(db.Model):
    __tablename__ = "admin_chat"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sender = db.Column(db.String(100), nullable=False)       # admin, distributor, retailer
    receiver = db.Column(db.String(100), nullable=False)     # admin, distributor, retailer
    message = db.Column(db.Text, nullable=False)
    delivered = db.Column(db.Boolean, default=True)          # ✅ default True
    date = db.Column(db.Date, default=get_ist_time)       # store only date
    time = db.Column(db.Time, default=get_ist_time().time)  # store only time

    def to_dict(self):
        return {
            "id": self.id,
            "sender": self.sender,
            "receiver": self.receiver,
            "message": self.message,
            "delivered": self.delivered,
            "date": self.date.strftime("%Y-%m-%d"),
            "time": self.time.strftime("%H:%M:%S")
        }
