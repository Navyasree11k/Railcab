from app.utils.time_utils import get_ist_time
from app.extension import db
from datetime import datetime


class RetailerChat(db.Model):
    __tablename__ = "retailer_chats"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sender = db.Column(db.String(100), nullable=True)
    receiver = db.Column(db.String(100), nullable=True)
    message = db.Column(db.Text, nullable=True)
    delivered = db.Column(db.Boolean, default=True)
    timestamp = db.Column(db.DateTime, default=get_ist_time)

    # 🔹 Foreign key to User (if exists)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    def to_dict(self):
        return {
            "id": self.id,
            "sender": self.sender,
            "receiver": self.receiver,
            "message": self.message,
            "delivered": self.delivered,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        }
