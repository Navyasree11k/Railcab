
import os
import boto3
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from dotenv import load_dotenv
from flask_mail import Mail
from flask_socketio import SocketIO
# app/extension.py
import redis

# redis_client = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

# Dummy Redis Client to prevent ImportErrors while Redis is disabled for troubleshooting
class DummyRedis:
    def __getattr__(self, name):
        def dummy_func(*args, **kwargs):
            print(f"DEBUG: Redis {name} called with {args} {kwargs} (Redis is disabled)")
            return None
        return dummy_func
    def scan_iter(self, *args, **kwargs):
        return []

redis_client = DummyRedis()

load_dotenv()


db = SQLAlchemy()
jwt = JWTManager()
mail = Mail()
socketio = SocketIO(cors_allowed_origins=["http://localhost:3001","http://localhost:3000","http://localhost:3003", "https://novelskidev.online"], async_mode="eventlet")


AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
BUCKET_NAME = os.getenv("AWS_BUCKET_NAME")

if all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME]):
    s3 = boto3.client(
        "s3",
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        region_name=AWS_REGION,
    )
else:
    s3 = None
