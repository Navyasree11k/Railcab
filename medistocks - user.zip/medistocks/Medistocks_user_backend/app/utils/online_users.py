from app.extension import redis_client

# Track online user SIDs in Redis sets
def set_user_online(user_id, sid):
    redis_client.sadd(f"user_sids:{user_id}", sid)

def set_user_offline(user_id, sid):
    redis_client.srem(f"user_sids:{user_id}", sid)

def get_online_user_sids(user_id):
    """Return list of SIDs for a given user"""
    sids = redis_client.smembers(f"user_sids:{user_id}")
    return [sid.decode("utf-8") for sid in sids] if sids else []

def get_user_id_by_sid(sid):
    """Reverse lookup: find user_id by sid"""
    # Scan all users to find the sid
    for key in redis_client.scan_iter("user_sids:*"):
        sids = redis_client.smembers(key)
        if sid.encode("utf-8") in sids:
            return int(key.decode("utf-8").split(":")[1])
    return None
