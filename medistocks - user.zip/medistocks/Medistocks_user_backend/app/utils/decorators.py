from functools import wraps
from flask import request, jsonify

def is_admin(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        admin_token = request.headers.get("X-Admin-Token")
        if admin_token != "secret123":  # replace with your own logic
            return jsonify({"error": "Admin access required"}), 403
        return f(*args, **kwargs)
    return decorated_function
