from datetime import datetime, timedelta

def get_ist_time():
    """Returns current time in IST (UTC+5:30)"""
    return datetime.utcnow() + timedelta(hours=5, minutes=30)
