# app/utils/email_utils.py
import random
from flask_mail import Message
from app.extension import mail

def generate_otp(length=6):
    """Generate a numeric OTP of given length."""
    return ''.join([str(random.randint(0, 9)) for _ in range(length)])


def send_html_email(subject: str, recipients: list, html_body: str):
    """Send an HTML email using Flask-Mail."""
    try:
        msg = Message(
            subject=subject,
            recipients=recipients
        )
        msg.html = html_body
        mail.send(msg)
        return True
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        return False


def otp_email_template(otp: str, recipient_name="User"):
    """Return a professional HTML template for OTP email."""
    return f"""
    <html>
        <head>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f7;
                    margin: 0;
                    padding: 0;
                }}
                .container {{
                    max-width: 500px;
                    margin: 50px auto;
                    background-color: #ffffff;
                    padding: 30px;
                    border-radius: 12px;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                }}
                h2 {{
                    color: #1d4ed8;
                    text-align: center;
                }}
                .otp {{
                    display: inline-block;
                    padding: 15px 25px;
                    font-size: 28px;
                    letter-spacing: 4px;
                    background-color: #1d4ed8;
                    color: #ffffff;
                    border-radius: 10px;
                    font-weight: bold;
                    margin: 20px 0;
                    text-align: center;
                }}
                p {{
                    color: #374151;
                    font-size: 16px;
                    line-height: 1.5;
                }}
                .footer {{
                    font-size: 12px;
                    color: #9ca3af;
                    text-align: center;
                    margin-top: 20px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Medistocks Email Verification</h2>
                <p>Hello {recipient_name},</p>
                <p>Use the OTP below to verify your email address:</p>
                <div class="otp">{otp}</div>
                <p>This OTP is valid for <b>10 minutes</b>. Please do not share it with anyone.</p>
                <div class="footer">© 2025 Medistocks. All rights reserved.</div>
            </div>
        </body>
    </html>
    """


def send_otp_email(email_address: str, otp: str, recipient_name="User"):
    """Send email with provided OTP (does NOT generate a new one)."""
    print(f"DEBUG: Sending OTP {otp} to {email_address}", flush=True)
    html_body = otp_email_template(otp, recipient_name)
    sent = send_html_email(
        subject="🔐 Medistocks Email Verification OTP",
        recipients=[email_address],
        html_body=html_body
    )
    return sent

