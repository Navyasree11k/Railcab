from sqlalchemy import inspect, text

from app.extension import db


SCHEMA_PATCHES = {
    "users": [
        ("mobile_number", "ALTER TABLE users ADD COLUMN mobile_number VARCHAR(20)"),
        ("email_address", "ALTER TABLE users ADD COLUMN email_address VARCHAR(255)"),
        ("mobile_otp", "ALTER TABLE users ADD COLUMN mobile_otp VARCHAR(10)"),
        ("email_otp", "ALTER TABLE users ADD COLUMN email_otp VARCHAR(10)"),
        ("role", "ALTER TABLE users ADD COLUMN role VARCHAR(50)"),
        ("image", "ALTER TABLE users ADD COLUMN image VARCHAR(500)"),
        ("created_at", "ALTER TABLE users ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
        ("user_name", "ALTER TABLE users ADD COLUMN user_name VARCHAR(255)"),
        ("shop_name", "ALTER TABLE users ADD COLUMN shop_name VARCHAR(255)"),
        ("shop_address", "ALTER TABLE users ADD COLUMN shop_address VARCHAR(500)"),
        ("gst_in_number", "ALTER TABLE users ADD COLUMN gst_in_number VARCHAR(50)"),
        ("pan_number", "ALTER TABLE users ADD COLUMN pan_number VARCHAR(50)"),
        ("city_name", "ALTER TABLE users ADD COLUMN city_name VARCHAR(255)"),
        ("pin_code", "ALTER TABLE users ADD COLUMN pin_code VARCHAR(10)"),
        ("date_of_birth", "ALTER TABLE users ADD COLUMN date_of_birth DATE"),
        ("address_line1", "ALTER TABLE users ADD COLUMN address_line1 VARCHAR(255)"),
        ("address_line2", "ALTER TABLE users ADD COLUMN address_line2 VARCHAR(255)"),
        ("address_line3", "ALTER TABLE users ADD COLUMN address_line3 VARCHAR(255)"),
        ("shop_location", "ALTER TABLE users ADD COLUMN shop_location VARCHAR(255)"),
        ("gender", "ALTER TABLE users ADD COLUMN gender VARCHAR(20)"),
        ("state", "ALTER TABLE users ADD COLUMN state VARCHAR(100)"),
        ("updated_at", "ALTER TABLE users ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
        ("is_verified", "ALTER TABLE users ADD COLUMN is_verified VARCHAR(20) DEFAULT 'pending'"),
    ],
    "login_audits": [
        ("mobile_number", "ALTER TABLE login_audits ADD COLUMN mobile_number VARCHAR(20)"),
        ("email_address", "ALTER TABLE login_audits ADD COLUMN email_address VARCHAR(255)"),
    ],
}


def sync_legacy_schema():
    inspector = inspect(db.engine)
    existing_tables = set(inspector.get_table_names())

    with db.engine.begin() as connection:
        for table_name, patches in SCHEMA_PATCHES.items():
            if table_name not in existing_tables:
                continue

            existing_columns = {
                column_info["name"] for column_info in inspector.get_columns(table_name)
            }

            for column_name, statement in patches:
                if column_name in existing_columns:
                    continue
                connection.execute(text(statement))
