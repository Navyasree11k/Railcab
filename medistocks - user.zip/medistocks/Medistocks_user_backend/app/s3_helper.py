import boto3
from werkzeug.utils import secure_filename
from app.extension import s3,AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME

s3 = boto3.client("s3",
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    region_name=AWS_REGION
)

BUCKET_NAME = "your-bucket-name"
AWS_REGION = "ap-south-1"

def upload_to_s3(file_obj, filename):
    safe_filename = secure_filename(filename)
    s3.upload_fileobj(file_obj, BUCKET_NAME, safe_filename)
    return f"https://{BUCKET_NAME}.s3.{AWS_REGION}.amazonaws.com/{safe_filename}"
