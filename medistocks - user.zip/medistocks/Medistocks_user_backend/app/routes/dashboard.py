from flask import Blueprint, request, jsonify
from datetime import date
from sqlalchemy import func, or_
from app.extension import db
from app.models.registermodel import User
from app.models.MyProductsModel import MyProducts
from app.models.PurchaseModel import PurchaseRequest,InvoicePlanPurchase
from app.models.adrequests_model import AdvertisementRequest
dashboard_bp = Blueprint("dashboard_bp", __name__)

@dashboard_bp.route("/dashboard-summary/<int:user_id>", methods=["GET"])
def get_user_dashboard(user_id):
    try:
        # 🧠 Validate user existence
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404

        today = date.today()

        # 🧾 1️⃣ Total products posted by this user (using their ID)
        total_products = (
            db.session.query(func.count(MyProducts.id))
            .filter(MyProducts.user_id == user_id)
            .scalar()
        )

        # 📦 2️⃣ Purchase requests (sent + received)
        sent_requests = (
            db.session.query(func.count(PurchaseRequest.id))
            .filter(PurchaseRequest.sender_id == user_id)
            .scalar()
        )
        received_requests = (
            db.session.query(func.count(PurchaseRequest.id))
            .filter(PurchaseRequest.receiver_id == user_id)
            .scalar()
        )
        total_purchase_requests = sent_requests + received_requests

        # 📅 3️⃣ Today’s purchase requests (sent or received)
        today_requests = (
            PurchaseRequest.query.filter(
                or_(
                    PurchaseRequest.sender_id == user_id,
                    PurchaseRequest.receiver_id == user_id,
                ),
                func.date(PurchaseRequest.created_at) == today,
            ).all()
        )
        today_requests_data = [req.to_dict() for req in today_requests]

        # 💰 4️⃣ Total revenue (from active or paid invoices by user)
        total_revenue = (
            db.session.query(func.coalesce(func.sum(InvoicePlanPurchase.amount), 0))
            .filter(
                InvoicePlanPurchase.user_id == user_id,
                InvoicePlanPurchase.status.in_(["active", "paid"]),
            )
            .scalar()
        )

        # 📢 5️⃣ Total ads requested by user
        total_ads = (
            db.session.query(func.count(AdvertisementRequest.id))
            .filter(AdvertisementRequest.user_id == user_id)
            .scalar()
        )

        # 🕓 6️⃣ Pending ads (awaiting admin approval)
        pending_ads = (
            db.session.query(func.count(AdvertisementRequest.id))
            .filter(
                AdvertisementRequest.user_id == user_id,
                AdvertisementRequest.status == "pending",
            )
            .scalar()
        )

        # ✅ Combine data
        summary = {
            "user_id": user_id,
            "user_email": user.email_address,
            "total_products": total_products,
            "total_purchase_requests": total_purchase_requests,
            "sent_requests": sent_requests,
            "received_requests": received_requests,
            "total_revenue": float(total_revenue or 0),
            "total_ads": total_ads,
            "pending_ads": pending_ads,
            "today_purchase_requests_count": len(today_requests_data),
            "today_purchase_requests": today_requests_data,
        }

        return jsonify(summary), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
