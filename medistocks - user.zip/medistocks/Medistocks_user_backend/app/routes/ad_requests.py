from flask import Blueprint, request, jsonify
from datetime import datetime
from app.extension import db
from app.models.registermodel import User
from app.models.adrequests_model import  AdvertisementRequest
import boto3, uuid, os
from app.extension import s3,AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME
from app.s3_helper import upload_to_s3
from app.utils.decorators import is_admin

ads_bp = Blueprint("ads_bp", __name__)

S3_CLIENT = boto3.client(
    "s3",
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    region_name=AWS_REGION,
)


def generate_presigned_url(filename):
    # Create a unique key for the S3 object
    key = f"ads/{uuid.uuid4()}_{filename}"
    
    # Generate the temporary URL for PUT request (for uploading)
    presigned_upload_url = S3_CLIENT.generate_presigned_url(
        "put_object",
        Params={"Bucket": BUCKET_NAME, "Key": key}, # ContentType will be set by the browser
        ExpiresIn=3600  # URL is valid for 1 hour
    )
    
    # This is the final, permanent URL of the object after it's uploaded
    final_object_url = f"https://{BUCKET_NAME}.s3.{AWS_REGION}.amazonaws.com/{key}"
    
    return presigned_upload_url, final_object_url


@ads_bp.route("/request-ad", methods=["POST"])
def request_ad():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"message": "Invalid JSON in request"}), 400

        user_id = data.get("user_id")
        user = User.query.get(user_id)
        if not user:
            return jsonify({"message": "User not found"}), 404

        # --- THIS IS THE CORRECTED LOGIC ---
        # 1. Get the original filename from the JSON payload
        original_filename = data.get("banner_filename")
        if not original_filename:
            return jsonify({"message": "banner_filename is required"}), 400

        # 2. Generate both the presigned URL for upload and the final object URL for the database
        presigned_upload_url, final_db_url = generate_presigned_url(original_filename)

        # 3. Create the new ad entry using the final URL
        new_ad = AdvertisementRequest(
            user_id=user.id,
            ad_title=data["ad_title"],
            banner_image_url=final_db_url,  # <-- CHANGED: Use the final URL here
            distributor_email=user.email_address,
            distributor_phone=user.mobile_number,
            duration_days=data["duration_days"],
            location=data["location"],
            payment_id=data.get("payment_id"),
            payment_amount=data["payment_amount"],
            payment_status=data.get("payment_status", "paid"),
            # Use the date from the frontend payload
            payment_schedule_date=datetime.strptime(data["payment_schedule_date"], "%Y-%m-%d").date(),
            status="pending_approval" # A more descriptive initial status
        )
        db.session.add(new_ad)
        db.session.commit()

        # 4. Return the presigned URL for the frontend to use for the PUT request
        return jsonify({
            "message": "Ad request created successfully. Ready for upload.",
            "presigned_upload_url": presigned_upload_url, # <-- CHANGED: Send this to the frontend
            "final_image_url": final_db_url,
            "ad_id": new_ad.id
        }), 201

    except Exception as e:
        db.session.rollback()
        # Log the actual error to your server console for better debugging
        print(f"An error occurred: {e}") 
        return jsonify({"message": "An internal error occurred", "error": str(e)}), 500


@ads_bp.route("/ads/review/<int:ad_id>", methods=["PUT"])
@is_admin
def review_ad(ad_id):
    try:
        data = request.get_json()
        action = data.get("action")  # 'approve' or 'reject'

        ad = AdvertisementRequest.query.get(ad_id)
        if not ad:
            return jsonify({"error": "Ad not found"}), 404

        if action == "approve":
            ad.status = "approved"
            ad.payment_status = "success"
        elif action == "reject":
            ad.status = "rejected"
            ad.payment_status = "failed"
        else:
            return jsonify({"error": "Invalid action"}), 400

        db.session.commit()
        return jsonify({"message": f"Ad {action}d successfully"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400


@ads_bp.route("/user/<int:user_id>", methods=["GET"])
def get_user_ads(user_id):
    ads = AdvertisementRequest.query.filter_by(user_id=user_id).all()
    return jsonify([
        {
            "id": ad.id,
            "ad_title": ad.ad_title,
            "banner_image_url": ad.banner_image_url,
            "duration_days": ad.duration_days,
            "location": ad.location,
            "payment_id": ad.payment_id,
            "payment_amount": float(ad.payment_amount),
            "payment_status": ad.payment_status,
            "status": ad.status,
            "created_at": ad.created_at.strftime("%Y-%m-%d %H:%M")
        }
        for ad in ads
    ])
