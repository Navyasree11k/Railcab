import json

from flask import Blueprint, request, jsonify
from sqlalchemy.exc import SQLAlchemyError
from app.models.MyProductsModel import  MyProducts
from app.models.PurchaseModel import PurchaseRequest
from app.models.registermodel import User,UserDocuments
from app.extension import db, s3, BUCKET_NAME, AWS_REGION,AWS_ACCESS_KEY_ID,AWS_SECRET_ACCESS_KEY  # ✅ FIXED
from datetime import datetime
from werkzeug.utils import secure_filename  
from app.utils.calculate_distance import calculate_distance
products_bp = Blueprint("products", __name__)

# -------------------- PRODUCT ROUTES --------------------
def iso(dt):
    return dt.isoformat() if isinstance(dt, datetime) else dt


def extract_user_identifier(payload):
    if not isinstance(payload, dict):
        return None

    for key in ("user_id", "distribution_id", "email_address", "mobile_number"):
        value = payload.get(key)
        if value not in (None, ""):
            return value

    return None


def resolve_user_id(user_identifier):
    if user_identifier is None:
        return None

    if isinstance(user_identifier, dict):
        nested_identifier = extract_user_identifier(user_identifier)
        if nested_identifier is None:
            return None
        return resolve_user_id(nested_identifier)

    value = str(user_identifier).strip()
    if not value:
        return None

    if value.startswith("{") and value.endswith("}"):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            parsed = None
        if isinstance(parsed, dict):
            return resolve_user_id(parsed)

    numeric_value = None
    if value.isdigit():
        numeric_value = int(value)
    else:
        try:
            float_value = float(value)
        except ValueError:
            float_value = None
        if float_value is not None and float_value.is_integer():
            numeric_value = int(float_value)

    if numeric_value is not None:
        return db.session.get(User, numeric_value)

    if "@" in value:
        return User.query.filter_by(email_address=value).first()

    return User.query.filter_by(mobile_number=value).first()


def get_user_from_identifier(user_identifier):
    user = resolve_user_id(user_identifier)
    if not user:
        print(f"DEBUG: Could not resolve user from identifier: {user_identifier!r}")
        return None

    print(f"DEBUG: Resolved user identifier {user_identifier!r} to user_id={user.id}")
    return user


def upload_to_s3(file_obj, filename):
    print("DEBUG: Starting upload_to_s3 function")
    
    if s3 is None:
        print("ERROR: S3 client is not configured!")
        print(f"DEBUG: AWS_ACCESS_KEY_ID={AWS_ACCESS_KEY_ID}")
        print(f"DEBUG: AWS_SECRET_ACCESS_KEY={AWS_SECRET_ACCESS_KEY}")
        print(f"DEBUG: AWS_REGION={AWS_REGION}")
        print(f"DEBUG: BUCKET_NAME={BUCKET_NAME}")
        raise RuntimeError("S3 not configured. Please set AWS_* env vars.")
    
    safe_filename = secure_filename(filename)
    print(f"DEBUG: Safe filename: {safe_filename}")
    
    try:
        print(f"DEBUG: Attempting to upload to bucket: {BUCKET_NAME} in region: {AWS_REGION}")
        s3.upload_fileobj(file_obj, BUCKET_NAME, safe_filename)
        print("DEBUG: Upload successful")
    except Exception as e:
        print("ERROR: Upload failed!")
        print(f"Exception: {e}")
        raise e
    
    url = f"https://{BUCKET_NAME}.s3.{AWS_REGION}.amazonaws.com/{safe_filename}"
    print(f"DEBUG: File URL: {url}")
    return url


@products_bp.route("/product", methods=["POST"])
def add_product():
    if 'file' not in request.files:
        return jsonify({"error": "Image file is required"}), 400

    file_obj = request.files['file']
    form = request.form

    user_identifier = extract_user_identifier(form)
    if not user_identifier:
        return jsonify({"error": "user_id is required"}), 400

    user = get_user_from_identifier(user_identifier)
    if not user:
        return jsonify({"error": f"user_id {user_identifier} does not exist"}), 403

    try:
        image_url = upload_to_s3(file_obj, file_obj.filename)

        # Helper to parse discount
        discount_val = form.get("pricing_discounts[discount]")
        try:
            if discount_val:
                # If multiple discounts are sent as "50, 75", take the max one
                discounts = [float(d.strip()) for d in discount_val.split(",") if d.strip()]
                final_discount = max(discounts) if discounts else 0.0
            else:
                final_discount = 0.0
        except ValueError:
            final_discount = 0.0

        product = MyProducts(
            user_id=user.id,
            image_url=image_url,
            location=form.get("location") or None,
            tablet_name=form.get("basic_information[tablet_name]") or None,
            brand=form.get("basic_information[brand]") or None,
            quantity=int(form.get("basic_information[quantity]") or 0),
            unit_type=form.get("basic_information[unit_type]") or "Tablets",
            manufacturing_date=form.get("important_dates[manufacturing_date]") or None,
            best_before_date=form.get("important_dates[best_before_date]") or None,
            expiry_date=form.get("important_dates[expiry_date]") or None,
            usage_instructions=form.get("usage_information[usage_instructions]") or None,
            storage_instructions=form.get("usage_information[storage_instructions]") or None,
            original_price=float(form.get("pricing_discounts[original_price]") or 0.0),
            discount=final_discount,
            batch_number=form.get("additional_details[batch_number]") or None,
        )
        db.session.add(product)
        db.session.commit()
        return jsonify({"message": "Product added", "product": product.to_dict()}), 201

    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500




@products_bp.route("/<int:user_id>", methods=["GET"])
def get_products(user_id):
    """
    Get all products with user details, excluding those posted by the requesting user,
    and check if the requesting user has already made a purchase request for each product.
    """
    try:
        if not user_id:
            return jsonify({"status": "error", "message": "Missing user_id"}), 400

        # Fetch products excluding those posted by this user
        products = MyProducts.query.filter(MyProducts.user_id != user_id).all()
        result = []

        # Fetch all purchase requests by this user in ONE query
        user_requests = PurchaseRequest.query.filter_by(sender_id=user_id).all()
        requested_product_ids = {r.product_id for r in user_requests}

        for p in products:
            user = User.query.get(p.user_id)
            user_docs = user.documents if user else None

            if user:
                address_parts = [
                    user.address_line1,
                    user.address_line2,
                    user.address_line3,
                    user.shop_address,
                    user.city_name,
                    user.state,
                    user.pin_code
                ]
                full_address = ", ".join([part for part in address_parts if part])
            else:
                full_address = None

            has_requested = p.id in requested_product_ids

            product_data = {
                "product_id": p.id,
                "user_id": p.user_id,
                "tablet_name": p.tablet_name,
                "brand": p.brand,
                "quantity": p.quantity,
                "unit_type": p.unit_type,
                "location": p.location or (user_docs.location if user_docs else None),
                "image_url": p.image_url,
                "manufacturing_date": p.manufacturing_date.isoformat() if p.manufacturing_date else None,
                "best_before_date": p.best_before_date.isoformat() if p.best_before_date else None,
                "expiry_date": p.expiry_date.isoformat() if p.expiry_date else None,
                "usage_instructions": p.usage_instructions,
                "storage_instructions": p.storage_instructions,
                "original_price": p.original_price,
                "discount": p.discount,
                "batch_number": p.batch_number,
                "user": {
                    "user_id": user.id if user else None,
                    "user_name": user.user_name if user else None,
                    "mobile_number": user.mobile_number if user else None,
                    "email_address": user.email_address if user else None,
                    "pan_number": user.pan_number if user else None,
                    "gst_in_number": user.gst_in_number if user else None,
                    "shop_name": user.shop_name if user else None,
                    "shop_address": user.shop_address if user else None,
                    "address_line1": user.address_line1 if user else None,
                    "address_line2": user.address_line2 if user else None,
                    "address_line3": user.address_line3 if user else None,
                    "city_name": user.city_name if user else None,
                    "pin_code": user.pin_code if user else None,
                    "profile_pic_url": user_docs.live_image_pic_url if user_docs else None,
                    "full_address": full_address,
                    "location": user_docs.location if user_docs else None
                },
                "ad_suggestion": "Promote your product to reach more buyers and increase sales!",
                "has_requested": has_requested
            }

            result.append(product_data)

        return jsonify({"status": "success", "data": result}), 200

    except Exception as e:
        print(" ERROR in get_products:", e)
        return jsonify({"status": "error", "message": str(e)}), 500


@products_bp.route("/item/<int:product_id>", methods=["GET"])
def get_product(product_id):
    product = MyProducts.query.get(product_id)
    if not product:
        return jsonify({"error": "Not found"}), 404
    return jsonify(product.to_dict())


@products_bp.route("/location/<string:location>", methods=["GET"])
def get_products_by_location(location):
    products = MyProducts.query.filter_by(location=location).all()
    return jsonify([p.to_dict() for p in products]), 200


@products_bp.route("/user/<int:user_id>", methods=["GET"])
def get_products_by_user(user_id):
    """
    Get all products posted by a specific user.
    """
    try:
        # ✅ Fetch all products for this user_id
        products = MyProducts.query.filter_by(user_id=user_id).all()

        if not products:
            return jsonify({
                "status": "success",
                "message": "No products found for this user",
                "data": []
            }), 200

        return jsonify({
            "status": "success",
            "data": [p.to_dict() for p in products]
        }), 200

    except Exception as e:
        print(" ERROR in get_products_by_user:", e)
        return jsonify({"status": "error", "message": str(e)}), 500


# -------------------- UPDATE PRODUCT --------------------
@products_bp.route("/item/<int:product_id>", methods=["PUT"])
def update_product(product_id):
    """
    Update an existing product. Supports both JSON and multipart/form-data (for image updates).
    """
    try:
        if request.is_json:
            data = request.get_json()
        else:
            data = request.form.to_dict()

        user_identifier = extract_user_identifier(data)
        if not user_identifier:
            return jsonify({"error": "user_id is required"}), 400

        # Verify user exists
        user = get_user_from_identifier(user_identifier)
        if not user:
            return jsonify({"error": f"user_id {user_identifier} does not exist"}), 403

        # Get product and check ownership
        product = MyProducts.query.get(product_id)
        if not product:
            return jsonify({"error": "Product not found"}), 404
        
        if str(product.user_id) != str(user.id):
            return jsonify({"error": "Unauthorized: you can only update your own products"}), 403

        # Handle image update if a file is provided
        if 'file' in request.files:
            file_obj = request.files['file']
            image_url = upload_to_s3(file_obj, file_obj.filename)
            product.image_url = image_url

        # Mapping of nested form keys to model attributes
        field_map = {
            "basic_information[tablet_name]": "tablet_name",
            "basic_information[brand]": "brand",
            "basic_information[quantity]": "quantity",
            "basic_information[unit_type]": "unit_type",
            "important_dates[manufacturing_date]": "manufacturing_date",
            "important_dates[best_before_date]": "best_before_date",
            "important_dates[expiry_date]": "expiry_date",
            "usage_information[usage_instructions]": "usage_instructions",
            "usage_information[storage_instructions]": "storage_instructions",
            "pricing_discounts[original_price]": "original_price",
            "pricing_discounts[discount]": "discount",
            "additional_details[batch_number]": "batch_number",
            "location": "location"
        }

        # Update fields dynamically
        for key, value in data.items():
            if key in ["user_id", "distribution_id", "email_address", "mobile_number"]:
                continue
            
            # Use None for empty strings to avoid DB errors
            final_value = value if value != "" else None
            
            # If it's a flat attribute on the model
            if hasattr(product, key):
                setattr(product, key, final_value)
            # If it's a mapped nested key
            elif key in field_map:
                target_field = field_map[key]
                # Special handling for numeric fields
                if target_field in ["original_price", "discount", "quantity"]:
                    try:
                        final_value = float(final_value) if final_value is not None else 0.0
                    except:
                        final_value = 0.0
                setattr(product, target_field, final_value)

        db.session.commit()
        return jsonify({"message": "Product updated", "product": product.to_dict()}), 200

    except Exception as e:
        print(" ERROR in update_product:", e)
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


# -------------------- DELETE PRODUCT --------------------
@products_bp.route("/item/<int:product_id>", methods=["DELETE"])
def delete_product(product_id):
    try:
        # Try to get user_id from body, then from query params
        data = request.get_json(silent=True) or {}
        user_identifier = extract_user_identifier(data)
        
        if user_identifier is None:
            user_identifier = request.args.get("user_id") or request.args.get("distribution_id")

        if user_identifier is None:
            return jsonify({"error": "user_id is required (either in body or as query param)"}), 400

        # Verify user exists
        user = get_user_from_identifier(user_identifier)
        if not user:
            return jsonify({"error": f"user_id {user_identifier} does not exist"}), 403

        # Get product and check ownership
        product = MyProducts.query.get(product_id)
        if not product:
            return jsonify({"error": "Product not found"}), 404

        if product.user_id != user.id:
            return jsonify({"error": "Unauthorized: you can only delete your own products"}), 403

        db.session.delete(product)
        db.session.commit()
        return jsonify({"message": "Product deleted"}), 200

    except Exception as e:
        print("ERROR in delete_product:", e)
        db.session.rollback()
        return jsonify({"error": str(e)}), 500



@products_bp.route("/nearby-inventory/<int:user_id>", methods=["GET"])
def get_nearby_inventory(user_id):
    try:
        # Ensure user_id is integer
        try:
            user_id = int(user_id)
        except ValueError:
            return jsonify({"error": "user_id must be an integer"}), 400

        radius_km = float(request.args.get("radius", 50))  # default 50 km

        # 1️⃣ Fetch requesting user
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404

        # 2️⃣ Get user's document location
        if not user.documents or not user.documents.location:
            return jsonify({"error": "User location not set"}), 400

        # Assuming `location` is stored as "lat,lon"
        try:
            user_lat, user_lon = map(float, user.documents.location.split(","))
        except ValueError:
            return jsonify({"error": "Invalid user location format"}), 400

        # 3️⃣ Fetch all distributor products except those posted by this user
        products = MyProducts.query.filter(MyProducts.user_id != user_id).all()
        nearby_products = []

        for product in products:
            distributor = User.query.get(int(product.user_id))
            if not distributor or not distributor.documents or not distributor.documents.location:
                continue

            try:
                dist_lat, dist_lon = map(float, distributor.documents.location.split(","))
            except ValueError:
                continue

            # 4️⃣ Calculate distance
            dist = calculate_distance(user_lat, user_lon, dist_lat, dist_lon)
            if dist <= radius_km:
                prod_data = product.to_dict()  # ✅ full product details
                prod_data["distance_km"] = round(dist, 2)
                prod_data["distributor_location"] = distributor.documents.location
                prod_data["distributor_email"] = distributor.email_address
                prod_data["distributor_phone"] = distributor.mobile_number
                nearby_products.append(prod_data)

        # 5️⃣ Sort by nearest
        nearby_products = sorted(nearby_products, key=lambda x: x["distance_km"])

        return jsonify({
            "user_id": user_id,
            "radius_km": radius_km,
            "nearby_count": len(nearby_products),
            "nearby_products": nearby_products
        }), 200

    except Exception as e:
        print(" ERROR in get_nearby_inventory:", e)
        return jsonify({"error": str(e)}), 500
