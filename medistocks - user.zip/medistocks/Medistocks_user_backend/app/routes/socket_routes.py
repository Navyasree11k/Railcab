from flask_socketio import emit
from app.extension import socketio, db
from app.models.chat_model import Message
from flask import request
from app.utils.online_users import set_user_online, set_user_offline, get_online_user_sids, get_user_id_by_sid

# When user connects
@socketio.on('connect')
def handle_connect():
    user_id = request.args.get('user_id')
    if user_id:
        user_id = int(user_id)
        set_user_online(user_id, request.sid)
        print(f"User {user_id} connected with sid {request.sid}")

# When user disconnects
@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid
    user_id = get_user_id_by_sid(sid)
    if user_id:
        set_user_offline(user_id, sid)
        print(f"User {user_id} disconnected from sid {sid}")

# Handle sending a message
@socketio.on('send_message')
def handle_send_message(data):
    sender_id = data['sender_id']
    receiver_id = data['receiver_id']
    msg_text = data['message_text']

    # Save message to DB
    message = Message(sender_id=sender_id, receiver_id=receiver_id, message_text=msg_text)
    db.session.add(message)
    db.session.commit()

    # Payload to emit
    emit_payload = {
        'id': message.id,
        'sender_id': sender_id,
        'receiver_id': receiver_id,
        'message_text': msg_text,
        'timestamp': message.timestamp.isoformat()
    }

    # Emit to all SIDs of receiver
    receiver_sids = get_online_user_sids(receiver_id)
    for sid in receiver_sids:
        emit('receive_message', emit_payload, room=sid)

    # Emit to all SIDs of sender (confirm delivery)
    sender_sids = get_online_user_sids(sender_id)
    for sid in sender_sids:
        emit('receive_message', emit_payload, room=sid)

    print(f"Message from {sender_id} to {receiver_id} emitted to SIDs: {receiver_sids}")
