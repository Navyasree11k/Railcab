from flask import Blueprint, request, jsonify
from app.extension import db
from app.models.PaymentModel import InvoicePayment
from app.models.InvoiceGenerationModel import Invoice

payment_bp = Blueprint("payment", __name__)

# ----------------- Create Payment -----------------
@payment_bp.route("/", methods=['POST'])
def create_payment():
    data = request.json
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    try:
        invoice_id = data.get("invoice_id")
        if not invoice_id:
            return jsonify({'error': 'invoice_id is required'}), 400

        invoice = Invoice.query.get(invoice_id)
        if not invoice:
            return jsonify({'error': f'Invoice {invoice_id} not found'}), 404

        new_payment = InvoicePayment(
            invoice_id=invoice_id,
            user_id=data['user_id'],
            payment_type=data.get('payment_type'),
            payment_mode=data.get('payment_mode'),
            payment_status=data.get('payment_status'),
            total_amount=data.get('total_amount'),
            discount_amount=data.get('discount_amount'),
            gst=data.get('gst')
        )
        db.session.add(new_payment)
        db.session.commit()

        return jsonify({
            'message': 'Payment record created successfully',
            'payment': new_payment.to_dict()
        }), 201

    except KeyError as e:
        db.session.rollback()
        return jsonify({'error': f'Missing required field: {e}'}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ----------------- Get Payments -----------------
@payment_bp.route("/", methods=['GET'])
def get_payments():
    try:
        payments = InvoicePayment.query.all()
        result = [payment.to_dict() for payment in payments]
        return jsonify(result), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
