from flask import Blueprint, request, jsonify
from app.extension import db
from app.models.DistributorChatModel import DistributorChat

distributor_chat_bp = Blueprint("distributor_chat", __name__)

# ✅ POST - Add new chat message
@distributor_chat_bp.route("/chat", methods=["POST"])
def add_chat():
    data = request.json
    try:
        new_chat = DistributorChat(
            sender=data["sender"],
            receiver=data["receiver"],
            message=data["message"],
            delivered=data.get("delivered", True),
        )
        db.session.add(new_chat)
        db.session.commit()
        return jsonify({"message": "Message sent successfully!", "chat": new_chat.to_dict()}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to send message", "error": str(e)}), 500


# ✅ GET - Fetch messages where user is sender OR receiver
@distributor_chat_bp.route("/chat/<string:username>", methods=["GET"])
def get_chats(username):
    sent_messages = DistributorChat.query.filter_by(sender=username, delivered=True).all()
    received_messages = DistributorChat.query.filter_by(receiver=username, delivered=True).all()

    return jsonify({
        "sent": [msg.to_dict() for msg in sent_messages],
        "received": [msg.to_dict() for msg in received_messages],
    }), 200
