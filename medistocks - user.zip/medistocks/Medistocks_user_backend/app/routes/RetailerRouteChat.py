from flask import Blueprint, request, jsonify
from app.extension import db
from app.models.RetailerModelChat import RetailerChat

# ✅ Create Blueprint
retailer_chat_bp = Blueprint("retailer_chat", __name__)

# ---------------- ROUTES ----------------

# ✅ POST - Add new chat message
@retailer_chat_bp.route("/chats", methods=["POST"])
def add_chat():
    data = request.json
    try:
        new_chat = RetailerChat(
            sender=data["sender"],
            receiver=data["receiver"],
            message=data["message"],
            delivered=data.get("delivered", True)  # default True unless specified
        )
        db.session.add(new_chat)
        db.session.commit()
        return jsonify({"message": "Message sent successfully!", "chat": new_chat.to_dict()}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to send message", "error": str(e)}), 500


# ✅ GET - Fetch messages where user is sender OR receiver
@retailer_chat_bp.route("/chats/<string:username>", methods=["GET"])
def get_chats(username):
    sent_messages = RetailerChat.query.filter_by(sender=username, delivered=True).all()
    received_messages = RetailerChat.query.filter_by(receiver=username, delivered=True).all()

    return jsonify({
        "sent": [msg.to_dict() for msg in sent_messages],
        "received": [msg.to_dict() for msg in received_messages]
    }), 200
