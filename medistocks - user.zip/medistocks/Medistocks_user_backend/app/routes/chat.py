from flask import Blueprint, request, jsonify,current_app
from app.models.chat_model import Message, db
from app.models.registermodel import User
from sqlalchemy.orm import aliased

chat_bp = Blueprint('chat', __name__)

# Fetch messages for a user (sent or received)

@chat_bp.route('/messages/<int:user_id>', methods=['GET'])
def get_messages(user_id):
    try:
        Sender = aliased(User)
        Receiver = aliased(User)

        rows = (
            db.session.query(Message, Sender, Receiver)
            .join(Sender, Message.sender_id == Sender.id)
            .join(Receiver, Message.receiver_id == Receiver.id)
            .filter((Message.sender_id == user_id) | (Message.receiver_id == user_id))
            .order_by(Message.timestamp.asc())
            .all()
        )

        result = []
        for msg, sender, receiver in rows:
            result.append({
                'id': msg.id,
                'sender_id': msg.sender_id,
                'sender_name': sender.user_name,
                'sender_mobile': sender.mobile_number,
                'sender_email': sender.email_address,
                'sender_shop_name': getattr(sender, 'shop_name', None),
                'sender_image': getattr(sender, 'image', None),
                'sender_is_verified': getattr(sender, 'is_verified', None),

                'receiver_id': msg.receiver_id,
                'receiver_name': receiver.user_name,
                'receiver_mobile': receiver.mobile_number,
                'receiver_email': receiver.email_address,
                'receiver_shop_name': getattr(receiver, 'shop_name', None),
                'receiver_image': getattr(receiver, 'image', None),
                'receiver_is_verified': getattr(receiver, 'is_verified', None),

                'message_text': msg.message_text,
                'is_read': msg.is_read,
                'timestamp': msg.timestamp.isoformat()
            })

        return jsonify(result)
    except Exception as e:
        current_app.logger.exception("Error fetching messages")
        return jsonify({'error': 'Failed to fetch messages', 'detail': str(e)}), 500

# Send a message via REST API (also used for Socket fallback)
@chat_bp.route('/messages', methods=['POST'])
def send_message():
    data = request.get_json()
    message = Message(
        sender_id=data['sender_id'],
        receiver_id=data['receiver_id'],
        message_text=data['message_text']
    )
    db.session.add(message)
    db.session.commit()
    return jsonify({'message_id': message.id, 'status': 'sent'})
