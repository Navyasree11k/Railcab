from flask import Blueprint, request, jsonify
from app.extension import db
from app.models.InvoiceGenerationModel import Invoice

invoicegeneration_bp = Blueprint("invoicegeneration", __name__)

# -------------------------
# Create Invoice
# -------------------------
@invoicegeneration_bp.route("/", methods=["POST"])
def create_invoice():
    data = request.get_json()
    new_invoice = Invoice(
        user_id=data.get("user_id"),
        buyer_name=data.get("buyer_name"),
        product_name=data.get("product_name"),
        quantity=data.get("quantity"),
        total_amount=data.get("total_amount"),
        product_information=data.get("product_information"),
        buyer_verification=data.get("buyer_verification", False),
        user_otp=data.get("user_otp")
    )
    db.session.add(new_invoice)
    db.session.commit()
    return jsonify({"message": "Invoice created successfully", "invoice": new_invoice.to_dict()}), 201


# -------------------------
# Get All Invoices
# -------------------------
@invoicegeneration_bp.route("/", methods=["GET"])
def get_invoices():
    invoices = Invoice.query.all()
    return jsonify([invoice.to_dict() for invoice in invoices])


# -------------------------
# Get Invoice by ID
# -------------------------
@invoicegeneration_bp.route("/<int:id>", methods=["GET"])
def get_invoice(id):
    invoice = Invoice.query.get_or_404(id)
    return jsonify(invoice.to_dict())
