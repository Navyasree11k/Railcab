from flask import Blueprint, request, jsonify
from app.extension import db
from app.models.InvoiceModel import ProductInvoice
from app.models.registermodel import User
from datetime import datetime

invoice_bp = Blueprint("invoice", __name__)

# ---------------- Create invoice ----------------
@invoice_bp.route('/invoice', methods=['POST'])
def create_invoice():
    data = request.get_json()

    required_fields = ["sender_id", "receiver_id", "product_name", "quantity", "unit_price"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400

    sender = User.query.get(data["sender_id"])
    receiver = User.query.get(data["receiver_id"])

    if not sender:
        return jsonify({"error": f"Sender with id {data['sender_id']} does not exist"}), 404
    if not receiver:
        return jsonify({"error": f"Receiver with id {data['receiver_id']} does not exist"}), 404

    # Calculate sub_total, discount, tax, and total
    quantity = data["quantity"]
    unit_price = data["unit_price"]
    sub_total = quantity * unit_price
    tax_percentage = data.get("tax_percentage", 0.0)
    discount = data.get("discount", 0.0)
    total_amount = (sub_total - discount) + (sub_total * tax_percentage / 100)

    new_invoice = ProductInvoice(
        user_id=data["sender_id"],  # Set user_id same as sender_id
        sender_id=data["sender_id"],
        receiver_id=data["receiver_id"],
        product_name=data["product_name"],
        quantity=quantity,
        unit_price=unit_price,
        sub_total=sub_total,
        tax_percentage=tax_percentage,
        discount=discount,
        total_amount=total_amount,
        description=data.get("description", ""),
        sender_gst=sender.gst_in_number,
        sender_pan=sender.pan_number,
        sender_shop_name=sender.shop_name,
        sender_address=sender.shop_address,
        receiver_gst=receiver.gst_in_number,
        receiver_pan=receiver.pan_number,
        receiver_shop_name=receiver.shop_name,
        receiver_address=receiver.shop_address,
        product_id=data.get("product_id"),  # Optional: link to MyProducts if provided
        status="completed",
    )

    db.session.add(new_invoice)
    db.session.commit()

    return jsonify({
        "message": "Invoice created successfully",
        "invoice": new_invoice.to_dict()
    }), 201


# ---------------- Get all invoices ----------------
@invoice_bp.route('/invoice', methods=['GET'])
def get_invoices():
    invoices = ProductInvoice.query.all()
    return jsonify([invoice.to_dict() for invoice in invoices])

# ---------------- Get invoice by ID ----------------
@invoice_bp.route('/invoice/<int:id>', methods=['GET'])
def get_invoice(id):
    invoice = ProductInvoice.query.get_or_404(id)
    return jsonify(invoice.to_dict())

# ---------------- Get all invoices for a specific sender ----------------
@invoice_bp.route('/invoice/sender/<int:user_id>', methods=['GET'])
def get_invoices_by_sender(user_id):
    invoices = ProductInvoice.query.filter_by(user_id=user_id).all()
    return jsonify([invoice.to_dict() for invoice in invoices])

# ---------------- Get all invoices for a specific receiver ----------------
@invoice_bp.route('/invoice/receiver/<int:receiver_id>', methods=['GET'])
def get_invoices_by_receiver(receiver_id):
    invoices = ProductInvoice.query.filter_by(receiver_id=receiver_id).all()
    return jsonify([invoice.to_dict() for invoice in invoices])


# ---------------- Get invoice by product ID ----------------
@invoice_bp.route('/get-invoice/product', methods=['GET'])
def get_invoice_by_product_sender_receiver():
    """
    Query params expected:
    - product_id (required)
    - sender_id (optional)
    - receiver_id (optional)
    """

    # Get query params
    product_id = request.args.get("product_id", type=int)
    sender_id = request.args.get("sender_id", type=int)
    receiver_id = request.args.get("receiver_id", type=int)

    # Validation: product_id is required
    if not product_id:
        return jsonify({"error": "product_id query parameter is required"}), 400

    # Build base query
    query = ProductInvoice.query.filter_by(product_id=product_id)

    # Apply sender_id filter if provided
    if sender_id:
        query = query.filter_by(sender_id=sender_id)

    # Apply receiver_id filter if provided
    if receiver_id:
        query = query.filter_by(receiver_id=receiver_id)

    # Fetch all matching invoices
    invoices = query.all()

    if not invoices:
        return jsonify({"error": "No invoices found for the given criteria"}), 404

    return jsonify([invoice.to_dict() for invoice in invoices]), 200

