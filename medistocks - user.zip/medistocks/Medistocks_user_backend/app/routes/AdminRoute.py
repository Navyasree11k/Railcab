from flask import Blueprint, request, jsonify
from app.extension import db
from app.models.AdminModel import AdminChat
from app.utils.decorators import is_admin

# ✅ Create Blueprint
admin_bp = Blueprint("admin", __name__)

# ---------------- ROUTES ----------------

# ✅ POST - Add new chat message
@admin_bp.route("/chat", methods=["POST"])
@is_admin
def add_admin_chat():
    data = request.json
    try:
        new_chat = AdminChat(
            sender=data["sender"],
            receiver=data["receiver"],
            message=data["message"]
        )
        db.session.add(new_chat)
        db.session.commit()
        return jsonify({"message": "Message sent successfully!", "chat": new_chat.to_dict()}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to send message", "error": str(e)}), 500


# ✅ GET - Fetch messages for a user
@admin_bp.route("/chat/<string:username>", methods=["GET"])
@is_admin
def get_admin_chats(username):
    sent_messages = AdminChat.query.filter_by(sender=username, delivered=True).all()
    received_messages = AdminChat.query.filter_by(receiver=username, delivered=True).all()

    return jsonify({
        "sent": [msg.to_dict() for msg in sent_messages],
        "received": [msg.to_dict() for msg in received_messages]
    }), 200


# ✅ DELETE - Remove a chat message
@admin_bp.route("/chat/<int:chat_id>", methods=["DELETE"])
@is_admin
def delete_admin_chat(chat_id):
    try:
        chat = AdminChat.query.get(chat_id)
        if not chat:
            return jsonify({"message": f"Chat with id {chat_id} not found"}), 404

        db.session.delete(chat)
        db.session.commit()
        return jsonify({"message": f"Chat with id {chat_id} deleted successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to delete chat", "error": str(e)}), 500
