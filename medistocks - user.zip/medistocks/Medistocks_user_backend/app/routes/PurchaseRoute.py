from flask import Blueprint, request, jsonify
from app.extension import db, mail
from app.models.PurchaseModel import PurchaseRequest
from app.models.MyProductsModel import MyProducts
from app.models.registermodel import User
from app.models.NotificationModel import Notification
from flask_mail import Message
from datetime import datetime

purchase_bp = Blueprint("purchase", __name__)

# ---------------- Create Purchase Request ----------------
@purchase_bp.route("/send-purchase-request", methods=["POST"])
def create_request():
    data = request.get_json()

    # ✅ Only check mandatory fields
    required_fields = ["sender_id", "receiver_id", "product_id", "quantity", "unit_price"]
    missing_fields = [f for f in required_fields if f not in data]
    if missing_fields:
        print(f"Missing fields: {missing_fields}")
        return jsonify({"error": f"Missing required fields: {missing_fields}"}), 400

    # Fetch product
    product = MyProducts.query.get(data["product_id"])
    if not product:
        return jsonify({"error": "Invalid product_id"}), 400

    new_request = PurchaseRequest(
        sender_id=data["sender_id"],
        receiver_id=data["receiver_id"],
        product_id=product.id,
        quantity=int(data["quantity"]),
        unit_price=float(data["unit_price"]),
        description=data.get("description", ""),
        tablet_name=product.tablet_name  # store tablet_name for reference
    )

    db.session.add(new_request)
    db.session.commit()

    return jsonify({
        "message": "Purchase request created successfully",
        "request_id": new_request.id,
        "tablet_name": product.tablet_name
    }), 201
# ---------------- Distributor View ----------------
@purchase_bp.route("/user/<int:user_id>/sent-requests", methods=["GET"])
def get_sent_requests(user_id):
    try:
        # Fetch all purchase requests sent by this user
        sent_requests = PurchaseRequest.query.filter_by(sender_id=user_id).order_by(PurchaseRequest.created_at.desc()).all()

        if not sent_requests:
            return jsonify({"message": "No sent purchase requests found for this user"}), 404

        # Convert each request to dictionary
        return jsonify([req.to_dict() for req in sent_requests]), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500



# ---------------- Sender View ----------------
@purchase_bp.route("/receiver/<int:receiver_id>", methods=["GET"])
def get_requests_for_receiver(receiver_id):
    try:
        # Fetch all purchase requests for this receiver
        received_requests = (
            PurchaseRequest.query
            .filter_by(receiver_id=receiver_id)
            .order_by(PurchaseRequest.created_at.desc())
            .all()
        )

        if not received_requests:
            return jsonify({"message": "No received purchase requests found for this user"}), 404

        result = []

        for req in received_requests:
            # Sender details (Retailer)
            sender = User.query.get(req.sender_id)
            sender_data = {
                "id": sender.id,
                "user_name": sender.user_name,
                "shop_name": sender.shop_name,
                "gst_in_number": sender.gst_in_number,
                "pan_number": sender.pan_number,
                "shop_address": sender.shop_address,
                "shop_location": sender.shop_location,
                "email": sender.email_address,
                "mobile": sender.mobile_number,
                "city": sender.city_name,
                "state": sender.state,
                "pin_code": sender.pin_code,
            } if sender else None

            # Receiver details (Distributor)
            receiver = User.query.get(req.receiver_id)
            receiver_data = {
                "id": receiver.id,
                "user_name": receiver.user_name,
                "shop_name": receiver.shop_name,
                "gst_in_number": receiver.gst_in_number,
                "pan_number": receiver.pan_number,
                "shop_address": receiver.shop_address,
                "shop_location": receiver.shop_location,
                "email": receiver.email_address,
                "mobile": receiver.mobile_number,
                "city": receiver.city_name,
                "state": receiver.state,
                "pin_code": receiver.pin_code,
            } if receiver else None

            # Invoice-ready data
            req_data = req.to_dict()
            req_data["sender_details"] = sender_data
            req_data["receiver_details"] = receiver_data

            # Optionally calculate total
            req_data["sub_total"] = req.quantity * req.unit_price
            req_data["tax_percentage"] = getattr(req, "tax_percentage", 0.0)
            req_data["discount"] = getattr(req, "discount", 0.0)
            req_data["total_amount"] = (
                (req_data["sub_total"] - req_data["discount"])
                + (req_data["sub_total"] * req_data["tax_percentage"] / 100)
            )

            result.append(req_data)

        return jsonify(result), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ---------------- Approve / Reject Request ----------------
@purchase_bp.route("/<int:request_id>/action", methods=["PUT"])
def action_request(request_id):
    data = request.get_json()
    action = data.get("action")  # accepted | rejected
    if action not in ["accepted", "rejected"]:
        return jsonify({"error": "Invalid action"}), 400

    req = PurchaseRequest.query.get(request_id)
    if not req:
        return jsonify({"error": "Request not found"}), 404

    req.status = action
    db.session.commit()

    # Create an in-app notification for the sender
    notif = Notification(
        user_id=req.sender_id,
        title=f"Purchase Request {action.capitalize()}",
        message=f"Your purchase request for {req.tablet_name} (Qty: {req.quantity}) has been {action}.",
        status="pending",
        audience_type="user",
        target_user_id=req.sender_id,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow()
    )
    db.session.add(notif)
    db.session.commit()

    # Send email to sender if accepted
    if action == "accepted":
        sender = User.query.get(req.sender_id)
        if sender and sender.email_address:
            try:
                msg = Message(
                    subject="✅ Your purchase request has been accepted",
                    recipients=[sender.email_address],
                )
                msg.body = (
                    f"Hello,\n\n"
                    f"Your purchase request for {req.tablet_name} (Qty: {req.quantity}) "
                    f"has been accepted by the distributor.\n\n"
                    f"Thank you for using our platform!"
                )
                mail.send(msg)
            except Exception as e:
                print(f"Failed to send email: {e}")

    return jsonify({
        "message": f"Request {action} successfully",
        "status": req.status
    })
