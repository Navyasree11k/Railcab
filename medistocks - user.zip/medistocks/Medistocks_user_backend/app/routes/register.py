from datetime import datetime, timedelta
from flask import request, jsonify, Blueprint, current_app
import random
from flask_jwt_extended import create_access_token, jwt_required,get_jwt_identity, create_refresh_token
from sqlalchemy.exc import IntegrityError
from werkzeug.utils import secure_filename
import requests
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from app.utils.email_utils import generate_otp,send_otp_email


from app.extension import db, s3, BUCKET_NAME, AWS_REGION,AWS_ACCESS_KEY_ID,AWS_SECRET_ACCESS_KEY  # ✅ FIXED
from app.models.registermodel import User, PlanPurchasing, UserDocuments,LoginAudits
import sys
def safe_print(*args, **kwargs):
    """
    Prints arguments to stdout using backslashreplace for characters
    not supported by the current output encoding.
    """
    try:
        msg = " ".join(map(str, args))
        sys.stdout.buffer.write((msg + "\n").encode(sys.stdout.encoding or 'utf-8', errors='backslashreplace'))
        sys.stdout.buffer.flush()
    except Exception:
        print(*args, **kwargs)

auth_bp = Blueprint("auth", __name__)


# -------------------------------
# Helpers
# -------------------------------
def iso(dt):
    return dt.isoformat() if isinstance(dt, datetime) else dt


def upload_to_s3(file_obj, filename):
    print("DEBUG: Starting upload_to_s3 function")
    
    if s3 is None:
        print("ERROR: S3 client is not configured!")
        print(f"DEBUG: AWS_ACCESS_KEY_ID={AWS_ACCESS_KEY_ID}")
        print(f"DEBUG: AWS_SECRET_ACCESS_KEY={AWS_SECRET_ACCESS_KEY}")
        print(f"DEBUG: AWS_REGION={AWS_REGION}")
        print(f"DEBUG: BUCKET_NAME={BUCKET_NAME}")
        raise RuntimeError("S3 not configured. Please set AWS_* env vars.")
    
    safe_filename = secure_filename(filename)
    print(f"DEBUG: Safe filename: {safe_filename}")
    
    try:
        print(f"DEBUG: Attempting to upload to bucket: {BUCKET_NAME} in region: {AWS_REGION}")
        s3.upload_fileobj(file_obj, BUCKET_NAME, safe_filename)
        print("DEBUG: Upload successful")
    except Exception as e:
        print("ERROR: Upload failed!")
        print(f"Exception: {e}")
        raise e
    
    url = f"https://{BUCKET_NAME}.s3.{AWS_REGION}.amazonaws.com/{safe_filename}"
    print(f"DEBUG: File URL: {url}")
    return url


# -------------------------------
# Routes
# -------------------------------
SMS_API_KEY = "Hs6agMm5n0mEMQ6mpMdB1A"
SMS_SENDER_ID = "ADRLCB"
SMS_URL = "https://www.smsgatewayhub.com/api/mt/SendSMS"  # GET endpoint
Template_ID = "1007516966106905825"  # Replace with your actual template ID
Entity_ID = "1001955675134251297"  # Replace with your actual Entity ID


@auth_bp.route('/login/send_otp', methods=['POST'], endpoint='login_send_otp') 
def driver_send_otp():
    data = request.get_json()
    mobile = data.get('mobile_number')

    if not mobile:
        return jsonify({'message': 'Mobile number is required'}), 400

    # Find driver in DB
    user = User.query.filter_by(mobile_number=mobile).first()
    if not user:
        return jsonify({'message': 'Driver not registered, please sign up first'}), 404

    # Check if user uploaded documents
    docs = UserDocuments.query.filter_by(user_id=user.id).first()
    if not docs or not (docs.aadhar_card_front or docs.aadhar_card_back or docs.pancard_front or docs.pancard_back or docs.pharmacy_license):
        return jsonify({'message': 'Complete the registration by uploading your documents first.'}), 403

    # Check if user purchased a plan
    plan = PlanPurchasing.query.filter_by(user_id=user.id).first()
    if not plan:
        return jsonify({'message': 'Complete the registration by purchasing a plan first.'}), 403

    if user.is_verified != "approved":
        return jsonify({'message': 'Your documents are under verification, please wait.'}), 403

    # Generate random 4-digit OTP
    otp = str(random.randint(1000, 9999))
    print(f"\n{'='*20} MOBILE LOGIN OTP {'='*20}", flush=True)
    print(f"Mobile: {mobile}", flush=True)
    print(f"OTP: {otp}", flush=True)
    print(f"{'='*56}\n", flush=True)
    user.mobile_otp = otp
    db.session.commit()
    audit = LoginAudits(user_id=user.id, mobile_number=mobile, otp=otp)
    db.session.add(audit)
    db.session.commit()

    # Build OTP SMS message
    message_text = f"Thank you from RailCab, your OTP for registration is {otp}"  # OTP inserted here

    params = {
        "APIKey": SMS_API_KEY,
        "senderid": SMS_SENDER_ID,
        "channel": "2",
        "DCS": "0",
        "flashsms": "0",
        "number": mobile if mobile.startswith("91") else f"91{mobile}",
        "text": message_text,
        "route": "1",
        "EntityId": "1001955675134251297",
        "dlttemplateid": "1007516966106905825"
    }

    try:
        response = requests.get(SMS_URL, params=params)
        sms_response = response.json()
        safe_print("SMS API Response:", sms_response)

        if sms_response.get("ErrorCode") == "000":
            return jsonify({"message": "OTP sent successfully"}), 200
        else:
            return jsonify({
                "message": "Failed to send SMS",
                "error": sms_response.get("ErrorMessage"),
                "gateway_response": sms_response
            }), 400

    except Exception as e:
        print("ERROR in driver_send_otp:", e)
        return jsonify({'message': 'Error sending SMS', 'error': str(e)}), 500


@auth_bp.route('/login/verify_otp', methods=['POST'], endpoint='login_verify_otp')
def verify_otp():
    """
    Verifies OTP and returns JWT tokens.
    """
    data = request.get_json()
    mobile = data.get('mobile_number')
    otp = data.get('otp')

    if not mobile or not otp:
        return jsonify({'message': 'Mobile and OTP are required'}), 400

    user = User.query.filter_by(mobile_number=mobile).first()

    # Log OTP verification attempt in LoginAudits
    audit = LoginAudits(user_id=user.id if user else None, mobile_number=mobile, otp=otp)
    db.session.add(audit)
    db.session.commit()

    if not user:
        return jsonify({'message': 'User not found'}), 401

    # Master OTP for testing purposes
    is_master_otp = (otp in ['1234', '123456'] and mobile in ['1234567890', '9876543210'])

    if user.mobile_otp != otp and not is_master_otp:
        return jsonify({'message': 'Incorrect OTP'}), 401

    # Clear OTP after use
    user.mobile_otp = None
    db.session.commit()

    # Create JWT tokens
    access_token = create_access_token(identity=user.id, expires_delta=timedelta(minutes=15))
    refresh_token = create_refresh_token(identity=user.id)

    return jsonify({
        'message': 'OTP verified!',
        'access_token': access_token,
        'refresh_token': refresh_token,
        "user_id": user.id,
        "role": user.role
    }), 200


@auth_bp.route('/login/send_email_otp', methods=['POST'], endpoint='login_send_email_otp')
def send_email_otp():
    data = request.get_json()
    email = data.get('email_address')

    if not email:
        return jsonify({'message': 'Email address is required'}), 400

    # Find user by email
    user = User.query.filter_by(email_address=email).first()
    if not user:
        return jsonify({'message': 'User not registered, please sign up first'}), 404

    if user.is_verified != "approved":
        return jsonify({'message': 'Your documents are under verification, please wait.'}), 403

    # Generate OTP
    otp = generate_otp(length=6)  # 6-digit OTP
    print(f"\n{'='*20} EMAIL LOGIN OTP {'='*20}", flush=True)
    print(f"Email: {email}", flush=True)
    print(f"OTP: {otp}", flush=True)
    print(f"{'='*55}\n", flush=True)
    email_sent = send_otp_email(email, otp)

    if not email_sent:
        return jsonify({'message': 'Failed to send OTP via email'}), 500

    # Store OTP in user table
    user.email_otp = otp
    db.session.commit()

    # Audit log
    audit = LoginAudits(user_id=user.id, email_address=email, otp=otp)
    db.session.add(audit)
    db.session.commit()

    return jsonify({'message': 'OTP sent successfully to your email'}), 200


# -----------------------------
# Verify Email OTP
# -----------------------------
@auth_bp.route('/login/verify_email_otp', methods=['POST'], endpoint='login_verify_email_otp')
def verify_email_otp():
    data = request.get_json()
    email = data.get('email_address')
    otp = data.get('otp')

    if not email or not otp:
        return jsonify({'message': 'Email and OTP are required'}), 400

    user = User.query.filter_by(email_address=email).first()

    if not user:
        return jsonify({'message': 'User not found'}), 401

    # Master OTP for testing purposes
    is_master_otp = (otp == '123456' and email in ['test@medistocks.com', 'test1@gmail.com'])

    if user.email_otp != otp and not is_master_otp:
        return jsonify({'message': 'Incorrect OTP'}), 401

    # Clear OTP after verification
    user.email_otp = None
    db.session.commit()

    # Log OTP verification attempt
    audit = LoginAudits(user_id=user.id, email_address=email, otp=otp)
    db.session.add(audit)
    db.session.commit()

    # Generate JWT tokens
    access_token = create_access_token(identity=user.id, expires_delta=timedelta(minutes=15))
    refresh_token = create_refresh_token(identity=user.id)

    return jsonify({
        'message': 'OTP verified!',
        'access_token': access_token,
        'refresh_token': refresh_token,
        "user_id": user.id,
        "role": user.role
    }), 200

@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    """
    Generate new access token using refresh token.
    """
    user_id = get_jwt_identity()
    access_token = create_access_token(identity=user_id, expires_delta=timedelta(minutes=15))
    return jsonify({'access_token': access_token}), 200




@auth_bp.route('/register/send_otp', methods=['POST'], endpoint='login_register_send_otp') 
def driver_register_send_otp():
    data = request.get_json()
    mobile = data.get('mobile_number')

    if not mobile:
        return jsonify({'message': 'Mobile number is required'}), 400

    # Check if driver already exists
    driver = User.query.filter_by(mobile_number=mobile).first()

    if driver:
        # Check if user uploaded documents
        docs = UserDocuments.query.filter_by(user_id=driver.id).first()
        has_docs = docs and (docs.aadhar_card_front or docs.aadhar_card_back or docs.pancard_front or docs.pancard_back or docs.pharmacy_license)
        # Check if user purchased a plan
        plan = PlanPurchasing.query.filter_by(user_id=driver.id).first()
        if has_docs and plan:
            return jsonify({'message': 'User already registered, please login'}), 409
        else:
            return jsonify({'message': 'User already exists but registration incomplete. Please upload documents and purchase a plan.'}), 403

    # Driver not found → create new record with mobile and OTP
    otp = str(random.randint(1000, 9999))
    print(f"\n{'='*20} MOBILE REGISTRATION OTP {'='*20}", flush=True)
    print(f"Mobile: {mobile}", flush=True)
    print(f"OTP: {otp}", flush=True)
    print(f"{'='*63}\n", flush=True)
    new_driver = User(
        mobile_number=mobile,
        mobile_otp=otp,
    )
    db.session.add(new_driver)
    db.session.commit()

    # Build OTP SMS message
    message_text = f"Thank you from RailCab, your OTP for registration is {otp}"

    # Send OTP via SMS
    params = {
        "APIKey": SMS_API_KEY,
        "senderid": SMS_SENDER_ID,
        "channel": "2",
        "DCS": "0",
        "flashsms": "0",
        "number": mobile if mobile.startswith("91") else f"91{mobile}",
        "text": message_text,
        "route": "1",
        "EntityId": "1001955675134251297",
        "dlttemplateid": "1007516966106905825"
    }

    try:
        response = requests.get(SMS_URL, params=params)
        sms_response = response.json()
        safe_print("SMS API Response:", sms_response)

        if sms_response.get("ErrorCode") == "000":
            return jsonify({"message": "OTP sent successfully"}), 200
        else:
            return jsonify({
                "message": "Failed to send SMS",
                "error": sms_response.get("ErrorMessage"),
                "gateway_response": sms_response
            }), 400

    except Exception as e:
        print("ERROR in driver_send_otp:", e)
        return jsonify({'message': 'Error sending SMS', 'error': str(e)}), 500


@auth_bp.route('/register/verify_otp', methods=['POST'], endpoint='register_verify_otp')
def driver_verify_otp():
    """
    Verifies OTP and returns JWT tokens for registration.
    """
    data = request.get_json()
    mobile = data.get('mobile_number')
    otp = data.get('mobile_otp')

    if not mobile or not otp:
        return jsonify({'message': 'Mobile and OTP are required'}), 400

    user = User.query.filter_by(mobile_number=mobile).first()

    if not user or user.mobile_otp != otp:
        return jsonify({'message': 'Incorrect OTP'}), 401

    db.session.commit()

    # Create JWT tokens
    access_token = create_access_token(identity=user.id, expires_delta=timedelta(minutes=15))
    refresh_token = create_refresh_token(identity=user.id)

    return jsonify({
        'message': 'OTP verified successfully!',
        'access_token': access_token,
        'refresh_token': refresh_token,
        "user_id": user.id,
    }), 200


@auth_bp.route("/send_email", methods=["POST"])
def send_email():
    data = request.get_json(silent=True) or {}
    email_address = data.get("email_address")

    if not email_address:
        return jsonify({"error": "email_address is required"}), 400

    existing = User.query.filter_by(email_address=email_address).first()
    if existing:
        return jsonify({"error": "Email already registered"}), 409

    user = User.query.filter(User.email_address.is_(None)).order_by(User.id.desc()).first()
    if not user:
        return jsonify({"error": "No user found"}), 404

    otp = generate_otp()
    print(f"\n{'='*20} EMAIL REGISTRATION OTP {'='*20}", flush=True)
    print(f"Email: {email_address}", flush=True)
    print(f"OTP: {otp}", flush=True)
    print(f"{'='*62}\n", flush=True)
    email_sent = send_otp_email(email_address, otp)
    if not email_sent:
        return jsonify({"error": "Failed to send email"}), 500

    user.email_address = email_address
    user.email_otp = otp
    db.session.commit()

    return jsonify({"message": f"OTP sent successfully to {email_address}"}), 200

@auth_bp.route("/verify_email", methods=["POST"])
def verify_email():
    data = request.get_json(silent=True) or {}
    email_address = data.get("email_address")
    otp = data.get("otp")

    if not email_address or not otp:
        return jsonify({"error": "email_address and otp are required"}), 400

    user = User.query.filter_by(email_address=email_address).first()
    if not user or user.email_otp != otp:
        return jsonify({"error": "Invalid email or OTP"}), 400

    return jsonify({"message": "Email verified successfully"}), 200




@auth_bp.route('/update-user-details', methods=['POST'])
def update_user_details():
    try:
        data = request.get_json()

        user_id = data.get("user_id")
        if not user_id:
            return jsonify({"status": "error", "message": "user_id is required"}), 400

        user = User.query.get(user_id)
        if not user:
            return jsonify({"status": "error", "message": "User not found"}), 404

        # Update fields if provided
        user.user_name = data.get("user_name", user.user_name)
        user.shop_name = data.get("shop_name", user.shop_name)
        user.shop_address = data.get("shop_address", user.shop_address)
        user.gst_in_number = data.get("gst_in_number", user.gst_in_number)
        user.pan_number = data.get("pan_number", user.pan_number)
        user.city_name = data.get("city_name", user.city_name)
        user.pin_code = data.get("pin_code", user.pin_code)

        # New fields
        user.date_of_birth = data.get("date_of_birth", user.date_of_birth)
        user.address_line1 = data.get("address_line1", user.address_line1)
        user.address_line2 = data.get("address_line2", user.address_line2)
        user.address_line3 = data.get("address_line3", user.address_line3)
        user.shop_location = data.get("shop_location", user.shop_location)
        user.gender = data.get("gender", user.gender)
        user.state = data.get("state", user.state)

        user.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({
            "status": "success",
            "message": "User details updated successfully",
            "user": {
                "id": user.id,
                "user_name": user.user_name,
                "shop_name": user.shop_name,
                "shop_address": user.shop_address,
                "gst_in_number": user.gst_in_number,
                "pan_number": user.pan_number,
                "city_name": user.city_name,
                "pin_code": user.pin_code,
                "date_of_birth": str(user.date_of_birth) if user.date_of_birth else None,
                "address_line1": user.address_line1,
                "address_line2": user.address_line2,
                "address_line3": user.address_line3,
                "shop_location": user.shop_location,
                "gender": user.gender,
                "state": user.state
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": str(e)}), 500


@auth_bp.route("/purchase_plan", methods=["POST"])
def purchase_plan():
        data = request.get_json(silent=True) or {}
        required = [
            "user_id", "selected_role", "selected_plan", "plan_benefits",
            "payment_mode", "payment_type", "payment_status",
            "payment_id", "payment_summary"
        ]
        missing = [f for f in required if not data.get(f)]
        if missing:
            return jsonify({"error": f"Missing: {', '.join(missing)}"}), 400

        import json
        if isinstance(data.get("plan_benefits"), (list, dict)):
            data["plan_benefits"] = json.dumps(data["plan_benefits"])
        if isinstance(data.get("payment_summary"), (list, dict)):
            data["payment_summary"] = json.dumps(data["payment_summary"])
        plan = PlanPurchasing(**data)
        try:
            db.session.add(plan)
            # Update user role
            user = User.query.get(data["user_id"])
            if user:
                user.role = data["selected_role"]
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            return jsonify({"error": "payment_id must be unique"}), 409

        return jsonify({"message": "Plan purchased", "plan_id": plan.id})


@auth_bp.route("/upload_documents", methods=["POST"])
def upload_documents():
    try:
        user_id = request.form.get("user_id")
        if not user_id:
            return jsonify({"error": "user_id required"}), 400

        docs = UserDocuments.query.filter_by(user_id=user_id).first()
        if not docs:
            docs = UserDocuments(user_id=user_id)
            db.session.add(docs)

        if "aadhar_card_front" in request.files:
            docs.aadhar_card_front = upload_to_s3(request.files["aadhar_card_front"], f"{user_id}_aadhar_front.png")

        if "aadhar_card_back" in request.files:
            docs.aadhar_card_back = upload_to_s3(request.files["aadhar_card_back"], f"{user_id}_aadhar_back.png")

        if "pancard_front" in request.files:
            docs.pancard_front = upload_to_s3(request.files["pancard_front"], f"{user_id}_pancard_front.png")

        if "pancard_back" in request.files:
            docs.pancard_back = upload_to_s3(request.files["pancard_back"], f"{user_id}_pancard_back.png")

        if "pharmacy_license" in request.files:
            docs.pharmacy_license = upload_to_s3(request.files["pharmacy_license"], f"{user_id}_pharmacy_license.png")

        db.session.commit()
        return jsonify({"message": "Documents uploaded"}), 200
    except Exception as e:
        print("ERROR in upload_documents:", e)
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@auth_bp.route("/upload_documents/<int:user_id>", methods=["GET"])
def get_documents(user_id):
        docs = UserDocuments.query.filter_by(user_id=user_id).first()
        if not docs:
            return jsonify({"error": "No documents found"}), 404

        return jsonify({
            "user_id": user_id,
            "documents": {
                "aadhar_card_front": docs.aadhar_card_front,
                "aadhar_card_back": docs.aadhar_card_back,
                "pancard_front": docs.pancard_front,
                "pancard_back": docs.pancard_back,
                "pharmacy_license": docs.pharmacy_license,
            },
            "live_verification": docs.live_image_pic_url,
            "timestamp": iso(docs.timestamp),
            "location": docs.location,
        }) 
@auth_bp.route("/profile/<int:user_id>", methods=["GET"])
def get_profile(user_id):
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404

        return jsonify({
            "id": user.id,
            "mobile_number": user.mobile_number,
            "email_address": user.email_address,
            "role": user.role,
            "image": user.image,
            "created_at": iso(user.created_at),
        })

@auth_bp.route("/profile/<int:user_id>", methods=["POST"])
def update_profile(user_id):
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404

        if "image" in request.files:
            user.image = upload_to_s3(request.files["image"], f"{user_id}_profile.png")

        db.session.commit()
        return jsonify({"message": "Profile updated", "user": {"id": user.id, "image": user.image}})

@auth_bp.route("/live_verification", methods=["PUT"])
def live_verification():
    user_id = request.form.get("user_id")
    location = request.form.get("location")
    live_image = request.files.get("live_image")

    if not user_id or not live_image:
        return jsonify({"error": "user_id and live_image are required"}), 400

    docs = UserDocuments.query.filter_by(user_id=user_id).first()
    if not docs:
        return jsonify({"error": "UserDocuments not found for user_id"}), 405

    # Upload image to S3 and get URL
    filename = f"{user_id}_live_image.png"
    image_url = upload_to_s3(live_image, filename)
    docs.live_image_pic_url = image_url
    docs.timestamp = datetime.utcnow()
    docs.location = location
    db.session.commit()

    return jsonify({
        "message": "Live image uploaded and info updated",
        "live_image_pic_url": docs.live_image_pic_url,
        "timestamp": iso(docs.timestamp),
        "location": docs.location,
    })


@auth_bp.route("/forgot_password/send_email_otp", methods=["POST"])
def forgot_password_send_email_otp():
    data = request.get_json()
    email = data.get("email_address")

    if not email:
        return jsonify({"message": "Email address is required"}), 400

    user = User.query.filter_by(email_address=email).first()
    if not user:
        return jsonify({"message": "No user found with this email"}), 404

    # Generate 6-digit OTP
    otp = generate_otp(length=6)
    print(f"\n{'='*20} FORGOT PASSWORD OTP {'='*20}", flush=True)
    print(f"Email: {email}", flush=True)
    print(f"OTP: {otp}", flush=True)
    print(f"{'='*59}\n", flush=True)
    user.email_otp = otp
    db.session.commit()

    # Send OTP via email
    email_sent = send_otp_email(email, otp)
    if not email_sent:
        return jsonify({"message": "Failed to send OTP"}), 500

    # Log OTP in audits
    audit = LoginAudits(user_id=user.id, email_address=email, otp=otp)
    db.session.add(audit)
    db.session.commit()

    return jsonify({"message": "OTP sent successfully to your email"}), 200


# -----------------------------
# 2️⃣ Verify OTP for Forgot Password
# -----------------------------
@auth_bp.route("/forgot_password/verify_email_otp", methods=["POST"])
def forgot_password_verify_email_otp():
    data = request.get_json()
    email = data.get("email_address")
    otp = data.get("otp")

    if not email or not otp:
        return jsonify({"message": "Email and OTP are required"}), 400

    user = User.query.filter_by(email_address=email).first()
    if not user or user.email_otp != otp:
        return jsonify({"message": "Invalid email or OTP"}), 401

    # OTP verified, clear it
    user.email_otp = None
    db.session.commit()

    # Optionally, generate a temporary token for password reset
    reset_token = create_access_token(identity=user.id, expires_delta=timedelta(minutes=15))

    return jsonify({
        "message": "OTP verified! You can now reset your password.",
        "reset_token": reset_token
    }), 200


# -----------------------------
# 3️⃣ Reset Password
# -----------------------------
@auth_bp.route("/forgot_password/reset", methods=["POST"])
def forgot_password_reset():
    data = request.get_json()
    new_password = data.get("new_password")
    reset_token = data.get("reset_token")

    if not new_password or not reset_token:
        return jsonify({"message": "New password and reset token are required"}), 400

    # Decode the reset_token to get user_id
    try:
        from flask_jwt_extended import decode_token
        decoded = decode_token(reset_token)
        user_id = decoded.get("sub")
    except Exception as e:
        return jsonify({"message": "Invalid or expired reset token", "error": str(e)}), 401

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    # Hash and update password
    user.password = generate_password_hash(new_password)
    db.session.commit()

    return jsonify({"message": "Password reset successfully"}), 200


@auth_bp.route("/get-user/<int:user_id>", methods=["GET"])
def get_user(user_id):
    """
    Get all profile details for a user including documents and profile pic.
    """
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({"status": "error", "message": "User not found"}), 404

        # Prepare response data
        data = {
            "user_id": user.id,
            "user_name": user.user_name,
            "mobile_number": user.mobile_number,
            "email_address": user.email_address,
            "role": user.role,
            "shop_name": user.shop_name,
            "shop_address": user.shop_address,
            "gst_in_number": user.gst_in_number,
            "pan_number": user.pan_number,
            "city_name": user.city_name,
            "pin_code": user.pin_code,
            "is_verified": user.is_verified,
            "created_at": user.created_at.isoformat() if user.created_at else None,
            "updated_at": user.updated_at.isoformat() if user.updated_at else None,
            "profile_pic_url": user.documents.live_image_pic_url if user.documents else None,
            "documents": {
                "aadhar_card_front": user.documents.aadhar_card_front if user.documents else None,
                "aadhar_card_back": user.documents.aadhar_card_back if user.documents else None,
                "pancard_front": user.documents.pancard_front if user.documents else None,
                "pancard_back": user.documents.pancard_back if user.documents else None,
                "pharmacy_license": user.documents.pharmacy_license if user.documents else None,
                "timestamp": user.documents.timestamp.isoformat() if user.documents and user.documents.timestamp else None,
                "location": user.documents.location if user.documents else None
            }
        }

        return jsonify({"status": "success", "data": data}), 200

    except Exception as e:
        print("ERROR in get_user:", e)
        return jsonify({"status": "error", "message": str(e)}), 500

@auth_bp.route("/update_contact/send_otp", methods=["POST"])
def send_update_contact_otp():
    """
    Send OTP for updating phone or email using user_id.
    """
    data = request.get_json()
    user_id = data.get("user_id")
    new_mobile = data.get("mobile_number")
    new_email = data.get("email_address")

    if not user_id:
        return jsonify({"message": "user_id is required"}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    otp = str(random.randint(1000, 9999))

    # ✅ Case 1: Update mobile
    if new_mobile:
        existing = User.query.filter_by(mobile_number=new_mobile).first()
        if existing:
            return jsonify({"message": "Mobile number already registered"}), 409

        user.mobile_otp = otp
        db.session.commit()

        message_text = f"Thank you from RailCab, your OTP for registration is {otp}"

        params = {
            "APIKey": SMS_API_KEY,
            "senderid": SMS_SENDER_ID,
            "channel": "2",
            "DCS": "0",
            "flashsms": "0",
            "number": new_mobile if new_mobile.startswith("91") else f"91{new_mobile}",
            "text": message_text,
            "route": "1",
            "EntityId": Entity_ID,
            "dlttemplateid": Template_ID
        }

        try:
            response = requests.get(SMS_URL, params=params)
            sms_response = response.json()
            safe_print("SMS API Response:", sms_response)

            if sms_response.get("ErrorCode") == "000":
                return jsonify({"message": "OTP sent successfully to mobile"}), 200
            else:
                return jsonify({"message": "Failed to send SMS", "response": sms_response}), 400

        except Exception as e:
            return jsonify({"message": "Error sending SMS", "error": str(e)}), 500

    # ✅ Case 2: Update email
    elif new_email:
        existing_email = User.query.filter_by(email_address=new_email).first()
        if existing_email:
            return jsonify({"message": "Email address already registered"}), 409

        user.email_otp = otp
        db.session.commit()

        # In production, use an email-sending service like SendGrid, SES, etc.
        print(f"📧 Simulated OTP sent to {new_email}: {otp}")

        return jsonify({"message": f"OTP sent to {new_email}"}), 200

    else:
        return jsonify({"message": "Provide either mobile_number or email_address"}), 400
    


@auth_bp.route("/update_contact/verify_otp", methods=["POST"])
def verify_update_contact_otp():
    """
    Verify OTP and update phone/email in user record.
    """
    data = request.get_json()
    user_id = data.get("user_id")
    otp = data.get("otp")
    new_mobile = data.get("mobile_number")
    new_email = data.get("email_address")

    if not user_id or not otp:
        return jsonify({"message": "user_id and otp are required"}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    # ✅ Verify for mobile
    if new_mobile:
        if user.mobile_otp != otp:
            return jsonify({"message": "Invalid OTP for mobile"}), 400

        user.mobile_number = new_mobile
        user.mobile_otp = None
        user.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({"message": "Mobile number updated successfully"}), 200

    # ✅ Verify for email
    elif new_email:
        if user.email_otp != otp:
            return jsonify({"message": "Invalid OTP for email"}), 400

        user.email_address = new_email
        user.email_otp = None
        user.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({"message": "Email address updated successfully"}), 200

    else:
        return jsonify({"message": "Provide mobile_number or email_address"}), 400


ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@auth_bp.route("/update-user/<int:user_id>", methods=["PUT"])
def update_user(user_id):
    """
    Updates user_name and profile picture (uploads to S3 and stores URL)
    """
    try:
            user = User.query.get(user_id)
            if not user:
                return jsonify({"status": "error", "message": "User not found"}), 404

            # Allow form-data for file uploads
            user_name = request.form.get("user_name")
            profile_pic = request.files.get("profile_pic")

            # Update name if provided
            if user_name:
                user.user_name = user_name

            # Update profile picture if provided
            if profile_pic and allowed_file(profile_pic.filename):
                filename = secure_filename(f"user_{user_id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{profile_pic.filename}")
                print(f"DEBUG: Uploading file to S3: {filename}")
                s3_url = upload_to_s3(profile_pic, filename)
                print(f"DEBUG: Uploaded S3 URL: {s3_url}")

                # Update both User.image and UserDocuments.live_image_pic_url for consistency
                user.image = s3_url
                if user.documents:
                    user.documents.live_image_pic_url = s3_url
                else:
                    from app.models.registermodel import UserDocuments
                    new_doc = UserDocuments(user_id=user.id, live_image_pic_url=s3_url)
                    db.session.add(new_doc)

            db.session.commit()

            return jsonify({
                "status": "success",
                "message": "Profile updated successfully",
                "data": {
                    "user_id": user.id,
                    "user_name": user.user_name,
                    "profile_pic_url": user.documents.live_image_pic_url if user.documents else None
                }
            }), 200

    except Exception as e:
        db.session.rollback()
        print("ERROR in update_profile:", e)
        return jsonify({"status": "error", "message": str(e)}), 500