import json

from flask import Blueprint, jsonify, request

from app.models.cart_models import Cart
from app.models.registermodel import User
from app import db
cart_bp = Blueprint("cart", __name__)


def extract_user_identifier(payload):
    if payload is None:
        return None

    if isinstance(payload, dict):
        for key in ("user_id", "distribution_id", "email_address", "mobile_number"):
            value = payload.get(key)
            if value not in (None, ""):
                return value

    return payload


def get_user_from_identifier(user_identifier):
    if user_identifier is None:
        return None

    if isinstance(user_identifier, dict):
        user_identifier = extract_user_identifier(user_identifier)

    value = str(user_identifier).strip()
    if not value:
        return None

    if value.startswith("{") and value.endswith("}"):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            parsed = None
        if isinstance(parsed, dict):
            return get_user_from_identifier(parsed)

    numeric_value = None
    if value.isdigit():
        numeric_value = int(value)
    else:
        try:
            float_value = float(value)
        except ValueError:
            float_value = None
        if float_value is not None and float_value.is_integer():
            numeric_value = int(float_value)

    if numeric_value is not None:
        return db.session.get(User, numeric_value)

    if "@" in value:
        return User.query.filter_by(email_address=value).first()

    return User.query.filter_by(mobile_number=value).first()

@cart_bp.route("/add-to-cart", methods=["POST"])
def add_to_cart():
    data = request.get_json()
    required_fields = ["user_id", "product_id", "tablet_name", "image_url", "amount", "quantity", "seller_id"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": f"Missing fields {data}"}), 400

    user = get_user_from_identifier(data.get("user_id"))
    if not user:
        return jsonify({"error": f"user_id {data.get('user_id')} does not exist"}), 403

    # Check if product already in cart for the user
    existing = Cart.query.filter_by(user_id=user.id, product_id=data["product_id"]).first()
    if existing:
        existing.quantity += int(data["quantity"])
        db.session.commit()
        return jsonify({"message": "Cart updated", "cart_id": existing.id}), 200

    new_item = Cart(
        user_id=user.id,
        seller_id=data["seller_id"],
        product_id=data["product_id"],
        tablet_name=data["tablet_name"],
        image_url=data["image_url"],
        amount=float(data["amount"]),
        quantity=int(data["quantity"])
    )
    db.session.add(new_item)
    db.session.commit()
    return jsonify({"message": "Added to cart", "cart_id": new_item.id}), 201


@cart_bp.route("/my-cart/<user_identifier>", methods=["GET"])
def get_cart(user_identifier):
    user = get_user_from_identifier(user_identifier)
    if not user:
        return jsonify({"error": f"user_id {user_identifier} does not exist"}), 404

    items = Cart.query.filter_by(user_id=user.id).all()
    result = [item.to_dict() for item in items]
    return jsonify({"status": "success", "data": result}), 200

@cart_bp.route("/delete/<int:cart_id>", methods=["DELETE"])
def delete_cart_item(cart_id):
    item = Cart.query.get(cart_id)
    if not item:
        return jsonify({"error": "Cart item not found"}), 404

    db.session.delete(item)
    db.session.commit()
    return jsonify({"message": "Cart item deleted successfully"}), 200
