from flask import Blueprint, request, jsonify
from datetime import datetime
from functools import wraps
from app import db
from app.models.TermsModel import Terms

# Blueprint with prefix "/terms"
terms_bp = Blueprint("terms", __name__, url_prefix="/terms")

from app.utils.decorators import is_admin

# ------------------- ROUTES -------------------

# Get latest terms
@terms_bp.route("/", methods=["GET"])
def get_terms():
    latest = Terms.query.order_by(Terms.updated_at.desc()).first()
    if not latest:
        return jsonify({"message": "No terms found"}), 404
    return jsonify(latest.to_dict()), 200

# Create or update terms (Admin only)
@terms_bp.route("/", methods=["POST"])
@is_admin
def update_terms():
    data = request.get_json()
    if not data or "content" not in data:
        return jsonify({"error": "Content is required"}), 400

    version = str(datetime.utcnow().timestamp())
    new_terms = Terms(version=version, content=data["content"])
    db.session.add(new_terms)
    db.session.commit()
    return jsonify(new_terms.to_dict()), 201
