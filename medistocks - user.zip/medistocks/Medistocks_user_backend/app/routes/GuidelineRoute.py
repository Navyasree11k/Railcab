from flask import Blueprint, request, jsonify
from datetime import datetime
from functools import wraps
from app import db
from app.models.GuidelineModel import Guideline

# Create Blueprint with prefix "/guidelines"
guidelines_bp = Blueprint("guidelines", __name__)

from app.utils.decorators import is_admin


# ------------------- ROUTES -------------------

# Get the latest guidelines
@guidelines_bp.route("/latest", methods=["GET"])
def get_guidelines():
    latest = Guideline.query.order_by(Guideline.updated_at.desc()).first()
    if not latest:
        return jsonify({"message": "No guidelines found"}), 404
    return jsonify(latest.to_dict()), 200


# Create or update guidelines (Admin only)
@guidelines_bp.route("/create", methods=["POST"])
@is_admin
def update_guidelines():
    data = request.get_json()
    if not data or "content" not in data:
        return jsonify({"error": "Content is required"}), 400

    version = str(datetime.utcnow().timestamp())
    new_guideline = Guideline(version=version, content=data["content"])
    db.session.add(new_guideline)
    db.session.commit()
    return jsonify(new_guideline.to_dict()), 201
