from flask import Blueprint, request, jsonify
from datetime import datetime
from functools import wraps
from app import db
from app.models.NotificationModel import Notification
from app.models.registermodel import User


# Blueprint with prefix "/notifications"
notifications_bp = Blueprint("notifications", __name__)

from app.utils.decorators import is_admin

# ------------------- ROUTES -------------------

# Create a new notification
@notifications_bp.route("/create", methods=["POST"])
@is_admin
def create_notification():
    data = request.get_json()
    if not data or "message" not in data:
        return jsonify({"error": "Message is required"}), 400

    title = data.get("title")
    message = data["message"]
    audience_type = data.get("audience_type", "all")
    role = data.get("role")
    target_user_id = data.get("target_user_id")

    scheduled_at_str = data.get("scheduled_at")
    scheduled_at = None
    if scheduled_at_str:
        try:
            scheduled_at = datetime.fromisoformat(scheduled_at_str)
        except Exception:
            scheduled_at = None

    created_notifications = []

    if audience_type == "all":
        users = User.query.all()
    elif audience_type == "role":
        if not role:
            return jsonify({"error": "Role is required when audience_type = 'role'"}), 400
        users = User.query.filter_by(role=role).all()
    elif audience_type == "user":
        if not target_user_id:
            return jsonify({"error": "target_user_id is required when audience_type = 'user'"}), 400
        user = User.query.get(target_user_id)
        if not user:
            return jsonify({"error": f"User with ID {target_user_id} not found"}), 404
        users = [user]
    else:
        return jsonify({"error": "Invalid audience_type. Must be 'all', 'role', or 'user'."}), 400

    for u in users:
        notif = Notification(
            user_id=u.id,
            title=title,
            message=message,
            status="pending",
            audience_type=audience_type,
            target_user_id=target_user_id if audience_type == "user" else None,
            scheduled_at=scheduled_at,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        db.session.add(notif)
        created_notifications.append(notif)

    db.session.commit()

    return jsonify({
        "message": f"{len(created_notifications)} notifications created successfully.",
        "count": len(created_notifications),
        "id": created_notifications[0].id if created_notifications else None,
        "notifications": [n.to_dict() for n in created_notifications]
    }), 201

# Get all notifications (optionally filter by status)
@notifications_bp.route("/list", methods=["GET"])
def get_notifications():
    status = request.args.get("status")
    role_filter = request.args.get("role")  # ✅ Get role from query params

    query = Notification.query

    # Filter by status if provided
    if status:
        query = query.filter_by(status=status)

    # Filter by user role if provided
    if role_filter:
        query = query.join(User).filter(User.role == role_filter)

    notifications = query.all()

    # Include user role in the response
    return jsonify([n.to_dict() for n in notifications]), 200

# Approve or reject a notification (Admin only)
@notifications_bp.route("/approve/<int:id>", methods=["PATCH"])
@is_admin
def approve_notification(id):
    data = request.get_json()
    status = data.get("status")
    if status not in ["approved", "rejected"]:
        return jsonify({"error": "Invalid status"}), 400

    notif = Notification.query.get(id)
    if not notif:
        return jsonify({"error": "Notification not found"}), 404

    notif.status = status
    notif.updated_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"id": notif.id, "status": notif.status}), 200
# Fetch all users for dropdown
@notifications_bp.route("/users", methods=["GET"])
def get_users():
    users = User.query.all()
    return jsonify([
        {
            "id": u.id,
            "role": u.role
        } for u in users
    ])
@notifications_bp.route("/delete/<int:id>", methods=["DELETE"])
@is_admin
def delete_notification(id):
    notif = Notification.query.get(id)
    if not notif:
        return jsonify({"error": "Notification not found"}), 404
    db.session.delete(notif)
    db.session.commit()
    return jsonify({"message": f"Notification ID {id} deleted successfully."}), 200