from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
from app.extension import db
from app.models.VideoModel import Video
import boto3
from botocore.exceptions import NoCredentialsError
import os

from app.utils.decorators import is_admin

videos_bp = Blueprint("videos", __name__)


# ✅ S3 CONFIG (you can move these to .env and load with python-dotenv)
S3_BUCKET = os.getenv("AWS_BUCKET_NAME")
S3_REGION = os.getenv("AWS_REGION")
S3_ACCESS_KEY = os.getenv("AWS_ACCESS_KEY_ID")
S3_SECRET_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")

# ✅ Allowed extensions
ALLOWED_IMAGE_EXTS = {"jpg", "jpeg", "png", "gif"}
ALLOWED_VIDEO_EXTS = {"mp4", "mov", "avi", "mkv"}


def allowed_file(filename, allowed_exts):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in allowed_exts


def upload_fileobj_to_s3(file_obj, filename, content_type):
    try:
        s3 = boto3.client(
            "s3",
            region_name=S3_REGION,
            aws_access_key_id=S3_ACCESS_KEY,
            aws_secret_access_key=S3_SECRET_KEY,
        )

        s3.upload_fileobj(
    file_obj,
    S3_BUCKET,
    filename,
    ExtraArgs={"ContentType": content_type}  # remove "ACL": "public-read"
)


        return f"https://{S3_BUCKET}.s3.{S3_REGION}.amazonaws.com/{filename}"

    except NoCredentialsError:
        raise Exception("AWS credentials not found")
    except Exception as e:
        raise Exception(f"S3 upload failed: {str(e)}")




# ------------------ GET ALL VIDEOS ------------------
@videos_bp.route("/videos", methods=["GET"])
def get_videos():
    videos = Video.query.all()
    return jsonify([v.to_dict() for v in videos]), 200

# ------------------ ADD NEW VIDEO ------------------
@videos_bp.route("/videos", methods=["POST"])
@is_admin
def add_video():
    title = request.form.get("title")
    subtitle = request.form.get("subtitle")
    description = request.form.get("description")
    image_file = request.files.get("image")
    video_file = request.files.get("video")

    if not title or not image_file or not video_file:
        return jsonify({"error": "Title, image, and video are required"}), 400

    if not allowed_file(image_file.filename, ALLOWED_IMAGE_EXTS):
        return jsonify({"error": "Invalid image format"}), 400
    if not allowed_file(video_file.filename, ALLOWED_VIDEO_EXTS):
        return jsonify({"error": "Invalid video format"}), 400

    # Upload files to S3
    image_url = upload_fileobj_to_s3(image_file, secure_filename(image_file.filename), image_file.content_type)
    video_url = upload_fileobj_to_s3(video_file, secure_filename(video_file.filename), video_file.content_type)

    new_video = Video(title=title, subtitle=subtitle, description=description, image_url=image_url, video_url=video_url)
    db.session.add(new_video)
    db.session.commit()
    return jsonify(new_video.to_dict()), 201

# ------------------ EDIT VIDEO ------------------
@videos_bp.route("/videos/<int:video_id>", methods=["PUT"])
@is_admin
def edit_video(video_id):
    video = Video.query.get(video_id)
    if not video:
        return jsonify({"error": "Video not found"}), 404

    title = request.form.get("title", video.title)
    subtitle = request.form.get("subtitle", video.subtitle)
    description = request.form.get("description", video.description)
    image_file = request.files.get("image")
    video_file = request.files.get("video")

    video.title = title
    video.subtitle = subtitle
    video.description = description

    # Optional new files
    if image_file and allowed_file(image_file.filename, ALLOWED_IMAGE_EXTS):
        video.image_url = upload_fileobj_to_s3(image_file, secure_filename(image_file.filename), image_file.content_type)
    if video_file and allowed_file(video_file.filename, ALLOWED_VIDEO_EXTS):
        video.video_url = upload_fileobj_to_s3(video_file, secure_filename(video_file.filename), video_file.content_type)

    db.session.commit()
    return jsonify(video.to_dict()), 200

# ------------------ DELETE VIDEO ------------------
@videos_bp.route("/videos/<int:video_id>", methods=["DELETE"])
@is_admin
def delete_video(video_id):
    video = Video.query.get(video_id)
    if not video:
        return jsonify({"error": "Video not found"}), 404

    db.session.delete(video)
    db.session.commit()
    return jsonify({"message": "Video deleted successfully"}), 200