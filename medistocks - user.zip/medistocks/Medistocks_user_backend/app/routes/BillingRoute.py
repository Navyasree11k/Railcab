from flask import Blueprint, request, jsonify
from app.models.BillingModel import BillingRecord
from app.extension import db, s3, BUCKET_NAME, AWS_REGION, mail
from app.models.registermodel import User
from sqlalchemy.exc import SQLAlchemyError
from werkzeug.utils import secure_filename
from flask_mail import Message
from datetime import datetime, timedelta

billing_bp = Blueprint("billing", __name__)

# ---------- Upload to S3 ---------- #
def upload_to_s3(file_obj, filename):
    safe_filename = secure_filename(filename)
    s3.upload_fileobj(file_obj, BUCKET_NAME, safe_filename)
    return f"https://{BUCKET_NAME}.s3.{AWS_REGION}.amazonaws.com/{safe_filename}"

# ---------- Send Expiry Notification Email ---------- #
def send_expiry_notification(user_email, product):
    try:
        msg = Message(
            subject=f"⚠️ Product Expiry Alert: {product.tablet_name}",
            recipients=[user_email],
        )
        msg.body = (
            f"Hello,\n\n"
            f"The following product in your inventory is nearing its expiry date:\n\n"
            f"Product ID: {product.id}\n"
            f"Tablet Name: {product.tablet_name}\n"
            f"Quantity: {product.quantity}\n"
            f"Expiry Date: {product.expiry_date.strftime('%Y-%m-%d')}\n\n"
            f"Click below to quickly list it for sale before it expires:\n"
            f"https://yourplatform.com/sell/{product.id}\n\n"
            f"Regards,\nYour Inventory Management Team"
        )
        mail.send(msg)
        print(f"✅ Email sent successfully to {user_email}")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")

# ---------- Add Inventory Record ---------- #
@billing_bp.route('/myinventory', methods=['POST'])
def add_inventory_record():
    try:
        # ✅ Ensure file exists
        if 'file' not in request.files:
            return jsonify({"error": "Product image file is required"}), 400

        file_obj = request.files['file']
        form = request.form

        # ✅ Validate user
        user_id = form.get("user_id")
        if not user_id:
            return jsonify({"error": "user_id is required"}), 400

        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": f"user_id {user_id} not found"}), 403

        # ✅ Upload image to S3
        image_url = upload_to_s3(file_obj, file_obj.filename)

        # ✅ Safely extract and cast fields
        tablet_name = form.get("tablet_name") or "Unnamed Product"
        quantity = int(form.get("quantity") or 0)
        unit_cost = float(form.get("unit_cost") or 0.0)
        discount_percentage = float(form.get("discount_percentage") or 0.0)
        expiry_date_str = form.get("expiry_date")
        expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d") if expiry_date_str else None
        brand = form.get("brand")
        location = form.get("location")
        batch_number = form.get("batch_number")

        # ✅ Create record
        record = BillingRecord(
            user_id=user.id,
            tablet_name=tablet_name,
            quantity=quantity,
            unit_cost=unit_cost,
            discount_percentage=discount_percentage,
            expiry_date=expiry_date,
            image_url=image_url,
            location=location,
            batch_number=batch_number,
            brand=brand
        )

        # ✅ Calculate totals & save
        record.calculate_totals()
        db.session.add(record)
        db.session.commit()

        # ✅ Trigger expiry alert if ≤ 30 days left
        if expiry_date:
            days_left = (expiry_date - datetime.utcnow()).days
            if days_left <= 30:
                send_expiry_notification(user.email_address, record)

        return jsonify({
            "message": "Inventory item added successfully",
            "inventory": record.to_dict()
        }), 201

    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# ---------- UPDATE RECORD ---------- #

@billing_bp.route('/myinventory/<int:record_id>', methods=['PUT'])
def update_record(record_id):
    try:
        record = BillingRecord.query.get(record_id)
        if not record:
            return jsonify({"error": "Record not found"}), 404

        # Check if form-data (for file upload) or JSON
        if 'file' in request.files or request.form:
            # Form-data (possibly with file)
            form = request.form
            file_obj = request.files.get('file')
            
            if file_obj:
                # Upload new image to S3
                safe_filename = secure_filename(file_obj.filename)
                s3.upload_fileobj(file_obj, BUCKET_NAME, safe_filename)
                record.image_url = f"https://{BUCKET_NAME}.s3.{AWS_REGION}.amazonaws.com/{safe_filename}"

            record.tablet_name = form.get('tablet_name', record.tablet_name)
            record.quantity = int(form.get('quantity') or record.quantity or 0)
            record.unit_cost = float(form.get('unit_cost') or record.unit_cost or 0.0)
            record.discount_percentage = float(form.get('discount_percentage') or record.discount_percentage or 0.0)
            
            expiry_date_str = form.get('expiry_date')
            record.expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d") if expiry_date_str else record.expiry_date

            record.location = form.get('location', record.location)
            record.batch_number = form.get('batch_number', record.batch_number)

        else:
            # JSON payload
            data = request.get_json()
            record.tablet_name = data.get('tablet_name', record.tablet_name)
            record.quantity = int(data.get('quantity') or record.quantity or 0)
            record.unit_cost = float(data.get('unit_cost') or record.unit_cost or 0.0)
            record.discount_percentage = float(data.get('discount_percentage') or record.discount_percentage or 0.0)
            
            expiry_date_str = data.get('expiry_date')
            record.expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d") if expiry_date_str else record.expiry_date

            record.location = data.get('location', record.location)
            record.batch_number = data.get('batch_number', record.batch_number)
            record.image_url = data.get('image_url', record.image_url)

        # Recalculate totals
        record.calculate_totals()
        # Update status based on expiry
        record.update_status()

        db.session.commit()

        return jsonify({
            "message": "Record updated successfully",
            "inventory": record.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    
# ---------- READ ALL RECORDS ---------- #
@billing_bp.route('/myinventory', methods=['GET'])
def get_all_records():
    try:
        records = BillingRecord.query.order_by(BillingRecord.created_at.desc()).all()
        result = []

        for record in records:
            # Auto-update expiry status before returning
            record.update_status()
            result.append(record.to_dict())

        db.session.commit()  # Save any status updates
        return jsonify(result), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


# ---------- READ SINGLE RECORD ---------- #
@billing_bp.route('/myinventory/<int:record_id>', methods=['GET'])
def get_record(record_id):
    try:
        record = BillingRecord.query.get(record_id)
        if not record:
            return jsonify({"error": "Record not found"}), 404

        record.update_status()
        db.session.commit()

        return jsonify(record.to_dict()), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@billing_bp.route('/get-user-billing-records/<int:user_id>', methods=['GET'])
def get_user_billing_records(user_id):
    try:
        # Fetch records for this user, latest first
        records = (
            BillingRecord.query.filter_by(user_id=user_id)
            .order_by(BillingRecord.created_at.desc())
            .all()
        )

        # Handle case where no records exist
        if not records:
            return jsonify({"message": "No billing records found for this user"}), 200

        # Update expiry status and return all details
        result = []
        for record in records:
            record.update_status()  # auto update expiry status
            result.append(record.to_dict())

        db.session.commit()  # commit any status updates

        return jsonify({
            "user_id": user_id,
            "total_records": len(result),
            "records": result
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


# ---------- DELETE RECORD ---------- #
@billing_bp.route('/myinventory/<int:record_id>', methods=['DELETE'])
def delete_record(record_id):
    try:
        record = BillingRecord.query.get(record_id)
        if not record:
            return jsonify({"error": "Record not found"}), 404

        db.session.delete(record)
        db.session.commit()

        return jsonify({"message": f"Record ID {record_id} deleted successfully"}), 200

    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
