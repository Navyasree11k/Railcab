# app/config.py
import os
class Config:
    # Flask Mail
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'mahesh.gudivada54@gmail.com'  # Fetch from environment
    MAIL_PASSWORD = 'erlx sqsw yrlg qrnu'# Fetch from environment
    MAIL_DEFAULT_SENDER = 'mahesh.gudivada54@gmail.com'

    # Add your database config here if needed
    